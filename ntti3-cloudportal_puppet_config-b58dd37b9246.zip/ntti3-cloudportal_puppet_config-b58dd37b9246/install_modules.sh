# External modules used by the NTT Clouds Portal Puppet configuration
puppet module install --force ajjahn/dns
puppet module install --force gdsoperations/resolvconf
puppet module install --force puppetlabs/ntp
puppet module install --force puppetlabs/mysql
puppet module install --force puppetlabs-firewall
puppet module install --force puppetlabs-stdlib
