# --- !Ups

alter table play_evolutions modify apply_script longtext;
alter table play_evolutions modify revert_script longtext;

# --- !Downs

alter table play_evolutions modify apply_script text;
alter table play_evolutions modify revert_script text;