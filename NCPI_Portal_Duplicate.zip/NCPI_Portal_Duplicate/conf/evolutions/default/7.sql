# --- !Ups

alter table product_content add launch_url varchar(255);

update product_content set launch_url = 'https://m2cloud.nttclouds.co/m2cloud/' where name = 'M2Cloud';
update product_content set launch_url = 'https://ama.nttclouds.co/' where name = 'AMA';
update product_content set launch_url = 'https://devopsplus.nttclouds.co/' where name = 'DevOps';

# --- !Downs

alter table product_content drop launch_url;