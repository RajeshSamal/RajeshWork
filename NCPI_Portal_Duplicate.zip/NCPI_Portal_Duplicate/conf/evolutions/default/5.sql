# --- !Ups

alter table question drop foreign key fk_question_product_3;
drop table question;


# --- !Downs

create table question (
   id                        bigint auto_increment not null,
   question                  varchar(255),
   product_id                bigint,
   constraint pk_question primary key (id))
 ;

 alter table question add constraint fk_question_product_3 foreign key (product_id) references product_content (id) on delete restrict on update restrict;
 create index ix_question_product_3 on question (product_id);
