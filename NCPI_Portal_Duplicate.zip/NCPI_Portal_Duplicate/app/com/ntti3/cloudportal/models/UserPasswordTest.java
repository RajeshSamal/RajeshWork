package com.ntti3.cloudportal.models;

import org.junit.Test;
import play.data.validation.ValidationError;

import java.util.List;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class UserPasswordTest {

    @Test
    public void tooShortPassword() {
        expectMessageForPassword(UserPassword.PASSWORD_TOO_SHORT, "6chaRs");
    }


    @Test
    public void noCapitalLetterPassword() {
        expectMessageForPassword(UserPassword.PASSWORD_CAPITAL, "13characters");
    }

    @Test
    public void noDigitPassword() {
        expectMessageForPassword(UserPassword.PASSWORD_DIGIT, "NoDigitAbcdef");
    }

    @Test
    public void passwordOk() {
        final String password = "2OkonOkon";
        UserPassword userPassword = createPasswordCandidate(password);
        assertNull(userPassword.validate());
    }

    public void expectMessageForPassword(String message, String password) {
        UserPassword userPassword = createPasswordCandidate(password);
        AssertErrorListContainsMessage(userPassword.validate(), message);
    }


    private UserPassword createPasswordCandidate(String newPassword) {
        UserPassword userPassword = new UserPassword();
        userPassword.setPassword("oldpassword");
        userPassword.setNewPassword(newPassword);
        userPassword.setRepeatNewPassword(newPassword);
        return userPassword;
    }


    private boolean ErrorListContainsMessage(List<ValidationError> errors, String message) {
        if (errors == null) {
            return false;
        }

        for (ValidationError error : errors) {
            if (message == error.message()) { // both nulls or the same string
                return true;
            }

            if (message != null && message.equals(error.message())) {
                return true;
            }
        }
        return false;
    }

    private void AssertErrorListContainsMessage(List<ValidationError> errors,String message) {
        assertTrue("Error list does not contain message '" + message + "'", ErrorListContainsMessage(errors, message));
    }

}