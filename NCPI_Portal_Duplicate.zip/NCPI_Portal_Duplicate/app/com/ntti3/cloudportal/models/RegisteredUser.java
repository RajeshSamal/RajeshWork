package com.ntti3.cloudportal.models;

import play.data.validation.Constraints.Email;
import play.data.validation.Constraints.MaxLength;
import play.data.validation.Constraints.MinLength;
import play.data.validation.Constraints.Pattern;
import play.data.validation.Constraints.Required;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jan.karwowski@ntti3.com
 */
public class RegisteredUser {
    //Matches ANY STRING containing at least 1 digit, 1 uppercase, 1 lowercase and at least 8 characters long
    public static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,})";
    //optional pattern - does not accept special characters "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\\W)(?!.*[_]).{8,})"
	public static final String PASSWORD_FIELD = "password";
    public static final String PASSWORD_REPEAT_FIELD = "repeatPassword";
	@Required
	private String firstName;
	@Required
	private String lastName;
	@Required
	@Email(message = "UserRegister.validation.email_invalid")
	private String email;
    @Required
    private String company;
	@Required
    @Pattern(value = PASSWORD_PATTERN, message = "UserRegister.validation.password_invalid")
	private String password;
	@Required
    @Pattern(value = PASSWORD_PATTERN, message = "UserRegister.validation.password_invalid")
	private String repeatPassword;
	@Required
	private String securityQuestion;
	@Required
    @MinLength(value = 4, message = "UserRegister.validation.answer_invalid")
	private String securityAnswer;
    @MaxLength(value = 255, message = "UserRegister.validation.info_invalid")
	private String additionalInfo;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepeatPassword() {
		return repeatPassword;
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

	public List<ValidationError> validate() {
		final List<ValidationError> validationErrors = new ArrayList<>();
		if (!password.equals(repeatPassword)) {
			validationErrors.add(new ValidationError(PASSWORD_FIELD,
                    "UserRegister.validation.password_not_match"));
            validationErrors.add(new ValidationError(PASSWORD_REPEAT_FIELD,
                    "UserRegister.validation.password_not_match"));
		}
		return validationErrors.isEmpty() ? null : validationErrors;
	}

}
