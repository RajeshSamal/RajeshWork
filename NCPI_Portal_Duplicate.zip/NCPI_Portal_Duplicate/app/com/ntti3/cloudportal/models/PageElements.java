package com.ntti3.cloudportal.models;

import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.ProductContent;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-09.
 */
public interface PageElements {
    public List<? extends ProductContent> getProducts();

    public List<MenuItem> getFooter();

    public String getHeaderContent();
}
