package com.ntti3.cloudportal.models;

import com.ntti3.cms.Cms;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.ProductContent;
import com.ntti3.cms.models.WebPageContent;
import com.ntti3.cms.models.util.BaseContentWeightComparator;

import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-12.
 */
public class DefaultPageElements implements PageElements {
    private final Cms cms;

    public DefaultPageElements(Cms cms) {
        this.cms = cms;
    }

    @Override
    public List<? extends ProductContent> getProducts() {
        List<? extends ProductContent> result = cms.getProducts();
        Collections.sort(result, new BaseContentWeightComparator());
        return result;
    }

    @Override
    public List<MenuItem> getFooter() {
        return cms.getMenu("Footer");
    }

    @Override
    public String getHeaderContent() {
        WebPageContent page = cms.getPage("/");
        if(page!=null) {
            return page.getHtmlContent();
        }
        return "";
    }
}
