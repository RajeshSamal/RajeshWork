package com.ntti3.cloudportal.lib.contactFormMailer;

import javax.mail.MessagingException;
import java.util.List;

/**
 * Class for sending e-mails from the contact form.
 * 
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface ContactFormMailer {

	/**
	 * Sends an e-mail based on the data from the contact form.
	 * 
	 * @param contactEmail
	 *            An e-mail of the user that filled the contact form.
	 * @param firstName
	 *            User's first name.
	 * @param lastName
	 *            User's last name.
	 * @param company
	 *            User's company name.
     * @param message
     *            The content of the contact form's message.
     * @param products
     *            The list of demos requested.
	 * @throws MessagingException
	 */
	void sendMail(String contactEmail, String firstName, String lastName, String company,
                  String message, List<String> products) throws MessagingException;
}
