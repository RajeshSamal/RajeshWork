package com.ntti3.cloudportal.controllers;

import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.cloudportal.lib.contactFormMailer.ContactFormMailer;
import com.ntti3.cloudportal.models.ContactForm;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import com.ntti3.play.frontend.JsonResponseBuilder;
import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;

import javax.mail.MessagingException;
import java.util.ArrayList;

@ExceptionHandler
public class ContactFormHandler extends Controller {
	private final ContactFormMailer contactFormMailer;

	@Inject
	public ContactFormHandler(ContactFormMailer contactFormMailer) {
		Preconditions.checkNotNull(contactFormMailer);
		this.contactFormMailer = contactFormMailer;
	}

	public Result index() throws MessagingException {

		Form<ContactForm> contactForm = Form.form(ContactForm.class)
				.bindFromRequest();

		if (contactForm.hasErrors()) {
			return badRequest(JsonResponseBuilder.invalidFields(contactForm
					.errorsAsJson()));
		}

		ContactForm contact = contactForm.get();
		contactFormMailer.sendMail(contact.getEmail(), contact.getFirstName(),
				contact.getLastName(), contact.getCompany(), contact.getMessage(),
                Optional.fromNullable(contact.getProducts()).or(new ArrayList<String>()));
		return ok(JsonResponseBuilder.prepareMessage(Messages
				.getString("ContactFormHandler.successMsg"),
				Messages
				.getString("ContactFormHandler.responseMsg")));
	}
}
