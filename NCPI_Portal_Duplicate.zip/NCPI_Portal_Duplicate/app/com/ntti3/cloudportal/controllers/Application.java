package com.ntti3.cloudportal.controllers;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.cloudportal.controllers.annotations.AfpUrlSelector;
import com.ntti3.cloudportal.controllers.annotations.OpcoSelector;
import com.ntti3.cloudportal.models.DefaultPageElements;
import com.ntti3.cms.Cms;
import com.ntti3.cms.exceptions.NotFoundException;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.ProductContent;
import com.ntti3.cms.models.WebPageContent;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.urlhelper.UrlHelper;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import views.html.main;
import views.html.upgrade;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.List;

public class Application extends Controller {

    private final Cms cms;
    private final VhostInstanceSelector<String> afpUrlSelector;
    private final DefaultPageElements defaultPageElements;
    private final VhostInstanceSelector<UrlHelper> urlHelperSelector;
    private final VhostInstanceSelector<String> opcoSelector;

    @Inject
    public Application(Cms cms,
                       @AfpUrlSelector VhostInstanceSelector<String> afpUrlSelector,
                       VhostInstanceSelector<UrlHelper> urlHelperSelector,
                       @OpcoSelector VhostInstanceSelector<String> opcoSelector) {
        this.opcoSelector = opcoSelector;
        this.urlHelperSelector = Preconditions.checkNotNull(urlHelperSelector, "URL helper can not be null");
        this.cms = Preconditions.checkNotNull(cms, "Cms instance can not be null");
        this.afpUrlSelector = Preconditions.checkNotNull(afpUrlSelector,
                "AFP URL selector can not be null");
        this.defaultPageElements = new DefaultPageElements(cms);
    }

    public Result upgrade() {
		return ok(upgrade.render());
	}

	public Result index() throws UnknownVhostException, MalformedURLException {
		return getResult();
	}

    private Result getResult() throws UnknownVhostException, MalformedURLException {
        return ok(main.render(defaultPageElements,
                afpUrlSelector.getInstanceForVhost(request()),
                urlHelperSelector.getInstanceForVhost(request()).absoluteAddress(""),
                opcoSelector.getInstanceForVhost(request())));
    }

    public Result wildcard(String action, Boolean json) throws UnknownVhostException, MalformedURLException {
        if(!json) {
            return getResult();
        }
        WebPageContent page;
        try {
            page = cms.getPage(java.net.URLDecoder.decode(action,"UTF-8"));
        } catch(NotFoundException e) {
            return notFound(e.getMessage());
        } catch (UnsupportedEncodingException e) {
            return internalServerError(e.getMessage());
        }
        ObjectNode pageNode = Json.newObject();
        pageNode.put("title", page.getTitle());
        pageNode.put("content", page.getHtmlContent());
        pageNode.put("isMenu", page.isMenu());
        ArrayNode menu = pageNode.putArray("menu");
        for(MenuItem url : page.getMenuUrls()) {
            menu.add(Json.toJson(url));
        }
        ObjectNode result = Json.newObject();
        result.put("data", pageNode);
        return ok(result);
    }

    public Result getProducts() {
        ObjectNode result = Json.newObject();
        ObjectNode p = Json.newObject();
        List<? extends ProductContent> products = cms.getProducts();
        for (ProductContent product : products) {
            ObjectNode tmp = Json.newObject();
            tmp.put("title", product.getTitle());
            p.put(product.getName(),tmp);
        }
        result.put("products",p);
        return ok(result);
    }
}
