package com.ntti3.cloudportal.controllers;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.play.build.BuildInfoReader;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import play.mvc.Result;

import static play.mvc.Results.ok;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@ExceptionHandler
public class BuildInfoController {

	private BuildInfoReader buildInfoReader;

	@Inject
	public BuildInfoController(BuildInfoReader buildInfoReader) {
		Preconditions.checkNotNull(buildInfoReader);
		this.buildInfoReader = buildInfoReader;
	}

	public Result index() {
		return ok(buildInfoReader.getHumanReadable());
	}
}