package com.ntti3.cloudportal.controllers;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.cloudportal.controllers.annotations.OpcoSelector;
import com.ntti3.cloudportal.models.RegisteredUser;
import com.ntti3.cloudportal.models.UserInfo;
import com.ntti3.cloudportal.models.UserPassword;
import com.ntti3.cloudportal.models.UserQuestion;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.models.RequestedPendingUser;
import com.ntti3.gums.models.User;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import com.ntti3.play.frontend.JsonResponseBuilder;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.spsso.session.UserSessionManager;
import com.ntti3.spsso.session.annotations.UserAuthorized;
import play.Logger;
import play.data.Form;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.UUID;

@ExceptionHandler
public class UserHandler extends Controller {

	private final GumsConnector gumsConnector;
	private final UserSessionManager userSessionManager;
    private final VhostInstanceSelector<String> opcoSelector;
	public static final String ERROR_TITLE = "Error!";
	private static final String UNAUTHORIZED_MSG = "You do not have required permission to perform that action!";
	public static final String GUMS_MSG = "Action failed because an internal server error occurred. Please try again later";
	private static final String SUCCESS_TITLE = "Success!";
	private static final String UPDATE_MSG = "Your user data has been successfully updated.";
	private static final String REGISTER_TITLE = "Thank you for registering!";
	private static final String REGISTER_MSG = "The registration form has been sent successfully."
			+ "You will receive an email, as soon as your operator's account manager activates your account.";

	@Inject
	public UserHandler(GumsConnector gumsConnector,
			UserSessionManager userSessionManager,
            @OpcoSelector VhostInstanceSelector<String> opcoSelector) {
		Preconditions.checkNotNull(gumsConnector);
		Preconditions.checkNotNull(userSessionManager);
		this.gumsConnector = gumsConnector;
		this.userSessionManager = userSessionManager;
        this.opcoSelector = opcoSelector;
	}

	public Result register() throws GumsProtocolException,
			PeerCommunicationException, UnknownVhostException {
		if (userSessionManager.getSession(session()) != null
				&& userSessionManager.getSession(session()).getGuid() != null) {
			return unauthorized(JsonResponseBuilder.prepareMessage(ERROR_TITLE,
					UNAUTHORIZED_MSG));
		}
		Form<RegisteredUser> form = Form.form(RegisteredUser.class)
				.bindFromRequest();

		if (form.hasErrors()) {
			return badRequest(JsonResponseBuilder.invalidFields(form
					.errorsAsJson()));
		}

		RegisteredUser registeredUser = form.get();

		try {
			RequestedPendingUser requestedPendingUser = new RequestedPendingUser();
			requestedPendingUser.setFirstName(registeredUser.getFirstName());
			requestedPendingUser.setLastName(registeredUser.getLastName());
			requestedPendingUser.setEmail(registeredUser.getEmail());
			requestedPendingUser.setOpcoCName(registeredUser.getCompany());
			requestedPendingUser.setOpcoUUid(registeredUser.getEmail());
			//requestedPendingUser.setMobilePhone(registeredUser.getMobilePhone());
			requestedPendingUser.setOpcoUid(opcoSelector.getInstanceForVhost(request()));
			requestedPendingUser.setPassword(registeredUser.getPassword());
			requestedPendingUser.setRecoveryQuestion(registeredUser
					.getSecurityQuestion());
			requestedPendingUser.setRecoveryAnswer(registeredUser
					.getSecurityAnswer());
            if (!registeredUser.getAdditionalInfo().equals("")) {
                requestedPendingUser.setAdditionalInfo(registeredUser.getAdditionalInfo());
            }
			int id = gumsConnector.addPendingUser(requestedPendingUser);

			Logger.debug("Registered user with id {}", id);

			return ok(JsonResponseBuilder.prepareMessage(REGISTER_TITLE,
					REGISTER_MSG));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

	@UserAuthorized
	public Result userData() throws GumsProtocolException,
			PeerCommunicationException {
		try {
			User user = gumsConnector.getUser(UUID
					.fromString(userSessionManager.getSession(session())
							.getGuid()));
			return ok(Json.toJson(user));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}

	}

	@UserAuthorized
	public Result updateUserInfo() throws GumsProtocolException,
			PeerCommunicationException {
		Form<UserInfo> form = Form.form(UserInfo.class).bindFromRequest();
		if (form.hasErrors()) {
			return badRequest(JsonResponseBuilder.invalidFields(form
					.errorsAsJson()));
		}
		UserInfo info = form.get();
		try {
			User user = gumsConnector.getUser(UUID
					.fromString(userSessionManager.getSession(session())
							.getGuid()));

            user.setFirstName(nullIfEmpty(info.getFirstName()));
			user.setLastName(nullIfEmpty(info.getLastName()));
			user.setEmail(nullIfEmpty(info.getEmail()));
			user.setMobilePhone(nullIfEmpty(info.getMobilePhone()));
			gumsConnector.updateUserData(user);

			return ok(JsonResponseBuilder.prepareMessage(SUCCESS_TITLE,
					UPDATE_MSG));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

	@UserAuthorized
	public Result updateUserPassword() throws GumsProtocolException,
			PeerCommunicationException {
		Form<UserPassword> form = Form.form(UserPassword.class)
				.bindFromRequest();
		if (form.hasErrors()) {
			return badRequest(JsonResponseBuilder.invalidFields(form
					.errorsAsJson()));
		}
		UserPassword info = form.get();
		try {
			User user = gumsConnector.getUser(UUID
					.fromString(userSessionManager.getSession(session())
							.getGuid()));
			gumsConnector.updatePassword(user.getGuid(), info.getPassword(),
					info.getNewPassword());
			return ok(JsonResponseBuilder.prepareMessage(SUCCESS_TITLE,
					UPDATE_MSG));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

	@UserAuthorized
	public Result updateUserQuestion() throws GumsProtocolException,
			PeerCommunicationException {
		Form<UserQuestion> form = Form.form(UserQuestion.class)
				.bindFromRequest();
		if (form.hasErrors()) {
			return badRequest(JsonResponseBuilder.invalidFields(form
					.errorsAsJson()));
		}
		UserQuestion info = form.get();
		try {
			User user = gumsConnector.getUser(UUID
					.fromString(userSessionManager.getSession(session())
							.getGuid()));
			gumsConnector.updateRecoveryQuestion(user.getGuid(),
					info.getPassword(), info.getSecurityQuestion(),
					info.getSecurityAnswer());
			return ok(JsonResponseBuilder.prepareMessage(SUCCESS_TITLE,
					UPDATE_MSG));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

	public Result updateableOpcos() throws GumsProtocolException,
			PeerCommunicationException {
		try {
			return ok(Json.toJson(gumsConnector.getUpdateableOpcos()));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

	public Result getProducts() throws GumsProtocolException,
			PeerCommunicationException {
		try {
			return ok(Json.toJson(gumsConnector.getProducts()));
		} catch (IOException ex) {
			throw new PeerCommunicationException("GUMS", ex);
		}
	}

    private static String nullIfEmpty(String string) {
        if(string != null && !string.isEmpty()) {
            return string;
        }
        return null;
    }
}
