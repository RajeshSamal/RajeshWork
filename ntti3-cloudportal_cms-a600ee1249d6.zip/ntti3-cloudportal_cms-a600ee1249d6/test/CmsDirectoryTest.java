import com.ntti3.cms.Cms;
import com.ntti3.cms.DefaultCms;
import com.ntti3.cms.exceptions.NotFoundException;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ContentDirectory;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import play.test.FakeApplication;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
public class CmsDirectoryTest {
    private FakeApplication app;
    private Cms cms;

    @Before
    public void setUp() {
        app = fakeApplication(inMemoryDatabase());
        cms = new DefaultCms(Collections.singleton("removable"));
        start(app);
    }

    @After
    public void tearDown() {
        stop(app);
    }

    @Test
    public void getMainDirectories() {
        List<? extends ContentDirectory> directoryList = cms.getMainDirectories();
        assertTrue(!directoryList.isEmpty());
    }


    @Test
    public void getDirectory() {
        ContentDirectory dir = cms.getNode(1, CmsType.TYPE_DIRECTORY);
        assertNotNull(dir);
        assertFalse(dir.isRemovable());
    }

    @Test
    public void updateDirectory() {
        ContentDirectoryForm dir = new ContentDirectoryForm();
        dir.setName("Test");
        ContentDirectory parent = cms.getNode(1, CmsType.TYPE_DIRECTORY);
        dir.setParent(parent);
        cms.saveNode(dir);

        dir = cms.getNode(dir.getId(), CmsType.TYPE_DIRECTORY);
        assertNotNull(dir);

        dir.setName("Test2");
        cms.saveNode(dir);

        dir = cms.getNode(dir.getId(), CmsType.TYPE_DIRECTORY);
        assertEquals("Test2", dir.getName());
    }

    @Test(expected = NotFoundException.class)
    public void addRemoveDirectory() throws NotFoundException {
        ContentDirectoryForm dir = new ContentDirectoryForm();
        dir.setName("Test");
        ContentDirectory parent = cms.getNode(1, CmsType.TYPE_DIRECTORY);
        dir.setParent(parent);
        cms.saveNode(dir);
        dir = cms.getNode(dir.getId(), CmsType.TYPE_DIRECTORY);

        assertEquals(dir.getName(), "Test");
        assertEquals(dir.getParent().getId(), parent.getId());
        assertTrue(dir.isRemovable());

        cms.deleteNode(dir.getId(), CmsType.TYPE_DIRECTORY);
        cms.getNode(dir.getId(), CmsType.TYPE_DIRECTORY);
    }

    @Test(expected = IllegalArgumentException.class)
    public void tryRemoveNonRemovableDirectory() {
        ContentDirectory parent = cms.getNode(1, CmsType.TYPE_DIRECTORY);
        assertFalse(parent.isRemovable());

        cms.deleteNode(parent.getId(), CmsType.TYPE_DIRECTORY);
    }

    @Test(expected = IllegalArgumentException.class)
    public void tryMoveNonRemovableDirectory() {
        ContentDirectory parent = cms.getNode(1, CmsType.TYPE_DIRECTORY);
        assertFalse(parent.isRemovable());

        cms.moveNode(parent.getId(), parent.getType(), null, 2L, 0);
    }

    @Test
    public void contentDirectoryFormWithNullParent() {
        ContentDirectoryForm dir = new ContentDirectoryForm();
        dir.setParent(null);
        cms.saveNode(dir);
        Assert.assertNull("Parent should be null", dir.getParent());
    }

    @Test
    public void contentDirectoryFormWithNullParentImplicit() {
        ContentDirectoryForm dir = new ContentDirectoryForm();
        cms.saveNode(dir);
        Assert.assertNull("Parent should be null", dir.getParent());
    }
}
