import com.ntti3.cms.Cms;
import com.ntti3.cms.DefaultCms;
import com.ntti3.cms.exceptions.NotFoundException;
import com.ntti3.cms.models.*;
import com.ntti3.cms.models.form.WebPageContentForm;
import com.ntti3.cms.models.util.BaseContentWeightComparator;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import play.data.Form;
import play.data.format.Formatters;
import play.libs.Json;
import play.mvc.Http;
import play.test.FakeApplication;

import java.util.*;

import static junit.framework.Assert.*;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertNotNull;
import static org.mockito.Mockito.mock;
import static play.test.Helpers.*;


/**
 * Simple (JUnit) tests that can call all parts of a play app.
 * If you are interested in mocking a whole application, see the wiki for more details.
 */
public class CmsPageTest {
    private FakeApplication app;
    private Cms cms;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Before
    public void setUp() {
        cms = new DefaultCms(Collections.singleton("removable"));
        Map<String, String> flashData = Collections.emptyMap();
        Map<String, Object> argData = Collections.emptyMap();
        Long id = 2L;
        Http.Context context = new Http.Context(id, mock(play.api.mvc.RequestHeader.class), mock(Http.Request.class), flashData, flashData, argData);
        Http.Context.current.set(context);
        app = fakeApplication(inMemoryDatabase());
        start(app);

        Formatters.register(ContentDirectory.class, new Formatters.SimpleFormatter<ContentDirectory>() {
            @Override
            public ContentDirectory parse(String input, Locale l) {
                return cms.getNode(Long.parseLong(input), CmsType.TYPE_DIRECTORY);
            }

            @Override
            public String print(ContentDirectory cd, Locale l) {
                return cd.getId().toString();
            }
        });
    }

    @After
    public void tearDown() {
        stop(app);
    }

    @Test
    public void getPage() {
        WebPageContent page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        assertNotNull(page);
    }

    @Test
    public void updatePage() {
        WebPageContentForm page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        assertNotNull(page);
        page.setName("Test");
        cms.saveNode(page);
        page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        assertEquals(page.getName(), "Test");
    }

    @Test
    public void addRemovePage() throws NotFoundException {
        WebPageContentForm page = new WebPageContentForm();
        page.setName("Test");
        page.setTitle("Test");
        page.setUrl("test");
        final Long id = 1L;
        page.setParent(id);
        cms.saveNode(page);
        page = cms.getPage("test");
        assertEquals("Test", page.getName());
        assertEquals("Test", page.getTitle());
        assertEquals("test", page.getUrl());
        assertEquals(id, page.getParent().getId());
        assertTrue(page.isRemovable());

        cms.deleteNode(page.getId(), CmsType.TYPE_WEBPAGE);
        exception.expect(NotFoundException.class);
        cms.getPage("test");
    }

    @Test
    public void getFooterMenu() {
        List<MenuItem> menu = cms.getMenu("Footer");
        assertTrue(!menu.isEmpty());
    }

    @Test
    public void moveNode() {
        WebPageContentForm page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        assertNotNull(page);

        //Move node to diffrent parent
        cms.moveNode(page.getId(), page.getType(), page.getParent().getId(), (long) 2, 1);
        page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        assertEquals(new Long(2), page.getParent().getId());
        assertEquals(1, page.getWeight());
        List<? extends BaseContent> siblings = page.getParent().getContent();
        Collections.sort(siblings, new BaseContentWeightComparator());
        assertNotSame(page.getId() + page.getType().toString(), siblings.get(0).getId() + siblings.get(0).getType().toString());
        assertEquals(page.getId() + page.getType().toString(), siblings.get(1).getId() + siblings.get(1).getType().toString());

        //Move node up in the same parent
        cms.moveNode(page.getId(), page.getType(), page.getParent().getId(), (long) 2, 0);
        page = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        siblings = page.getParent().getContent();
        Collections.sort(siblings, new BaseContentWeightComparator());
        assertNotSame(page.getId() + page.getType().toString(), siblings.get(1).getId() + siblings.get(1).getType().toString());
        assertEquals(page.getId() + page.getType().toString(), siblings.get(0).getId() + siblings.get(0).getType().toString());
    }

    @Test
    public void testUniqueValidation() {
        Form<WebPageContentForm> form = Form.form(WebPageContentForm.class);
        WebPageContentForm exists = cms.getNode(1, CmsType.TYPE_WEBPAGE);
        form = form.fill(exists);
        assertFalse(form.hasErrors());

        WebPageContentForm page = new WebPageContentForm();
        page.setName("Test");
        page.setTitle("Test");
        page.setUrl(exists.getUrl());
        form = Form.form(WebPageContentForm.class);
        form = form.bind(Json.toJson(page));

        //URL is not unique
        assertTrue("No required errors", form.hasErrors());
    }

    @Test
    public void testNameChangeNonRemovableValidation() {
        Form<WebPageContentForm> form = Form.form(WebPageContentForm.class);
        WebPageContentForm nonRemovable = cms.getNode(2, CmsType.TYPE_WEBPAGE);
        assertFalse("Is removable!", nonRemovable.isRemovable());

        form = form.bind(Json.toJson(nonRemovable));
        assertFalse("Errors:" + form.errorsAsJson().toString(), form.hasErrors());

        nonRemovable.setName(nonRemovable.getName() + "_" + (new Random()).nextInt());
        form = form.bind(Json.toJson(nonRemovable));

        //URL is not unique
        assertTrue("No required errors", form.hasErrors());
    }

    @Test(expected = IllegalArgumentException.class)
    public void pageWithNullParent() {
        WebPageContentForm webPageContentForm = new WebPageContentForm();
        webPageContentForm.setName("a name");
        webPageContentForm.setUrl("testurl");
        webPageContentForm.setParent(null);
        cms.saveNode(webPageContentForm);
    }

    @Test(expected = IllegalArgumentException.class)
    public void pageWithNullParentImplicit() {
        WebPageContentForm webPageContentForm = new WebPageContentForm();
        webPageContentForm.setName("a name");
        webPageContentForm.setUrl("testurl");
        cms.saveNode(webPageContentForm);
    }
}
