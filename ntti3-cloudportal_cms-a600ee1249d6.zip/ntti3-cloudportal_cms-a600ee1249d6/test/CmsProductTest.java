import com.ntti3.cms.Cms;
import com.ntti3.cms.DefaultCms;
import com.ntti3.cms.exceptions.NotFoundException;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ProductContent;
import com.ntti3.cms.models.form.ProductContentForm;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import play.test.FakeApplication;

import java.util.Collections;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertNotNull;
import static play.test.Helpers.*;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
public class CmsProductTest {
    private FakeApplication app;
    private Cms cms;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Before
    public void setUp() {
        app = fakeApplication(inMemoryDatabase());
        cms = new DefaultCms(Collections.singleton("removable"));
        start(app);
    }

    @After
    public void tearDown() {
        stop(app);
    }

    @Test
    public void getAllProducts() {
        List<? extends ProductContent> products = cms.getProducts();
        assertTrue(!products.isEmpty());
    }

    @Test
    public void getProduct() {
        ProductContent product = cms.getNode(1, CmsType.TYPE_PRODUCT);
        assertNotNull(product);
    }

    @Test
    public void updateProduct() {
        ProductContentForm product = cms.getNode(1, CmsType.TYPE_PRODUCT);
        assertNotNull(product);
        product.setName("Test");
        cms.saveNode(product);
        product = cms.getNode(1, CmsType.TYPE_PRODUCT);
        assertEquals(product.getName(), "Test");
    }

    @Test
    public void addRemoveProduct() throws NotFoundException {
        ProductContentForm product = new ProductContentForm();
        product.setName("Test");
        product.setUrl("test");
        final Long id = 1L;
        product.setParent(id);
        cms.saveNode(product);
        product = cms.getNode(product.getId(), CmsType.TYPE_PRODUCT);
        assertEquals(product.getName(), "Test");
        assertEquals(product.getUrl(), "test");
        assertEquals(id, product.getParent().getId());
        assertTrue(product.isRemovable());
        cms.deleteNode(product.getId(), CmsType.TYPE_PRODUCT);
        exception.expect(NotFoundException.class);
        cms.getNode(product.getId(), CmsType.TYPE_PRODUCT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void productWithNullParent() {
        ProductContentForm pageContentForm = new ProductContentForm();
        pageContentForm.setName("a name");
        pageContentForm.setUrl("testurl");
        pageContentForm.setParent(null);
        cms.saveNode(pageContentForm);
    }

    @Test(expected = IllegalArgumentException.class)
    public void productWithNullParentImplicit() {
        ProductContentForm pageContentForm = new ProductContentForm();
        pageContentForm.setName("a name");
        pageContentForm.setUrl("testurl");
        cms.saveNode(pageContentForm);
    }
}
