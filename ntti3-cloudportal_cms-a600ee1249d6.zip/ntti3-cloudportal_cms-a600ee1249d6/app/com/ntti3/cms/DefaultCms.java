package com.ntti3.cms;

import com.avaje.ebean.Ebean;
import com.ntti3.cms.exceptions.NotFoundException;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.ebean.BaseContent;
import com.ntti3.cms.models.ebean.ProductContent;
import com.ntti3.cms.models.form.BaseContentForm;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import com.ntti3.cms.models.form.ProductContentForm;
import com.ntti3.cms.models.form.WebPageContentForm;
import com.ntti3.cms.models.util.BaseContentWeightComparator;
import play.Configuration;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-28.
 */
public class DefaultCms implements Cms {
    private final Collection<String> notAllowedOnUpdateFields;
    public static final String CMS_READ_ONLY_FIELDS_CONFIG_KEY = "cms.readOnlyFields";

    public DefaultCms() {
        this(Configuration.root().getStringList(CMS_READ_ONLY_FIELDS_CONFIG_KEY));
    }

    public DefaultCms(Collection<String> notAllowedOnUpdateFields) {
        this.notAllowedOnUpdateFields = Collections.unmodifiableCollection(new HashSet<>(notAllowedOnUpdateFields));
    }

    @Override
    public List<ProductContentForm> getProducts() {
        List<ProductContentForm> result = new ArrayList<>();
        List<ProductContent> ebeans = ProductContent.find.all();
        for (ProductContent ebean : ebeans) {
            result.add(new ProductContentForm(ebean));
        }
        return result;
    }

    @Override
    public <T extends BaseContentForm<? extends BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> void moveNode(Long nodeId, CmsType<T, E> type, Long sourceId, Long destinationId, int index) {
        Ebean.beginTransaction();
        try {
            com.ntti3.cms.models.ebean.ContentDirectory newParent = destinationId == null ? null : com.ntti3.cms.models.ebean.ContentDirectory.find.setForUpdate(true).setId(destinationId).findUnique();
            BaseContent object = Ebean.find(type.getEbeanClass()).setForUpdate(true).setId(nodeId).findUnique();
            if (!object.isRemovable()) {
                throw new IllegalArgumentException("Content is not removable or movable!");
            }
            object.setParent(newParent);
            object.setWeight(index);

            List<BaseContent> contents = com.ntti3.cms.models.ebean.ContentDirectory.getContentOf(newParent, true);
            Collections.sort(contents, new BaseContentWeightComparator());
            int weightCounter = 0;
            for (BaseContent content : contents) {
                if (content.getId().equals(object.getId()) && content.getType().equals(object.getType())) continue;
                if (weightCounter == index) {
                    weightCounter++;
                }
                content.setWeight(weightCounter);
                content.update();
                weightCounter++;
            }
            object.update();
            Ebean.commitTransaction();
        } finally {
            Ebean.endTransaction();
        }
    }

    @Override
    public void saveNode(BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent> node) {
        com.ntti3.cms.models.ebean.BaseContent ebeanContent = node.getEbean();
        List<ValidationError> errors = node.validate();
        if (errors != null) {
            String errorsString = "";
            for (ValidationError err : errors) {
                errorsString += err.toString() + "\n";
            }
            throw new IllegalArgumentException(errorsString);
        }
        if (node.getId() == null) {
            ebeanContent.save();
        } else {
            ebeanContent.setId(node.getId());
            Set<String> allowedFields = new HashSet<>(Arrays.asList((ebeanContent._ebean_getFieldNames())));
            allowedFields.removeAll(notAllowedOnUpdateFields);
            Ebean.update(ebeanContent, allowedFields);
        }
    }

    @Override
    public <T extends BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> T getNode(long id, CmsType<T, E> type) {
        E content = Ebean.find(type.getEbeanClass()).setId(id).findUnique();
        if (content == null) {
            throw new NotFoundException(type.getEbeanClass(), id);
        }
        return type.create(content);
    }

    @Override
    public <T extends BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> void deleteNode(long id, CmsType<T, E> type) {
        com.ntti3.cms.models.ebean.BaseContent content = Ebean.find(type.getEbeanClass(), id);
        if (content == null) {
            throw new NotFoundException(type.getEbeanClass(), id);
        }
        if (content.isRemovable()) {
            content.delete();
        } else {
            throw new IllegalArgumentException("Content is not removable!");
        }
    }

    @Override
    public WebPageContentForm getPage(String url) {
        com.ntti3.cms.models.ebean.WebPageContent content = com.ntti3.cms.models.ebean.WebPageContent.find.where()
                .ieq(com.ntti3.cms.models.ebean.WebPageContent.URL_FIELD, url).findUnique();
        if (content == null) {
            throw new NotFoundException("WebPage with given url does not exists");
        }
        return new WebPageContentForm(content);
    }

    @Override
    public List<MenuItem> getMenu(String name) {
        com.ntti3.cms.models.ContentDirectory directory = com.ntti3.cms.models.ebean.ContentDirectory.find.where()
                .ieq(BaseContent.NAME_FIELD, name).findUnique();
        if (directory == null) {
            return Collections.emptyList();
        }
        return directory.getPagesUrls();
    }

    @Override
    public List<ContentDirectoryForm> getMainDirectories() {
        List<ContentDirectoryForm> result = new ArrayList<>();
        List<com.ntti3.cms.models.ebean.ContentDirectory> ebeans = com.ntti3.cms.models.ebean.ContentDirectory.find.where()
                .ieq(BaseContent.PARENT_FIELD, null).order(BaseContent.WEIGHT_FIELD).findList();
        for (com.ntti3.cms.models.ebean.ContentDirectory ebean : ebeans) {
            result.add(new ContentDirectoryForm(ebean));
        }
        return result;
    }
}
