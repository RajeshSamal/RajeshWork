package com.ntti3.cms;

import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.form.BaseContentForm;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import com.ntti3.cms.models.form.ProductContentForm;
import com.ntti3.cms.models.form.WebPageContentForm;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 * <p/>
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public interface Cms {
    /**
     * Retrieves list of all products.
     *
     * @return List of all products
     */
    List<ProductContentForm> getProducts();

    /**
     * Moves node of given id and type to from parent sourceId to parent destinationId on position index.
     *
     * @param nodeId        node to move, not null
     * @param type          type of node to move, not null
     * @param sourceId      id of current parent, not null
     * @param destinationId id of new parent, not null
     * @param index         position on new parent
     */
    <T extends BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> void moveNode(Long nodeId, CmsType<T, E> type, Long sourceId, Long destinationId, int index);

    /**
     * Saves given object in database. If node have id of existing obejct it will be updated, otherwise it will be created.
     *
     * @param node node to save in database.
     */
    void saveNode(BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent> node);

    /**
     * Retrieves content of given id and type
     *
     * @param id   id of content
     * @param type type of content
     * @return node of given id and type
     */
    <T extends BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> T getNode(long id, CmsType<T, E> type);

    /**
     * Deletes content of given id and type
     *
     * @param id   id of content
     * @param type type of content
     * @param <T>  class of content
     */
    <T extends BaseContentForm<? extends com.ntti3.cms.models.ebean.BaseContent>, E extends com.ntti3.cms.models.ebean.BaseContent> void deleteNode(long id, CmsType<T, E> type);

    /**
     * Retrieves page with given url
     *
     * @param url url of page
     * @return page for given url, null if does not exists
     */
    WebPageContentForm getPage(String url);

    /**
     * Retrieves menu associated with directory with given name
     *
     * @param name name of the directory
     * @return list of MenuItems for given directory
     */
    List<MenuItem> getMenu(String name);

    /**
     * Retrieves main directories (this without parent).
     *
     * @return list of root directories
     */
    List<ContentDirectoryForm> getMainDirectories();
}
