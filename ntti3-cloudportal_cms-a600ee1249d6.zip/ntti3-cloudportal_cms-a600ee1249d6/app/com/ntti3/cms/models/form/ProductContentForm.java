package com.ntti3.cms.models.form;

import com.ntti3.cms.models.ebean.BaseContent;
import play.data.validation.Constraints;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
public class ProductContentForm extends BaseContentForm<com.ntti3.cms.models.ebean.ProductContent> implements com.ntti3.cms.models.ProductContent {
    //fields are just for constraints
    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 30, message = "form.validation.string_too_long")
    private String title;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 30, message = "form.validation.string_too_long")
    private String subtitle;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 120, message = "form.validation.string_too_long")
    private String shortDescription;

    @SuppressWarnings("unused")
    @Constraints.Required
    private String longDescription;

    @SuppressWarnings("unused")
    @Constraints.Required
    private String thumbnailImagePath;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.Pattern(value = BaseContent.TARGET_PATTERN, message = "form.validation.invalid_url_format")
    private String url;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 120, message = "form.validation.string_too_long")
    private String launchUrl;

    private List<String> questions;

    public ProductContentForm() {
        this(new com.ntti3.cms.models.ebean.ProductContent());
    }

    public ProductContentForm(com.ntti3.cms.models.ebean.ProductContent content) {
        super(content);
    }

    @Override
    public String getTitle() {
        return this.getEbean().getTitle();
    }

    @Override
    public String getSubtitle() {
        return this.getEbean().getSubtitle();
    }

    @Override
    public String getShortDescription() {
        return this.getEbean().getShortDescription();
    }

    @Override
    public String getLongDescription() {
        return this.getEbean().getLongDescription();
    }

    @Override
    public String getThumbnailImagePath() {
        return this.getEbean().getThumbnailImagePath();
    }

    @Override
    public String getUrl() {
        return this.getEbean().getUrl();
    }

    @Override
    public String getLaunchUrl() {
        return this.getEbean().getLaunchUrl();
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
        this.getEbean().setTitle(title);
    }

    @Override
    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
        this.getEbean().setSubtitle(subtitle);
    }

    @Override
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
        this.getEbean().setShortDescription(shortDescription);
    }

    @Override
    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
        this.getEbean().setLongDescription(longDescription);
    }

    @Override
    public void setThumbnailImagePath(String thumbnailImagePath) {
        this.thumbnailImagePath = thumbnailImagePath;
        this.getEbean().setThumbnailImagePath(thumbnailImagePath);
    }

    @Override
    public void setUrl(String url) {
        this.url = url;
        this.getEbean().setUrl(url);
    }

    @Override
    public void setLaunchUrl(String launchUrl) {
        this.launchUrl = launchUrl;
        this.getEbean().setLaunchUrl(launchUrl);
    }

    @Override
    public List<ValidationError> validate() {
        List<ValidationError> errors = super.validate();
        if (errors == null) {
            errors = new ArrayList<>();
        }
        if (getParent() == null) {
            errors.add(new ValidationError("parent", "Parent can not be null"));
        }
        return errors.isEmpty() ? null : errors;
    }
}
