package com.ntti3.cms.models.form;

import com.avaje.ebean.Ebean;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.WebPageContent;
import com.ntti3.cms.models.ebean.BaseContent;
import play.data.validation.Constraints;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
public class WebPageContentForm extends BaseContentForm<com.ntti3.cms.models.ebean.WebPageContent> implements WebPageContent {

    //fields are just for constraints
    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 30, message = "form.validation.string_too_long")
    private String title;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.Pattern(value = BaseContent.URL_PATTERN, message = "form.validation.invalid_url_format")
    private String url;

    public WebPageContentForm() {
        this(new com.ntti3.cms.models.ebean.WebPageContent());
    }

    public WebPageContentForm(com.ntti3.cms.models.ebean.WebPageContent content) {
        super(content);
    }

    @Override
    public String getHtmlContent() {
        return this.getEbean().getHtmlContent();
    }

    @Override
    public String getTitle() {
        return this.getEbean().getTitle();
    }

    @Override
    public String getUrl() {
        return this.getEbean().getUrl();
    }

    @Override
    public boolean isMenu() {
        return this.getEbean().isMenu();
    }

    @Override
    public List<MenuItem> getMenuUrls() {
        return this.getEbean().getMenuUrls();
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
        this.getEbean().setTitle(title);
    }

    @Override
    public void setUrl(String url) {
        this.url = url;
        this.getEbean().setUrl(url);
    }

    @Override
    public void setHtmlContent(String htmlContent) {
        this.getEbean().setHtmlContent(htmlContent);
    }

    @Override
    public List<ValidationError> validate() {
        List<ValidationError> errors = super.validate();
        if (errors == null) {
            errors = new ArrayList<>();
        }
        if (getParent() == null) {
            errors.add(new ValidationError("parent", "Parent can not be null"));
        }
        com.ntti3.cms.models.ebean.BaseContent bean = Ebean.find(this.getType().getEbeanClass()).where().eq("url", this.getUrl()).findUnique();
        if (bean != null) {
            if (!bean.getId().equals(this.getId())) {
                errors.add(new ValidationError("url", "This URL is already used."));
            }
        }
        return errors.isEmpty() ? null : errors;
    }
}
