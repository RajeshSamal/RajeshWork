package com.ntti3.cms.models.form;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ntti3.cms.models.BaseContent;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.WebPageContent;

import java.util.List;
import java.util.Set;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
public class ContentDirectoryForm extends BaseContentForm<com.ntti3.cms.models.ebean.ContentDirectory> implements com.ntti3.cms.models.ContentDirectory {

    public ContentDirectoryForm() {
        this(new com.ntti3.cms.models.ebean.ContentDirectory());
    }

    public ContentDirectoryForm(com.ntti3.cms.models.ebean.ContentDirectory content) {
        super(content);
    }

    @Override
    @JsonIgnore
    public Set<? extends WebPageContent> getPages() {
        return this.getEbean().getPages();
    }

    @Override
    @JsonIgnore
    public List<? extends BaseContent> getContent() {
        return this.getEbean().getContent();
    }

    @Override
    @JsonIgnore
    public List<MenuItem> getPagesUrls() {
        return this.getEbean().getPagesUrls();
    }

    @Override
    public boolean isMenu() {
        return this.getEbean().isMenu();
    }

    @Override
    public void setMenu(boolean hasMenu) {
        this.getEbean().setMenu(hasMenu);
    }
}
