package com.ntti3.cms.models.form;

import com.avaje.ebean.Ebean;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ntti3.cms.models.CmsType;
import play.data.validation.Constraints;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-07.
 */
@JsonIgnoreProperties({"ebean"})
public abstract class BaseContentForm<T extends com.ntti3.cms.models.ebean.BaseContent> implements com.ntti3.cms.models.BaseContent {
    private final T ebean;

    protected BaseContentForm(T ebean) {
        if (ebean == null) {
            throw new NullPointerException();
        }
        this.ebean = ebean;
    }

    //fields are just for constraints
    @SuppressWarnings("unused")
    private Long id;

    @SuppressWarnings("unused")
    @Constraints.Required
    private int weight;

    @SuppressWarnings("unused")
    @Constraints.Required
    @Constraints.MaxLength(value = 60, message = "form.validation.string_too_long")
    private String name;

    @SuppressWarnings("unused")
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    private com.ntti3.cms.models.ContentDirectory parent;

    @Override
    public Long getId() {
        return ebean.getId();
    }

    @Override
    public void setId(Long id) {
        this.id = id;
        ebean.setId(id);
    }

    @Override
    public int getWeight() {
        return ebean.getWeight();
    }

    @Override
    public String getName() {
        return ebean.getName();
    }

    @Override
    public boolean isRemovable() {
        return ebean.isRemovable();
    }

    @Override
    public com.ntti3.cms.models.ContentDirectory getParent() {
        return ebean.getParent();
    }

    @Override
    public void setParent(com.ntti3.cms.models.ContentDirectory parent) {
        this.parent = parent;
        ebean.setParent(parent);
    }

    @Override
    public void setParent(long id) {
        this.setParent(com.ntti3.cms.models.ebean.ContentDirectory.find.byId(id));
    }

    @Override
    public void setWeight(int weight) {
        this.weight = weight;
        ebean.setWeight(weight);
    }

    @Override
    public void setName(String name) {
        this.name = name;
        ebean.setName(name);
    }

    @Override
    public CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> getType() {
        return ebean.getType();
    }

    @JsonIgnore
    public T getEbean() {
        return ebean;
    }

    public List<ValidationError> validate() {
        List<ValidationError> errors = new ArrayList<>();
        com.ntti3.cms.models.ebean.BaseContent bean = Ebean.find(this.getType().getEbeanClass()).where().eq("name", this.getName()).findUnique();
        if (bean != null) {
            if (!bean.getId().equals(this.getId())) {
                errors.add(new ValidationError("name", "This name is already used."));
            }
        }
        if (this.getId() != null) {
            bean = Ebean.find(this.getType().getEbeanClass()).setId(this.getId()).findUnique();
            if (bean != null && !bean.isRemovable()) { //Non-removable object cannot change name!
                if (!this.getName().equals(bean.getName())) {
                    errors.add(new ValidationError("name", "You cannot change name for this object."));
                }
            }
        }
        return errors.isEmpty() ? null : errors;
    }
}
