package com.ntti3.cms.models;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public interface WebPageContent extends BaseContent {
    public static final String TYPE = "webpage";

    /**
     * HTML content to display of this web page
     *
     * @return HTML content, may be null
     */
    String getHtmlContent();

    /**
     * @return Title of this web page, may be null
     */
    String getTitle();

    /**
     * @return url of this web page, may be null
     */
    String getUrl();

    /**
     * @return Information if this web page should display meu
     */
    boolean isMenu();

    /**
     * @return menu items for menu on this web page or empty List if isMenu is false
     */
    List<MenuItem> getMenuUrls();

    /**
     * Sets title for the web page
     *
     * @param title new title of this web page
     */
    void setTitle(String title);

    /**
     * @param url new url for the web page
     */
    void setUrl(String url);

    /**
     * @param htmlContent new HTML content for the web page
     */
    void setHtmlContent(String htmlContent);
}
