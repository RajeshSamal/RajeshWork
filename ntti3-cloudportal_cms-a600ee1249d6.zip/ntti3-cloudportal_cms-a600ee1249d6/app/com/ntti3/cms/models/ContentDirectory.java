package com.ntti3.cms.models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import java.util.List;
import java.util.Set;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */

@JsonIgnoreProperties({"content"})
public interface ContentDirectory extends BaseContent {
    public static final String TYPE = "directory";

    /**
     * Retrieves content of type WebPageContent in this directory
     *
     * @return set of WebPageContent
     */
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    Set<? extends com.ntti3.cms.models.WebPageContent> getPages();

    /**
     * Retrieves all content in this directory
     *
     * @return list of BaseContent
     */
    @JsonIgnore
    List<? extends BaseContent> getContent();

    /**
     * Retrieves menu items for this directory
     *
     * @return list of MenuItem
     */
    List<MenuItem> getPagesUrls();


    /**
     * Indicates if web pages in this directory should display menu
     *
     * @return boolean
     */
    boolean isMenu();

    /**
     * Sets if web pages in this directory should display menu
     *
     * @param hasMenu value to set
     */
    void setMenu(boolean hasMenu);
}
