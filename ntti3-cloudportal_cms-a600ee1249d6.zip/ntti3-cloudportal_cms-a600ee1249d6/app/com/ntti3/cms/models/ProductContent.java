package com.ntti3.cms.models;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public interface ProductContent extends BaseContent {
    public static final String TYPE = "product";

    /**
     * @return Title of this product, may be null
     */
    String getTitle();

    /**
     * @return subtitle of this product, may be null
     */
    String getSubtitle();

    /**
     * @return short description of the product, may be null
     */
    String getShortDescription();

    /**
     * @return long description of the product, may be null
     */
    String getLongDescription();

    /**
     * @return path to the thumbnail image of the product, may be null
     */
    String getThumbnailImagePath();

    /**
     * @return url to the page associated with this product, may be null
     */
    String getUrl();

    /**
     * @return url of the page being opened after LAUNCH button click
     */
    String getLaunchUrl();

    /**
     * Sets title for the product
     *
     * @param title new title of this product
     */
    void setTitle(String title);

    /**
     * Sets subtitle for the product
     *
     * @param subtitle new subtitle of this product
     */
    void setSubtitle(String subtitle);

    /**
     * Sets the short description
     *
     * @param shortDescription short description of the product
     */
    void setShortDescription(String shortDescription);

    /**
     * Sets the long description
     *
     * @param longDescription long description of the product
     */
    void setLongDescription(String longDescription);

    /**
     * Sets the path to the thumbnail image
     *
     * @param thumbnailImagePath path to the thumbnail image of the product
     */
    void setThumbnailImagePath(String thumbnailImagePath);

    /**
     * Sets the url
     *
     * @param url url to the page associated with this product
     */
    void setUrl(String url);

    /**
     * Sets LAUNCH button url
     *
     * @param url url of the page being opened after LAUNCH button click
     */
    void setLaunchUrl(String url);
}
