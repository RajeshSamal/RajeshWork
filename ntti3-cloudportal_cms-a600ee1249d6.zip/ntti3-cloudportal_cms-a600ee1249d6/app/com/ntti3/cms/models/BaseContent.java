package com.ntti3.cms.models;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.ntti3.cms.models.form.BaseContentForm;

import javax.annotation.Nullable;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public interface BaseContent {
    /**
     * Retrieves id of the content.
     *
     * @return id of content. May be null if object does not have id (have not been save to Database).
     */
    Long getId();

    /**
     * Sets id for content
     *
     * @param id for object, or null if you want insert it as new object
     */
    void setId(Long id);

    /**
     * Retrieves weight of the content. Object of lower weight should be shown first in tree.
     *
     * @return weight of the content
     */
    int getWeight();

    /**
     * Retrieves name of the content
     *
     * @return name of the content, may be null
     */
    String getName();

    /**
     * Indicates if this content can be removed
     *
     * @return true if it is removable
     */
    boolean isRemovable();

    /**
     * Retrieves parent of the current content
     *
     * @return parent, may be null
     */
    ContentDirectory getParent();

    /**
     * Sets parent of the current content
     *
     * @param parent new parent of the content
     */
    void setParent(@Nullable ContentDirectory parent);

    /**
     * Sets parent of the current content
     *
     * @param id id of the new parent of content
     */
    void setParent(long id);

    /**
     * Sets new weight of the content. Object of lower weight should be shown first in tree.
     *
     * @param weight weight of the content
     */
    void setWeight(int weight);

    /**
     * Sets the name of the content
     *
     * @param name of the content
     */
    void setName(String name);

    /**
     * Retrieves type of this content.
     *
     * @return type of the content
     */
    @JsonSerialize(using = ToStringSerializer.class)
    CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> getType();
}
