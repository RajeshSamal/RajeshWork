package com.ntti3.cms.models;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-29.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public class MenuItem {
    private String title;
    private String url;

    /**
     * Constructs new menu item with given attributes
     *
     * @param title title of the menu item
     * @param url   url of the menu item
     */
    public MenuItem(String title, String url) {
        this.title = title;
        this.url = url;
    }

    /**
     * Retrieves title for this menu item
     *
     * @return title title of the menu item
     */
    public String getTitle() {
        return title;
    }

    /**
     * Retrieves url for this menu item
     *
     * @return url of the menu item
     */
    public String getUrl() {
        return url;
    }
}
