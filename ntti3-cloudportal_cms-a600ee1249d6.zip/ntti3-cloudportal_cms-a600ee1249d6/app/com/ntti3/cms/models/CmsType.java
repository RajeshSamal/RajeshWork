package com.ntti3.cms.models;

import com.ntti3.cms.models.form.BaseContentForm;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import com.ntti3.cms.models.form.ProductContentForm;
import com.ntti3.cms.models.form.WebPageContentForm;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-12.
 * Represents information about types in CMS
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
public final class CmsType<T extends BaseContentForm<?>, E extends com.ntti3.cms.models.ebean.BaseContent> {
    private static final Map<String, CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent>> MAP = new HashMap<>();

    private static interface Creator<T extends BaseContentForm<?>, E extends com.ntti3.cms.models.ebean.BaseContent> {
        T create(E content);
    }

    /**
     * Type for the ContentDirectory @see com.ntti3.cms.models.ContentDirectory
     */
    public static final CmsType<ContentDirectoryForm, com.ntti3.cms.models.ebean.ContentDirectory> TYPE_DIRECTORY = new CmsType<>(com.ntti3.cms.models.ebean.ContentDirectory.class,
            ContentDirectoryForm.class, ContentDirectory.TYPE,
            new Creator<ContentDirectoryForm, com.ntti3.cms.models.ebean.ContentDirectory>() {
                @Override
                public ContentDirectoryForm create(com.ntti3.cms.models.ebean.ContentDirectory content) {
                    return new ContentDirectoryForm(content);
                }
            }
    );

    /**
     * Type for WebPageContent @see com.ntti3.cms.models.WebPageContent
     */
    public static final CmsType<WebPageContentForm, com.ntti3.cms.models.ebean.WebPageContent> TYPE_WEBPAGE = new CmsType<>(com.ntti3.cms.models.ebean.WebPageContent.class,
            WebPageContentForm.class, WebPageContent.TYPE,
            new Creator<WebPageContentForm, com.ntti3.cms.models.ebean.WebPageContent>() {
                @Override
                public WebPageContentForm create(com.ntti3.cms.models.ebean.WebPageContent content) {
                    return new WebPageContentForm(content);
                }
            }
    );

    /**
     * Type for ProductContentForm @see com.ntti3.cms.models.ProductContent
     */
    public static final CmsType<ProductContentForm, com.ntti3.cms.models.ebean.ProductContent> TYPE_PRODUCT = new CmsType<>(com.ntti3.cms.models.ebean.ProductContent.class,
            ProductContentForm.class, ProductContent.TYPE,
            new Creator<ProductContentForm, com.ntti3.cms.models.ebean.ProductContent>() {
                @Override
                public ProductContentForm create(com.ntti3.cms.models.ebean.ProductContent content) {
                    return new ProductContentForm(content);
                }
            }
    );

    private final Class<E> ebeanClass;

    private final Class<T> formClass;

    private final String stringRepresentation;

    private final Creator<T, E> crt;

    private CmsType(Class<E> ebeanClass, Class<T> formClass, String stringRepresentation, Creator<T, E> crt) {
        this.ebeanClass = ebeanClass;
        this.formClass = formClass;
        this.stringRepresentation = stringRepresentation;
        this.crt = crt;
        MAP.put(stringRepresentation, this);
    }

    /**
     * Get ebean class of the given type
     *
     * @return ebean class
     */
    public Class<E> getEbeanClass() {
        return ebeanClass;
    }

    /**
     * Get form class of the given type
     *
     * @return form class
     */
    public Class<T> getFormClass() {
        return formClass;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }

    /**
     * Return type based on string returned by toString method
     *
     * @param type string representation of the type
     * @return type
     */
    public static CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> fromString(String type) {
        CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> result = MAP.get(type);
        if (result == null) {
            throw new IllegalArgumentException("Unknown type!");
        }
        return result;
    }

    /**
     * Creates instance of form class from ebean class
     *
     * @param content ebean class
     * @return form class
     */
    public T create(E content) {
        return crt.create(content);
    }
}
