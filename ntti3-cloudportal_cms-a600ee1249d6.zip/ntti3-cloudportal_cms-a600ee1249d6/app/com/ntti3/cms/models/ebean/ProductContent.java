package com.ntti3.cms.models.ebean;

import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ContentDirectory;
import com.ntti3.cms.models.form.BaseContentForm;

import javax.persistence.Entity;
import javax.persistence.Lob;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-25.
 */
@Entity
public class ProductContent extends BaseContent implements com.ntti3.cms.models.ProductContent {
    private static final long serialVersionUID = 5910645521439320658L;

    private String title;

    private String subtitle;

    private String shortDescription;

    @Lob
    private String longDescription;

    private String thumbnailImagePath;

    private String url;

    private String launchUrl;

    public static Finder<Long, ProductContent> find = new Finder<>(
            Long.class, ProductContent.class
    );

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getSubtitle() {
        return subtitle;
    }

    @Override
    public String getShortDescription() {
        return shortDescription;
    }

    @Override
    public String getLongDescription() {
        return longDescription;
    }

    @Override
    public String getThumbnailImagePath() {
        return thumbnailImagePath;
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public String getLaunchUrl() {
        return launchUrl;
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    @Override
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Override
    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    @Override
    public void setThumbnailImagePath(String thumbnailImagePath) {
        this.thumbnailImagePath = thumbnailImagePath;
    }

    @Override
    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public void setLaunchUrl(String launchUrl) {
        this.launchUrl = launchUrl;
    }

    @Override
    public CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> getType() {
        return CmsType.TYPE_PRODUCT;
    }

    @Override
    public void setParent(long id) {
        super.setParent(id);
    }

    @Override
    public void setParent(ContentDirectory parent) {
        if (parent == null) {
            throw new IllegalArgumentException("Parent for product content can not be null");
        }
        super.setParent(parent);
    }
}
