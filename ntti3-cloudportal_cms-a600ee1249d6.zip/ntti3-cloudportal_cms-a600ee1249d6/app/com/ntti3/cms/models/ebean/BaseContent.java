package com.ntti3.cms.models.ebean;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import play.db.ebean.Model;

import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-25.
 */
@MappedSuperclass
public abstract class BaseContent extends Model implements com.ntti3.cms.models.BaseContent {
    private static final long serialVersionUID = 1507285052422938105L;
    public static final String URL_PATTERN = "^((\\/){0,1}([\\w_-]+\\/)*([\\w_-]+)?)$";
    public static final String TARGET_PATTERN = "(\\b(https?|ftp|file)://)?[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]";

    public static final String PARENT_FIELD = "parent";
    public static final String NAME_FIELD = "name";
    public static final String WEIGHT_FIELD = "weight";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int weight;

    @Column(unique = true)
    @NotNull
    private String name;

    private boolean removable = true;

    @ManyToOne
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    private ContentDirectory parent; //TODO: saving parents from json

    @SuppressWarnings("unused")
    @Version
    private Timestamp lastUpdate;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public int getWeight() {
        return weight;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isRemovable() {
        return removable;
    }

    @Override
    public com.ntti3.cms.models.ContentDirectory getParent() {
        return parent;
    }

    public Timestamp getVersion() {
        return lastUpdate;
    }

    @Override
    public void setParent(@Nullable com.ntti3.cms.models.ContentDirectory parent) {
        if (parent == null) {
            this.parent = null;
        } else if (parent instanceof ContentDirectory) {
            this.parent = (ContentDirectory) parent;
        } else if (parent instanceof ContentDirectoryForm) {
            this.parent = ((ContentDirectoryForm) parent).getEbean();
        } else {
            throw new IllegalArgumentException("Parent must be instance of ContentDirectory returned by this interface!");
        }
    }

    @Override
    public void setParent(long id) {
        this.setParent(ContentDirectory.find.byId(id));
    }

    @Override
    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return this.getType() + " " + this.getId() + " - " + this.getName();
    }
}
