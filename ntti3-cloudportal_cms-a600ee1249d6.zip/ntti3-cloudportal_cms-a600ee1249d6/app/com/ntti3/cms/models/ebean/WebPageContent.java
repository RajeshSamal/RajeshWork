package com.ntti3.cms.models.ebean;

import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.form.BaseContentForm;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ContentDirectory;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-25.
 */
@Entity
public class WebPageContent extends BaseContent implements com.ntti3.cms.models.WebPageContent {
    private static final long serialVersionUID = 2795414175896967878L;

    public static final String URL_FIELD = "url";

    private String title;

    @Column(unique = true)
    private String url;

    @Lob
    private String htmlContent;

    public static Finder<Long, WebPageContent> find = new Finder<>(
            Long.class, WebPageContent.class
    );

    @Override
    public String getHtmlContent() {
        return htmlContent;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public boolean isMenu() {
        ContentDirectory parent = getParent();
        return parent != null && parent.isMenu();
    }

    @Override
    public List<MenuItem> getMenuUrls() {
        List<MenuItem> result = new ArrayList<>();
        if (this.isMenu()) {
            ContentDirectory parent = this.getParent();
            if (parent != null) {
                result = parent.getPagesUrls();
            }
        }
        return Collections.unmodifiableList(result);
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public void setHtmlContent(String htmlContent) {
        this.htmlContent = htmlContent;
    }

    @Override
    public CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> getType() {
        return CmsType.TYPE_WEBPAGE;
    }

    @Override
    public void setParent(ContentDirectory parent) {
        if (parent == null) {
            throw new IllegalArgumentException("Parent for web page content can not be null");
        }
        super.setParent(parent);
    }
}
