package com.ntti3.cms.models.ebean;

import com.google.common.collect.Lists;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.MenuItem;
import com.ntti3.cms.models.form.BaseContentForm;

import javax.annotation.Nullable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-25.
 */
@Entity
public class ContentDirectory extends BaseContent implements com.ntti3.cms.models.ContentDirectory {
    private static final long serialVersionUID = 170267817684494338L;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = PARENT_FIELD)
    @OrderBy("weight ASC")
    @SuppressWarnings("unused")
    private Set<WebPageContent> pages;

    public static Finder<Long, ContentDirectory> find = new Finder<>(
            Long.class, ContentDirectory.class
    );

    boolean menu = false;

    @Override
    public Set<? extends com.ntti3.cms.models.WebPageContent> getPages() {
        if (pages != null) {
            return Collections.unmodifiableSet(pages);
        }
        return Collections.unmodifiableSet(Collections.<WebPageContent>emptySet());
    }

    @Override
    public List<com.ntti3.cms.models.ebean.BaseContent> getContent() {
        return getContentOf(this, false);
    }

    public List<com.ntti3.cms.models.ebean.BaseContent> getContent(boolean forUpdate) {
        return getContentOf(this, forUpdate);
    }

    /**
     * Gets content of a directory.
     *
     * @param directory Parent directory of the content. <code>null</code> to get root content.
     * @param forUpdate To select the content for update.
     * @return
     */
    public static List<com.ntti3.cms.models.ebean.BaseContent> getContentOf(@Nullable com.ntti3.cms.models.ebean.BaseContent directory, boolean forUpdate) {
        List<com.ntti3.cms.models.ebean.BaseContent> result = Lists.newArrayList();
        result.addAll(WebPageContent.find.setForUpdate(forUpdate).where().eq(PARENT_FIELD, directory).findList());
        result.addAll(ProductContent.find.setForUpdate(forUpdate).where().eq(PARENT_FIELD, directory).findList());
        result.addAll(ContentDirectory.find.setForUpdate(forUpdate).where().eq(PARENT_FIELD, directory).findList());
        return result;
    }


    @Override
    public List<MenuItem> getPagesUrls() {
        List<MenuItem> result = new ArrayList<>();
        for (com.ntti3.cms.models.WebPageContent page : this.getPages()) {
            result.add(new MenuItem(page.getTitle(), page.getUrl()));
        }
        return result;
    }

    @Override
    public boolean isMenu() {
        return menu;
    }

    @Override
    public void setMenu(boolean hasMenu) {
        this.menu = hasMenu;
    }

    @Override
    public CmsType<? extends BaseContentForm<?>, ? extends com.ntti3.cms.models.ebean.BaseContent> getType() {
        return CmsType.TYPE_DIRECTORY;
    }
}
