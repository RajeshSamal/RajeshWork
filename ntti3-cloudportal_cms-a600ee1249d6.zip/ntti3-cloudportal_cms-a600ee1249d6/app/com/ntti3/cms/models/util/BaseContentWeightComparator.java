package com.ntti3.cms.models.util;

import com.ntti3.cms.models.BaseContent;

import java.util.Comparator;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-06.
 */
public class BaseContentWeightComparator implements Comparator<BaseContent> {
    @Override
    public int compare(BaseContent o1, BaseContent o2) {
        return o1.getWeight() - o2.getWeight();
    }
}