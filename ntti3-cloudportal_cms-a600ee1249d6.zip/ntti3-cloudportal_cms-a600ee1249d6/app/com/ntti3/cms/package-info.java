/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-13.
 * All parameters cannot be set to null if not specified. All methods does not return null if not specified.
 */
