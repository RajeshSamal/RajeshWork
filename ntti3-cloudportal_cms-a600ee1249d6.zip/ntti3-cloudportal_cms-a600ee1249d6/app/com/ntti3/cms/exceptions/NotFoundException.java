package com.ntti3.cms.exceptions;

import com.ntti3.cms.models.ebean.BaseContent;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-05.
 */
public class NotFoundException extends RuntimeException {
    private static final long serialVersionUID = 2540116552352533587L;

    public NotFoundException(Class<? extends BaseContent> type, long id) {
        super(type.getName() + " with id " + id + " does not exsist.");
    }

    public NotFoundException(String msg) {
        super(msg);
    }
}
