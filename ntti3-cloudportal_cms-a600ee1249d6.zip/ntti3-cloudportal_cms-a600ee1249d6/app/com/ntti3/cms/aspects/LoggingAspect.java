package com.ntti3.cms.aspects;

import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

    @Pointcut("execution(* com.ntti3.cms.*.*(..)) && !execution(* com.ntti3.cms.*.*$*(..))")
    @Override
    public void controllerMethodPointcut() {
    }

    @Pointcut("within(com.ntti3.cms.controllers..*) || within(com.ntti3.cms.models..*)")
    @Override
    public void applicationMethodPointcut() {
    }

    @Override
    public String getPathContains() {
        return "cms";
    }
}


