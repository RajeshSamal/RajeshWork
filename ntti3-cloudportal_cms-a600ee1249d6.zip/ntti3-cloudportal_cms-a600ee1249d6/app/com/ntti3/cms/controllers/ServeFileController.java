package com.ntti3.cms.controllers;

import com.google.common.base.Preconditions;
import controllers.Assets;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.impl.cookie.DateParseException;
import org.apache.http.impl.cookie.DateUtils;
import play.Configuration;
import play.Logger;
import play.api.mvc.Action;
import play.api.mvc.AnyContent;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Call;
import play.mvc.Results;

import java.io.File;
import java.util.Date;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-14.
 */
public class ServeFileController extends Controller {
    private static final String CMS_UPLOAD_PATH = "cms.upload.path";
    private static final String CSS_PATH = "/public/stylesheets";
    private final String path;

    public ServeFileController() {
        path = Preconditions.checkNotNull(Configuration.root().getString(CMS_UPLOAD_PATH),
                "Conifiguration key " + CMS_UPLOAD_PATH + "can not be null!");
    }

    public Action serveCss(String fileName) {
        return Assets.at(CSS_PATH, fileName);
    }

    public Result serve(String fileName) {
        String fullPath = FilenameUtils.concat(path, fileName);
        if (!fullPath.startsWith(path)) { //somebody used ../ notation in filename
            return notFound();
        }

        final File requestedFile = new File(fullPath);
        if (!requestedFile.exists()) {
            return notFound();
        } else {
            if (needSend(requestedFile)) {
                Date modifiedDate = new Date(requestedFile.lastModified());
                response().setHeader(LAST_MODIFIED,
                        DateUtils.formatDate(modifiedDate, DateUtils.PATTERN_RFC1123));
                return ok(requestedFile);
            } else {
                return Results.status(NOT_MODIFIED);
            }
        }
    }

    private static boolean needSend(File file) {
        String ifModifiedSinceHeader = request().getHeader(IF_MODIFIED_SINCE);
        if (ifModifiedSinceHeader == null) return true;
        try {
            final Date ifModifiedSinceDate = DateUtils.parseDate(ifModifiedSinceHeader);
            Date fileDate = new Date(file.lastModified());
            return fileDate.after(ifModifiedSinceDate);
        } catch (DateParseException e) {
            Logger.warn("Received HTTP request with corrupted if-modiffied-since header - serving the file", e);
            return true;
        }
    }
}
