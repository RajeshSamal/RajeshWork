# --- !Ups

create table content_directory (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  menu                      boolean,
  last_update               timestamp not null,
  constraint uq_content_directory_name unique (name),
  constraint pk_content_directory primary key (id))
;

create table product_content (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  title                     varchar(255),
  short_description         varchar(255),
  long_description          longtext,
  thumbnail_image_path      varchar(255),
  url                       varchar(255),
  last_update               timestamp not null,
  constraint uq_product_content_name unique (name),
  constraint pk_product_content primary key (id))
;

create table question (
   id                        bigint auto_increment not null,
   question                  varchar(255),
   product_id                bigint,
   constraint pk_question primary key (id))
 ;

create table web_page_content (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  title                     varchar(255),
  url                       varchar(255),
  html_content              longtext,
  last_update               timestamp not null,
  constraint uq_web_page_content_name unique (name),
  constraint uq_web_page_content_url unique (url),
  constraint pk_web_page_content primary key (id))
;

alter table content_directory add constraint fk_content_directory_parent_1 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_content_directory_parent_1 on content_directory (parent_id);
alter table product_content add constraint fk_product_content_parent_2 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_product_content_parent_2 on product_content (parent_id);
alter table question add constraint fk_question_product_3 foreign key (product_id) references product_content (id) on delete restrict on update restrict;
create index ix_question_product_3 on question (product_id);
alter table web_page_content add constraint fk_web_page_content_parent_4 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_web_page_content_parent_4 on web_page_content (parent_id);

INSERT INTO `content_directory`
(`id`,
`weight`,
`name`,
`removable`,
`parent_id`,
`menu`,
`last_update`)
VALUES
(1,
1,
'Web Pages',
0,
null,
0,
NOW()
);


INSERT INTO `content_directory`
(`id`,
`weight`,
`name`,
`removable`,
`parent_id`,
`menu`,
`last_update`)
VALUES
(2,
0,
'Products',
0,
null,
0,
NOW()
);


INSERT INTO `content_directory`
(`id`,
`weight`,
`name`,
`removable`,
`parent_id`,
`menu`,
`last_update`)
VALUES
(3,
0,
'Footer',
0,
1,
0,
NOW()
);



INSERT INTO `product_content`
(
`id`,
`weight`,
`name`,
`parent_id`,
`removable`,
`short_description`,
`long_description`,
`thumbnail_image_path`,
`url`,
     `last_update`)
VALUES
(
1,
0,
'AMA',
2,
1,
'Move, manage, and govern one or more applications on one or more clouds with complete portability and lifecycle management.',
'<p>AMA''s broad assortment of packaged application profiles make it fast and efficient to represent application requirements, automating best-practice orchestration on the cloud.</p><p>Using role-based policies, gain visibility and control of users, applications, and clouds from a set of centralized administration tools.</p><a href="ama" class="navigate">learn more</a><a href="https://ama.stagingntti3.com/" class="navigate">go to AMA</a>',
'images/ama-dashboard.jpg',
'ama',
NOW()
);

INSERT INTO `web_page_content`
(
`id`,
`weight`,
`name`,
`removable`,
`parent_id`,
`title`,
`url`,
`html_content`,
`last_update`)
VALUES
(
1,
0,
'Privacy Policy',
1,
3,
'Privacy Policy',
'privacy-policy',
'<article class="product-page">		<div>			<section>				<h1>Privacy Policy</h1>				<p>					NTT I3 and its Affiliates (individually and collectively, the “Company”) are committed to protecting the privacy of your information. This Privacy Statement describes Company’s Web site privacy practices. This Privacy Statement covers the information practices of Company. If you have any questions about this Privacy Statement, please feel free to contact us through our Web-site. For purposes of this Privacy Statement, the term “Affiliate” shall mean any entity that, directly or indirectly, controls, is controlled by, or is under common control with, NTT I3.				</p>				<ol>					<li>						<strong>Information we collect</strong>						<p>							Company offers a variety of services that are collectively referred to as the "Services." Company collects information from individuals who visit the Company''s Web site ("Visitors") and individuals who register to use the Services ("Customers").						</p>						<p>							When expressing an interest in obtaining additional information about the Services or registering to use the Services, Company requires you to provide the Company with personal contact information, such as name, company name, address, phone number, and email address ("Required Contact Information"). 						</p>						<p>							As you navigate the Company''s Web site, Company may also collect information through the use of commonly-used information-gathering tools, such as cookies and Web beacons ("Web Site Navigational Information"). Web Site Navigational Information includes standard information from your Web browser (such as browser type and browser language), your Internet Protocol ("IP") address, and the actions you take on the Company''s Web site (such as the Web pages viewed and the links clicked).						</p>					</li>					<li>						<strong>Use of Information Collected</strong>						<p>							The Company uses Required Contact Information to perform the Services requested. For example, if you fill out a "Contact Information" Web form, the Company will use the information provided to contact you about your interest in the Services.  Additionally, the Company may use information you provide to contact you to further discuss your interest in the Services and to send you information regarding the Company and its partners, such as information about promotions or events. Company may use Web Site Navigational Information to operate and improve the Company''s Web site. The Company may also use Web Site Navigational Information alone or in combination with Required Contact Information to provide personalized information about the Company.						</p>					</li>					<li>						<strong>Web Site Navigational Information</strong>						<p>							 Company may use commonly-used information-gathering tools, such as cookies and Web beacons, to collect information as you navigate the Company''s Web site ("Web Site Navigational Information"). This section describes the types of Web Site Navigational Information that may be collected on the Company''s Web site and how this information may be used.						</p>						<ol>							<li>								<span class="u">Cookies</span>								<p>									Company may use cookies to make interactions with the Company''s Web site easy and meaningful. When you visit the Company''s Web site, Company''s servers send a cookie to your computer. Standing alone, cookies do not personally identify you. They merely recognize your Web browser. Unless you choose to identify yourself to Company, either by responding to a promotional offer, opening an account, or filling out a Web form, you remain anonymous to the Company. Company may use cookies that are session-based and persistent-based. Session cookies exist only during one session. They disappear from your computer when you close your browser software or turn off your computer. Persistent cookies remain on your computer after you close your browser or turn off your computer.								</p>								<p>									If you have chosen to identify yourself to Company, the Company may use session cookies containing encrypted information to allow the Company to uniquely identify you. Each time you log into the Services, a session cookie containing an encrypted, unique identifier that is tied to your account is placed your browser. These session cookies allow the Company to uniquely identify you when you are logged into the Services and to process your online transactions and requests. Session cookies are required to use the Services.								</p>								<p>									Company may use persistent cookies that only the Company can read and use to identify browsers that have previously visited the Company''s Web site. When you purchase the Services or provide the Company with personal information, a unique identifier may be assigned you. This unique identifier is associated with a persistent cookie that the Company places on your Web browser. The Company is especially careful about the security and confidentiality of the information stored in persistent cookies. For example, the Company does not store account numbers or passwords in persistent cookies. If you disable your Web browser''s ability to accept cookies, you will be able to navigate the Company''s Web site, but you will not be able to successfully use the Services.								</p>								<p>									Company may use information from session and persistent cookies in combination with Required Contact Information to provide you with information about the Company and the Services.								</p>							</li>							<li>								<span class="u">Web Beacons</span>								<p>									Company may use Web beacons alone or in conjunction with cookies to compile information about Customers and Visitors'' usage of the Company''s Web site and interaction with emails from the Company. Web beacons are clear electronic images that can recognize certain types of information on your computer, such as cookies, when you viewed a particular Web site tied to the Web beacon, and a description of a Web site tied to the Web beacon. For example, Company may place Web beacons in marketing emails that notify the Company when you click on a link in the email that directs you to one of the Company''s Web site. Company may use Web beacons to operate and improve the Company''s Web site and email communications. Company may use information from Web beacons in combination with Required Contact Information  to provide you with information about the Company and the Services.								</p>							</li>							<li>								<span class="u">IP Addresses</span>								<p>									When you visit Company’s Web site, the Company may collect your IP addresses to track and aggregate non-personal information. For example, Company uses IP addresses to monitor the regions from which Customers and Visitors navigate the Company''s Web site.								</p>							</li>							<li>								<span class="u">Third Party Cookies</span>								<p>									From time-to-time, Company may engage third parties to track and analyze usage and volume statistical information from individuals who visit the Company''s Web site. Company may also use other third-party cookies to track the performance of Company advertisements. The information provided to third parties does not include personal information, but this information may be re-associated with personal information after the Company receives it.								</p>								<p>									Company may also contract with third-party advertising networks that collect IP addresses and other Web Site Navigational Information on the Company''s Web site and emails and on third-party Web sites. Ad networks follow your online activities over time by collecting Web Site Navigational Information through automated means, including through the use of cookies. They use this information to provide advertisements about products and services tailored to your interests. You may see these advertisements on other Web sites. This process also helps us manage and track the effectiveness of our marketing efforts. To learn more about these and other advertising networks and their opt-out instructions, click here.								</p>							</li>							<li>								<span class="u">Do Not Track</span>								<p>									Currently, (i)&nbsp;;other parties (e.g. third-party advertising networks and analytics providers) may not collect personal information about your online activities over time and across different websites when you use Company’s Web site or use Company’s Services, and (ii)&nbsp;;Company does not respond to, or take any specific action in connection with the receipt of, Do-Not-Track signals or other similar mechanisms regarding the collection of personally identifiable information about an individual consumer’s online activities over time and across third-party websites or online services.								</p>							</li>						</ol>					</li>					<li>						<strong>Public Forums and Customer Testimonials</strong>						<p>							Company may provide bulletin boards, blogs, or chat rooms on the Company''s Web site. Any personal information you choose to submit in such a forum may be read, collected, or used by others who visit these forums, and may be used to send you unsolicited messages. Company is not responsible for the personal information you choose to submit in these forums.						</p>						<p>							Company may post a list of Customers and testimonials on the Company''s Web site that contain information such as Customer names and titles. Company obtains the consent of each Customer prior to posting any information on such a list or posting testimonials.						</p>					</li>					<li>						<strong>Sharing of Information Collected</strong>						<p>							Company may share Required Contact Information  with (i) the Company''s service providers, including Company’s payments process provider, so that these service providers may perform their related services for or on behalf of Company, and (ii) Affiliates in connection with the provision of the Services. Unless described in this Privacy Statement, Company does not share, sell, rent, or trade any information provided with third parties for their promotional purposes.						</p>						<p>							Company reserves the right to use or disclose information provided if required by law or if the Company reasonably believes that use or disclosure is necessary to protect the Company''s rights and/or to comply with a judicial proceeding, court order, or legal process.						</p>					</li>					<li>						<strong>International Transfer of Information Collected</strong>						<p>							To facilitate Company''s global operations, the Company may transfer and access Required Contact Information from around the world, including the United States. This Privacy Statement shall apply even if Company transfers Required Contact Information to other countries.						</p>					</li>					<li>						<strong>Security</strong>						<p>							Company uses appropriate administrative, technical, and physical security measures to protect Required Contact Information. 						</p>					</li>					<li>						<strong>Changes to this Privacy Statement</strong>						<p>							Company reserves the right to change this Privacy Statement. Company will post any amended version(s) of this Privacy Statement on the Company''s Web site. You should review this Privacy Statement from time to time to ensure that you are comfortable with any changes the Company may make. 						</p>					</li>					<li>						<strong>Contacting Us</strong>						<p>							Questions regarding this Privacy Statement or the information practices of the Company''s Web site should be directed to: <a href="mailto:AMA@@ntti3.com">AMA@@ntti3.com</a>.						</p>						</li>				</ol>				<p style="float: right;; margin-top: 3em;; font-size: 1.3em;;">Effective Date of this Privacy Statement: March 10, 2014.</p>			</section>			<div class="clear"></div>		</div>	</article>',
NOW()),
(2,1,'Main Page',0,1,'Main Page','/',
'<h1>Creating a connected world</h1><p>At NTT we believe that creating a connected world will make a better world for everyone and clouds are part of that connecting journey.</p><p>Our clouds already connect countries, governments, businesses and people. Our clouds are transforming healthcare, education, energy and businesses of all shapes and sizes. Our clouds are connecting people, devices and data leading to revolutionary changes in how we see and interact with the world around us.</p>',
NOW());

# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table content_directory;

drop table product_content;

drop table question;

drop table web_page_content;

SET FOREIGN_KEY_CHECKS=1;

