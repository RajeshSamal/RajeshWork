package models;

import com.google.common.collect.Lists;
import com.ntti3.gumsapp.models.OpCo;
import helpers.DatabaseHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.db.ebean.Model;
import play.test.FakeApplication;

import javax.persistence.PersistenceException;

import java.util.List;
import java.util.concurrent.Semaphore;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
public class OpCoTest {
    private String opcoUid = "testOpcoUid";
    private String opcoName = "testOpco";

    private FakeApplication app;

    @After
    public void after() {
        stop(app);
    }

    @Before
    public void before() {
        app = DatabaseHelper.fakeApp(null);
        start(app);
    }

    @Test
    public void testGetOrRegister() throws Exception {
        OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
        assertEquals(opco.getOpcoName(), opcoName);
        assertEquals(opco.getOpcoUid(), opcoUid);
    }

    @Test
    public void doubleGetOrRegister() throws Exception {
        OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
        assertEquals(opco.getOpcoName(), opcoName);
        assertEquals(opco.getOpcoUid(), opcoUid);
        opco = OpCo.getOrRegister(opcoUid, opcoName);
        assertEquals(opco.getOpcoName(), opcoName);
        assertEquals(opco.getOpcoUid(), opcoUid);
    }

    @Test
    public void nameUpdate() throws Exception {
        OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
        assertEquals(opco.getOpcoName(), opcoName);
        assertEquals(opco.getOpcoUid(), opcoUid);

        Model.Finder<String, OpCo> finder = new Model.Finder<>(String.class, OpCo.class);
        opco = finder.byId(opcoUid);
        assertEquals(opco.getOpcoName(), opcoName);
        assertEquals(opco.getOpcoUid(), opcoUid);

        OpCo.getOrRegister(opcoUid, "name2");
        opco.refresh();
        assertEquals("name2", opco.getOpcoName());
    }


    private class MyUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
        private Throwable last = null;

        @Override
        public void uncaughtException(Thread t, Throwable e) {
            last = e;
        }

        public void checkExceptions() throws Throwable {
            if (last != null) {
                throw last;
            }
        }
    }

    @Test
    public void massiveAttack() throws Throwable {
        int numThreads = 100;
        final Semaphore sem = new Semaphore(0);
        List<Thread> threads = Lists.newArrayList();
        MyUncaughtExceptionHandler ueh = new MyUncaughtExceptionHandler();

        for (int i = 0; i < numThreads; i++) {
            Thread t = new Thread() {
                @Override
                public void run() {
                    try {
                        sem.acquire();
                    } catch (InterruptedException ex) {
                        fail(ex.toString());
                    }
                    OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
                    assertEquals(opco.getOpcoName(), opcoName);
                    assertEquals(opco.getOpcoUid(), opcoUid);
                }
            };

            t.setUncaughtExceptionHandler(ueh);

            threads.add(t);
            t.start();
        }

        sem.release(100);

        for (Thread t : threads) {
            t.join();
        }
        ueh.checkExceptions();
    }

    @Test
    public void getById() {
        OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
        assertNotNull(OpCo.getById(opcoUid));
    }

    @Test(expected = PersistenceException.class)
    public void registerTwice() {
        OpCo opco = new OpCo(opcoUid, opcoName);
        opco.save();
        opco = new OpCo(opcoUid, opcoName);
        opco.save();
    }
}
