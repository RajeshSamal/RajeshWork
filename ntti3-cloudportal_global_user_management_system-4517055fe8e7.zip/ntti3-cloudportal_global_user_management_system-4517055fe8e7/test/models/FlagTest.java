package models;

import com.ntti3.gumsapp.models.Flag;
import helpers.DatabaseHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.db.ebean.Model;
import play.test.FakeApplication;

import javax.persistence.PersistenceException;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.TestCase.assertNull;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

public class FlagTest {

    private FakeApplication application;

    @Before
    public void setUp() throws Exception {
        application = DatabaseHelper.fakeApp(null);
        start(application);
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void registerFlag() {
        Flag.registerFlag("test");

        Model.Finder<Integer, Flag> finder = new Model.Finder<>(Integer.class, Flag.class);
        assertNotNull(finder.where().eq("name", "test").findUnique());
    }

    @Test(expected = PersistenceException.class)
    public void registerExistingFlag() {
        Flag.registerFlag("test");
        Flag.registerFlag("test");
    }

    @Test
    public void getByName() {
        assertNull(Flag.getByName("xyzzy"));
    }
}
