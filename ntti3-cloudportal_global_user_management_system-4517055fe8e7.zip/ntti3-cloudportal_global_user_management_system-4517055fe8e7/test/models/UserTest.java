package models;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ntti3.gumsapp.models.Company;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.models.UserNotFoundException;
import helpers.DatabaseHelper;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.test.FakeApplication;

import javax.annotation.Nullable;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.TestCase.assertTrue;
import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

public class UserTest {
    OpCo opco;
    FakeApplication app;

    @After
    public void after() {
        stop(app);
    }

    @Before
    public void before() {
        app = DatabaseHelper.fakeApp(null);
        start(app);

        opco = OpCo.getOrRegister("testOpco", "testOpcoName");
    }

    private User insertStandardUser() {
        return User.getOrRegister("firstName", "lastName", "email@example.com", "testOpco", "testOpcoName",
                "testUUid", "testCUid", "testCompanyName", Lists.newArrayList("admin"));
    }

    @Test
    public void testGetOrRegister() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.com", "testOpco", "testOpcoName",
                "testUUid", "testCUid", "testCompanyName", null);

        TestCase.assertEquals("firstName", user.getFirstName());
        TestCase.assertEquals("lastName", user.getLastName());
        assertEquals("email@example.com", user.getEmail());
        assertEquals("testUUid", user.getOpcoUUid());
        assertEquals("testCompanyName", user.getCompany().getOpcoCName());
        assertNotNull(user.getCompany());
        assertEquals("testCUid", user.getCompany().getOpcoCUid());
        assertEquals("testOpco", user.getCompany().getOpco().getOpcoUid());
        assertEquals("testOpcoName", user.getCompany().getOpco().getOpcoName());
        TestCase.assertEquals(true, user.isActive());
        TestCase.assertNotNull(user.getGuid());
    }

    @Test
    public void testGetOrRegisterNullCompany() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.com", "testOpco", "testOpcoName",
                "testUUid", null, null, null);

        TestCase.assertEquals("firstName", user.getFirstName());
        TestCase.assertEquals("lastName", user.getLastName());
        assertEquals("email@example.com", user.getEmail());
        assertEquals("testUUid", user.getOpcoUUid());
        assertNotNull(user.getCompany());
        assertEquals("testOpco", user.getCompany().getOpco().getOpcoUid());
        assertEquals("testOpcoName", user.getCompany().getOpco().getOpcoName());
        TestCase.assertEquals(true, user.isActive());
        TestCase.assertNotNull(user.getGuid());
    }

    @Test
    public void testGetOrRegisterAdmin() throws Exception {
        User user = insertStandardUser();

        TestCase.assertEquals("firstName", user.getFirstName());
        TestCase.assertEquals("lastName", user.getLastName());
        assertEquals("email@example.com", user.getEmail());
        assertEquals("testUUid", user.getOpcoUUid());
        assertEquals("testCompanyName", user.getCompany().getOpcoCName());
        assertNotNull(user.getCompany());
        assertEquals("testCUid", user.getCompany().getOpcoCUid());
        assertEquals("testOpco", user.getCompany().getOpco().getOpcoUid());
        assertEquals("testOpcoName", user.getCompany().getOpco().getOpcoName());
        TestCase.assertNotNull(user.getGuid());

        User u2 = User.getByGUID(user.getGuid());
        assertThat(u2.getFlagsAsStrings()).contains("admin");
    }


    @Test
    public void testGetGuidFor() throws Exception {
        User user = insertStandardUser();
        UUID guid = User.getGuidFor("testOpco", "testUUid");
        TestCase.assertNotNull(guid);
        assertEquals(guid, user.getGuid());
    }

    @Test(expected = UserNotFoundException.class)
    public void testGetGuidForNx() throws Exception {
        User.getGuidFor("a", "a");
    }

    @Test
    public void productList() throws Exception {
        User user = insertStandardUser();

        TestCase.assertEquals("firstName", user.getFirstName());
        TestCase.assertEquals("lastName", user.getLastName());
        assertEquals("email@example.com", user.getEmail());
        assertEquals("testUUid", user.getOpcoUUid());
        assertEquals("testCompanyName", user.getCompany().getOpcoCName());
        assertNotNull(user.getCompany());
        assertEquals("testCUid", user.getCompany().getOpcoCUid());
        assertEquals("testOpco", user.getCompany().getOpco().getOpcoUid());
        assertEquals("testOpcoName", user.getCompany().getOpco().getOpcoName());
        TestCase.assertNotNull(user.getGuid());

        Product.registerProduct("testProduct1");
        Product.registerProduct("testProduct2");
        
        user.getProducts().add(Product.getByName("testProduct1"));
        user.saveManyToManyAssociations("products");
        
        User u2 = User.getByGUID(user.getGuid());
        assertThat(u2.getProductsAsStrings()).containsExactly("testProduct1");
    }

    @Test
    public void testCreatedDate() throws Exception {
        Calendar before = Calendar.getInstance();
        before.add(Calendar.SECOND, -1);
        User user = insertStandardUser();
        user.refresh();
        Calendar after = Calendar.getInstance();
        after.add(Calendar.SECOND, 1);
        assertTrue(user.getAddedToGums().after(before));
        assertTrue(user.getAddedToGums().before(after));
    }

    @Test
    public void testUpdatedDate() throws Exception {
        User user = insertStandardUser();
        user.refresh();

        Calendar before = Calendar.getInstance();
        before.add(Calendar.SECOND, -1);

        user.setFirstName("Moses");
        Ebean.save(user);
        user.refresh();

        Calendar after = Calendar.getInstance();
        after.add(Calendar.SECOND, 1);
        assertTrue(user.getUpdated().after(new Timestamp(before.getTimeInMillis())));
        assertTrue(user.getUpdated().before(new Timestamp(after.getTimeInMillis())));
    }

    @Test
    public void testUpdateDataFromAFP() throws Exception {
        User user = insertStandardUser();
        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid",
                "testCUid", "testCompanyName", null);

        user.refresh();
        TestCase.assertEquals("email@example.net", user.getEmail());
        assertThat(user.getFlags()).isEmpty();
    }

    @Test
    public void testUpdateDataFromAFPFlags() throws Exception {
        User user = insertStandardUser();
        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid",
                "testCUid", "testCompanyName", Lists.newArrayList("testFlag"));

        user.refresh();
        TestCase.assertEquals("email@example.net", user.getEmail());
        assertThat(user.getFlagsAsStrings()).containsExactly("testFlag");
    }

    @Test
    public void testUpdateDataFromAFPDisabled() throws Exception {
        User user = insertStandardUser();
        user.setOpcoUpdateable(false);
        user.save();
        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid",
                "testCUid", "testCompanyName", null);

        user.refresh();
        TestCase.assertEquals("email@example.com", user.getEmail());
    }

    @Test
    public void getUsersForOpCo() {
        UUID[] ids = {User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid1", "testCUid", "testCompanyName", null).getGuid(), User.getOrRegister("firstName",
                "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid2", "testCUid",
                "testCompanyName", null).getGuid(), User.getOrRegister("firstName", "lastName", "email@example.net",
                "testOpco", "testOpcoName", "testUUid3", "testCUid", "testCompanyName", null).getGuid(),
                User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                        "testUUid4", "testCUid", "testCompanyName", null).getGuid()};

        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco2", "testOpcoName2", "testUUid",
                "testCUid", "testCompanyName", null);

        QueryIterator<User> users = User.getUserIdsForOpCo(opco, null, null, null);


        List<UUID> gotGuids = Lists.newArrayList();
        while (users.hasNext()) {
            gotGuids.add(users.next().getGuid());
        }
        users.close();

        assertThat(gotGuids).contains(ids);
        assertThat(gotGuids).containsOnly(ids);
    }

    @Test
    public void getUsersForOpCoPaged() {
        UUID[] ids = {User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid1", "testCUid", "testCompanyName", null).getGuid(), User.getOrRegister("firstName",
                "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid2", "testCUid",
                "testCompanyName", null).getGuid(), User.getOrRegister("firstName", "lastName", "email@example.net",
                "testOpco", "testOpcoName", "testUUid3", "testCUid", "testCompanyName", null).getGuid(),
                User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                        "testUUid4", "testCUid", "testCompanyName", null).getGuid()};

        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco2", "testOpcoName2", "testUUid",
                "testCUid", "testCompanyName", null);

        QueryIterator<User> users = User.getUserIdsForOpCo(opco, 2, 2, null);

        Arrays.sort(ids, new Comparator<UUID>() {
            @Override
            public int compare(UUID o1, UUID o2) {
                return o1.toString().compareTo(o2.toString());
            }
        });
        List<UUID> gotGuids = Lists.newArrayList();
        while (users.hasNext()) {
            User user = users.next();
            gotGuids.add(user.getGuid());
        }
        users.close();

        assertThat(gotGuids).contains(Arrays.copyOfRange(ids, 2, 4));
        assertThat(gotGuids).containsOnly(Arrays.copyOfRange(ids, 2, 4));
    }

    @Test
    public void getUsersForCompany() {
        UUID[] ids = {User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid1", "testCUid", "testCompanyName", null).getGuid(), User.getOrRegister("firstName",
                "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid2", "testCUid",
                "testCompanyName", null).getGuid(), User.getOrRegister("firstName", "lastName", "email@example.net",
                "testOpco", "testOpcoName", "testUUid3", "testCUid", "testCompanyName", null).getGuid(),
                User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                        "testUUid4", "testCUid", "testCompanyName", null).getGuid()};

        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid",
                "testCUid66", "testCompanyName66", null);

        QueryIterator<User> users = User.getUserIdsForCompany(Company.getOrRegister(opco, "testCUid", "testOpcoName"),
                null, null, null);


        List<UUID> gotGuids = Lists.newArrayList();
        while (users.hasNext()) {
            gotGuids.add(users.next().getGuid());
        }
        users.close();

        assertThat(gotGuids).contains(ids);
        assertThat(gotGuids).containsOnly(ids);
    }

    @Test
    public void getUsersForCompanyPaged() {
        UUID[] ids = {User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid1", "testCUid", "testCompanyName", null).getGuid(), User.getOrRegister("firstName",
                "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid2", "testCUid",
                "testCompanyName", null).getGuid(), User.getOrRegister("firstName", "lastName", "email@example.net",
                "testOpco", "testOpcoName", "testUUid3", "testCUid", "testCompanyName", null).getGuid(),
                User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                        "testUUid4", "testCUid", "testCompanyName", null).getGuid()};

        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName", "testUUid",
                "testCUid66", "testCompanyName66", null);

        QueryIterator<User> users = User.getUserIdsForCompany(Company.getOrRegister(opco, "testCUid", "testOpcoName"),
                0, 2, null);

        Arrays.sort(ids, new Comparator<UUID>() {
            @Override
            public int compare(UUID o1, UUID o2) {
                return o1.toString().compareTo(o2.toString());
            }
        });

        List<UUID> gotGuids = Lists.newArrayList();
        while (users.hasNext()) {
            gotGuids.add(users.next().getGuid());
        }
        users.close();

        assertThat(gotGuids).containsOnly((Object[]) Arrays.copyOfRange(ids, 0, 2));
        assertThat(gotGuids).hasSize(2);
    }

    @Test
    public void testJsonFieldNames() throws JsonProcessingException {
        User u = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", null);

        ObjectMapper mapper = new ObjectMapper();

        String json = mapper.writeValueAsString(u);

        JsonNode obj = Json.parse(json);

        assertThat(Lists.newArrayList(obj.fieldNames())).contains("first_name", "last_name", "email", "active",
                "opco_uid", "opco_name", "opco_u_uid", "opco_c_uid", "opco_c_name", "company_guid", "flags",
                "products", "mobile_phone","active_in_opco");

        assertThat(Lists.newArrayList(obj.fieldNames())).containsOnly("first_name", "last_name", "email", "active",
                "opco_uid", "opco_name", "opco_u_uid", "opco_c_uid", "opco_c_name", "company_guid", "flags",
                "products", "mobile_phone","active_in_opco");
    }

    @Test
    public void testJsonFlagArray() throws JsonProcessingException {
        User u = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        ObjectMapper mapper = new ObjectMapper();

        String json = mapper.writeValueAsString(u);
        JsonNode obj = Json.parse(json);

        ArrayList<JsonNode> arr = Lists.newArrayList((obj.get("flags")).elements());
        assertThat(Lists.transform(arr, new Function<JsonNode, String>() {
            @Nullable
            @Override
            public String apply(@Nullable JsonNode input) {
                return input.asText();
            }
        })).containsExactly("testFlag");
    }


    @Test
    public void testJsonProductsArray() throws JsonProcessingException {
        User u = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Product.registerProduct("prod1");
        Product.registerProduct("prod2");
        
        u.getProducts().add(Product.getByName("prod1"));
        u.getProducts().add(Product.getByName("prod2"));
        u.saveManyToManyAssociations("products");

        ObjectMapper mapper = new ObjectMapper();

        String json = mapper.writeValueAsString(u);
        JsonNode obj = Json.parse(json);

        ArrayList<JsonNode> arr = Lists.newArrayList((obj.get("products")).elements());
        assertThat(Lists.transform(arr, new Function<JsonNode, String>() {
            @Nullable
            @Override
            public String apply(@Nullable JsonNode input) {
                return input.asText();
            }
        })).contains("prod1", "prod2");
    }

    @Test
    public void updateFromJson() throws IOException {
        User u = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        String json = "{\"first_name\" : \"Moses\"}";

        ObjectMapper mapper = new ObjectMapper();
        mapper.readerForUpdating(u).readValue(json);
        TestCase.assertEquals("Moses", u.getFirstName());
        TestCase.assertEquals("lastName", u.getLastName());
    }

}
