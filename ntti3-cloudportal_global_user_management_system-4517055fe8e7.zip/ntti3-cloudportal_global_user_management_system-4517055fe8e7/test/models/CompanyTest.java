package models;

import com.ntti3.gumsapp.models.Company;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.OpCoNotFoundException;
import helpers.DatabaseHelper;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.test.FakeApplication;

import javax.persistence.PersistenceException;

import java.util.UUID;

import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
public class CompanyTest {
    private FakeApplication app;
    private OpCo opco;

    @After
    public void after() {
        stop(app);
    }

    @Before
    public void before() {
        app = DatabaseHelper.fakeApp(null);
        start(app);

        opco = OpCo.getOrRegister("testOpco", "testOpcoName");
    }

    @Test
    public void testGetOrRegister() throws Exception {
        Company company = Company.getOrRegister(opco, "testCompanyId", "testCompanyName");
        assertEquals("testCompanyId", company.getOpcoCUid());
        assertEquals("testCompanyName", company.getOpcoCName());
        assertEquals("testOpco", company.getOpco().getOpcoUid());
    }


    @Test
    public void getOrRegisterChangeName() throws Exception {
        Company company = Company.getOrRegister(opco, "testCompanyId", "testCompanyName");
        assertEquals("testCompanyId", company.getOpcoCUid());
        assertEquals("testCompanyName", company.getOpcoCName());
        assertEquals("testOpco", company.getOpco().getOpcoUid());
        Company company2 = Company.getOrRegister(opco, "testCompanyId", "testCompanyName2");
        assertEquals("testCompanyName2", company2.getOpcoCName());
        company.refresh();
        assertEquals("testCompanyName2", company.getOpcoCName());
    }

    @Test
    public void getGuid() throws Exception {
        Company company = Company.getOrRegister(opco, "testCompanyId", "testCompanyName");
        UUID guid = Company.getCompanyGuid("testOpco", "testCompanyId");
        assertNotNull(company.getGuid());
        assertEquals(company.getGuid(), guid);
    }

    @Test(expected = PersistenceException.class)
    public void registerTwiceWithOpCo() throws Exception {
        Company company = new Company("testComapnyId", "testName", opco);
        company.save();
        company = new Company("testComapnyId", "testName2", opco);
        company.save();
    }

    @Test
    public void registerWithOpCoUid() throws Exception {
        Company c = Company.registerWithOpCoUid("testCompanyId", "testCompanyName", opco.getOpcoUid());
        Company c2 = Company.getById(c.getGuid());

        TestCase.assertEquals("testCompanyId", c2.getOpcoCUid());
        TestCase.assertEquals("testCompanyName", c2.getOpcoCName());
    }

    @Test(expected = PersistenceException.class)
    public void registerTwiceWithOpCoUid() throws Exception {
        Company.registerWithOpCoUid("testCompanyId", "testCompanyName", opco.getOpcoUid());
        Company.registerWithOpCoUid("testCompanyId", "testCompanyName", opco.getOpcoUid());
    }


    @Test(expected = OpCoNotFoundException.class)
    public void registerWithNXOpCo() throws Exception {
        Company.registerWithOpCoUid("testCompanyId", "testCompanyName", "324123957129573748926354821634898946" +
                                                                        "347289374190273490129074219037940433" +
                                                                        "423648326483242342342342423423423423" +
                                                                        "342423423423424234234234234234234234" +
                                                                        "234234234234234234234234234234234234" +
                                                                        "000000000000000000000000000000000000" +
                                                                        "000000000000000000000000000000000000" +
                                                                        "111111111111111111111111111111111111");
    }

    @Test
    public void registerWithNxOpCoCreate() throws Exception {
        Company.registerWithOpCoUid("testCompanyId", "testCompanyName", "opco2", "Mighty Opco 2");
        TestCase.assertEquals("Mighty Opco 2", OpCo.getById("opco2").getOpcoName());
    }
}
