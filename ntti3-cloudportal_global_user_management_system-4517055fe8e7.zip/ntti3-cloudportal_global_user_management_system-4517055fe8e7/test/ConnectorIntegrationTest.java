import com.avaje.ebean.Ebean;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ntti3.gums.DefaultGumsConnector;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.gums.Order;
import com.ntti3.gums.OrderBy;
import com.ntti3.gums.PagedResult;
import com.ntti3.gums.exceptions.GumsProtocolOpcoNotFoundException;
import com.ntti3.gums.models.Opco;
import com.ntti3.gums.models.RequestedPendingUser;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gumsapp.global.Global;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.Company;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.PendingUser;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.Role;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.models.UserProductRole;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.protocol.CloseableIOIterator;
import helpers.DatabaseHelper;
import org.fest.assertions.MapAssert;
import org.jodah.concurrentunit.Waiter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.test.TestServer;

import java.io.IOException;
import java.net.URI;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;
import static play.test.Helpers.testServer;
/**
 * @author jan.karwowski@ntti3.com
 */
public class ConnectorIntegrationTest {
    private play.test.FakeApplication app;
    private TestServer server;
    private OpCo opco1;
    private User user1;
    private Company company1;
    private GumsConnector connector;
    private UserRegistrationConnector mockUserRegistrationConnector;
    private MailingSystemConnector mailingSystemConnector;

    @Before
    public void setUp() throws Exception {
        int port = 3333;

        mockUserRegistrationConnector = mock(UserRegistrationConnector.class);
        mailingSystemConnector = mock(MailingSystemConnector.class);
        Map<String, UserRegistrationConnector> map = Maps.newHashMap();
        map.put("testOpco", mockUserRegistrationConnector);
        final OpcoUpdatersStore store = new OpcoUpdatersStore(map);
        Global global = new Global() {
            @Override
            protected OpcoUpdatersStore initOpcoUpdatersStore() {
                return store;
            }

            @Override
            protected MailingSystemConnector initMailSystem() throws Exception {
                return mailingSystemConnector;
            }
        };

        app = DatabaseHelper.fakeApp(global);
        server = testServer(port, app);

        start(server);

        Product.registerProduct("ama");

        user1 = User.getOrRegister("firstName", "lastName", "email@example.net", "345-345-345", "testOpco",
                "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        company1 = user1.getCompany();
        opco1 = company1.getOpco();
        //connector = new GumsConnector(new URI("https://gums.devntti3.com/"), "mykeystore.jks", "123456");
        connector = new DefaultGumsConnector(new URI("http://localhost:" + port + "/"), null);
    }

    @After
    public void tearDown() {
        stop(server);
    }

    @Test
    public void getUser() throws IOException, GumsProtocolException {
        com.ntti3.gums.models.User user = connector.getUser(user1.getGuid());
        assertEquals(user.getGuid(), user1.getGuid());
        assertEquals(user1.getFirstName(), user.getFirstName());
        assertEquals(user1.getLastName(), user.getLastName());
        assertEquals(user1.getEmail(), user.getEmail());
        assertEquals(user1.isActive(), user.isActive());
        assertEquals(user1.getMobilePhone(), user.getMobilePhone());
        assertEquals(user1.getCompany().getOpco().getOpcoUid(), user.getOpcoUid());
        assertEquals(user1.getCompany().getOpco().getOpcoName(), user.getOpcoName());
        assertEquals(user1.getCompany().getOpcoCUid(), user.getOpcoCUid());
        assertEquals(user1.getCompany().getOpcoCName(), user.getOpcoCName());
        assertThat(user.getProducts()).isEmpty();
        assertThat(user.getFlags()).containsExactly("testFlag");
    }

    @Test(expected = GumsProtocolExceptionWithErrorResponse.class)
    public void getNxUser() throws Exception {
        com.ntti3.gums.models.User user = connector.getUser(UUID.fromString
                ("25892e17-80f6-415f-9c65-7395632f0223"));
    }

    @Test
    public void registerUserWCompany() throws IOException, GumsProtocolException {
        UUID guid = connector.getOrRegisterUser("Moses", "Smith", "email@email.pl", "opco2", "Opco 2", "moses1",
                "company1", "Company 1", Lists.newArrayList("flag1", "flag2"));

        OpCo opco = OpCo.getById("opco2");
        assertNotNull(opco);
        assertEquals("Opco 2", opco.getOpcoName());

        User user = User.getByGUID(guid);
        assertEquals("Moses", user.getFirstName());
        assertEquals("Smith", user.getLastName());
        assertEquals("email@email.pl", user.getEmail());
        assertEquals("moses1", user.getOpcoUUid());
        Company company = user.getCompany();
        assertEquals("company1", company.getOpcoCUid());
        assertEquals("Company 1", company.getOpcoCName());

        assertThat(user.getFlagsAsStrings()).contains("flag1", "flag2");
    }

    @Test
    public void registerUserWMobile() throws IOException, GumsProtocolException {
        UUID guid = connector.getOrRegisterUser("Moses", "Smith", "email@email.pl", "5555-555-555",
                "opco2", "Opco 2", "moses1",
                "company1", "Company 1", Lists.newArrayList("flag1", "flag2"));

        OpCo opco = OpCo.getById("opco2");
        assertNotNull(opco);
        assertEquals("Opco 2", opco.getOpcoName());

        User user = User.getByGUID(guid);
        assertEquals("Moses", user.getFirstName());
        assertEquals("Smith", user.getLastName());
        assertEquals("email@email.pl", user.getEmail());
        assertEquals("moses1", user.getOpcoUUid());
        assertEquals("5555-555-555", user.getMobilePhone());
        Company company = user.getCompany();
        assertEquals("company1", company.getOpcoCUid());
        assertEquals("Company 1", company.getOpcoCName());

        assertThat(user.getFlagsAsStrings()).contains("flag1", "flag2");
    }


    @Test
    public void registerUserWoCompany() throws IOException, GumsProtocolException {
        UUID guid = connector.getOrRegisterUser("Moses", "Smith", "email@email.pl", "opco2", "Opco 2", "moses1",
                null, null, Lists.newArrayList("flag1", "flag2"));

        OpCo opco = OpCo.getById("opco2");
        assertNotNull(opco);
        assertEquals("Opco 2", opco.getOpcoName());

        User user = User.getByGUID(guid);
        assertEquals("Moses", user.getFirstName());
        assertEquals("Smith", user.getLastName());
        assertEquals("email@email.pl", user.getEmail());
        assertEquals("moses1", user.getOpcoUUid());
        Company company = user.getCompany();
        assertNotNull(company);

        assertThat(user.getFlagsAsStrings()).contains("flag1", "flag2");
    }

    @Test
    public void changeUserData() throws Exception {
        com.ntti3.gums.models.User user = connector.getUser(user1.getGuid());
        user.setFirstName("Aaron");
        user.setFlags(Lists.newArrayList("flag1", "flag2", "flag3"));
        connector.updateUserData(user);

        user1.refresh();
        assertEquals("Aaron", user1.getFirstName());
        assertThat(user1.getFlagsAsStrings()).containsOnly("flag1", "flag2", "flag3");
    }


    @Test
    public void changeUserDataUtf() throws Exception {
        com.ntti3.gums.models.User user = connector.getUser(user1.getGuid());
        user.setFirstName("Ąąron");
        user.setMobilePhone("555-543-543");
        user.setFlags(Lists.newArrayList("flag1", "flag2", "flag3"));
        connector.updateUserData(user);

        user1.refresh();
        assertEquals("Ąąron", user1.getFirstName());
        assertEquals("555-543-543", user1.getMobilePhone());
        assertThat(user1.getFlagsAsStrings()).containsOnly("flag1", "flag2", "flag3");
    }

    @Test
    public void readUserWhitelist() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");
        
        user1.getProducts().add(p1);
        user1.getProducts().add(p2);
        user1.saveManyToManyAssociations("products");

        List<String> bl = connector.getUserProductWhitelist(user1.getGuid());
        assertThat(bl).contains("prod1", "prod2");
        assertThat(bl).containsOnly("prod1", "prod2");
    }

    @Test
    public void setUserWhitelist() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");
        user1.getProducts().add(p1);
        user1.saveManyToManyAssociations("products");
        connector.setUserProductWhitelist(user1.getGuid(), Lists.newArrayList("prod2"));
        List<String> bl = User.getByGUID(user1.getGuid()).getProductsAsStrings();
        assertThat(bl).containsExactly("prod2");
    }

    @Test
    public void isInUserWhitelistTrue() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");
        user1.getProducts().add(p1);
        user1.saveManyToManyAssociations("products");

        assertTrue(connector.isProductInUserWhitelist(user1.getGuid(), "prod1"));
    }

    @Test
    public void isInUserWhitelistFalse() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");
        user1.getProducts().add(p1);
        user1.saveManyToManyAssociations("products");

        assertFalse(connector.isProductInUserWhitelist(user1.getGuid(), "prod2"));
    }

    @Test
    public void addProductToUserWhitelist() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");

        connector.addProductToUserWhitelist(user1.getGuid(), "prod2");

        assertThat(User.getByGUID(user1.getGuid()).getProductsAsStrings()).containsExactly("prod2");
    }

    @Test
    public void removeProductFromUserWhitelist() throws Exception {
        Product p1 = Product.registerProduct("prod1");
        Product p2 = Product.registerProduct("prod2");

        user1.getProducts().add(p1);
        user1.getProducts().add(p2);
        user1.saveManyToManyAssociations("products");

        connector.removeProductFromUserWhitelist(user1.getGuid(), "prod1");

        assertThat(User.getByGUID(user1.getGuid()).getProductsAsStrings()).containsExactly("prod2");
    }

    @Test
    public void getGuidTest() throws Exception {
        assertEquals(user1.getGuid(), connector.getUserGuid(user1.getOpcoUid(), user1.getOpcoUUid()));
    }

    @Test
    public void getCompanyTest() throws Exception {
        com.ntti3.gums.models.Company company = connector.getCompany(company1.getGuid());

        assertEquals(company1.getGuid(), company.getCompanyGuid());
        assertEquals(company1.getOpcoCName(), company.getOpcoCName());
        assertEquals(company1.getOpcoCUid(), company.getOpcoCUid());
        assertEquals(company1.getOpco().getOpcoUid(), company.getOpcoUid());
    }

    @Test
    public void updateCompanyTest() throws Exception {
        com.ntti3.gums.models.Company company = new com.ntti3.gums.models.Company(company1.getGuid
                (), "newuid",
                "New Name", company1.getOpcoUid());

        connector.updateCompany(company);
        company1.refresh();
        assertEquals("newuid", company1.getOpcoCUid());
        assertEquals("New Name", company1.getOpcoCName());
    }

    @Test
    public void addCompanyTest() throws Exception {
        UUID guid = connector.addCompany("company__", "CoMpAnY", opco1.getOpcoUid());

        Company company = Company.getById(guid);
        assertEquals("company__", company.getOpcoCUid());
        assertEquals("CoMpAnY", company.getOpcoCName());
        assertEquals(opco1.getOpcoUid(), company.getOpco().getOpcoUid());
    }

    @Test
    public void getCompanyUsers() throws Exception {
        User u1 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        PagedResult<UUID> pagedResult = connector.getCompanyUsers(company1.getGuid(), null, null, null);
        CloseableIOIterator<UUID> iterator = pagedResult.getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertEquals(5, pagedResult.getAllResultsCount());
        assertThat(uids).contains(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
        assertThat(uids).containsOnly(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
    }

    @Test
    public void getCompanyUsersPaged() throws Exception {
        User u1 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        PagedResult<UUID> companyUsers = connector.getCompanyUsers(company1.getGuid(), 0, 1, null);
        CloseableIOIterator<UUID> iterator = companyUsers.getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        List<UUID> users = Lists.newArrayList(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
        Collections.sort(users, new Comparator<UUID>() {
            @Override
            public int compare(UUID o1, UUID o2) {
                return o1.toString().compareTo(o2.toString());
            }
        });

        assertThat(uids).contains(users.get(0));
        assertThat(uids).hasSize(1);
        assertEquals(5, companyUsers.getAllResultsCount());
    }

    @Test
    public void addOpco() throws Exception {
        connector.addOpco("opco33", "OPCO 33 Name");

        OpCo opco = OpCo.getById("opco33");
        assertEquals("OPCO 33 Name", opco.getOpcoName());
    }

    @Test
    public void updateOpCo() throws Exception {
        com.ntti3.gums.models.Opco opco = new Opco(opco1.getOpcoUid(), "new name");
        connector.updateOpco(opco);
        opco1.refresh();
        assertEquals("new name", opco1.getOpcoName());
    }

    @Test
    public void getOpCo() throws Exception {
        Opco opco = connector.getOpco(opco1.getOpcoUid());

        assertEquals(opco1.getOpcoUid(), opco.getOpcoUid());
        assertEquals(opco1.getOpcoName(), opco.getOpcoName());
    }

    @Test
    public void getOpcoUsers() throws Exception {
        User u1 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getOpcoUsers(opco1.getOpcoUid(), null, null,
                null).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).contains(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
        assertThat(uids).containsOnly(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
    }


    @Test
    public void getOpcoUsersOrder() throws Exception {
        User u1 = User.getOrRegister("firstName", "alastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("firstName", "clastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("firstName", "blastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("firstName", "dlastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getOpcoUsers(opco1.getOpcoUid(), null, null, new OrderBy(
                "lastName", Order.ASC
        )).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).containsExactly(u1.getGuid(), u3.getGuid(), u2.getGuid(), u4.getGuid(), user1.getGuid());
    }
    
    @Test
    public void getOpcoPendingUsers() throws Exception {
        PendingUser u1 = createPendingUser("u1", opco1.getOpcoUid());
        PendingUser u2 = createPendingUser("u2", opco1.getOpcoUid());
        PendingUser u3 = createPendingUser("u3", opco1.getOpcoUid());
        PendingUser u4 = createPendingUser("u4", opco1.getOpcoUid());
        
        CloseableIOIterator<Integer> iterator = connector.getOpcoPendingUsers(opco1.getOpcoUid(), null, null,
                null).getResultPage();

        List<Integer> ids = Lists.newArrayList();
        while (iterator.hasNext()) {
            ids.add(iterator.next());
        }
        iterator.close();

        assertThat(ids).contains(u1.getId(), u2.getId(), u3.getId(), u4.getId());
        assertThat(ids).containsOnly(u1.getId(), u2.getId(), u3.getId(), u4.getId());
    }


    @Test
    public void getOpcoPendinUsersOrder() throws Exception {
        PendingUser u1 = createPendingUser("a", opco1.getOpcoUid());
        PendingUser u2 = createPendingUser("c", opco1.getOpcoUid());
        PendingUser u3 = createPendingUser("b", opco1.getOpcoUid());
        PendingUser u4 = createPendingUser("d", opco1.getOpcoUid());

        CloseableIOIterator<Integer> iterator = connector.getOpcoPendingUsers(opco1.getOpcoUid(), null, null, new OrderBy(
                "opcoUUid", Order.ASC
        )).getResultPage();

        List<Integer> ids = Lists.newArrayList();
        while (iterator.hasNext()) {
            ids.add(iterator.next());
        }
        iterator.close();

        assertThat(ids).containsExactly(u1.getId(), u3.getId(), u2.getId(), u4.getId());
    }

    @Test
    public void getUsers() throws Exception {
        User u1 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getUsers(null, null, null).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).contains(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
        assertThat(uids).containsOnly(u1.getGuid(), u2.getGuid(), u3.getGuid(), u4.getGuid(), user1.getGuid());
    }

    @Test
    public void getUsersOrder() throws Exception {
        User u1 = User.getOrRegister("afirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("dfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("bfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("cfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getUsers(null, null, new OrderBy("firstName",
                Order.ASC)).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).containsExactly(u1.getGuid(), u3.getGuid(), u4.getGuid(), u2.getGuid(), user1.getGuid());
    }

    @Test
    public void getUsersOrderPaging() throws Exception {
        User u1 = User.getOrRegister("afirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("dfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("bfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("cfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getUsers(2, 2, new OrderBy("firstName",
                Order.ASC)).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).containsExactly(u4.getGuid(), u2.getGuid());
    }

    @Test(expected = GumsProtocolException.class)
    public void getUsersBadOrder() throws Exception {
        User u1 = User.getOrRegister("afirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u2 = User.getOrRegister("dfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u3 = User.getOrRegister("bfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User u4 = User.getOrRegister("cfirstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);

        CloseableIOIterator<UUID> iterator = connector.getUsers(null, null, new OrderBy("opcoCName",
                Order.ASC)).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        assertThat(uids).containsExactly(u1.getGuid(), u3.getGuid(), u4.getGuid(), u2.getGuid(), user1.getGuid());
    }

    @Test
    public void getProducts() throws Exception {
        assertThat(connector.getProducts()).containsExactly("ama");
    }


    @Test
    public void flagsProducts() throws Exception {
        assertThat(connector.getFlags()).containsExactly("testFlag");
    }

    @Test
    public void getOpcoCompanies() throws Exception {
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                "c2", "c2", null);

        CloseableIOIterator<UUID> iterator = connector.getOpcoCompanies(opco1.getOpcoUid(), null, null,
                null).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        Company company = Company.getById(Company.getCompanyGuid(opco1.getOpcoUid(), "c2"));

        assertThat(uids).contains(company1.getGuid(), company.getGuid());
        assertThat(uids).containsOnly(company1.getGuid(), company.getGuid());
    }


    @Test
    public void getOpcoCompaniesOrder() throws Exception {
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                "c2", "c2", null);

        CloseableIOIterator<UUID> iterator = connector.getOpcoCompanies(opco1.getOpcoUid(), null, null,
                new OrderBy("opcoCName", Order.ASC)).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        Company company = Company.getById(Company.getCompanyGuid(opco1.getOpcoUid(), "c2"));

        assertThat(uids).containsExactly(company.getGuid(), company1.getGuid());
    }

    public void getOpcoCompaniesOrderLimit() throws Exception {
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid1",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid2",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid3",
                company1.getOpcoCUid(), company1.getOpcoCName(), null);
        User.getOrRegister("firstName", "lastName", "email@email.com", opco1.getOpcoUid(),
                opco1.getOpcoName(), "uuid4",
                "c2", "c2", null);

        CloseableIOIterator<UUID> iterator = connector.getOpcoCompanies(opco1.getOpcoUid(), 1, 1,
                new OrderBy("opcoCName", Order.ASC)).getResultPage();

        List<UUID> uids = Lists.newArrayList();
        while (iterator.hasNext()) {
            uids.add(iterator.next());
        }
        iterator.close();

        Company company = Company.getById(Company.getCompanyGuid(opco1.getOpcoUid(), "c2"));

        assertThat(uids).containsExactly(company1.getGuid());
    }

    @Test
    public void concurrentConnectionTest() throws Throwable {
        List<Thread> threads = new LinkedList<>();
        try {
            final Waiter waiter = new Waiter();
            int threadNum = 100;


            for (int i = 0; i < threadNum; i++) {
                Thread thread = new Thread(new Runnable() {
                    public void run() {
                        try {
                            connector.getUser(user1.getGuid());
                            waiter.resume();
                        } catch (Throwable e) {
                            //e.printStackTrace();
                            waiter.fail(e);
                        }
                    }
                });
                thread.start();
                threads.add(thread);
            }
            waiter.await(10000, threadNum);
            for (Thread t : threads) {
                while (true) {
                    try {
                        t.join();
                        break;
                    } catch (InterruptedException ex) {

                    }
                }
            }
        } finally {
            for (Thread t : threads) {
                t.stop();
            }
        }
    }

    @Test
    public void addUserProductRole() throws Exception {
        Product product = Product.registerProduct("banana");
        Role role = new Role("ad-min");
        role.save();

        connector.setUserProductRole(user1.getGuid(), product.getName(), role.getName());

        assertEquals(1, Ebean.find(UserProductRole.class).where().eq("role.id", role.getId())
                .eq("user.guid", user1.getGuid()).eq("product.id", product.getId()).findRowCount());
    }

    @Test
    public void updateUserProductRole() throws Exception {
        Product product = Product.registerProduct("banana");
        Role role = new Role("ad-min");
        role.save();

        Role role6 = new Role("ad-m-in");
        role6.save();

        new UserProductRole(product, user1, role6).save();

        connector.setUserProductRole(user1.getGuid(), product.getName(), role.getName());

        assertEquals(1, Ebean.find(UserProductRole.class).where().eq("role.id", role.getId())
                .eq("user.guid", user1.getGuid()).eq("product.id", product.getId()).findRowCount());
        assertEquals(1, Ebean.find(UserProductRole.class).where()
                .eq("user.guid", user1.getGuid()).eq("product.id", product.getId()).findRowCount());
    }


    @Test
    public void removeUserProductRole() throws Exception {
        Product product = Product.registerProduct("banana");
        Role role6 = new Role("ad-m-in");
        role6.save();
        new UserProductRole(product, user1, role6).save();
        connector.removeUserProductRole(user1.getGuid(), product.getName());

        assertEquals(0, Ebean.find(UserProductRole.class).where()
                .eq("user.guid", user1.getGuid()).eq("product.id", product.getId()).findRowCount());
    }

    @Test
    public void getUserProductRole() throws Exception {
        Product product = Product.registerProduct("banana");
        Role role6 = new Role("ad-m-in");
        role6.save();
        new UserProductRole(product, user1, role6).save();
        assertEquals(role6.getName(), connector.getUserProductRole(user1.getGuid(), product.getName()));
    }

    @Test
    public void getUserProductRoles() throws Exception {
        Product product = Product.registerProduct("banana");
        Product product2 = Product.registerProduct("pineapple");
        Role role6 = new Role("ad-m-in");
        role6.save();
        Role role5 = new Role("ad-min");
        role5.save();
        new UserProductRole(product, user1, role6).save();
        new UserProductRole(product2, user1, role5).save();
        Map<String, String> roles = connector.getUserRoles(user1.getGuid());
        assertThat(roles).hasSize(2);
        assertThat(roles).includes(MapAssert.entry(product.getName(), role6.getName()),
                MapAssert.entry(product2.getName(), role5.getName()));
    }

    @Test
    public void unlockUserTest() throws Exception {
        connector.unlock(user1.getGuid());
        verify(mockUserRegistrationConnector).unlockUser(user1.getOpcoUUid());
    }

    @Test
    public void setPassword() throws Exception {
        connector.setPassword(user1.getGuid(), "newPW");
        verify(mockUserRegistrationConnector).updatePassword(user1.getOpcoUUid(), "newPW");
    }

    @Test
    public void updatePasswordTrue() throws Exception {
        when(mockUserRegistrationConnector.updatePassword(user1.getOpcoUUid(), "oldPW", "newPW")).thenReturn(true);
        assertTrue(connector.updatePassword(user1.getGuid(), "oldPW", "newPW"));
        verify(mockUserRegistrationConnector).updatePassword(user1.getOpcoUUid(), "oldPW", "newPW");
    }

    @Test
    public void updatePasswordFalse() throws Exception {
        when(mockUserRegistrationConnector.updatePassword(user1.getOpcoUUid(), "oldPW", "newPW")).thenReturn(false);
        assertFalse(connector.updatePassword(user1.getGuid(), "oldPW", "newPW"));
        verify(mockUserRegistrationConnector).updatePassword(user1.getOpcoUUid(), "oldPW", "newPW");
    }

    @Test
    public void updateQuestionTrue() throws Exception {
        when(mockUserRegistrationConnector.updateRecoveryQuestion(user1.getOpcoUUid(), "oldPW", "q",
                "a")).thenReturn(true);
        assertTrue(connector.updateRecoveryQuestion(user1.getGuid(), "oldPW", "q", "a"));
        verify(mockUserRegistrationConnector).updateRecoveryQuestion(user1.getOpcoUUid(), "oldPW", "q", "a");
    }

    @Test
    public void updateQuestionFalze() throws Exception {
        when(mockUserRegistrationConnector.updateRecoveryQuestion(user1.getOpcoUUid(), "oldPW", "q",
                "a")).thenReturn(false);
        assertFalse(connector.updateRecoveryQuestion(user1.getGuid(), "oldPW", "q", "a"));
        verify(mockUserRegistrationConnector).updateRecoveryQuestion(user1.getOpcoUUid(), "oldPW", "q", "a");
    }

    @Test
    public void addPendingUser() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");

        RequestedPendingUser requestedPendingUser = new RequestedPendingUser();
        requestedPendingUser.setFirstName("Jack");
        requestedPendingUser.setLastName("Falcon");
        requestedPendingUser.setEmail("i.j.k@l.m.net");
        requestedPendingUser.setMobilePhone("555-666-666");
        requestedPendingUser.setOpcoUid("testOpco");
        requestedPendingUser.setOpcoUUid("i.j.k@l.m.net");
        requestedPendingUser.setPassword("pa");
        requestedPendingUser.setRecoveryQuestion("quaqua");
        requestedPendingUser.setRecoveryAnswer("weeeeeee. Ihaa!");
        requestedPendingUser.setAdditionalInfo("tomasz roda is watching you");
        requestedPendingUser.setOpcoCName("testOpco");

        int id = connector.addPendingUser(requestedPendingUser);

        PendingUser pendingUser = Ebean.find(PendingUser.class, id);
        assertNotNull(pendingUser);
        assertEquals("Jack", pendingUser.getFirstName());
    }

    @Test(expected = GumsProtocolOpcoNotFoundException.class)
    public void noAddPendingUser() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");

        RequestedPendingUser requestedPendingUser = new RequestedPendingUser();
        requestedPendingUser.setFirstName("Jack");
        requestedPendingUser.setLastName("Falcon");
        requestedPendingUser.setEmail("i.j.k@l.m.net");
        requestedPendingUser.setMobilePhone("555-666-666");
        requestedPendingUser.setOpcoUid("ymca");
        requestedPendingUser.setOpcoUUid("i.j.k@l.m.net");
        requestedPendingUser.setPassword("pa");
        requestedPendingUser.setRecoveryQuestion("quaqua");
        requestedPendingUser.setRecoveryAnswer("weeeeeee. Ihaa!");
        requestedPendingUser.setAdditionalInfo("tomasz roda is watching you");
        requestedPendingUser.setOpcoCName("testOpco");

        int id = connector.addPendingUser(requestedPendingUser);
    }

    @Test
    public void createUser() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");

        UUID id = connector.createUser("Jack", "Falcon", "i.j.k@l.m.net", "testOpco", "testOpco", "i.j.k@l.m.net", 
                "testOpco", "testOpco", "pa", "quaqua", "weeeeeee. Ihaa!", Lists.newArrayList("cheese", "toona"));

        User user = Ebean.find(User.class, id);
        assertNotNull(user);
        assertEquals("Jack", user.getFirstName());
    }

    @Test(expected = GumsProtocolOpcoNotFoundException.class)
    public void noCreateUser() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");


        UUID id = connector.createUser("Jack", "Falcon", "i.j.k@l.m.net", "ymca", "ymca", "i.j.k@l.m.net",
                    "testOpco", "testOpco", "pa", "quaqua", "weeeeeee. Ihaa!", Lists.newArrayList("cheese", "toona"));
    }
    
    @Test
    public void rejectUser() throws Exception {
        PendingUser u1 = createPendingUser("u1", "testOpco");
        
        connector.rejectUser(u1.getId());
        
        PendingUser user = Ebean.find(PendingUser.class, u1.getId());
        
        assertEquals(true, user.isRejected());
    }
    
    @Test
    public void activateUser() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");
        
        PendingUser u1 = createPendingUser("u1", "testOpco");
        
        UUID id = connector.activateUser(u1.getId(), Lists.newArrayList("cheese", "toona"), "testCompany", "testCompany");
        
        User user = Ebean.find(User.class, id);
        assertNotNull(user);
    }

    @Test
    public void getPendingUsers() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");

        PendingUser u1 = createPendingUser("u1", "testOpco");
        PendingUser u2 = createPendingUser("u2", "testOpco");

        PagedResult<Integer> result = connector.getPendingUsers(0, 0, null);

        assertEquals(2, result.getAllResultsCount());
        List<Integer> users = Lists.newArrayList();
        CloseableIOIterator<Integer> iterator = result.getResultPage();

        while (iterator.hasNext()) {
            users.add(iterator.next());
        }

        assertThat(users).contains(u1.getId(), u2.getId());
    }

    private PendingUser createPendingUser(String u1, String testOpco) {
        PendingUser pendingUser = new PendingUser();

        pendingUser.setEmail(u1 + "a@example.com");
        pendingUser.setFirstName("fN");
        pendingUser.setLastName("lN");
        pendingUser.setMobilePhone("555055054859037263423234634");
        pendingUser.setPassword("iii");
        pendingUser.setSecurityAnswer("ihaa");
        pendingUser.setSecurityQuestion("eaieeee");
        pendingUser.setOpcoUid(testOpco);
        pendingUser.setOpcoUUid(u1 + "a@example.com");
        pendingUser.setOpcoCName("testCompany");

        pendingUser.save();

        return pendingUser;
    }
    
    @Test
    public void removePendingUserTest() throws Exception {
        Product p1 = Product.registerProduct("cheese");
        Product p2 = Product.registerProduct("toona");

        PendingUser u2 = createPendingUser("u2", "testOpco");

        connector.removePendingUser(u2.getId());

        assertEquals(0, Ebean.find(PendingUser.class).where().eq("id", u2.getId()).findRowCount());
    }

    @Test
    public void getUpdateableOpcos() throws Exception {
        List<String> opcos = connector.getUpdateableOpcos();
        assertThat(opcos).containsExactly("testOpco");
    }

/*
    @Test
    public void addFlagToRealGums() throws Exception {
        GumsConnector connector = new GumsConnector(new URI("https://gums.devntti3.com/"), "mykeystore.jks", "123456");
        com.ntti3.gums.User user = connector.getUser(UUID.fromString
               ("31d00622-f4df-41ea-97d1-3b73d263faa5"));
        user.setFlags(Lists.newArrayList("admin", "opco_admin", "super_admin"));
        connector.updateUserData(user);
    }*/

}
