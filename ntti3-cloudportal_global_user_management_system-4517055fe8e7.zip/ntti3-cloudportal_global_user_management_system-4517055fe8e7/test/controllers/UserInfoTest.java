package controllers;

import com.avaje.ebean.Ebean;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gumsapp.global.Global;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.DataConstraints;
import com.ntti3.gumsapp.models.Flag;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.Role;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.models.UserProductRole;
import helpers.DatabaseHelper;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import static com.ntti3.gums.GumsProtocolConstants.EMAIL_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.FIRST_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.FLAGS_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.LAST_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_C_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_C_UID_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_UID_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_U_UID_PARAMETER;
import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.matches;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.header;
import static play.test.Helpers.start;
import static play.test.Helpers.status;
import static play.test.Helpers.stop;

public class UserInfoTest {
    private FakeApplication application;
    private UserRegistrationConnector mockConnector;


    @Before
    public void setUp() throws Exception {
        mockConnector = mock(UserRegistrationConnector.class);
        Map<String, UserRegistrationConnector> map = Maps.newHashMap();
        map.put("up_opco", mockConnector);
        final OpcoUpdatersStore store = new OpcoUpdatersStore(map);
        Global global = new Global() {
            @Override
            protected OpcoUpdatersStore initOpcoUpdatersStore() {
                return store;
            }
        };
        application = DatabaseHelper.fakeApp(global);
        start(application);
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void getUserTest() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getUser(user.getGuid()));
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        assertEquals(user.getFirstName(), node.get("first_name").asText());
        assertEquals(false, node.get("is_opco_editable").asBoolean());
    }


    @Test
    public void getOpcoEditableUserTest() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "up_opco", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getUser(user.getGuid()));
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        assertEquals(user.getFirstName(), node.get("first_name").asText());
        assertEquals(true, node.get("is_opco_editable").asBoolean());
    }

    @Test
    public void updateUserFieldTest() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        FakeRequest request = fakeRequest("PUT", "");
        Map<String, String> body = Maps.newHashMap();
        body.put("first_name", "Moses");
        request.withFormUrlEncodedBody(body);
        callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateUser(user.getGuid()), request);

        user.refresh();
        assertEquals("Moses", user.getFirstName());
    }

    @Test
    public void updateUserFieldTestValidationError() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        FakeRequest request = fakeRequest("PUT", "");
        Map<String, String> body = Maps.newHashMap();
        body.put("opco_u_uid", "ĄĄ///ĄĄĄ");
        Pattern pattern = Pattern.compile(DataConstraints.UID_PATTERN);
        assertFalse(pattern.matcher("ĄĄ///ĄĄĄ").matches());
        request.withFormUrlEncodedBody(body);
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateUser(user.getGuid()), request);
        //assertEquals(400, status(result));
        //JsonNode node = Json.parse(contentAsString(result));

        //assertEquals(2002, node.get("error").get("code").asInt());

        user.refresh();
        assertEquals("testUUid", user.getOpcoUUid());
    }

    @Test
    public void updateUserArrayTest() {
        Flag.registerFlag("pope");
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        FakeRequest request = fakeRequest("PUT", "");
        Map<String, String> body = Maps.newHashMap();
        body.put("flags", "pope");

        request.withFormUrlEncodedBody(body);
        callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateUser(user.getGuid()), request);

        user.refresh();
        assertThat(user.getFlagsAsStrings()).containsExactly("pope");
    }

    @Test
    public void getGuidTest() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getGuid(user.getOpcoUid(), user.getOpcoUUid()));
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        assertEquals(user.getGuid().toString(), node.get("guid").asText());
    }


    @Test
    public void registerTest() {
        FakeRequest request = fakeRequest("POST", "");
        Map<String, String> body = Maps.newHashMap();
        body.put(FIRST_NAME_PARAMETER, "firstName");
        body.put(LAST_NAME_PARAMETER, "lastName");
        body.put(EMAIL_PARAMETER, "email@example.com");
        body.put(OPCO_UID_PARAMETER, "opco");
        body.put(OPCO_NAME_PARAMETER, "opcoName");
        body.put(OPCO_U_UID_PARAMETER, "opcoUUid");
        body.put(OPCO_C_UID_PARAMETER, "opcoCUid");
        body.put(OPCO_C_NAME_PARAMETER, "opcoCName");
        body.put(FLAGS_PARAMETER, "white");
        request.withFormUrlEncodedBody(body);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.registerUser(), request);
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        User user = User.getByGUID(UUID.fromString(node.get("guid").asText()));
        assertEquals("opcoUUid", user.getOpcoUUid());
        assertThat(user.getFlagsAsStrings()).containsExactly("white");
    }

    @Test
    public void registerTestUnicode() {
        FakeRequest request = fakeRequest("POST", "");
        Map<String, String> body = Maps.newHashMap();
        body.put(FIRST_NAME_PARAMETER, "firstąĄąĄName");
        body.put(LAST_NAME_PARAMETER, "lastName");
        body.put(EMAIL_PARAMETER, "email@example.com");
        body.put(OPCO_UID_PARAMETER, "opco");
        body.put(OPCO_NAME_PARAMETER, "opcoName");
        body.put(OPCO_U_UID_PARAMETER, "opcoUUid");
        body.put(OPCO_C_UID_PARAMETER, "opcoCUid");
        body.put(OPCO_C_NAME_PARAMETER, "opcoCName");
        body.put(FLAGS_PARAMETER, "white");
        request.withFormUrlEncodedBody(body);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.registerUser(), request);
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        User user = User.getByGUID(UUID.fromString(node.get("guid").asText()));
        assertEquals("opcoUUid", user.getOpcoUUid());
        assertThat(user.getFlagsAsStrings()).containsExactly("white");
        TestCase.assertEquals("firstąĄąĄName", user.getFirstName());
    }

    @Test
    public void registerTestNullCompany() {
        FakeRequest request = fakeRequest("POST", "");
        Map<String, String> body = Maps.newHashMap();
        body.put(FIRST_NAME_PARAMETER, "firstName");
        body.put(LAST_NAME_PARAMETER, "lastName");
        body.put(EMAIL_PARAMETER, "email@example.com");
        body.put(OPCO_UID_PARAMETER, "opco");
        body.put(OPCO_NAME_PARAMETER, "opcoName");
        body.put(OPCO_U_UID_PARAMETER, "opcoUUid");
        body.put(FLAGS_PARAMETER, "white");
        request.withFormUrlEncodedBody(body);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.registerUser(), request);
        String s = contentAsString(result);
        JsonNode node = Json.parse(s);
        User user = User.getByGUID(UUID.fromString(node.get("guid").asText()));
        assertEquals("opcoUUid", user.getOpcoUUid());
        assertThat(user.getFlagsAsStrings()).containsExactly("white");
    }

    @Test
    public void getWhitelist() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Product.registerProduct("mlaas");
        Product.registerProduct("saalm");

        user.getProducts().add(Product.getByName("mlaas"));
        user.getProducts().add(Product.getByName("saalm"));
        user.saveManyToManyAssociations("products");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getProductWhiteList(user.getGuid()));
        JsonNode node = Json.parse(contentAsString(result));
        JsonNode node2 = node.get("whitelist");

        List<String> whitelist = Lists.transform(Lists.newArrayList(node2.elements()), new Function<JsonNode,
                String>() {
            @Override
            public String apply(JsonNode input) {
                return input.asText();
            }
        });

        assertThat(whitelist).contains("mlaas", "saalm");
        assertThat(whitelist).containsOnly("mlaas", "saalm");
    }

    @Test
    public void isInWhitelistTestYes() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Product.registerProduct("mlaas");

        user.getProducts().add(Product.getByName("mlaas"));
        user.saveManyToManyAssociations("products");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.isProductInWhiteList(user.getGuid(), "mlaas"));
        assertEquals(200, status(result));
    }


    @Test
    public void isInWhitelistTestNo() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Product.registerProduct("mlaas");
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.isProductInWhiteList(user.getGuid(), "mlaas"));
        assertEquals(404, status(result));
    }

    @Test
    public void addProductToWhitelist() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Product pro = Product.registerProduct("mlaas");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.addProductToWhiteList(user.getGuid(), "mlaas"));
        assertEquals(200, status(result));
        assertThat(User.getByGUID(user.getGuid()).getProducts()).contains(pro);
    }

    @Test
    public void removeFromWhitelistTestYes() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Product pro = Product.registerProduct("mlaas");
        user.getProducts().add(Product.getByName("mlaas"));
        user.saveManyToManyAssociations("products");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.removeProductFromWhiteList(user.getGuid(), "mlaas"));
        assertEquals(200, status(result));
        assertFalse(User.getByGUID(user.getGuid()).getProducts().contains(pro));
    }


    @Test
    public void removeFromWhitelistTestNo() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Product.registerProduct("mlaas");
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.removeProductFromWhiteList(user.getGuid(), "mlaas"));
        assertEquals(404, status(result));
    }

    @Test
    public void setProductWhitelist() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Product.registerProduct("mlaas");
        Product.registerProduct("saalm");

        user.getProducts().add(Product.getByName("mlaas"));
        user.saveManyToManyAssociations("products");

        FakeRequest request = fakeRequest();
        Map<String, String> body = Maps.newHashMap();
        body.put("whitelist", "saalm");
        request.withFormUrlEncodedBody(body);
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setProductWhiteList(user.getGuid()), request);

        assertEquals(200, status(result));
        
        List<String> bla = User.getByGUID(user.getGuid()).getProductsAsStrings();
        
        assertEquals(1, bla.size());
        assertEquals("saalm", bla.get(0));
    }

    @Test
    public void clearProductWhitelist() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Product.registerProduct("mlaas");
        Product.registerProduct("saalm");

        user.getProducts().add(Product.getByName("mlaas"));
        user.saveManyToManyAssociations("products");
        
        FakeRequest request = fakeRequest();
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setProductWhiteList(user.getGuid()), request);

        assertEquals(200, status(result));

        List<String> bla = User.getByGUID(user.getGuid()).getProductsAsStrings();
        
        assertEquals(0, bla.size());
    }


    @Test
    public void getUsers() {
        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid2", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getUsers(null, null));
        assertEquals("chunked", header("Transfer-Encoding", result));
    }

    @Test
    public void getRole() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Product product = Product.registerProduct("test8");

        new UserProductRole(product, user, role).save();

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getRole(user.getGuid(), product.getName())));
        JsonNode node = Json.parse(contentAsString(result));
        TestCase.assertEquals("bunny", node.get("role").asText());
    }

    @Test
    public void getNXRole() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Product product = Product.registerProduct("test8");


        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getRole(user.getGuid(), product.getName())));
        TestCase.assertEquals(404, status(result));
    }


    @Test
    public void getRoles() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");
        Product product2 = Product.registerProduct("test9");

        new UserProductRole(product, user, role).save();
        new UserProductRole(product2, user, role2).save();

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getRoles(user.getGuid())));

        JsonNode node = Json.parse(contentAsString(result));
        List<Map.Entry<String, String>> entries = Lists.transform(Lists.newArrayList(node.fields()),
                new Function<Map.Entry<String, JsonNode>, Map.Entry<String, String>>() {

                    @Override
                    public Map.Entry<String, String> apply(Map.Entry<String, JsonNode> input) {
                        return new AbstractMap.SimpleEntry<>(input.getKey(), input.getValue().asText());
                    }
                });

        assertThat(entries).contains(new AbstractMap.SimpleEntry<>(product.getName(), role.getName()),
                new AbstractMap.SimpleEntry<>(product2.getName(), role2.getName()));
        assertThat(entries).containsOnly(new AbstractMap.SimpleEntry<>(product.getName(), role.getName()),
                new AbstractMap.SimpleEntry<>(product2.getName(), role2.getName()));
    }


    @Test
    public void getEmptyRoles() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");
        Product product2 = Product.registerProduct("test9");

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.getRoles(user.getGuid())));

        JsonNode node = Json.parse(contentAsString(result));
        List<Map.Entry<String, String>> entries = Lists.transform(Lists.newArrayList(node.fields()),
                new Function<Map.Entry<String, JsonNode>, Map.Entry<String, String>>() {

                    @Override
                    public Map.Entry<String, String> apply(Map.Entry<String, JsonNode> input) {
                        return new AbstractMap.SimpleEntry<>(input.getKey(), input.getValue().asText());
                    }
                });

        assertThat(entries).isEmpty();
    }


    @Test
    public void setRole() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");
        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("role", role.getName());
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setRole(user.getGuid(), product.getName()), request);
        TestCase.assertEquals(200, status(result));
        TestCase.assertEquals(1, Ebean.find(UserProductRole.class).where().eq("user", user).eq("product", product)
                .eq("role", role).findRowCount());
    }

    @Test
    public void setRoleReplace() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");

        new UserProductRole(product, user, role).save();


        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("role", role2.getName());
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setRole(user.getGuid(), product.getName()), request);
        TestCase.assertEquals(200, status(result));
        TestCase.assertEquals(1, Ebean.find(UserProductRole.class).where().eq("user", user).eq("product", product)
                .eq("role", role2).findRowCount());
        TestCase.assertEquals(1, Ebean.find(UserProductRole.class).where().eq("user", user).eq("product", product)
                .findRowCount());
    }

    @Test
    public void setRoleNXUser() {
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");


        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("role", role.getName());
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setRole(new UUID(0, 0), product.getName()), request);
        TestCase.assertEquals(404, status(result));
    }

    @Test
    public void setRoleNXProduct() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");


        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("role", role.getName());
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setRole(user.getGuid(), "servants-and-slaves"), request);
        TestCase.assertEquals(404, status(result));
    }

    @Test
    public void setRoleNXRole() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Role role2 = new Role("rabbit");
        role2.save();
        Product product = Product.registerProduct("test8");


        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("role", "omega-male");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.setRole(user.getGuid(), product.getName()), request);
        TestCase.assertEquals(404, status(result));
    }

    @Test
    public void removeRole() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Product product = Product.registerProduct("test8");

        new UserProductRole(product, user, role).save();

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.removeRole(user.getGuid(), product.getName())));
        assertEquals(200, status(result));

        TestCase.assertEquals(0, Ebean.find(UserProductRole.class).where().eq("user", user).eq("product", product)
                .eq("role", role).findRowCount());
    }

    @Test
    public void removeRoleNXUser() {
        Role role = new Role("bunny");
        role.save();
        Product product = Product.registerProduct("test8");

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.removeRole(new UUID(0, 0), product.getName())));
        assertEquals(200, status(result));
    }

    @Test
    public void removeRoleNXProduct() {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
        Role role = new Role("bunny");
        role.save();
        Product product = Product.registerProduct("test8");

        new UserProductRole(product, user, role).save();

        Result result = callAction((com.ntti3.gumsapp.controllers.routes.ref.UserInfo.removeRole(user.getGuid(), "test5")));
        assertEquals(200, status(result));

        TestCase.assertEquals(1, Ebean.find(UserProductRole.class).where().eq("user", user).eq("product", product)
                .eq("role", role).findRowCount());
    }

    @Test
    public void changePasswordUserTest() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updatePassword(matches("testUUid"), matches("opw"), anyString())).thenReturn(true);

        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("old_password", "opw");
        requestParams.put("new_password", "npw");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updatePassword(user.getGuid()), request);
        assertEquals(200, status(result));

        verify(mockConnector).updatePassword("testUUid", "opw", "npw");
    }

    @Test
    public void changePasswordUserTestBadOpco() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updatePassword(matches("testUUid"), matches("opw"), anyString())).thenReturn(true);


        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("old_password", "opw");
        requestParams.put("new_password", "npw");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updatePassword(user.getGuid()), request);
        assertEquals(400, status(result));
    }

    @Test
    public void changeQuestionUserTest() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updateRecoveryQuestion(matches("testUUid"), matches("opw"), anyString(),
                anyString())).thenReturn(true);

        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("old_password", "opw");
        requestParams.put("recovery_question", "q");
        requestParams.put("recovery_answer", "a");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateRecoveryQuestion(user.getGuid()), request);
        assertEquals(200, status(result));

        verify(mockConnector).updateRecoveryQuestion("testUUid", "opw", "q", "a");
    }

    //
    @Test
    public void changeQuestionUserTestBadOpco() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updateRecoveryQuestion(matches("testUUid"), matches("opw"), anyString(),
                anyString())).thenReturn(true);

        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("password", "opw");
        requestParams.put("recovery_question", "q");
        requestParams.put("recovery_answer", "a");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateRecoveryQuestion(user.getGuid()), request);
        assertEquals(400, status(result));
    }

    @Test
    public void changeBadPasswordUserTest() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updatePassword(matches("testUUid"), matches("opw"), anyString())).thenReturn(false);

        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("old_password", "opw");
        requestParams.put("new_password", "npw");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updatePassword(user.getGuid()), request);

        assertEquals(401, status(result));

        verify(mockConnector).updatePassword("testUUid", "opw", "npw");
    }

    @Test
    public void changeBadPasswordQuestionUserTest() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        when(mockConnector.updateRecoveryQuestion(matches("testUUid"), matches("opw"), anyString(),
                anyString())).thenReturn(false);

        FakeRequest request = fakeRequest();
        Map<String, String> requestParams = Maps.newHashMap();
        requestParams.put("old_password", "opw");
        requestParams.put("recovery_question", "q");
        requestParams.put("recovery_answer", "a");
        request.withFormUrlEncodedBody(requestParams);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.updateRecoveryQuestion(user.getGuid()), request);
        assertEquals(401, status(result));

        verify(mockConnector).updateRecoveryQuestion("testUUid", "opw", "q", "a");
    }

    @Test
    public void unlockOK() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "up_opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.unlock(user.getGuid()));
        TestCase.assertEquals(200, status(result));
        verify(mockConnector).unlockUser(user.getOpcoUUid());
    }


    @Test
    public void unlockFail() throws Exception {
        User user = User.getOrRegister("firstName", "lastName", "email@example.net", "opco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.UserInfo.unlock(user.getGuid()));
        TestCase.assertEquals(400, status(result));
    }


}
