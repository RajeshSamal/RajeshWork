package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ntti3.gumsapp.models.Company;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.User;
import helpers.DatabaseHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.Map;
import java.util.UUID;

import static junit.framework.Assert.assertEquals;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.header;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * @author jan.karwowski@ntti3.com
 */
public class CompanyInfoTest {
    private FakeApplication application;
    private OpCo opco;
    private Company company;

    @Before
    public void setUp() throws Exception {
        application = DatabaseHelper.fakeApp(null);
        start(application);

        opco = OpCo.getOrRegister("opco", "Opco Name");
        company = Company.getOrRegister(opco, "company", "Company Name");
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void testGetUsers() throws Exception {
        User user1 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user2 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid2", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user3 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid3", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user4 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid4", "testCUid67", "testCompanyName66", Lists.newArrayList("testFlag"));

        UUID company = Company.getCompanyGuid("testOpco", "testCUid66");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.CompanyInfo.getUsers(company, null, null));

        assertEquals("chunked", header("Transfer-Encoding", result));
    }

    @Test
    public void testGetGuid() throws Exception {
        Company company = Company.getOrRegister(OpCo.getOrRegister("opco_uid", "Name"), "company", "ccc");
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.CompanyInfo.getGuid("opco_uid", "company"));
        JsonNode node = Json.parse(contentAsString(result));
        assertEquals(company.getGuid().toString(), node.get("guid").asText());
    }

    @Test
    public void testRegister() throws Exception {
        FakeRequest request = fakeRequest();
        Map<String, String> body = Maps.newHashMap();
        body.put("opco_uid", opco.getOpcoUid());
        body.put("opco_c_uid", "company2");
        body.put("opco_c_name", "Company2");
        request.withFormUrlEncodedBody(body);
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.CompanyInfo.register(), request);
        JsonNode node = Json.parse(contentAsString(result));
        Company company = Company.getById(UUID.fromString(node.get("guid").asText()));
        assertEquals("company2", company.getOpcoCUid());
        assertEquals("Company2", company.getOpcoCName());
        assertEquals("opco", company.getOpco().getOpcoUid());
    }

    @Test
    public void testGet() throws Exception {
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.CompanyInfo.get(company.getGuid()));
        JsonNode json = Json.parse(contentAsString(result));

        assertEquals(company.getOpcoCName(), json.get("opco_c_name").asText());
        assertEquals(company.getOpcoCUid(), json.get("opco_c_uid").asText());
        assertEquals(company.getOpco().getOpcoUid(), json.get("opco_uid").asText());
    }

    @Test
    public void testUpdate() throws Exception {
        FakeRequest request = fakeRequest();
        Map<String, String> map = Maps.newHashMap();
        map.put("opco_c_name", "Swiss Guards");
        map.put("opco_c_uid", "sg");
        request.withFormUrlEncodedBody(map);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.CompanyInfo.update(company.getGuid()), request);

        company.refresh();
        assertEquals("Swiss Guards", company.getOpcoCName());
        assertEquals("sg", company.getOpcoCUid());
    }
}
