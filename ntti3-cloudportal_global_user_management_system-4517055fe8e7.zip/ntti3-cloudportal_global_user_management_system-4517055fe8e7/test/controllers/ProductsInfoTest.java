package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ntti3.gumsapp.models.Product;
import helpers.DatabaseHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;

import javax.annotation.Nullable;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ProductsInfoTest {
    private FakeApplication application;
    private List<Product> products;

    @Before
    public void setUp() throws Exception {
        application = DatabaseHelper.fakeApp(null);
        start(application);
        products = Lists.newArrayList(Product.registerProduct("prod1"),
                Product.registerProduct("prod2"),
                Product.registerProduct("prod3"));
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void testGet() throws Exception {
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.ProductsInfo.get());
        JsonNode arr = Json.parse(contentAsString(result)).get("products");

        assertThat(Lists.transform(Lists.newArrayList(arr.elements()), new Function<JsonNode, String>() {
            @Nullable
            @Override
            public String apply(@Nullable JsonNode input) {
                return input.asText();
            }
        })).containsOnly(Lists.transform(products, new Function<Product, Object>() {
            @Nullable
            @Override
            public Object apply(@Nullable Product input) {
                return input.getName();
            }
        }).toArray());
    }
}
