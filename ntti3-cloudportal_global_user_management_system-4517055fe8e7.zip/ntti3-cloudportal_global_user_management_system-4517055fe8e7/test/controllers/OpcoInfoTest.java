package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ntti3.gumsapp.models.Company;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.PendingUser;
import com.ntti3.gumsapp.models.User;
import helpers.DatabaseHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.Map;
import java.util.UUID;

import static junit.framework.Assert.assertEquals;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.header;
import static play.test.Helpers.start;
import static play.test.Helpers.status;
import static play.test.Helpers.stop;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OpcoInfoTest {
    private FakeApplication application;
    
    private String firstName = "Mickey";
    private String lastName = "Mouse";
    private String email = "mickey@mouse.org";
    private String phone = "555-0-0-0-0-0-0";
    private String password = "minnie123";
    private String securityQuestion = "What's up?";
    private String securityAnswer = "sky";
    private String opcoUid = "testOpco";
    private String opcoName = "testOpco";
    private String opcoCName = "testCompany";
    private String additionalInfo = "Winter is comming";    
    
    @Before
    public void setUp() throws Exception {
        application = DatabaseHelper.fakeApp(null);
        start(application);
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }
    
    private PendingUser addUser(String opcoUUid) {
        PendingUser pendingUser = new PendingUser();

        pendingUser.setEmail(email);
        pendingUser.setFirstName(firstName);
        pendingUser.setLastName(lastName);
        pendingUser.setMobilePhone(phone);
        pendingUser.setPassword(password);
        pendingUser.setSecurityAnswer(securityAnswer);
        pendingUser.setSecurityQuestion(securityQuestion);
        pendingUser.setOpcoUid(opcoUid);
        pendingUser.setOpcoUUid(opcoUUid);
        pendingUser.setAdditionalInfo(additionalInfo);
        pendingUser.setOpcoCName(opcoCName);

        pendingUser.save();

        return pendingUser;
    }

    @Test
    public void testGetUsers() throws Exception {
        User user1 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user2 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid2", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user3 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid3", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user4 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid4", "testCUid67", "testCompanyName66", Lists.newArrayList("testFlag"));

        UUID company = Company.getCompanyGuid("testOpco", "testCUid66");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.getUsers("testOpco", null, null));
        assertEquals("chunked", header("Transfer-Encoding", result));
    }
    
    @Test
    public void testGetPendingUsers() throws Exception {
        OpCo.getOrRegister(opcoUid, opcoName);
        
        PendingUser user1 = addUser("testUUid");

        PendingUser user2 = addUser("testUUid2");

        PendingUser user3 = addUser("testUUid3");

        PendingUser user4 = addUser("testUUid4");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.getPendingUsers("testOpco", null, null));
        assertEquals("chunked", header("Transfer-Encoding", result));
    }

    @Test
    public void testGetUsersKillAllPeople() throws Exception {
        User user1 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user2 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid2", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user3 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid3", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user4 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid4", "testCUid67", "testCompanyName66", Lists.newArrayList("testFlag"));

        UUID company = Company.getCompanyGuid("testOpco", "testCUid66");
        for (int i = 0; i < 300; i++) {
            Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.getUsers("testOpco", null, null));
            assertEquals("chunked", header("Transfer-Encoding", result));
        }
    }


    @Test
    public void testGetCompanies() throws Exception {
        User user1 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user2 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid2", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user3 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid3", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));

        User user4 = User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid4", "testCUid67", "testCompanyName66", Lists.newArrayList("testFlag"));

        UUID company = Company.getCompanyGuid("testOpco", "testCUid66");

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.getCompanies("testOpco", null, null));
        assertEquals("chunked", header("Transfer-Encoding", result));
    }

    @Test
    public void testRegister() throws Exception {
        FakeRequest request = fakeRequest();
        Map<String, String> fakeBody = Maps.newHashMap();
        fakeBody.put("opco_uid", "crusade");
        fakeBody.put("opco_name", "Crusade Supplies Company");
        request.withFormUrlEncodedBody(fakeBody);
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.register(), request);
        assertEquals(200, status(result));

        OpCo opco = OpCo.getById("crusade");
        assertEquals("Crusade Supplies Company", opco.getOpcoName());
    }

    @Test
    public void testGet() throws Exception {
        OpCo opco = OpCo.getOrRegister("test", "Test");
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.get(opco.getOpcoUid()));

        JsonNode json = Json.parse(contentAsString(result));
        assertEquals(opco.getOpcoName(), json.get("opco_name").asText());
        assertEquals(opco.getOpcoUid(), json.get("opco_uid").asText());
    }

    @Test
    public void testUpdate() throws Exception {
        OpCo opco = OpCo.getOrRegister("test", "Test");
        FakeRequest request = fakeRequest();
        Map<String, String> map = Maps.newHashMap();
        map.put("opco_name", "SPQR");
        request.withFormUrlEncodedBody(map);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.OpcoInfo.update(opco.getOpcoUid()), request);

        opco.refresh();
        assertEquals("SPQR", opco.getOpcoName());
    }
}
