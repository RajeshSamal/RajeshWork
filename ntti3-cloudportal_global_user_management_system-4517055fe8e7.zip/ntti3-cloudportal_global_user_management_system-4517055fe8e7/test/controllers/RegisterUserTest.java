package controllers;

import com.avaje.ebean.Ebean;
import com.beust.jcommander.internal.Maps;
import com.google.common.collect.Lists;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gumsapp.global.Global;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.PendingUser;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.Role;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.models.UserProductRole;
import com.ntti3.mailing.connector.MailingSystemConnector;
import helpers.DatabaseHelper;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static play.test.Helpers.callAction;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.start;
import static play.test.Helpers.status;
import static play.test.Helpers.stop;
/**
 * @author jan.karwowski@ntti3.com
 */

public class RegisterUserTest {

    private FakeApplication application;
    private Product product;


    private String firstName = "Mickey";
    private String lastName = "Mouse";
    private String email = "mickey@mouse.org";
    private String phone = "555-0-0-0-0-0-0";
    private String password = "minnie123";
    private String securityQuestion = "What's up?";
    private String securityAnswer = "sky";
    private String opcoUid = "testOpco";
    private String opcoUUid = email;
    private UserRegistrationConnector userRegistrationConnector;
    private MailingSystemConnector mailSystemMock;
    private String oamName = "oamName";
    private String oamEmail = "oamEmail";
    private String opcoName = "testOpco";
    private String opcoCUid = "testCompany";
    private String opcoCName = "testCompany";
    private String additionalInfo = "Winter is comming";

    private PendingUser addUser() {
        PendingUser pendingUser = new PendingUser();

        pendingUser.setEmail(email);
        pendingUser.setFirstName(firstName);
        pendingUser.setLastName(lastName);
        pendingUser.setMobilePhone(phone);
        pendingUser.setPassword(password);
        pendingUser.setSecurityAnswer(securityAnswer);
        pendingUser.setSecurityQuestion(securityQuestion);
        pendingUser.setOpcoUid(opcoUid);
        pendingUser.setOpcoUUid(opcoUUid);
        pendingUser.setAdditionalInfo(additionalInfo);
        pendingUser.setOpcoCName(opcoCName);

        pendingUser.save();

        return pendingUser;
    }

    private User crateAdmin() {
        return User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                "testUUid", "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
    }

    private User crateAdmin(String opcoUUid) {
        return User.getOrRegister("firstName", "lastName", "email@example.net", "testOpco", "testOpcoName",
                opcoUUid, "testCUid66", "testCompanyName66", Lists.newArrayList("testFlag"));
    }

    @Before
    public void setUp() throws Exception {
        userRegistrationConnector = mock(UserRegistrationConnector.class);
        mailSystemMock = mock(MailingSystemConnector.class);
        application = DatabaseHelper.fakeApp(new Global() {
            @Override
            protected OpcoUpdatersStore initOpcoUpdatersStore() {
                Map<String, UserRegistrationConnector> map = new HashMap<>();
                map.put(opcoUid, userRegistrationConnector);
                return new OpcoUpdatersStore(map);
            }

            @Override
            protected MailingSystemConnector initMailSystem() {
                return mailSystemMock;
            }
        });
        start(application);
        OpCo.getOrRegister(opcoUid, opcoName);
        product = Product.registerProduct("tp");
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void testCreatePendingUser() throws Exception {
        Map<String, String> fakeBody = Maps.newHashMap();

        fakeBody.put("first_name", firstName);
        fakeBody.put("last_name", lastName);
        fakeBody.put("email", email);
        fakeBody.put("password", password);
        fakeBody.put("recovery_question", securityQuestion);
        fakeBody.put("recovery_answer", securityAnswer);
        fakeBody.put("opco_uid", opcoUid);
        fakeBody.put("opco_u_uid", opcoUUid);
        fakeBody.put("mobile_phone", phone);
        fakeBody.put("additional_info", additionalInfo);
        fakeBody.put("opco_c_name", opcoCName);

        FakeRequest fakeRequest = fakeRequest();
        fakeRequest.withFormUrlEncodedBody(fakeBody);

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.RegisterUser.createPendingUser(), fakeRequest);
        assertEquals(200, status(result));

        TestCase.assertEquals(1, Ebean.find(PendingUser.class).where().eq("email", email).findRowCount());
    }
    
    @Test
    public void testActivateUser() throws Exception {
    	PendingUser pendingUser = addUser();
    	
    	Map<String, String> fakeBody = Maps.newHashMap();
    	fakeBody.put("products", product.getName());
    	fakeBody.put("opco_c_name", opcoCName);
    	fakeBody.put("opco_c_uid", opcoCUid);
    	
        FakeRequest fakeRequest = fakeRequest();
        fakeRequest.withFormUrlEncodedBody(fakeBody);
        
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.RegisterUser.activateUser(pendingUser.getId()), fakeRequest);
        assertEquals(200, status(result));
        PendingUser pendingUser2 = Ebean.find(PendingUser.class, pendingUser.getId());
        TestCase.assertNull(pendingUser2);
        User user = Ebean.find(User.class).findUnique();
        TestCase.assertNotNull(user);
        TestCase.assertEquals(pendingUser.getOpcoUUid(), user.getOpcoUUid());
    }
    
    @Test
    public void testCreateUser()
    {
        Map<String, String> fakeBody = Maps.newHashMap();

        fakeBody.put("first_name", firstName);
        fakeBody.put("last_name", lastName);
        fakeBody.put("email", email);
        fakeBody.put("password", password);
        fakeBody.put("recovery_question", securityQuestion);
        fakeBody.put("recovery_answer", securityAnswer);
        fakeBody.put("opco_uid", opcoUid);
        fakeBody.put("opco_u_uid", opcoUUid);
        fakeBody.put("mobile_phone", phone);
        fakeBody.put("products", product.getName());
        fakeBody.put("opco_c_uid", opcoCUid);
        fakeBody.put("opco_c_name", opcoCName);
        fakeBody.put("opco_name", opcoName);

        FakeRequest fakeRequest = fakeRequest();
        fakeRequest.withFormUrlEncodedBody(fakeBody);
        
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.RegisterUser.createUser(), fakeRequest);
        assertEquals(200, status(result));
        User user = Ebean.find(User.class).findUnique();
        TestCase.assertNotNull(user);
        TestCase.assertEquals(opcoUUid, user.getOpcoUUid());
    }

    @Test
    public void testGetPendingUsers() throws Exception {
        PendingUser user = addUser();
        Product product2 = Product.registerProduct("butter");
        User admin = crateAdmin();
        Role adminRole = Ebean.find(Role.class).where().eq("name", "admin").findUnique();

        new UserProductRole(product, admin, adminRole).save();
        new UserProductRole(product2, admin, adminRole).save();

        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.RegisterUser.getPendingUsers(null, null));

        assertEquals(200, status(result));
    }

    /*public void testPendingUserStatuses() {
        Product product2 = Product.registerProduct("butter");
        User admin = crateAdmin();
        Role adminRole = Ebean.find(Role.class).where().eq("name", "admin").findUnique();

        PendingUser user = addUser();
        new UserProductRole(product, admin, adminRole).save();
        new UserProductRole(product2, admin, adminRole).save();
        
        Result result = callAction(routes.ref.RegisterUser.getPendingUser(admin.getGuid(), user.getId()));

        JsonNode node = Json.parse(contentAsString(result));

        TestCase.assertNotNull(node);
        TestCase.assertEquals(user.getId(), node.get("id").asInt());
    }*/

    /*@Test
    public void testPendingUserNX() {
        PendingUser user = addUser();
        Product product2 = Product.registerProduct("butter");
        User admin = crateAdmin();
        Role adminRole = Ebean.find(Role.class).where().eq("name", "admin").findUnique();

        Result result = callAction(routes.ref.RegisterUser.getPendingUser(admin.getGuid(), user.getId()));

        TestCase.assertEquals(404, status(result));
    }*/

    @Test
    public void testRemovePendingUser() throws Exception {
        PendingUser pendingUser = addUser();
        Result result = callAction(com.ntti3.gumsapp.controllers.routes.ref.RegisterUser.removePendingUser(pendingUser.getId()));
        TestCase.assertEquals(200, status(result));
        TestCase.assertEquals(0, Ebean.find(PendingUser.class).where().eq("email", email).findRowCount());
        TestCase.assertEquals(1, Ebean.find(Product.class).findRowCount());
    }

    /*@Test
    public void testSetPendingUserStatus() throws Exception {
        final Semaphore semaphore = new Semaphore(0);
        PendingUser user = addUser();
        Product product2 = Product.registerProduct("butter");
        User admin = crateAdmin();
        Role adminRole = Ebean.find(Role.class).where().eq("name", "admin").findUnique();

        new UserProductRole(product, admin, adminRole).save();
        new UserProductRole(product2, admin, adminRole).save();

        Answer<Object> answer = new Answer<Object>() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                semaphore.release();
                return null;
            }
        };
        Mockito.doAnswer(answer).when(mailSystemMock).sendTemplateMessage(any(SendingMessage.class));

        FakeRequest fakeRequest = fakeRequest();
        Map<String, String> map = Maps.newHashMap();
        map.put("admin_guid", admin.getGuid().toString());
        map.put("status", Status.ACCEPTED.toString());
        fakeRequest.withFormUrlEncodedBody(map);

        Result result = callAction(routes.ref.RegisterUser.setPendingUserStatus(user.getId()), fakeRequest);

        TestCase.assertEquals(200, status(result));

        semaphore.tryAcquire(5, TimeUnit.SECONDS);
        semaphore.tryAcquire(5, TimeUnit.SECONDS);
        verify(mailSystemMock).sendTemplateMessage(any(SendingMessage.class));
        verify(userRegistrationConnector).activateUser(user.getEmail());
    }


    @Test
    public void testSetPendingUserRejected() throws Exception {
        final Semaphore semaphore = new Semaphore(0);
        PendingUser user = addUser();
        Product product2 = Product.registerProduct("butter");
        User admin = crateAdmin();
        User admin2 = crateAdmin("xyz");
        Role adminRole = Ebean.find(Role.class).where().eq("name", "admin").findUnique();

        new UserProductRole(product, admin, adminRole).save();
        new UserProductRole(product2, admin2, adminRole).save();

        Answer<Object> answer = new Answer<Object>() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                semaphore.release();
                return null;
            }
        };
        Mockito.doAnswer(answer).when(mailSystemMock).sendTemplateMessage(any(SendingMessage.class));
        Mockito.doAnswer(answer).when(userRegistrationConnector).registerUser(any(com.ntti3.gums.register
                .User.class));


        FakeRequest fakeRequest = fakeRequest();
        Map<String, String> map = Maps.newHashMap();
        map.put("admin_guid", admin.getGuid().toString());
        map.put("status", Status.REJECTED.toString());
        fakeRequest.withFormUrlEncodedBody(map);

        Result result = callAction(routes.ref.RegisterUser.setPendingUserStatus(user.getId()), fakeRequest);

        FakeRequest fakeRequest2 = fakeRequest();
        Map<String, String> map2 = Maps.newHashMap();
        map2.put("admin_guid", admin2.getGuid().toString());
        map2.put("status", Status.ACCEPTED.toString());
        fakeRequest2.withFormUrlEncodedBody(map2);

        Result result2 = callAction(routes.ref.RegisterUser.setPendingUserStatus(user.getId()), fakeRequest2);

        TestCase.assertEquals(200, status(result));
        TestCase.assertEquals(200, status(result2));

        semaphore.tryAcquire(5, TimeUnit.SECONDS);
        verify(userRegistrationConnector, atMost(0)).registerUser(any(com.ntti3.gums.register
                .User.class));
        verify(mailSystemMock).sendTemplateMessage(any(SendingMessage.class));
    }*/
}
