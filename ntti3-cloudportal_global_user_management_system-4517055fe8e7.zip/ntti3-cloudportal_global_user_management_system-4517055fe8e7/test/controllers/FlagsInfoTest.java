package controllers;

import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Nullable;

import com.ntti3.gumsapp.models.Flag;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * @author jan.karwowski@ntti3.com
 */
public class FlagsInfoTest {

    private FakeApplication application;
    private List<Flag> flags;

    @Before
    public void setUp() throws Exception {
        application = fakeApplication(inMemoryDatabase());
        start(application);
        flags = Lists.newArrayList(Flag.getOrCreate("flag1"), Flag.getOrCreate("flag2"), Flag.getOrCreate("flag3"));
    }

    @After
    public void tearDown() throws Exception {
        stop(application);
    }

    @Test
    public void testGetFlags() throws Exception {
        Result response = callAction(com.ntti3.gumsapp.controllers.routes.ref.FlagsInfo.get());

        JsonNode node = Json.parse(contentAsString(response));
        JsonNode arr = node.get("flags");
        List<String> flags = new ArrayList<>();

        Iterator<JsonNode> iterator = arr.elements();
        while(iterator.hasNext()){
            flags.add(iterator.next().asText());
        }

        assertThat(flags).containsOnly(Lists.transform(this.flags, new Function<Flag, Object>() {
            @Nullable
            @Override
            public Object apply(@Nullable Flag input) {
                return input.getName();
            }
        }).toArray());
    }
}
