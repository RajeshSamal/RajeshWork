package com.ntti3.gumsapp.models;

import com.ntti3.play.data.PowerValidator;
import org.junit.Test;

public class UserTest {

    @Test
    public void validationTest() {
        OpCo opco = new OpCo("opcouid", "opconame");
        Company company = new Company("opcocuid", "opcocname", opco);

        User user = new User();
        user.setFirstName("Yas");
        user.setLastName("Naoi");
        user.setEmail("yas.naoi+test+1@gmail.com");
        user.setCompany(company);
        user.setActiveInOpCo(true);
        user.setOpco(opco);

        user.setOpcoUUid("yas.naoi+test+1@gmail.com");
        PowerValidator.validate(user);
        user.setOpcoUUid("yas.naoi-test+1@gmail.com");
        PowerValidator.validate(user);
        user.setOpcoUUid("yas.naoi-test-1@gmail.com");
        PowerValidator.validate(user);
    }
}