package helpers;

import com.google.common.collect.Maps;
import com.ntti3.gumsapp.global.Global;
import liquibase.database.Database;
import liquibase.exception.DatabaseException;
import liquibase.integration.commandline.CommandLineUtils;
import play.Logger;
import play.test.FakeApplication;

import java.util.Map;

import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;

public class DatabaseHelper {
    
    private final static String DB_URL = "jdbc:mysql://localhost/gumsdb?characterEncoding=utf8";
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_USER = "root";
    private static final String DB_PASS = null;
    private final static boolean IN_MEMORY_DB = false;
    
    public static FakeApplication fakeApp(Global global) {
        if(IN_MEMORY_DB)
        {
            return fakeApplication(inMemoryDatabase(),global);
        }
        else
        {
            Map<String, String> testConfig = Maps.newHashMap(inMemoryDatabase());
            testConfig.put("db.default.user", DB_USER);
            testConfig.put("db.default.pass", DB_PASS);
            testConfig.put("db.default.driver", DB_DRIVER);
            testConfig.put("db.default.url", DB_URL);
            FakeApplication app = fakeApplication(testConfig,global);
            try {
                dropLocalDb();
            } catch (DatabaseException e) {
                Logger.error("Failed to drop database content");
                throw new RuntimeException();
            }
            
            return app;
        }
    }
    
    private static void dropLocalDb() throws DatabaseException {
        Database referenceDatabase = getDatabase();
        String schema = referenceDatabase.getConnection().getCatalog();
         
        Logger.warn("Dropping database " + schema);
        referenceDatabase.dropDatabaseObjects(schema);
    }
    
    private static Database getDatabase() throws DatabaseException {
        return CommandLineUtils.createDatabaseObject(DatabaseHelper.class.getClassLoader(), 
                DB_URL, DB_USER, DB_PASS, DB_DRIVER, null, null, null);
    }
}
