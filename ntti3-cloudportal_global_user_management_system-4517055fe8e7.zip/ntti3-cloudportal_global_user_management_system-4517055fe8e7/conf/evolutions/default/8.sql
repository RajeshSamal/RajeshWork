
# --- !Ups

ALTER TABLE user ADD opco_uid varchar(255) not null;
-- update user left join company on user.company_guid = company.guid left join op_co on op_co.opco_uid = company.opco_uid set user.opco_uid = op_co.opco_uid;

# --- !Downs

ALTER TABLE user DROP opco_uid;