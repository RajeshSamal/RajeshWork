# --- !Ups

ALTER TABLE pending_user ADD opco_account_manager_name varchar(128);
ALTER TABLE pending_user ADD opco_account_manager_email varchar(128);

# --- !Downs

ALTER TABLE pending_user DROP opco_account_manager_name;
ALTER TABLE pending_user DROP opco_account_manager_email;
