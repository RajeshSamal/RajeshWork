
# --- !Ups

SET FOREIGN_KEY_CHECKS=0;

drop table if exists user_product_whitelist;
ALTER TABLE pending_user ADD opco_cname varchar(255) not null;

SET FOREIGN_KEY_CHECKS=1;

# --- !Downs

create table user_product_whitelist (
  user                      char(36) not null,
  product                   integer not null,
  constraint uq_user_product_blacklist_1 unique (user,product))

ALTER TABLE pending_use DROP opco_cname;

