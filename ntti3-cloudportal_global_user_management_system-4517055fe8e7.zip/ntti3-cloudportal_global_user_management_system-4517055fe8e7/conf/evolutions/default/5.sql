
# --- !Ups

drop table op_co_product_blacklist;
drop table company_product_blacklist;
drop table user_product_blacklist;

create table user_product (
  user_guid                      char(36) not null,
  product_id                   integer not null,
  constraint uq_user_product_1 unique (user_guid,product_id))
;

create table user_product_whitelist (
  user                      char(36) not null,
  product                   integer not null,
  constraint uq_user_product_blacklist_1 unique (user,product))
;

ALTER TABLE user ADD active_in_op_co boolean not null;
ALTER TABLE pending_user ADD rejected boolean not null;

alter table user_product add constraint fk_user_product_user_9 foreign key (user_guid) references user (guid) on delete restrict on update restrict;
alter table user_product add constraint fk_user_product_prod_10 foreign key (product_id) references product (id) on delete restrict on update restrict;

# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

create table company_product_blacklist (
  company                   char(36) not null,
  product                   integer not null,
  constraint uq_company_product_blacklist_1 unique (company,product))
;

create table op_co_product_blacklist (
  opco                      varchar(255) not null,
  product                   integer not null,
  constraint uq_op_co_product_blacklist_1 unique (opco,product))
;

create table user_product_blacklist (
  user                      char(36) not null,
  product                   integer not null,
  constraint uq_user_product_blacklist_1 unique (user,product))
;

drop table if exists user_product;
drop table if exists user_product_whitelist;
ALTER TABLE user DROP active_in_opco;

SET REFERENTIAL_INTEGRITY TRUE;
