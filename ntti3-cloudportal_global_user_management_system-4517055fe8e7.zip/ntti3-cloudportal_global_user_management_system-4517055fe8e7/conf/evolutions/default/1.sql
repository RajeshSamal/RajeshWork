
# --- !Ups

create table company (
  guid                      char(36) not null,
  opco_uid                  varchar(255) not null,
  opco_c_uid                varchar(255),
  opco_cname                varchar(255),
  constraint uq_company_1 unique (opco_uid,opco_c_uid),
  constraint pk_company primary key (guid))
;

create table company_product_blacklist (
  company                   char(36) not null,
  product                   integer not null,
  constraint uq_company_product_blacklist_1 unique (company,product))
;

create table flag (
  id                        integer auto_increment not null,
  name                      varchar(255) not null,
  constraint uq_flag_1 unique (name),
  constraint pk_flag primary key (id))
;

create table op_co (
  opco_uid                  varchar(255) not null,
  opco_name                 varchar(255) not null,
  constraint pk_op_co primary key (opco_uid))
;

create table op_co_product_blacklist (
  opco                      varchar(255) not null,
  product                   integer not null,
  constraint uq_op_co_product_blacklist_1 unique (opco,product))
;

create table product (
  id                        integer auto_increment not null,
  name                      varchar(255) not null,
  constraint uq_product_1 unique (name),
  constraint pk_product primary key (id))
;

create table user (
  guid                      char(36) not null,
  opco_u_uid                varchar(255) not null,
  company_guid              char(36) not null,
  first_name                varchar(255) not null,
  last_name                 varchar(255) not null,
  email                     varchar(255) not null,
  added_to_gums             timestamp not null default NOW(),
  active                    boolean not null,
  opco_updateable           boolean not null,
  updated                   timestamp not null,
  constraint uq_user_1 unique (company_guid,opco_u_uid),
  constraint pk_user primary key (guid))
;

create table user_product_blacklist (
  user                      char(36) not null,
  product                   integer not null,
  constraint uq_user_product_blacklist_1 unique (user,product))
;


create table user_flag (
  user_guid                      char(36) not null,
  flag_id                        integer not null,
  constraint pk_user_flag primary key (user_guid, flag_id))
;

alter table company add constraint fk_company_opco_1 foreign key (opco_uid) references op_co (opco_uid) on delete restrict on update restrict;
create index ix_company_opco_1 on company (opco_uid);
alter table company_product_blacklist add constraint fk_company_product_blacklist_c_2 foreign key (company) references company (guid) on delete restrict on update restrict;
create index ix_company_product_blacklist_c_2 on company_product_blacklist (company);
alter table company_product_blacklist add constraint fk_company_product_blacklist_p_3 foreign key (product) references product (id) on delete restrict on update restrict;
create index ix_company_product_blacklist_p_3 on company_product_blacklist (product);
alter table op_co_product_blacklist add constraint fk_op_co_product_blacklist_opc_4 foreign key (opco) references op_co (opco_uid) on delete restrict on update restrict;
create index ix_op_co_product_blacklist_opc_4 on op_co_product_blacklist (opco);
alter table op_co_product_blacklist add constraint fk_op_co_product_blacklist_pro_5 foreign key (product) references product (id) on delete restrict on update restrict;
create index ix_op_co_product_blacklist_pro_5 on op_co_product_blacklist (product);
alter table user add constraint fk_user_company_6 foreign key (company_guid) references company (guid) on delete restrict on update restrict;
create index ix_user_company_6 on user (company_guid);
alter table user_product_blacklist add constraint fk_user_product_blacklist_user_7 foreign key (user) references user (guid) on delete restrict on update restrict;
create index ix_user_product_blacklist_user_7 on user_product_blacklist (user);
alter table user_product_blacklist add constraint fk_user_product_blacklist_prod_8 foreign key (product) references product (id) on delete restrict on update restrict;
create index ix_user_product_blacklist_prod_8 on user_product_blacklist (product);



alter table user_flag add constraint fk_user_flag_user_01 foreign key (user_guid) references user (guid) on delete restrict on update restrict;

alter table user_flag add constraint fk_user_flag_flag_02 foreign key (flag_id) references flag (id) on delete restrict on update restrict;

# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

drop table if exists company;

drop table if exists company_product_blacklist;

drop table if exists flag;

drop table if exists op_co;

drop table if exists op_co_product_blacklist;

drop table if exists product;

drop table if exists user;

drop table if exists user_flag;

drop table if exists user_product_blacklist;

SET REFERENTIAL_INTEGRITY TRUE;


