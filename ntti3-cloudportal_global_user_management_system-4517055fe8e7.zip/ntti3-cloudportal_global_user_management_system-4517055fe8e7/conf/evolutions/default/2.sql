# --- !Ups

ALTER TABLE user ADD mobile_phone varchar(64);

CREATE TABLE role (
     id                        integer auto_increment not null,
     name                      varchar(255) not null,
     constraint uq_role_1 unique (name),
     constraint pk_role primary key (id)
);

CREATE TABLE wanted_product (
    product_id      integer not null,
    user_id         integer not null,
    status          integer not null,
    constraint wanted_product primary key (product_id, user_id)
);

create table pending_user (
  id                        integer auto_increment not null,
  opco_u_uid                varchar(255) not null,
  opco_uid                varchar(255) not null,
  first_name                varchar(255) not null,
  last_name                 varchar(255) not null,
  mobile_phone                 varchar(255) not null,
  email                     varchar(255) not null,
  password                  varchar(255) not null,
  added_to_gums             timestamp not null default NOW(),
  updated                   timestamp not null,
  security_question         varchar(255),
  security_answer           varchar(255),
  email_sent                boolean not null,
  constraint pk_pending_user primary key (id)
);

create table user_product_role (
    user_guid       varchar(36) not null,
    product_id      integer not null,
    role_id         integer not null,
    constraint pk_user_product_role primary key (product_id, user_guid)
);

-- TODO: indeksy

# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

ALTER TABLE user DROP mobile_phone;
DROP TABLE role;
DROP TABLE wanted_product;
DROP TABLE pending_user;
DROP TABLE user_product_role;

SET REFERENTIAL_INTEGRITY TRUE;