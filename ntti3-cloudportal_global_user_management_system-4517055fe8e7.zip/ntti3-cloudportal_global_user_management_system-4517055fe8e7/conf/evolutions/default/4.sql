# --- !Ups

ALTER TABLE pending_user modify mobile_phone varchar(255);

# --- !Downs

ALTER TABLE pending_user modify mobile_phone varchar(255) not null;
