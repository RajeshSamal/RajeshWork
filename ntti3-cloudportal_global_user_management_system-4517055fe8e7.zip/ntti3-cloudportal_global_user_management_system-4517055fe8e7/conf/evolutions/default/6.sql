# --- !Ups

ALTER TABLE pending_user ADD additional_info varchar(255) AFTER security_answer;

# --- !Downs

ALTER TABLE pending_user modify DROP COLUMN additional_info;
