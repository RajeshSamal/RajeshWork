
# --- !Ups

update user left join company on user.company_guid = company.guid left join op_co on op_co.opco_uid = company.opco_uid set user.opco_uid = op_co.opco_uid;

# --- !Downs
