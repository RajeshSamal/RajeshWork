import com.google.common.collect.Maps;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.UserRegistrationConnectorFactory;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import org.springframework.beans.BeanUtils;
import play.Configuration;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Global extends com.ntti3.gumsapp.global.Global {
    @Override
    protected OpcoUpdatersStore initOpcoUpdatersStore() throws Exception {
        Map<String, UserRegistrationConnector> opcoUpdatersMap = Maps.newHashMap();

        Configuration config = Configuration.root().getConfig("opco_updaters");

        for (String key : config.subKeys()) {
            Configuration subconfig = config.getConfig(key);
            Properties props = new Properties();
            String properties = subconfig.getString("properties");
            try (InputStream inputStream = new FileInputStream(properties)) {
                props.load(inputStream);
            }
            String className = subconfig.getString("class");

            UserRegistrationConnectorFactory factory =
                    (UserRegistrationConnectorFactory) BeanUtils.instantiate(Class.forName(className));

            opcoUpdatersMap.put(key, factory.getInstance(props));
        }

        return new OpcoUpdatersStore(opcoUpdatersMap);
    }
}
