package com.ntti3.gumsapp.models;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.play.data.PowerValidator;
import play.Logger;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PersistenceException;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import static com.ntti3.gums.GumsProtocolConstants.*;
import static com.ntti3.gumsapp.models.User.COMPANY_GUID_COLUMN;
import static com.ntti3.gumsapp.models.User.OPCO_U_UID_COLUMN;

/**
 * Represents user entity in GUMS
 * <p/>
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(columnNames = {COMPANY_GUID_COLUMN, OPCO_U_UID_COLUMN})})
@JsonIgnoreProperties(ignoreUnknown = true)
public class User extends Model implements ModelWithStringId {
    /**
	 * 
	 */
    private static final long serialVersionUID = 2L;
    public static final String COMPANY_GUID_COLUMN = "company_guid";
    public static final String OPCO_U_UID_COLUMN = "opco_u_uid";

    @Id
    @JsonIgnore
    private UUID guid;

    @Column(name = OPCO_U_UID_COLUMN, nullable = false)
    @Constraints.Required
    @JsonProperty(value = OPCO_U_UID_PARAMETER)
    @Constraints.MaxLength(DataConstraints.UID_LENGTH)
    @Constraints.Pattern(DataConstraints.UID_PATTERN)
    private String opcoUUid;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = COMPANY_GUID_COLUMN, nullable = false)
    @NotNull
    @JsonIgnore
    private Company company;
    
    @ManyToOne
    @JoinColumn(name = OPCO_UID_PARAMETER, nullable = false)
    @NotNull
    @JsonIgnore
    private OpCo opco;

    /* Personal info */
    @NotNull
    @JsonProperty(value = FIRST_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String firstName;

    @NotNull
    @JsonProperty(value = LAST_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String lastName;

    @NotNull
    @Constraints.Email
    @JsonProperty(value = EMAIL_PARAMETER)
    private String email;

    @JsonProperty(value = MOBILE_PHONE_PARAMETER)
    private String mobilePhone;

    @Column(insertable = false, updatable = false)
    @JsonIgnore
    private Calendar addedToGums;

    @Version
    @JsonIgnore
    private Timestamp updated;

    @NotNull
    @JsonProperty(value = ACTIVE_PARAMETER)
    private boolean active = true;
    
    @NotNull
    @JsonProperty(value = ACTIVE_IN_OPCO_PARAMETER)
    private boolean activeInOpCo = false;

    @NotNull
    @JsonIgnore
    private boolean opcoUpdateable = true;

    @ManyToMany
    private List<Flag> flags;
    
    @ManyToMany
    private List<Product> products;

    @OneToMany
    @JsonIgnore
    private List<UserProductRole> userProductRoles;

    public List<UserProductRole> getUserProductRoles() {
        return userProductRoles;
    }

    public void setUserProductRoles(List<UserProductRole> userProductRoles) {
        this.userProductRoles = userProductRoles;
    }

    public static User getOrRegister(String firstName, String lastName, String email, String opcoUid,
            String opcoName, String opcoUUid, String opcoCUid, String opcoCName, List<String> flags) {
        return getOrRegister(firstName, lastName, email, null, opcoUid, opcoName, opcoUUid, opcoCUid, opcoCName, flags);
    }

    /**
     * This method assumes that entities are never removed from GUMS and PKs never change.
     *
     * @param firstName
     * @param lastName
     * @param email
     * @param opcoUid
     * @param opcoName
     * @param opcoUUid
     * @param opcoCUid
     * @param opcoCName
     * @param flags
     * @return
     */
    public static User getOrRegister(String firstName, String lastName, String email, String mobilePhone,
            String opcoUid,
            String opcoName, String opcoUUid, String opcoCUid, String opcoCName, List<String> flags) {
        return getOrRegisterAndAssignProducts(firstName, lastName, email, mobilePhone, opcoUid,
                opcoName, opcoUUid, opcoCUid, opcoCName, flags, false);
    }

    public static User getOrRegisterAndAssignProducts(String firstName, String lastName, String email,
                                                       String mobilePhone, String opcoUid, String opcoName,
                                                       String opcoUUid, String opcoCUid, String opcoCName,
                                                       List<String> flags, boolean assignAllProducts) {
        if (assignAllProducts) {
            Logger.warn("assign-all-products is TRUE! please disable it if not needed!");
        }
        OpCo opco = OpCo.getOrRegister(opcoUid, opcoName);
        Company company = Company.getOrRegister(opco, opcoCUid, opcoCName);

        Finder<UUID, User> finder = new Finder<>(UUID.class, User.class);

        User user = finder.where().eq("opcoUUid", opcoUUid).eq("opco", opco).findUnique();
        if (user != null && user.isOpcoUpdateable()) {
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setEmail(email);
            user.setOpcoUUid(opcoUUid);
            user.setCompany(company);
            user.setMobilePhone(mobilePhone);
            if (flags != null) {
                user.setFlagsByStrings(Lists.newArrayList(flags));
            }

            PowerValidator.validate(user);
            user.save();
        } else if (user == null) {
            user = new User();
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setEmail(email);
            user.setOpcoUUid(opcoUUid);
            user.setCompany(company);
            user.setMobilePhone(mobilePhone);
            user.setActiveInOpCo(true);
            user.setOpco(opco);

            if (assignAllProducts) {
                user.assignAllProducts();
            }

            if (flags != null) {
                user.setFlagsByStrings(Lists.newArrayList(flags));
            }
            try {
                PowerValidator.validate(user);
                user.save();
            } catch (PersistenceException ex) {
                Logger.debug("Exception when saving user", ex);
                user = finder.where().eq("opcoUUid", opcoUUid).eq("company.opco", opco).findUnique();
            }
        }
        return user;
    }

    public void assignAllProducts() {
        Finder<Integer, Product> productFinder = new Finder<>(Integer.class, Product.class);
        final List<Product> allProducts = productFinder.all();
        Logger.debug(String.format("Assigning all product '%s' to user '%s'", allProducts.toString(), this.toString()));
        this.setProducts(allProducts);
    }

    public static UUID getGuidFor(String opcoUid, String opcoUUid) {
        Finder<UUID, User> finder = new Finder<>(UUID.class, User.class);
        User user = finder.where().eq("opcoUUid", opcoUUid).eq("company.opco.opcoUid",
                opcoUid).select("guid").findUnique();
        if (user != null) {
            return user.getGuid();
        } else {
            throw new UserNotFoundException("User with uid " + opcoUUid + " in OpCo " + opcoUid + " not found");
        }
    }

    public static User getByGUID(UUID guid) {
        User u = getByGuidNull(guid);
        if (u == null) {
            throw new UserNotFoundException("User with GUID " + guid.toString() + " not found");
        }
        return u;
    }

    public static User getByGuidNull(UUID guid) {
        Finder<UUID, User> finder = new Finder<>(UUID.class, User.class);
        return finder.byId(guid);
    }

    public UUID getGuid() {
        return guid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean isActive) {
        this.active = isActive;
    }
    
    public boolean isActiveInOpCo() {
		return activeInOpCo;
	}

	public void setActiveInOpCo(boolean activeInOpCo) {
		this.activeInOpCo = activeInOpCo;
	}

    public List<Flag> getFlags() {
        return flags;
    }

    public void setFlags(List<Flag> flags) {
        this.flags = flags;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty(FLAGS_PARAMETER)
    public void setFlagsByStrings(List<String> flags) {
        setFlags(Lists.transform(flags, new Function<String, Flag>() {
            @Nullable
            @Override
            public Flag apply(@Nullable String input) {
                return Flag.getOrCreate(input);
            }
        }));
    }

    public Company getCompany() {
        return company;
    }

    public OpCo getOpco() {
        return opco;
    }

    public void setOpco(OpCo opco) {
        this.opco = opco;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }

    public void setOpcoUUid(String opcoUUid) {
        this.opcoUUid = opcoUUid;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    @JsonProperty(OPCO_C_UID_PARAMETER)
    public String getOpcoCUid() {
        return company.getOpcoCUid();
    }

    @JsonProperty(OPCO_C_NAME_PARAMETER)
    public String getOpcoCName() {
        return company.getOpcoCName();
    }

    @JsonProperty(OPCO_UID_PARAMETER)
    public String getOpcoUid() {
        return company.getOpco().getOpcoUid();
    }

    @JsonProperty(OPCO_NAME_PARAMETER)
    public String getOpcoName() {
        return company.getOpco().getOpcoName();
    }

    @JsonProperty(value = FLAGS_PARAMETER)
    public List<String> getFlagsAsStrings() {
        return Lists.transform(getFlags(), new Function<Flag, String>() {
            @Override
            public String apply(Flag input) {
                return input.getName();
            }
        });
    }

    public List<Product> getProducts() {
    	return products;
    }

    @Transient
    @JsonProperty(PRODUCTS_PARAMETER)
    public List<String> getProductsAsStrings() {
        return Lists.transform(getProducts(), new Function<Product, String>() {
            @Override
            public String apply(Product input) {
                return input.getName();
            }
        });
    }
    
    @JsonProperty(PRODUCTS_PARAMETER)
    public void setProductsByStrings(List<String> products) throws ProductNotFoundException {
        List<Product> productList = Lists.newArrayList();
        for(String product : products) {
            productList.add(Product.getByName(product));
        }
        setProducts(productList);
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    @JsonIgnore
    @Override
    public String getIdAsString() {
        if (getGuid() == null)
            return null;
        return getGuid().toString();
    }

    public Calendar getAddedToGums() {
        return addedToGums;
    }

    public Timestamp getUpdated() {
        return updated;
    }

    public boolean isOpcoUpdateable() {
        return opcoUpdateable;
    }

    public void setOpcoUpdateable(boolean opcoUpdateable) {
        this.opcoUpdateable = opcoUpdateable;
    }

    public static QueryIterator<User> getUserIdsForOpCo(OpCo opco, Integer offset, Integer limit,
            OrderBy orderBy) {
        Query<User> query = com.ntti3.gumsapp.helpers.Query.addOrderBy(getUserIdsForOpCoQuery(opco), orderBy)
                .orderBy().asc("guid");
        return pageQuery(query, offset, limit).findIterate();
    }

    public static Query<User> getUserIdsForOpCoQuery(OpCo opco) {
        return Ebean.find(User.class).select("guid").where().eq("company.opco", opco).query();
    }

    public static int getUserIdsForOpCoCount(OpCo opco) {
        return getUserIdsForOpCoQuery(opco).findRowCount();
    }

    public static <T> Query<T> pageQuery(Query<T> query, Integer offset, Integer limit) {
        if (limit != null) {
            query = query.setMaxRows(limit);
        }
        if (offset != null) {
            query = query.setFirstRow(offset);
        }
        return query;
    }

    public static QueryIterator<User> getUserIdsForCompany(Company company, Integer offset, Integer limit,
            OrderBy orderBy) {
        Query<User> query = com.ntti3.gumsapp.helpers.Query.addOrderBy(getUserIdsForCompanyQuery(company), orderBy).orderBy().asc("guid");
        return pageQuery(query, offset, limit).findIterate();
    }

    public static Query<User> getUserIdsForCompanyQuery(Company company) {
        return Ebean.find(User.class).select("guid").where().eq("company", company).query();
    }

    public static int getUserIdsForCompanyCount(Company company) {
        return getUserIdsForCompanyQuery(company).findRowCount();
    }

    @JsonProperty(COMPANY_GUID_PARAMETER)
    public UUID getCompanyGuid() {
        return company.getGuid();
    }
}
