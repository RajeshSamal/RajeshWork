package com.ntti3.gumsapp.models;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gumsapp.helpers.OrderBy;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Calendar;

import static com.ntti3.gums.GumsProtocolConstants.*;
import static com.ntti3.gumsapp.helpers.Query.addOrderBy;

/**
 * @author jan.karwowski@ntti3.com
 */
@Entity
public class PendingUser extends Model implements ModelWithStringId {
    private static final long serialVersionUID = 2L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @JsonProperty(OPCO_UID_PARAMETER)
    @Constraints.MaxLength(DataConstraints.UID_LENGTH)
    @Constraints.Pattern(DataConstraints.UID_PATTERN)
    @ManyToOne
    private String opcoUid;
    
    @JsonProperty(OPCO_C_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String opcoCName;

    @Constraints.Required
    @Constraints.Email
    @JsonProperty(value = EMAIL_PARAMETER)
    private String email;

    @Column(name = User.OPCO_U_UID_COLUMN, nullable = false)
    @Constraints.Required
    @JsonProperty(value = OPCO_U_UID_PARAMETER)
    @Constraints.MaxLength(DataConstraints.UID_LENGTH)
    @Constraints.Pattern(DataConstraints.UID_PATTERN)
    private String opcoUUid;

    /* Personal info */
    @NotNull
    @JsonProperty(value = FIRST_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String firstName;

    @NotNull
    @JsonProperty(value = LAST_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String lastName;

    @JsonProperty(MOBILE_PHONE_PARAMETER)
    private String mobilePhone;

    @JsonProperty(value = ADDITIONAL_INFO)
    private String additionalInfo;

    @JsonIgnore
    private boolean emailSent;
    
    @JsonIgnore
    private boolean rejected;

    @Version
    @JsonIgnore
    private Timestamp updated;

    @NotNull
    @Column(insertable = false, updatable = false)
    @JsonIgnore
    private Calendar addedToGums;

    @Constraints.Required
    private String password;

    @JsonProperty(value = RECOVERY_QUESTION_PARAMETER)
    private String securityQuestion;

    @JsonProperty(value = RECOVERY_QUESTION_ANSWER)
    private String securityAnswer;

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }

    public void setOpcoUUid(String opcoUUid) {
        this.opcoUUid = opcoUUid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public Timestamp getUpdated() {
        return updated;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public void setOpcoUid(String opcoUid) {
        this.opcoUid = opcoUid;
    }

    public boolean isEmailSent() {
        return emailSent;
    }

    public void setEmailSent(boolean emailSent) {
        this.emailSent = emailSent;
    }
    
    public boolean isRejected() {
        return rejected;
    }

    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }
    
    public String getOpcoCName() {
        return opcoCName;
    }

    public void setOpcoCName(String opcoCName) {
        this.opcoCName = opcoCName;
    }

    public static QueryIterator<PendingUser> getUserIdsForOpCo(OpCo opco, Integer offset, Integer limit,
            OrderBy orderBy) {
        Query<PendingUser> query = addOrderBy(getUserIdsForOpCoQuery(opco), orderBy)
                .orderBy().asc("id");
        return User.pageQuery(query, offset, limit).findIterate();
    }

    public static Query<PendingUser> getUserIdsForOpCoQuery(OpCo opco) {
        return Ebean.find(PendingUser.class).select("id").where().eq("opcoUid", opco.getOpcoUid()).where().eq("rejected", false).query();
    }
    
    public static int getUserIdsForOpCoCount(OpCo opco) {
        return getUserIdsForOpCoQuery(opco).findRowCount();
    }

    @Override
    public String toString() {
        return "PendingUser{" +
               "id=" + id +
               ", opcoUid='" + opcoUid + '\'' +
               ", opcoCName='" + opcoCName + '\'' +
               ", email='" + email + '\'' +
               ", opcoUUid='" + opcoUUid + '\'' +
               ", firstName='" + firstName + '\'' +
               ", lastName='" + lastName + '\'' +
               ", mobilePhone='" + mobilePhone + '\'' +
               ", emailSent=" + emailSent +
               ", updated=" + updated +
               ", addedToGums=" + addedToGums +
               ", password='" + password + '\'' +
               ", securityQuestion='" + securityQuestion + '\'' +
               ", securityAnswer='" + securityAnswer + '\'' +
               ", additionalInfo='" + additionalInfo + '\'' +
               '}';
    }

    @JsonIgnore
    @Override
    public String getIdAsString() {
        return String.valueOf(id);
    }
}
