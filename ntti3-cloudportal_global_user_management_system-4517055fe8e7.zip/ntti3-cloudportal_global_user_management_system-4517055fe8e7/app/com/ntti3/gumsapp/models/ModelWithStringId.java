package com.ntti3.gumsapp.models;

/**
 * Created by jan.karwowski@ntti3.com on 04.02.14.
 */
public interface ModelWithStringId {
    String getIdAsString();
}
