package com.ntti3.gumsapp.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.List;

/**
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(columnNames = {"name"})})
public class Product extends Model {
    private static final long serialVersionUID = 2L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    @Constraints.Required
    private String name;

    public Product(String name) {
        this.name = name;
    }

    public static Product registerProduct(String name) {
        Product product = new Product(name);
        product.save();
        return product;
    }

    public static Product getByName(String name) throws ProductNotFoundException {
        Finder<Integer, Product> finder = new Finder<>(Integer.class, Product.class);
        Product product = finder.where().eq("name", name).findUnique();
        if(product == null) {
            throw new ProductNotFoundException("Product with name "+name+" cannot be found", name);
        }
        return product;
    }

    @OneToMany
    @JsonIgnore
    private List<UserProductRole> userProductRoles;

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}
