package com.ntti3.gumsapp.models;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.play.data.PowerValidator;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityExistsException;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OptimisticLockException;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import java.util.UUID;

import static com.ntti3.gumsapp.helpers.Query.addOrderBy;
import static com.ntti3.gumsapp.models.Company.OPCO_C_UID_COLUMN;
import static com.ntti3.gumsapp.models.Company.OPCO_UID_COLUMN;

/**
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(columnNames = {OPCO_UID_COLUMN, OPCO_C_UID_COLUMN})})
public class Company extends Model implements ModelWithStringId {
    public static final String OPCO_UID_COLUMN = "opco_uid";
    public static final String OPCO_C_UID_COLUMN = "opco_c_uid";

    @Id
    @JsonProperty(GumsProtocolConstants.COMPANY_GUID_PARAMETER)
    private UUID guid;

    @JoinColumn(name = OPCO_UID_COLUMN)
    @ManyToOne
    @NotNull
    @JsonIgnore
    private OpCo opco;
    @Column(name = OPCO_C_UID_COLUMN)
    @JsonProperty(GumsProtocolConstants.OPCO_C_UID_PARAMETER)
    @Constraints.MaxLength(DataConstraints.UID_LENGTH)
    @Constraints.Pattern(DataConstraints.UID_PATTERN)
    private String opcoCUid;
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    @JsonProperty(GumsProtocolConstants.OPCO_C_NAME_PARAMETER)
    private String opcoCName;


    /**
     * This method assumes that entities are never removed from GUMS and PKs never change.
     *
     * @param opco
     * @param opcoCUid
     * @param opcoCName
     * @return
     */
    public static Company getOrRegister(OpCo opco, String opcoCUid, String opcoCName) {
        Finder<UUID, Company> finder = new Finder<>(UUID.class, Company.class);
        Company company = finder.where().eq("opco", opco).eq("opcoCUid", opcoCUid).findUnique();
        if (company == null) {
            company = new Company(opco, opcoCUid, opcoCName);
            try {
                PowerValidator.validate(company);
                company.save();
            } catch (EntityExistsException ex) {
                company = finder.where().eq("opco", opco).eq("opcoCUid", opcoCUid).findUnique();
            }
        } else {
            if ((company.getOpcoCName() == null && opcoCName != null)
                || (company.getOpcoCName() != null && !company.getOpcoCName().equals(opcoCName))) {
                company.setOpcoCName(opcoCName);
                try {
                    PowerValidator.validate(company);
                    company.save();
                } catch (OptimisticLockException ex) {

                }
            }
        }
        return company;
    }

    /**
     * Returns GUID of company identified by given OpCo and id oc company in OpCo
     *
     * @param opcoUid
     * @param opcoCUid
     * @return GUID if company found
     * @throws CompanyNotFoundException If GUID was not found
     */
    public static UUID getCompanyGuid(String opcoUid, String opcoCUid) {
        Finder<UUID, Company> finder = new Finder<>(UUID.class, Company.class);

        Company company = finder.where().eq("opcoCUid", opcoCUid).eq("opco.opcoUid",
                opcoUid).select("guid").findUnique();
        if (company != null) {
            return company.getGuid();
        }
        throw new CompanyNotFoundException("Company with c_uid " + opcoCUid + " in opco " + opcoUid + " not found");
    }

    private Company(OpCo opco, String opcoCUid, String opcoCName) {
        this.opco = opco;
        this.opcoCUid = opcoCUid;
        this.opcoCName = opcoCName;
    }

    public UUID getGuid() {
        return guid;
    }

    public OpCo getOpco() {
        return opco;
    }

    public String getOpcoCUid() {
        return opcoCUid;
    }

    public void setOpcoCUid(String opcoCUid) {
        this.opcoCUid = opcoCUid;
    }

    public String getOpcoCName() {
        return opcoCName == null ? opco.getOpcoName() : opcoCName;
    }

    @JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER)
    public String getOpcoUid() {
        return opco.getOpcoUid();
    }

    public void setOpcoCName(String opcoCName) {
        this.opcoCName = opcoCName;
    }

    public static Company getById(UUID key) {
        Company c = Ebean.find(Company.class, key);
        if (c == null) {
            throw new CompanyNotFoundException("UUID " + key.toString() + " not found");
        }
        return c;
    }

    @Override
    @JsonIgnore
    public String getIdAsString() {
        if (getGuid() == null)
            return null;
        return getGuid().toString();
    }

    public Company(String opcoCUid, String opcoCName, OpCo opco) {
        this.opcoCUid = opcoCUid;
        this.opcoCName = opcoCName;
        this.opco = opco;
    }

    public static Company registerWithOpCoUid(String opcoCUid, String opcoCName, String opcoUid) {
        return registerWithOpCoUid(opcoCUid, opcoCName, opcoUid, null);
    }

    public static Company registerWithOpCoUid(String opcoCUid, String opcoCName, String opcoUid, String opcoName) {
        final OpCo opco;
        if(opcoName == null) {
            opco = OpCo.getById(opcoUid);
        } else {
            opco = OpCo.getOrRegister(opcoUid, opcoName);
        }
        Company company = new Company(opcoCUid, opcoCName, opco);
        PowerValidator.validate(company);
        try {
        Ebean.beginTransaction();
        company.save();
        if(opcoCUid == null) {
            company.setOpcoCUid(company.getGuid().toString());
            company.update();
        }
        Ebean.commitTransaction();
        return company;
        } finally {
            Ebean.endTransaction();
        }
    }

    public static QueryIterator<Company> getCompanyIdsForOpCo(OpCo opco, Integer offset, Integer limit,
            OrderBy orderBy) {
        Query<Company> companyQuery = addOrderBy(getCompanyIdsForOpcoQuery(opco), orderBy).
                orderBy().asc("guid");
        return User.pageQuery(companyQuery, offset, limit).findIterate();
    }

    public static Query<Company> getCompanyIdsForOpcoQuery(OpCo opco) {
        return Ebean.find(Company.class).select("guid").where().eq("opco", opco).query();
    }

    public static int getCompanyIdsForOpCoCount(OpCo opco) {
        return getCompanyIdsForOpcoQuery(opco).findRowCount();
    }
}
