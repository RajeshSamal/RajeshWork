package com.ntti3.gumsapp.models;

import com.avaje.ebean.annotation.EnumMapping;

/**
 * @author jan.karwowski@ntti3.com
 */
@EnumMapping(integerType = true, nameValuePairs = "PENDING=1, ACCEPTED=3, REJECTED=2")
public enum Status  {
    PENDING(1), ACCEPTED(3), REJECTED(2);

    private final int priority;

    private Status(int priority) {
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }
}
