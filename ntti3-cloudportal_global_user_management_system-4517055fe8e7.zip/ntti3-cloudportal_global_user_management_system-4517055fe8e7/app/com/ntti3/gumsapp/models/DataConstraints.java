package com.ntti3.gumsapp.models;

/**
 * @author jan.karwowski@ntti3.com
 */
public class DataConstraints {
    public static final int READABLE_NAME_LENGTH = 64;
    public static final int UID_LENGTH = 128;
    public static final String UID_PATTERN = "^[-A-Za-z0-9_\\.@\\+]*$";
}
