package com.ntti3.gumsapp.models;

import javax.persistence.EntityNotFoundException;

/**
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class CompanyNotFoundException extends EntityNotFoundException {
    public CompanyNotFoundException() {
    }

    public CompanyNotFoundException(String message) {
        super(message);
    }
}
