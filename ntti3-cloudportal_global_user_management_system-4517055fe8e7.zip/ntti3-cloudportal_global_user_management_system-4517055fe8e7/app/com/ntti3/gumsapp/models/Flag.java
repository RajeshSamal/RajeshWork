package com.ntti3.gumsapp.models;

import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PersistenceException;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Model representing flags stored in GUMS
 * <p/>
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(columnNames = {"name"})})
public class Flag extends Model {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Constraints.Required
    @Column(nullable = false)
    private String name;

    public Flag(String name) {
        this.name = name;
    }

    public static Flag getByName(String name) {
        Finder<Integer, Flag> finder = new Finder<>(Integer.class, Flag.class);

        return finder.where().eq("name", name).findUnique();
    }

    public static Flag registerFlag(String name) {
        Flag flag = new Flag(name);
        flag.save();
        return flag;
    }

    /*
     This method assumes that entities are never removed from GUMS and PKs never change.
     */
    public static Flag getOrCreate(String name) {
        Flag flag = getByName(name);
        if (flag != null) {
            return flag;
        }
        try {
            registerFlag(name);
        } catch (PersistenceException ex) {
        }
        return getByName(name);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
