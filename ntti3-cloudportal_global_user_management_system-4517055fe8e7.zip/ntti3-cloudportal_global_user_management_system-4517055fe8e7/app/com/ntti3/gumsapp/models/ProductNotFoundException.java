package com.ntti3.gumsapp.models;

import javax.persistence.EntityNotFoundException;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class ProductNotFoundException extends EntityNotFoundException {

    private final String product;
    private static Long serialVersionUID = 1L;

    public ProductNotFoundException(String message, String product) {
        super(message);
        this.product = product;
    }

    public String getProduct() {
        return product;
    }
}
