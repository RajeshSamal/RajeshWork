package com.ntti3.gumsapp.models;

import javax.persistence.EntityNotFoundException;

/**
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class OpCoNotFoundException extends EntityNotFoundException {
    public OpCoNotFoundException() {
    }

    public OpCoNotFoundException(String message) {
        super(message);
    }
}
