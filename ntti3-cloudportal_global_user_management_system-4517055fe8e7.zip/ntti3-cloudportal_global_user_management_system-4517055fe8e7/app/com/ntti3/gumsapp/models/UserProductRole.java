package com.ntti3.gumsapp.models;

import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

/**
 * @author jan.karwowski@ntti3.com
 */
@Entity
public class UserProductRole extends Model {
    private static final long serialVersionUID = 2L;

    @Constraints.Required
    @ManyToOne
    private Product product;

    @Constraints.Required
    @ManyToOne
    private User user;

    @Constraints.Required
    @ManyToOne(fetch = FetchType.EAGER)
    private Role role;

    public Product getProduct() {
        return product;
    }

    public User getUser() {
        return user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public UserProductRole(Product product, User user, Role role) {
        this.product = product;
        this.user = user;
        this.role = role;
    }
}
