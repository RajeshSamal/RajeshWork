package com.ntti3.gumsapp.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.play.data.PowerValidator;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.validation.constraints.NotNull;

/**
 * Represents OpCo entity in GUMS.
 * <p/>
 * Created by jan.karwowski@ntti3.com on 03.02.14.
 */
@Entity
public class OpCo extends Model implements ModelWithStringId {
    @Id
    @JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER)
    @Constraints.MaxLength(DataConstraints.UID_LENGTH)
    @Constraints.Pattern(DataConstraints.UID_PATTERN)
    private String opcoUid;
    @NotNull
    @JsonProperty(GumsProtocolConstants.OPCO_NAME_PARAMETER)
    @Constraints.MaxLength(DataConstraints.READABLE_NAME_LENGTH)
    private String opcoName;

    public OpCo(String opcoUid, String opcoName) {
        this.opcoUid = opcoUid;
        this.opcoName = opcoName;
    }

    /**
     * This method assumes that entities are never removed from GUMS and PKs never change.
     *
     * @param opcoUid
     * @param opcoName
     * @return
     */
    public static OpCo getOrRegister(String opcoUid, String opcoName) {
        OpCo opco;
        try {
            opco = getById(opcoUid);
            if (!opco.getOpcoName().equals(opcoName)) {
                opco.setOpcoName(opcoName);
                try {
                    PowerValidator.validate(opco);
                    opco.save();
                } catch (OptimisticLockException e) {
                    //OK -- somebody else updated the data
                }
            }
        } catch (OpCoNotFoundException e) {
            opco = new OpCo(opcoUid, opcoName);
            try {
                PowerValidator.validate(opco);
                opco.save();
            } catch (PersistenceException ex) {
                opco = getById(opcoUid);
            }
        }
        return opco;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public String getOpcoName() {
        return opcoName;
    }

    public void setOpcoName(String opcoName) {
        this.opcoName = opcoName;
    }

    public static OpCo getById(String opco) {
        OpCo o = new Finder<>(String.class, OpCo.class).byId(opco);
        if (o == null) {
            throw new OpCoNotFoundException("Opco with uid " + opco + " not found");
        }
        return o;
    }

    @Override
    @JsonIgnore
    public String getIdAsString() {
        return getOpcoUid();
    }
}
