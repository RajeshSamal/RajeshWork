package com.ntti3.gumsapp.models;

import javax.persistence.EntityNotFoundException;

/**
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class UserNotFoundException extends EntityNotFoundException {
    public UserNotFoundException() {
    }

    public UserNotFoundException(String message) {
        super(message);
    }
}
