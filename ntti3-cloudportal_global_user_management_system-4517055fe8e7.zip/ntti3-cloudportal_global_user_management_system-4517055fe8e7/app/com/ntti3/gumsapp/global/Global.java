package com.ntti3.gumsapp.global;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.inject.AbstractModule;
import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.TypeLiteral;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.ValidationFailedException;
import com.ntti3.gumsapp.controllers.UsersToAcceptQueue;
import com.ntti3.gumsapp.controllers.UsersToRejectQueue;
import com.ntti3.gumsapp.helpers.PeerConnectionFailureException;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.CompanyNotFoundException;
import com.ntti3.gumsapp.models.Flag;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.OpCoNotFoundException;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.ProductNotFoundException;
import com.ntti3.gumsapp.models.Role;
import com.ntti3.gumsapp.models.UserNotFoundException;
import com.ntti3.gumsapp.registration.AcceptEmailTemplate;
import com.ntti3.gumsapp.registration.AcceptanceProcessingTask;
import com.ntti3.gumsapp.registration.DefaultProducts;
import com.ntti3.gumsapp.registration.PendingUserScanner;
import com.ntti3.gumsapp.registration.RejectEmailTemplate;
import com.ntti3.gumsapp.registration.RejectionProcessingTask;
import com.ntti3.gumsapp.registration.ScanFrequency;
import com.ntti3.gumsapp.registration.UserScanner;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.mailing.connector.MailingSystemConnectorFactory;
import com.ntti3.play.annotations.RequestBodyMissingException;
import com.ntti3.play.annotations.RequestParametersMissingException;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.excetions.handling.SimpleExceptionHandler;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.Application;
import play.Configuration;
import play.GlobalSettings;
import play.Logger;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Http.Response;
import play.mvc.Results;
import play.mvc.SimpleResult;

import javax.annotation.Nullable;
import javax.persistence.PersistenceException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Global extends GlobalSettings {
    private static final String APPLICATION_NAME = "gums";
    public static final String ACCEPTED_TEMPLATE_CONFIG_KEY = "registration.accepted_template";
    public static final String REJECTED_TEMPLATE_CONFIG_KEY = "registration.rejected_template";
	public static final String SCANNER_FREQUENCY_CONFIG_KEY = "scanner.frequency";
    private static final int THREAD_WAIT_TIME = 2000;
	private static final String MAILING_SYSTEM_URL_KEY = "mailingSystem.url";
    protected GlobalExceptionsHandler globalExceptionsHandler = new GlobalExceptionsHandler();
    private volatile Injector injector;
    BlockingQueue<UUID> usersToAccept;
    BlockingQueue<Integer> pendingUsersToReject;
    private Thread usersToAcceptProcessingThread;
    private Thread usersToRejectProcessingThread;
    private Thread userToAcceptCollectorThread;
    private Thread userToRejectCollectorThread;

    @Override
    public void onStart(Application app) {
        super.onStart(app);

        final ExecutorService executorService;
        final OpcoUpdatersStore opcoUpdatersStore;
        final MailingSystemConnector mailSystem;
        final Long SCAN_FREQUENCY = Configuration.root().getMilliseconds(SCANNER_FREQUENCY_CONFIG_KEY);
        final String ACCEPTED_EMAIL_TEMPLATE = Configuration.root().getString(ACCEPTED_TEMPLATE_CONFIG_KEY);
        final String REJECTED_EMAIL_TEMPLATE = Configuration.root().getString(REJECTED_TEMPLATE_CONFIG_KEY);

        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(UserNotFoundException.class, ErrorCode
                .USER_NOT_FOUND, "User not found"));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(CompanyNotFoundException.class, ErrorCode
                .COMPANY_NOT_FOUND, "Company not found"));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(OpCoNotFoundException.class, ErrorCode
                .OPCO_NOT_FOUND, "OpCo not found"));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(ProductNotFoundException.class, ErrorCode
                .PRODUCT_NOT_FOUND, "Product not found"));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(RequestBodyMissingException.class, ErrorCode
                .MISSING_PARAMETERS, "Missing required request body"));
        
        globalExceptionsHandler.registerHandler(new AbstractExceptionHandler<RequestParametersMissingException>(RequestParametersMissingException.class) {
			@Override
			protected SimpleResult handleExceptionWithType(RequestParametersMissingException ex,
					Response response) {
				return Results.badRequest(ResponseHelper.errorResponse(
						ErrorCode.INCORRECT_PARAMETER_FORMAT, "Missing parameters",
						ex.getMessage()));
			}
        	
        });
        
        globalExceptionsHandler.registerHandler(new AbstractExceptionHandler<ValidationFailedException>(ValidationFailedException.class) {
			@Override
			protected SimpleResult handleExceptionWithType(ValidationFailedException ex,
					Response response) {
				return Results.badRequest(ResponseHelper.errorResponse(
						ErrorCode.INCORRECT_PARAMETER_FORMAT, "Incorrect parameter format",
						ex.getValidationMessages().toString()));
			}
        	
        });
        
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(com.ntti3.gums.register
                .exceptions.UserNotFoundException.class, ErrorCode
                .INCORRECT_CALL, "Temporary failure", 500));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(RegistrationProtocolException.class,
                ErrorCode.INCORRECT_CALL, "Temporary failure", 500));
        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(PeerConnectionFailureException.class,
                ErrorCode.INCORRECT_CALL, "Temporary failure", 500));
        globalExceptionsHandler.registerHandler(new AbstractExceptionHandler<ConstraintViolationException>
                (ConstraintViolationException.class) {
            @Override
            protected SimpleResult handleExceptionWithType(ConstraintViolationException exception,
                    Http.Response response) {
                StringBuilder errorDetails = new StringBuilder();

                for (ConstraintViolation<?> violation : exception.getConstraintViolations()) {
                    errorDetails.append(violation.getMessage()).append("\n");
                }
                return Results.badRequest(ResponseHelper.errorResponse(ErrorCode.INCORRECT_PARAMETER_FORMAT,
                        "Parameter constraint violation", errorDetails.toString()));
            }
        });
        
        executorService = Executors.newFixedThreadPool(Configuration.root().getInt("threadPool.size"));
        try {
            opcoUpdatersStore = initOpcoUpdatersStore();
            mailSystem = initMailSystem();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        usersToAccept = new LinkedBlockingQueue<>();
        pendingUsersToReject = new LinkedBlockingQueue<>();

        injector = Guice.createInjector(new BuildInfoReaderModule(APPLICATION_NAME), new Module() {
            @Override
            public void configure(Binder binder) {
                binder.bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
                binder.bind(ExecutorService.class).toInstance(executorService);
                binder.bind(OpcoUpdatersStore.class).toInstance(opcoUpdatersStore);
                binder.bind(MailingSystemConnector.class).toInstance(mailSystem);
                binder.bind(new TypeLiteral<BlockingQueue<UUID>>() {
                })
                        .annotatedWith(UsersToAcceptQueue.class)
                        .toInstance(usersToAccept);
                binder.bind(new TypeLiteral<BlockingQueue<Integer>>() {
                })
                        .annotatedWith(UsersToRejectQueue.class)
                        .toInstance(pendingUsersToReject);
                binder.bind(Long.class).annotatedWith(ScanFrequency.class)
                		.toInstance(SCAN_FREQUENCY);
                binder.bind(String.class).annotatedWith(AcceptEmailTemplate.class)
        				.toInstance(ACCEPTED_EMAIL_TEMPLATE);
                binder.bind(String.class).annotatedWith(RejectEmailTemplate.class)
        				.toInstance(REJECTED_EMAIL_TEMPLATE);
            }
        }, getDefaultProductsModule());
        
        insertStandardFlags();

        usersToAcceptProcessingThread = new Thread(injector.getInstance(AcceptanceProcessingTask.class));
        usersToAcceptProcessingThread.setDaemon(true);
        usersToAcceptProcessingThread.start();
        
        usersToRejectProcessingThread = new Thread(injector.getInstance(RejectionProcessingTask.class));
        usersToRejectProcessingThread.setDaemon(true);
        usersToRejectProcessingThread.start();

        userToAcceptCollectorThread = new Thread(injector.getInstance(UserScanner.class));
        userToAcceptCollectorThread.setDaemon(true);
        userToAcceptCollectorThread.start();
        
        userToRejectCollectorThread = new Thread(injector.getInstance(PendingUserScanner.class));
        userToRejectCollectorThread.setDaemon(true);
        userToRejectCollectorThread.start();
    }

    private Module getDefaultProductsModule() {
        final Set<String> optionalDefaultProducts = Sets.newHashSet(Optional
                .of(Configuration.root().getStringList("gums.default-products")).get());

        return new AbstractModule() {
            @Override
            protected void configure() {
                bind(new TypeLiteral<Set<String>>(){})
                        .annotatedWith(DefaultProducts.class)
                        .toInstance(optionalDefaultProducts);
            }
        };
    }

    @Override
    public void onStop(Application app) {
        usersToAcceptProcessingThread.interrupt();
        usersToRejectProcessingThread.interrupt();
        userToAcceptCollectorThread.interrupt();
        userToRejectCollectorThread.interrupt();
        try {
            usersToAcceptProcessingThread.join(THREAD_WAIT_TIME);
            usersToRejectProcessingThread.join(THREAD_WAIT_TIME);
            userToAcceptCollectorThread.join(THREAD_WAIT_TIME);
            userToRejectCollectorThread.join(THREAD_WAIT_TIME);
            Logger.info("Joined user processing threads.");
        } catch (InterruptedException e) {
            Logger.info("Failed joining processing threads", e);
        }
    }

    protected MailingSystemConnector initMailSystem() throws Exception {
        return MailingSystemConnectorFactory.getMailingSystemConnector(
                Configuration.root().getString(MAILING_SYSTEM_URL_KEY)
        );
    }

    protected OpcoUpdatersStore initOpcoUpdatersStore() throws Exception {
        return new OpcoUpdatersStore(Collections.<String, UserRegistrationConnector>emptyMap());
    }

    private static void insertStandardFlags() {
        List<String> flags = Configuration.root().getStringList("gums.flags");
        if (flags != null) {
            for (String flag : flags) {
                Flag.getOrCreate(flag);
            }
        }

        List<String> products = Configuration.root().getStringList("gums.products");
        if (products != null) {
            for (String product : products) {
                try {
                    Product.registerProduct(product);
                } catch (PersistenceException ex) {
                    Logger.info("Tried to add a product {}, which already exists.", product);
                }
            }
        }

        List<String> roles = Configuration.root().getStringList("gums.roles");
        if (roles != null) {
            for (String role : roles) {
                try {
                    new Role(role).save();
                } catch (PersistenceException ex) {
                    Logger.info("Tried to add a role {}, which already exists.", role);
                }
            }
        }

        Map<String, String> defOpcos = Maps.transformValues(Configuration.root().getConfig("gums.opcos").asMap(),
                new Function<Object, String>() {
                    @Nullable
                    @Override
                    public String apply(Object input) {
                        return input.toString();
                    }
                });

        for (Map.Entry<String, String> opco : defOpcos.entrySet()) {
            try {
                new OpCo(opco.getKey(), opco.getValue()).save();
            } catch (PersistenceException ex) {
                Logger.info("Tried to add an opco {}, which already exists.", opco);
            }
        }
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return injector.getInstance(controllerClass);
    }

    @Override
    public F.Promise<SimpleResult> onHandlerNotFound(Http.RequestHeader request) {
        return F.Promise.<SimpleResult>pure(Results.badRequest(ResponseHelper.errorResponse(ErrorCode
                .INCORRECT_CALL, "Bad request path",
                "Request path: " + request.path() + " is incorrect")));
    }

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }
}
