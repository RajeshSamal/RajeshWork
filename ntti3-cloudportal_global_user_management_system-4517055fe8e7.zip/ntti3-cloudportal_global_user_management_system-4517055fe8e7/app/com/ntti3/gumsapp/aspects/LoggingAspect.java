package com.ntti3.gumsapp.aspects;

import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {
    @Pointcut("execution(* com.ntti3.gumsapp.controllers.*.*(..)) && !execution(* com.ntti3.gumsapp.controllers.*.*$*(..))")
    @Override
    public void controllerMethodPointcut() {
    }


    @Pointcut("within(com.ntti3.gumsapp.registration..*) || within(com.ntti3.gumsapp.misc.opco..*) || within(com.ntti3.gumsapp.helpers..*)")
	@Override
	public void applicationMethodPointcut() {
	}
	
	@Override
	public String getPathContains() {
		return "gums";
	}
}
