package com.ntti3.gumsapp.helpers;

/**
 * @author jan.karwowski@ntti3.com
 */
public class PeerConnectionFailureException extends Exception {
    private static final long serialVersionUID = 2L;

    public PeerConnectionFailureException() {
    }

    public PeerConnectionFailureException(String message) {
        super(message);
    }

    public PeerConnectionFailureException(String message, Throwable cause) {
        super(message, cause);
    }

    public PeerConnectionFailureException(Throwable cause) {
        super(cause);
    }

    public PeerConnectionFailureException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
