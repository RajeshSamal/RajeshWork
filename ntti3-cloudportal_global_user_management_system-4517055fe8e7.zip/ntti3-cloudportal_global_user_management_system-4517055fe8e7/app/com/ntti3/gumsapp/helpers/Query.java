package com.ntti3.gumsapp.helpers;

/**
 * @author Kamil Kawka (kamil.kawka@codilime.com)
 */
public class Query {
    public static <T> com.avaje.ebean.Query<T> addOrderBy(com.avaje.ebean.Query<T> ebeanQuery, OrderBy orderBy) {
        if (orderBy != null) {
            return orderBy.apply(ebeanQuery);
        }
        return ebeanQuery;
    }

    public static <T> com.avaje.ebean.Query<T> addLimit(com.avaje.ebean.Query<T> ebeanQuery, Integer offset,
			Integer limit) {
		if (offset != null) {
			ebeanQuery = ebeanQuery.setFirstRow(offset);
		}
		if (limit != null) {
			ebeanQuery = ebeanQuery.setMaxRows(limit);
		}
		return ebeanQuery;
	}
}
