package com.ntti3.gumsapp.helpers;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;

import java.util.List;
import java.util.UUID;

/**
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class JsonResponseHelper {
    public static ObjectNode buildGuidResponse(UUID guid) {
        ObjectNode node = JsonNodeFactory.instance.objectNode();

        node.put("guid", guid.toString());
        return node;
    }

    public static ObjectNode createJsonArray(String arrayKey, List<String> flags) {
        ObjectNode mainNode = Json.newObject();
        ArrayNode array = mainNode.putArray(arrayKey);
        for (String flag : flags) {
            array.add(flag);
        }
        return mainNode;
    }
}
