package com.ntti3.gumsapp.helpers;

import com.google.common.base.Function;
import com.ntti3.gumsapp.models.ModelWithStringId;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GetStringIdFunc implements Function<ModelWithStringId, Object> {
    @Override
    public Object apply(ModelWithStringId input) {
        return input.getIdAsString();
    }
}
