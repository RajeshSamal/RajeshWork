package com.ntti3.gumsapp.helpers;

import com.avaje.ebean.Query;
import com.ntti3.gums.GumsProtocolConstants;

import javax.annotation.concurrent.Immutable;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
@Immutable
public class OrderBy {
    private final String column;
    private final Order order;
    public static final OrderBy NAN_ORDER = new OrderBy("", Order.NAN);

    public OrderBy(String column, Order order) {
        this.column = column;
        this.order = order;
    }

    public <T> Query<T> apply(Query<T> query) {
        switch (order) {
            case ASC:
                return query.order().asc(column);
            case DESC:
                return query.order().desc(column);
            case NAN:
                return query;
        }
        throw new IllegalArgumentException("Unexpected order: " + order.toString());
    }


    /**
     * @param queryString
     * @return Order from query if both query params
     * {@link com.ntti3.gums.GumsProtocolConstants#ORDER_BY_QUERY_PARAM}
     * and {@link com.ntti3.gums.GumsProtocolConstants#ORDER_QUERY_PARAM} are set,
     * {@link #NAN_ORDER} otherwise}
     */
    public static OrderBy buildFromQueryString(Map<String, String[]> queryString) {
        if (queryString.containsKey(GumsProtocolConstants.ORDER_QUERY_PARAM) &&
            queryString.containsKey(GumsProtocolConstants.ORDER_BY_QUERY_PARAM)) {
            return new OrderBy(queryString.get(GumsProtocolConstants.ORDER_BY_QUERY_PARAM)[0],
                    Order.valueOf(queryString.get(GumsProtocolConstants.ORDER_QUERY_PARAM)[0]));
        }
        return NAN_ORDER;
    }
}
