package com.ntti3.gumsapp.helpers;

import com.google.common.base.Preconditions;
import com.ntti3.gumsapp.models.Status;
import play.libs.F;
import play.mvc.QueryStringBindable;

import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GreatStatusBinder implements QueryStringBindable<GreatStatusBinder> {
    private Status status;

    public GreatStatusBinder() {}

    public GreatStatusBinder(Status status) {
    	Preconditions.checkNotNull(status);
        this.status = status;
    }

    @Override
    public F.Option<GreatStatusBinder> bind(String key, Map<String, String[]> data) {
        if (data.containsKey(key) && data.get(key)[0] != null ) {
            try {
                return F.Option.Some(new GreatStatusBinder(Status.valueOf(data.get(key)[0])));
            } catch (IllegalArgumentException ex) {
                return F.Option.None();
            }
        }
        return F.Option.None();
    }

    @Override
    public String unbind(String key) {
        return key + "=" + status.name();
    }

    @Override
    public String javascriptUnbind() {
        return status.name();
    }

    public Status getStatus() {
        return status;
    }
}
