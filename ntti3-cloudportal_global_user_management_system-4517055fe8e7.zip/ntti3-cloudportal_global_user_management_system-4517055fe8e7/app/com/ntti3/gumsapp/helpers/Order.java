package com.ntti3.gumsapp.helpers;

/**
 * Order directions used by {@link OrderBy}
 *
 * @author jan.karwowski@ntti3.com
 */
public enum Order {

    ASC,
    DESC,
    /**
     * None order -- {@link OrderBy} with this order will not impose any order on query
     */
    NAN
}
