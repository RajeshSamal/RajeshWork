package com.ntti3.gumsapp.misc.opco;

import com.google.common.collect.ImmutableMap;
import com.ntti3.gums.register.UserRegistrationConnector;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OpcoUpdatersStore {
    private final ImmutableMap<String, UserRegistrationConnector> connectors;

    public OpcoUpdatersStore(@Nonnull Map<String, UserRegistrationConnector> connectors) {
        this.connectors = ImmutableMap.copyOf(connectors);
    }

    public boolean isOpcoUpdateable(@Nonnull String opcoUid) {
        return connectors.containsKey(opcoUid);
    }

    public UserRegistrationConnector getOpcoUpdater(@Nonnull String opcoUid) {
        return connectors.get(opcoUid);
    }

    public Collection<String> updateableOpcos() {
        return connectors.keySet();
    }

}
