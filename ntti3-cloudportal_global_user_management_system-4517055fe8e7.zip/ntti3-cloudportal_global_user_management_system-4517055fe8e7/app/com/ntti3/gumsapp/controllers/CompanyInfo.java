package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gumsapp.helpers.GetStringIdFunc;
import com.ntti3.gumsapp.helpers.JsonResponseHelper;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.gumsapp.models.CompanyNotFoundException;
import com.ntti3.gumsapp.models.User;
import com.ntti3.play.annotations.EnsureUrlEncodedRequestBody;
import com.ntti3.play.data.PowerValidator;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.Logger;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Results;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.ntti3.gums.GumsProtocolConstants.OPCO_C_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_C_UID_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.USER_ARRAY_FIELD;

@ControllerExceptionSupport.ExceptionHandler()
public class CompanyInfo extends Controller {

	@Inject
	private final ExecutorService executorService;

	static final JsonFactory jsonFactory = new JsonFactory();

	@Inject
	public CompanyInfo(ExecutorService executorService) {
		Preconditions.checkNotNull(executorService);
		this.executorService = executorService;
	}

	public Result getUsers(final UUID companyGuid, final Integer offset,
			final Integer limit) throws Exception {
		final com.ntti3.gumsapp.models.Company company = com.ntti3.gumsapp.models.Company.getById(companyGuid);
		final OrderBy orderBy = OrderBy.buildFromQueryString(request()
				.queryString());
		return streamEntityList(new Callable<QueryIterator<User>>() {
			@Override
			public QueryIterator<User> call() throws Exception {
				return User.getUserIdsForCompany(company, offset, limit,
						orderBy);
			}
		}, new GetStringIdFunc(), USER_ARRAY_FIELD,
				User.getUserIdsForCompanyCount(company), executorService);
	}

	public static <T> Result streamEntityList(
			final Callable<QueryIterator<T>> func,
			final Function<? super T, Object> genNodeF, final String arrayName,
			final int count, ExecutorService executorService)
			throws InnerFunctionException {
		final PipedOutputStream output = new PipedOutputStream();
		final PipedInputStream input;
		final QueryIterator<T> it;
		try {
			input = new PipedInputStream(output);
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
		try {
			it = func.call();
		} catch (Exception e) {
			try {
				input.close();
			} catch (IOException e1) {
				Logger.error("Pipe closing exception!!", e1);
			}
			throw new InnerFunctionException(e);
		}
		Runnable jsonStreamer = new Runnable() {
			@Override
			public void run() {
				try (OutputStream elOs = output;
						QueryIterator<T> result = it;
						JsonGenerator generator = jsonFactory
								.createGenerator(output)) {
					generator.writeStartObject();
					generator.writeNumberField("count", count);
					generator.writeArrayFieldStart(arrayName);

					while (result.hasNext()) {
						T user = result.next();
						generator.writeObject(genNodeF.apply(user));
					}

					generator.writeEndArray();
					generator.writeEndObject();
				} catch (Exception e) {
					Logger.error("Exception in streaming thread: ", e);

				}
			}
		};

		executorService.execute(jsonStreamer);
		return ok(input);
	}

	public Result getGuid(String opcoUid, String opcoCUid) {
		return Results.ok(JsonResponseHelper.buildGuidResponse(com.ntti3.gumsapp.models.Company.getCompanyGuid(
                opcoUid, opcoCUid)));
	}

	@EnsureUrlEncodedRequestBody()
	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	public Result register() {
		Map<String, String[]> body = request().body().asFormUrlEncoded();
		String opcoUid;
		String opcoCUid;
		String opcoCName;

		final String[] requiredParameters = {
				GumsProtocolConstants.OPCO_UID_PARAMETER,
				GumsProtocolConstants.OPCO_C_NAME_PARAMETER };

		if (RegisterUser.containsAnyNullParams(body,
				Arrays.asList(requiredParameters))) {
			return badRequest(ResponseHelper
					.errorResponse(
							ErrorCode.MISSING_PARAMETERS,
							"Not all required form parameters were set",
							String.format("Required: %s, Given: %s",
									Arrays.toString(requiredParameters),
									body.keySet())));
		}

		opcoUid = body.get(GumsProtocolConstants.OPCO_UID_PARAMETER)[0];
        if(body.containsKey(GumsProtocolConstants.OPCO_C_UID_PARAMETER) && body.get(GumsProtocolConstants.OPCO_C_UID_PARAMETER) != null) {
            opcoCUid = body.get(GumsProtocolConstants.OPCO_C_UID_PARAMETER)[0];
        } else {
            opcoCUid = null;
        }
		opcoCName = body.get(GumsProtocolConstants.OPCO_C_NAME_PARAMETER)[0];

		com.ntti3.gumsapp.models.Company company = com.ntti3.gumsapp.models.Company.registerWithOpCoUid(opcoCUid, opcoCName,
                opcoUid);

		return ok(JsonResponseHelper.buildGuidResponse(company.getGuid()));
	}

	public Result get(UUID companyGuid) {
		try {
			com.ntti3.gumsapp.models.Company company = com.ntti3.gumsapp.models.Company.getById(companyGuid);
			return ok(Json.toJson(company));
		} catch (CompanyNotFoundException ex) {
			return notFound();
		}
	}

	@EnsureUrlEncodedRequestBody()
	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	public Result update(UUID companyGuid) {
		try {
			com.ntti3.gumsapp.models.Company company = com.ntti3.gumsapp.models.Company.getById(companyGuid);
			Map<String, String[]> body = request().body().asFormUrlEncoded();

			if (body.containsKey(GumsProtocolConstants.OPCO_C_NAME_PARAMETER)) {
				company.setOpcoCName(body.get(OPCO_C_NAME_PARAMETER)[0]);
			}
			if (body.containsKey(GumsProtocolConstants.OPCO_C_UID_PARAMETER)) {
				company.setOpcoCUid(body.get(OPCO_C_UID_PARAMETER)[0]);
			}
			PowerValidator.validate(company);
			company.save();
			return ok();
		} catch (CompanyNotFoundException ex) {
			return notFound();
		}
	}

}
