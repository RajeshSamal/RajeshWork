package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.QueryIterator;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gumsapp.helpers.GetStringIdFunc;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.OpCoNotFoundException;
import com.ntti3.play.annotations.EnsureUrlEncodedRequestBody;
import com.ntti3.play.data.PowerValidator;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;

import javax.persistence.PersistenceException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.ntti3.gums.GumsProtocolConstants.COMPANY_ARRAY_FIELD;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.OPCO_UID_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.USER_ARRAY_FIELD;

/**
 * A controller providing info about OpCo
 * 
 * @author jan.karwowski@ntti3.com
 */
@ControllerExceptionSupport.ExceptionHandler()
public class OpcoInfo extends Controller {
	private final ExecutorService executorService;
	private final OpcoUpdatersStore opcoUpdatersStore;

	@Inject
	public OpcoInfo(ExecutorService executorService,
			OpcoUpdatersStore opcoUpdatersStore) {
		Preconditions.checkNotNull(executorService);
		Preconditions.checkNotNull(opcoUpdatersStore);
		this.executorService = executorService;
		this.opcoUpdatersStore = opcoUpdatersStore;
	}

	public Result getUsers(final String opcoUid, final Integer offset,
			final Integer limit) {
		final OrderBy orderBy;
		try {
			orderBy = OrderBy.buildFromQueryString(request()
					.queryString());
		} catch (IllegalArgumentException ex) {
			return badRequest();
		}
		final OpCo opco = OpCo.getById(opcoUid);
		try {
			return CompanyInfo.streamEntityList(
					new Callable<QueryIterator<com.ntti3.gumsapp.models.User>>() {
						@Override
						public QueryIterator<com.ntti3.gumsapp.models.User> call() throws Exception {
							return com.ntti3.gumsapp.models.User.getUserIdsForOpCo(opco, offset, limit,
                                    orderBy);
						}
					}, new GetStringIdFunc(), USER_ARRAY_FIELD, com.ntti3.gumsapp.models.User
							.getUserIdsForOpCoCount(opco), executorService);
		} catch (InnerFunctionException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Result getPendingUsers(final String opcoUid, final Integer offset,
			final Integer limit) {
		final OrderBy orderBy;
		try {
			orderBy = OrderBy.buildFromQueryString(request()
					.queryString());
		} catch (IllegalArgumentException ex) {
			return badRequest();
		}
		final OpCo opco = OpCo.getById(opcoUid);
		try {
			return CompanyInfo.streamEntityList(
					new Callable<QueryIterator<com.ntti3.gumsapp.models.PendingUser>>() {
						@Override
						public QueryIterator<com.ntti3.gumsapp.models.PendingUser> call() throws Exception {
							return com.ntti3.gumsapp.models.PendingUser.getUserIdsForOpCo(opco, offset, limit,
                                    orderBy);
						}
					}, new GetStringIdFunc(), USER_ARRAY_FIELD, com.ntti3.gumsapp.models.PendingUser
							.getUserIdsForOpCoCount(opco), executorService);
		} catch (InnerFunctionException e) {
			throw new RuntimeException(e);
		}
	}

	public Result getCompanies(String opcoUid, final Integer offset,
			final Integer limit) throws Exception {
		final OpCo opco = OpCo.getById(opcoUid);
		final OrderBy orderBy = OrderBy.buildFromQueryString(request()
				.queryString());
		return CompanyInfo.streamEntityList(
				new Callable<QueryIterator<com.ntti3.gumsapp.models.Company>>() {
					@Override
					public QueryIterator<com.ntti3.gumsapp.models.Company> call() throws Exception {
						return com.ntti3.gumsapp.models.Company.getCompanyIdsForOpCo(opco, offset,
                                limit, orderBy);
					}
				}, new GetStringIdFunc(), COMPANY_ARRAY_FIELD, com.ntti3.gumsapp.models.Company
						.getCompanyIdsForOpCoCount(opco), executorService);
	}

	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	@EnsureUrlEncodedRequestBody()
	public Result register() {
		Map<String, String[]> body = request().body().asFormUrlEncoded();
		if (body == null || !body.containsKey(OPCO_UID_PARAMETER)
				|| !body.containsKey(OPCO_NAME_PARAMETER)) {
			return badRequest(ResponseHelper.errorResponse(
					ErrorCode.MISSING_PARAMETERS, "Missing parameters",
					"Required both " + OPCO_UID_PARAMETER + " and "
							+ OPCO_NAME_PARAMETER + "params."));
		}

		String opcoUid = body.get(OPCO_UID_PARAMETER)[0];
		String opcoName = body.get(OPCO_NAME_PARAMETER)[0];
		try {
			OpCo opCo = new OpCo(opcoUid, opcoName);
			PowerValidator.validate(opCo);
			opCo.save();
		} catch (PersistenceException ex) {
			try {
				OpCo.getById(opcoUid);
				return badRequest(ResponseHelper.errorResponse(
						ErrorCode.ENTITY_EXISTS, "OpCo already registered",
						"OpCo " + opcoUid + " already registered."));
			} catch (OpCoNotFoundException e) {
				throw ex;
			}
		}
		return ok();
	}

	public Result get(String opcoUid) {
		try {
			OpCo opco = OpCo.getById(opcoUid);
			return (ok(Json.toJson(opco)));
		} catch (OpCoNotFoundException ex) {
			return notFound();
		}
	}

	public Result getRegistrable() {
		List<String> ret = new ArrayList<>(
				opcoUpdatersStore.updateableOpcos());
		return ok(Json.toJson(ret));
	}

	@EnsureUrlEncodedRequestBody()
	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	public Result update(String opcoUid) {
		try {
			Map<String, String[]> body = request().body().asFormUrlEncoded();
			OpCo opco = OpCo.getById(opcoUid);
			if (body.containsKey(GumsProtocolConstants.OPCO_NAME_PARAMETER)) {
				opco.setOpcoName(body.get(OPCO_NAME_PARAMETER)[0]);
			}
			PowerValidator.validate(opco);
			opco.save();
			return (ok());
		} catch (OpCoNotFoundException ex) {
			return notFound();
		}
	}
}
