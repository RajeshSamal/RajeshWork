package com.ntti3.gumsapp.controllers;

/**
* @author jan.karwowski@ntti3.com
*/
public class InnerFunctionException extends Exception {
    private static final long serialVersionUID = 2L;

    InnerFunctionException() {
    }

    InnerFunctionException(String message) {
        super(message);
    }

    InnerFunctionException(String message, Throwable cause) {
        super(message, cause);
    }

    InnerFunctionException(Throwable cause) {
        super(cause);
    }

    InnerFunctionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
