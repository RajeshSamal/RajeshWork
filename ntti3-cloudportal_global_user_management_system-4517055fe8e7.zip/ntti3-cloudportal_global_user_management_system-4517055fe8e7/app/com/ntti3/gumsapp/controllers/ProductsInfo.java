package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.Ebean;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gumsapp.helpers.JsonResponseHelper;
import com.ntti3.gumsapp.models.Product;
import play.mvc.Controller;
import play.mvc.Result;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ProductsInfo extends Controller {
    public Result get() {
        return ok(JsonResponseHelper.createJsonArray(
                GumsProtocolConstants.PRODUCTS_PARAMETER,
                Lists.transform(Ebean.find(Product.class).findList(),
                        new Function<Product, String>() {
                            @Override
                            public String apply(Product input) {
                                return input.getName();
                            }
                        })));
    }
}
