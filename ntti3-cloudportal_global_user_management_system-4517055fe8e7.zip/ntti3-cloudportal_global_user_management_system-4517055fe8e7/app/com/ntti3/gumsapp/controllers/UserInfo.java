package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.avaje.ebean.Update;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.UserNotFoundException;
import com.ntti3.gumsapp.helpers.GetStringIdFunc;
import com.ntti3.gumsapp.helpers.JsonResponseHelper;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.gumsapp.helpers.PeerConnectionFailureException;
import com.ntti3.gumsapp.helpers.Query;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.Flag;
import com.ntti3.gumsapp.models.Product;
import com.ntti3.gumsapp.models.ProductNotFoundException;
import com.ntti3.gumsapp.models.Role;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.models.UserProductRole;
import com.ntti3.play.annotations.EnsureUrlEncodedRequestBody;
import com.ntti3.play.data.PowerValidator;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import play.Logger;
import play.Play;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Results;

import javax.ws.rs.PathParam;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.ntti3.gums.GumsProtocolConstants.*;

/**
 * Controller responsible for requests connected to user entity
 * <p/>
 * Created by jan.karwowski@ntti3.com on 30.01.14.
 */
@Api(value = "/public/user", description = "Operations on users registered in GUMS")
@ControllerExceptionSupport.ExceptionHandler()
public class UserInfo extends Controller {
	private ObjectMapper mapper = new ObjectMapper();

    private final ExecutorService executorService;
    private final Boolean assignAllProducts;

	protected final OpcoUpdatersStore opcoUpdatersStore;

	public class UserDataWrapper {
		@JsonUnwrapped
		private User user;

		public User getUser() {
			return user;
		}

		@JsonProperty("is_opco_editable")
		public boolean isOpcoEditable() {
			return opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid());
		}

		private UserDataWrapper(User user) {
			this.user = user;
		}
	}

	@Inject
	public UserInfo(ExecutorService executorService,
			OpcoUpdatersStore opcoUpdatersStore) {
		Preconditions.checkNotNull(executorService);
		Preconditions.checkNotNull(opcoUpdatersStore);
		this.executorService = executorService;
		this.opcoUpdatersStore = opcoUpdatersStore;
        this.assignAllProducts = Preconditions
                .checkNotNull(Play.application().configuration().getBoolean("assign-all-products", false));
	}

	@ApiOperation(value = "Get GUID of given user id in given opco")
	public Result getGuid(@PathParam(value = OPCO_UID_PARAMETER) String opcoId,
			@PathParam(value = OPCO_U_UID_PARAMETER) String opcoUUid) {
		response().setContentType("application/json");
		return Results.ok(JsonResponseHelper.buildGuidResponse(User.getGuidFor(opcoId,
                opcoUUid)));
	}

	public Result getUser(UUID guid) throws JsonProcessingException {
		User user = User.getByGUID(guid);

		response().setContentType("application/json");
		return ok(mapper.writeValueAsString(new UserDataWrapper(user)));
	}

    public Result loginUsed(String opcoUid, String login) throws RegistrationProtocolException {
        if (opcoUpdatersStore.getOpcoUpdater(opcoUid).userExists(login)) {
            return ok("used");
        } else {
            return notFound("not used");
        }
    }

	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	@EnsureUrlEncodedRequestBody()
	public Result updateUser(UUID guid) throws IOException, RegistrationProtocolException, UserNotFoundException {
		User user = User.getByGUID(guid);
		Map<String, String[]> properties = request().body().asFormUrlEncoded();

		Map<String, Object> map = Maps.transformEntries(properties,
				new Maps.EntryTransformer<String, String[], Object>() {

					@Override
					public Object transformEntry(String key, String[] value) {
						if (key.equals(GumsProtocolConstants.FLAGS_PARAMETER)) {
							return value;
						}
						return value[0];
					}
				});
		String json = mapper.writeValueAsString(map);
		Logger.debug("got flags: "
				+ Arrays.toString((String[]) map.get("flags")));
		mapper.readerForUpdating(user).readValue(json);
		if (!properties.containsKey(FLAGS_PARAMETER)) {
			user.setFlags(Lists.<Flag> newArrayList());
		}
		user.saveManyToManyAssociations("flags");
		PowerValidator.validate(user);
		user.setOpcoUpdateable(opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid()));

		if (opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			com.ntti3.gums.register.models.User opcoUser = new com.ntti3.gums.register.models.User();
			opcoUser.setFirstName(user.getFirstName());
			opcoUser.setLastName(user.getLastName());
			opcoUser.setEmail(user.getEmail());
			opcoUser.setMobilePhone(user.getMobilePhone());
			opcoUser.setLogin(user.getOpcoUUid());
			opcoUpdatersStore.getOpcoUpdater(user.getOpcoUid()).editUser(
					opcoUser);
		}
		user.save();
		return ok();
	}

	private <K, V> V tryGetValue(Map<K, V> map, K key) {
		if (map.containsKey(key)) {
			return map.get(key);
		}
		throw new NoSuchElementException("Expected value for key: "
				+ key.toString());
	}

	@EnsureUrlEncodedRequestBody
	public Result registerUser() {
		Map<String, String[]> properties = request().body().asFormUrlEncoded();

		String[] f = properties.get(FLAGS_PARAMETER);
		List<String> flags = null;
		if (f != null) {
			flags = Arrays.asList(f);
		}

		String[] opcoCUidA = properties.get(OPCO_C_UID_PARAMETER);
		String[] opcoCNameA = properties.get(OPCO_C_NAME_PARAMETER);
		String[] mobilePhoneA = properties.get(MOBILE_PHONE_PARAMETER);
		String opcoCUid = opcoCUidA != null ? opcoCUidA[0] : null;
		String opcoCName = opcoCNameA != null ? opcoCNameA[0] : null;
		String mobilePhone = mobilePhoneA != null ? mobilePhoneA[0] : null;
		User user = User.getOrRegisterAndAssignProducts(
				tryGetValue(properties, FIRST_NAME_PARAMETER)[0],
				tryGetValue(properties, LAST_NAME_PARAMETER)[0],
				tryGetValue(properties, EMAIL_PARAMETER)[0], mobilePhone,
				tryGetValue(properties, OPCO_UID_PARAMETER)[0],
				tryGetValue(properties, OPCO_NAME_PARAMETER)[0],
				tryGetValue(properties, OPCO_U_UID_PARAMETER)[0], opcoCUid,
				opcoCName, flags, assignAllProducts);

		response().setContentType("application/json");
		return ok(JsonResponseHelper.buildGuidResponse(user.getGuid()));
	}

	public Result getProductWhiteList(UUID guid) {
		User user = User.getByGUID(guid);
		List<String> products = user.getProductsAsStrings();		
		ObjectNode mainNode = JsonResponseHelper.createJsonArray(WHITELIST_FLAG, products);
		response().setContentType("application/json");
		return ok(mainNode);
	}

	public Result isProductInWhiteList(UUID guid, String product) {
		if (User.getByGUID(guid).getProductsAsStrings().contains(product)) {
			return ok("");
		} else {
			return notFound("");
		}
	}

	public Result addProductToWhiteList(UUID guid, String product) throws ProductNotFoundException {
		Product prod = Product.getByName(product);
		User user = User.getByGUID(guid);
		if(!user.getProducts().contains(prod))
		{
			user.getProducts().add(prod);
			user.saveManyToManyAssociations("products");
		}
		return ok("");
	}

	public Result removeProductFromWhiteList(UUID guid, String product) throws ProductNotFoundException {
		Product prod = Product.getByName(product);
		User user = User.getByGUID(guid);
		if(user.getProducts().remove(prod))
		{
			if(user.getProducts().isEmpty())
			{
				user.deleteManyToManyAssociations("products");
			}
			else
			{
				user.saveManyToManyAssociations("products");
			}
			if(user.getProducts().isEmpty())
				return ok();
		}
		return notFound();
	}

	@BodyParser.Of(BodyParser.FormUrlEncoded.class)
	public Result setProductWhiteList(final UUID guid) throws ProductNotFoundException {
		List<String> whitelist;
		try {
			whitelist = Lists.newArrayList(request().body().asFormUrlEncoded()
					.get(WHITELIST_FLAG));
		} catch (NullPointerException ex) {
			whitelist = Collections.emptyList();
		}
		
		User user = User.getByGUID(guid);
		
		user.deleteManyToManyAssociations("products");
		
		if(!whitelist.isEmpty())
		{
			user.setProductsByStrings(whitelist);
			user.saveManyToManyAssociations("products");
		}
		
		return ok();
	}

	public Result getUsers(final Integer offset, final Integer limit)
			throws Exception {
		final OrderBy orderBy = OrderBy.buildFromQueryString(request()
				.queryString());
		return CompanyInfo.streamEntityList(
				new Callable<QueryIterator<User>>() {
					@Override
					public QueryIterator<User> call() throws Exception {
						return Query.addLimit(
                                Query.addOrderBy(Ebean.find(User.class), orderBy),
                                offset, limit).findIterate();
					}
				}, new GetStringIdFunc(), USER_ARRAY_FIELD, Ebean
						.find(User.class).findRowCount(), executorService);
	}

    public Result getRole(UUID user, String product) {
		UserProductRole role = Ebean.find(UserProductRole.class).where()
				.eq("user.guid", user).eq("product.name", product).findUnique();
		if (role == null)
			return notFound();
		ObjectNode node = Json.newObject();
		node.put("role", role.getRole().getName());
		return ok(node);
	}

	public Result getRoles(UUID user) {
		List<UserProductRole> roles = Ebean.find(UserProductRole.class).where()
				.eq("user.guid", user).findList();

		Map<String, String> rp = Maps.newHashMap();

		for (UserProductRole role : roles) {
			rp.put(role.getProduct().getName(), role.getRole().getName());
		}

		return ok(Json.toJson(rp));
	}

	@EnsureUrlEncodedRequestBody
	public Result setRole(UUID user, String product) {
		if (request().body().asFormUrlEncoded().get(ROLE_PARAMETER) == null)
			return badRequest();
		String role = request().body().asFormUrlEncoded().get(ROLE_PARAMETER)[0];
		Role roleBean = Ebean.find(Role.class).where().eq("name", role)
				.findUnique();
		if (roleBean == null)
			return notFound();

        final Product productBean;
        try {
            productBean = Product.getByName(product);
        } catch (ProductNotFoundException e) {
            return notFound();
        }

		User user1 = User.getByGuidNull(user);
		if (user1 == null)
			return notFound();

		Ebean.beginTransaction();
		try {
			UserProductRole userRoleBean = Ebean.find(UserProductRole.class)
					.setForUpdate(true).where().eq("user", user1)
					.eq("product", productBean).findUnique();
			if (userRoleBean == null) {
				new UserProductRole(productBean, user1, roleBean).save();
			} else {
				userRoleBean.setRole(roleBean);
				userRoleBean.save();
			}
			Ebean.commitTransaction();
			return ok();
		} finally {
			Ebean.endTransaction();
		}
	}

	public Result removeRole(UUID user, String product) {
        final Product product1;
        try {
            product1 = Product.getByName(product);
        } catch (ProductNotFoundException e) {
            return ok();
        }
		Update<UserProductRole> update = Ebean.createUpdate(
				UserProductRole.class, "DELETE FROM UserProductRole where "
						+ "user.guid = :user and product.id=:product");
		update.setParameter("user", user);
		update.setParameter("product", product1.getId());
		update.execute();
		return ok();
	}

	@EnsureUrlEncodedRequestBody
	public Result setPassword(UUID guid) throws UserNotFoundException,
			RegistrationProtocolException, PeerConnectionFailureException {
		Result br = RegisterUser.tryGetBadRequestResult(request().body()
				.asFormUrlEncoded(), PASSWORD_PARAMETER);
		if (br != null)
			return br;
		String newPassword = request().body().asFormUrlEncoded()
				.get(PASSWORD_PARAMETER)[0];
		User user = User.getByGuidNull(guid);
		if (user == null) {
			return notFound();
		}

		if (!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			return badRequest();
		}

		UserRegistrationConnector connector = opcoUpdatersStore
				.getOpcoUpdater(user.getOpcoUid());

		try {
			connector.updatePassword(user.getOpcoUUid(), newPassword);
		} catch (IOException e) {
			throw new PeerConnectionFailureException("opco updater", e);
		}

		return ok();
	}

	public Result setRecoveryQuestion(UUID guid) throws UserNotFoundException,
			RegistrationProtocolException {
		Result br = RegisterUser.tryGetBadRequestResult(request().body()
				.asFormUrlEncoded(), RECOVERY_QUESTION_ANSWER,
				RECOVERY_QUESTION_PARAMETER);
		if (br != null)
			return br;

		String question = request().body().asFormUrlEncoded()
				.get(RECOVERY_QUESTION_PARAMETER)[0];
		String answer = request().body().asFormUrlEncoded()
				.get(RECOVERY_QUESTION_ANSWER)[0];
		User user = User.getByGuidNull(guid);
		if (user == null) {
			return notFound();
		}

		if (!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			return badRequest();
		}

		UserRegistrationConnector connector = opcoUpdatersStore
				.getOpcoUpdater(user.getOpcoUid());

		connector.updateRecoveryQuestion(user.getOpcoUUid(), question, answer);

		return ok();
	}

	public Result updatePassword(UUID guid) throws UserNotFoundException,
			RegistrationProtocolException {
		Result br = RegisterUser.tryGetBadRequestResult(request().body()
				.asFormUrlEncoded(), NEW_PASSWORD_PARAMETER,
				OLD_PASSWORD_PARAMETER);
		if (br != null)
			return br;

		String newPassword = request().body().asFormUrlEncoded()
				.get(NEW_PASSWORD_PARAMETER)[0];
		String oldPassword = request().body().asFormUrlEncoded()
				.get(OLD_PASSWORD_PARAMETER)[0];

		User user = User.getByGuidNull(guid);
		if (user == null) {
			return notFound();
		}

		if (!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			return badRequest();
		}

		UserRegistrationConnector connector = opcoUpdatersStore
				.getOpcoUpdater(user.getOpcoUid());

		if (!connector.updatePassword(user.getOpcoUUid(), oldPassword,
				newPassword))
			return unauthorized();

		return ok();
	}

	public Result updateRecoveryQuestion(UUID guid)
			throws UserNotFoundException, RegistrationProtocolException {
		Result br = RegisterUser.tryGetBadRequestResult(request().body()
				.asFormUrlEncoded(), OLD_PASSWORD_PARAMETER,
				RECOVERY_QUESTION_ANSWER, RECOVERY_QUESTION_PARAMETER);
		if (br != null)
			return br;

		String oldPassword = request().body().asFormUrlEncoded()
				.get(OLD_PASSWORD_PARAMETER)[0];
		String question = request().body().asFormUrlEncoded()
				.get(RECOVERY_QUESTION_PARAMETER)[0];
		String answer = request().body().asFormUrlEncoded()
				.get(RECOVERY_QUESTION_ANSWER)[0];

		User user = User.getByGuidNull(guid);
		if (user == null) {
			return notFound();
		}

		if (!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			return badRequest();
		}

		UserRegistrationConnector connector = opcoUpdatersStore
				.getOpcoUpdater(user.getOpcoUid());

		if (!connector.updateRecoveryQuestion(user.getOpcoUUid(), oldPassword,
				question, answer))
			return unauthorized();

		return ok();
	}

	public Result unlock(UUID guid) throws UserNotFoundException,
			RegistrationProtocolException {
		User user = User.getByGuidNull(guid);
		if (user == null) {
			return notFound();
		}

		if (!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid())) {
			return badRequest();
		}
		UserRegistrationConnector connector = opcoUpdatersStore
				.getOpcoUpdater(user.getOpcoUid());

		connector.unlockUser(user.getOpcoUUid());

		return ok();
	}
}
