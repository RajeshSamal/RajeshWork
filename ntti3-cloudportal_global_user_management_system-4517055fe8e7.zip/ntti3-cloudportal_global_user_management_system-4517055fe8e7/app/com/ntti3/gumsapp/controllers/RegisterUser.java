package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.UserExistsException;
import com.ntti3.gumsapp.helpers.OrderBy;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.OpCo;
import com.ntti3.gumsapp.models.OpCoNotFoundException;
import com.ntti3.gumsapp.models.PendingUser;
import com.ntti3.gumsapp.models.ProductNotFoundException;
import com.ntti3.gumsapp.models.User;
import com.ntti3.gumsapp.registration.DefaultProducts;
import com.ntti3.play.annotations.EnsureUrlEncodedRequestBody;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.Logger;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Result;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import static com.ntti3.gums.GumsProtocolConstants.*;
import static play.mvc.Controller.request;
import static play.mvc.Results.badRequest;
import static play.mvc.Results.notFound;
import static play.mvc.Results.ok;

/**
 * @author jan.karwowski@ntti3.com
 */
@ControllerExceptionSupport.ExceptionHandler()
public class RegisterUser {
    private final ExecutorService executorService;
    private final OpcoUpdatersStore opcoUpdatersStore;
    private final BlockingQueue<UUID> usersToAcceptQueue;
    private final BlockingQueue<Integer> usersToRejectQueue;
    private final Set<String> defaultProducts;

    @Inject
    public RegisterUser(ExecutorService executorService, OpcoUpdatersStore opcoUpdatersStore,
                        @UsersToAcceptQueue BlockingQueue<UUID> usersToAcceptQueue,
                        @UsersToRejectQueue BlockingQueue<Integer> usersToRejectQueue,
                        @DefaultProducts Set<String> defaultProducts) {
        this.executorService =  Preconditions.checkNotNull(executorService);
        this.opcoUpdatersStore = Preconditions.checkNotNull(opcoUpdatersStore);
        this.usersToAcceptQueue = Preconditions.checkNotNull(usersToAcceptQueue);
        this.usersToRejectQueue = usersToRejectQueue;
        this.defaultProducts = Preconditions.checkNotNull(defaultProducts);
    }

    @EnsureUrlEncodedRequestBody(requiredParams = {OPCO_UID_PARAMETER, FIRST_NAME_PARAMETER, LAST_NAME_PARAMETER,
            EMAIL_PARAMETER, PASSWORD_PARAMETER, OPCO_U_UID_PARAMETER, RECOVERY_QUESTION_PARAMETER,
            RECOVERY_QUESTION_ANSWER, OPCO_C_NAME_PARAMETER})
    public Result createPendingUser() throws RegistrationProtocolException {
        Map<String, String[]> params = request().body().asFormUrlEncoded();

        final PendingUser pendingUser = getPendingUserFromParam(params);

        if (!opcoUpdatersStore.isOpcoUpdateable(pendingUser.getOpcoUid())) {
            return badRequest(ResponseHelper.errorResponse(ErrorCode.OPCO_NOT_FOUND,
                    "Cannot add user to given opco", "Opco " + pendingUser.getOpcoUid() + " does not support " +
                            "com/ntti3/gums/registration"));
        }

        try {
            savePendingUser(pendingUser);
            ObjectNode node = Json.newObject();
            node.put(ID_PARAMETER, pendingUser.getId());
            return ok(node);
        } catch (UserExistsException ex) {
            Logger.debug("User exists {} {}", pendingUser.getEmail(), pendingUser.getOpcoUUid(), ex);
            return badRequest(ResponseHelper.errorResponse(ErrorCode.ENTITY_EXISTS,
                    "User exists. No more users of that email",
                    pendingUser.getEmail() + "::" + pendingUser.getOpcoUUid()));
        }
    }
    
    @EnsureUrlEncodedRequestBody(requiredParams = {OPCO_UID_PARAMETER, FIRST_NAME_PARAMETER, LAST_NAME_PARAMETER,
            EMAIL_PARAMETER, PASSWORD_PARAMETER, OPCO_U_UID_PARAMETER, PRODUCTS_PARAMETER, RECOVERY_QUESTION_PARAMETER,
            RECOVERY_QUESTION_ANSWER, OPCO_NAME_PARAMETER})
    public Result createUser() throws RegistrationProtocolException, ProductNotFoundException
    {
        Map<String, String[]> params = request().body().asFormUrlEncoded();
        String[] opcoCUidA = params.get(OPCO_C_UID_PARAMETER);
        String[] opcoCNameA = params.get(OPCO_C_NAME_PARAMETER);
        String[] mobilePhoneA = params.get(MOBILE_PHONE_PARAMETER);
        String opcoCUid = opcoCUidA != null ? opcoCUidA[0] : null;
        String opcoCName = opcoCNameA != null ? opcoCNameA[0] : null;
        String mobilePhone = mobilePhoneA != null ? mobilePhoneA[0] : null;
        com.ntti3.gums.register.models.User user = new com.ntti3.gums.register.models.User();
        user.setFirstName(params.get(FIRST_NAME_PARAMETER)[0]);
        user.setLastName(params.get(LAST_NAME_PARAMETER)[0]);
        user.setEmail(params.get(EMAIL_PARAMETER)[0]);
        user.setMobilePhone(mobilePhone);
        user.setPassword(params.get(PASSWORD_PARAMETER)[0]);
        user.setRecoveryQuestion(params.get(RECOVERY_QUESTION_PARAMETER)[0]);
        user.setRecoveryAnswer(params.get(RECOVERY_QUESTION_ANSWER)[0]);
        user.setLogin(params.get(OPCO_U_UID_PARAMETER)[0]);

        try {
            Ebean.beginTransaction();
            User realUser = User.getOrRegister(params.get(FIRST_NAME_PARAMETER)[0], params.get(LAST_NAME_PARAMETER)[0],
                        params.get(EMAIL_PARAMETER)[0], mobilePhone,
                        params.get(OPCO_UID_PARAMETER)[0], params.get(OPCO_NAME_PARAMETER)[0],
                        params.get(OPCO_U_UID_PARAMETER)[0], opcoCUid, opcoCName, null);
            realUser.setProductsByStrings(getNewUserProducts(params.get(PRODUCTS_PARAMETER)));

            realUser.saveManyToManyAssociations("products");
            realUser.save();

            UserRegistrationConnector updater = opcoUpdatersStore.getOpcoUpdater(params.get(OPCO_UID_PARAMETER)[0]);
            if(updater == null)
            {
                throw new OpCoNotFoundException();
            }
            updater.registerUser(user);

            Ebean.commitTransaction();
            usersToAcceptQueue.add(realUser.getGuid());
            ObjectNode node = Json.newObject();
            node.put(GUID_RESPONSE_FIELD, realUser.getGuid().toString());
            return ok(node);
        } catch (UserExistsException ex) {
            Logger.debug("User exists {} {}", params.get(EMAIL_PARAMETER)[0], params.get(OPCO_U_UID_PARAMETER)[0], ex);
            return badRequest(ResponseHelper.errorResponse(ErrorCode.ENTITY_EXISTS,
                    "User exists. No more users of that email",
                    params.get(EMAIL_PARAMETER)[0] + "::" + params.get(OPCO_U_UID_PARAMETER)[0]));
        } finally {
            Ebean.endTransaction();
        }
    }

    // During registration a default set of products is assigned to each user.
    private List<String> getNewUserProducts(String[] products) {
        Set<String> mergedProducts = Sets.newHashSet();
        mergedProducts.addAll(defaultProducts);
        mergedProducts.addAll(Arrays.asList(products));
        return Lists.newArrayList(mergedProducts);
    }

    @EnsureUrlEncodedRequestBody(requiredParams = {PRODUCTS_PARAMETER})
    public Result activateUser(Integer id) throws ProductNotFoundException
    {
        Map<String, String[]> params = request().body().asFormUrlEncoded();
        String[] opcoCUidA = params.get(OPCO_C_UID_PARAMETER);
        String[] opcoCNameA = params.get(OPCO_C_NAME_PARAMETER);
        String opcoCUid = opcoCUidA != null ? opcoCUidA[0] : null;
        String opcoCName = opcoCUidA != null && opcoCNameA != null ? opcoCNameA[0] : null;
        PendingUser pendingUser = Ebean.find(PendingUser.class, id);
        if(pendingUser == null)
        {
            return notFound();
        }
        OpCo opCo = OpCo.getById(pendingUser.getOpcoUid());

        try {
            Ebean.beginTransaction();
            User realUser = User.getOrRegister(pendingUser.getFirstName(), pendingUser.getLastName(),
                    pendingUser.getEmail(), pendingUser.getMobilePhone(), pendingUser.getOpcoUid(),
                    opCo.getOpcoName(), pendingUser.getOpcoUUid(), opcoCUid, opcoCName, null);
            realUser.setProductsByStrings(getNewUserProducts(params.get(PRODUCTS_PARAMETER)));
            realUser.saveManyToManyAssociations("products");
            realUser.save();
            pendingUser.delete();
            Ebean.commitTransaction();
            usersToAcceptQueue.add(realUser.getGuid());
            ObjectNode node = Json.newObject();
            node.put(GUID_RESPONSE_FIELD, realUser.getGuid().toString());
            return ok(node);
        } finally {
            Ebean.endTransaction();
        }
    }
    
    public Result rejectUser(Integer id)
    {
        PendingUser pendingUser = Ebean.find(PendingUser.class, id);
        if(pendingUser == null)
        {
            return notFound();
        }
        pendingUser.setRejected(true);
        pendingUser.save();
        usersToRejectQueue.add(id);
        return ok();
    }

    public static Result tryGetBadRequestResult(final Map<String, String[]> params,
                                                final String... requiredParams) {
        return tryGetBadRequestResult(params, Arrays.asList(requiredParams));
    }

    public static Result tryGetBadRequestResult(final Map<String, String[]> params,
                                         final Collection<String> requiredParamz) {
        if(containsAnyNullParams(params, requiredParamz))
            return badRequest(ResponseHelper.errorResponse(ErrorCode.MISSING_PARAMETERS,
                    "Not all required form parameters were set",
                    Sets.difference(Sets.newHashSet(requiredParamz), params.keySet()).toString()));
        return null;
    }

    public static boolean containsAnyNullParams(final Map<String, String[]> params,
                                                final Collection<String> requiredParamz) {
        return params== null || ! params.keySet().containsAll(requiredParamz) ||
                hasNullsInFirstElements(params, requiredParamz);
    }

    public static boolean hasNullsInFirstElements(final Map<String, String[]> params,
                                                  final Collection<String> requiredParamz) {
        return ! Collections2.filter(Maps.filterKeys(params, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return requiredParamz.contains(input);
            }
        }).values(), new Predicate<String[]>() {
            @Override
            public boolean apply(@Nullable String[] input) {
                return input == null || input[0] == null;
            }
        }).isEmpty();
    }

    private void savePendingUser(final PendingUser pendingUser) throws RegistrationProtocolException {
        opcoUpdatersStore.getOpcoUpdater(pendingUser.getOpcoUid()).registerUser(initUserFromPending(pendingUser));
        Logger.debug("Adding user to database: {}", pendingUser);
        pendingUser.save();
    }

    private static PendingUser getPendingUserFromParam(Map<String, String[]> params) {
        final PendingUser pendingUser = new PendingUser();
        pendingUser.setOpcoUid(params.get(OPCO_UID_PARAMETER)[0]);
        pendingUser.setFirstName(params.get(FIRST_NAME_PARAMETER)[0]);
        pendingUser.setLastName(params.get(LAST_NAME_PARAMETER)[0]);
        if (params.containsKey(MOBILE_PHONE_PARAMETER))
            pendingUser.setMobilePhone(params.get(MOBILE_PHONE_PARAMETER)[0]);
        pendingUser.setEmail(params.get(EMAIL_PARAMETER)[0]);
        pendingUser.setSecurityQuestion(params.get(RECOVERY_QUESTION_PARAMETER)[0]);
        pendingUser.setSecurityAnswer(params.get(RECOVERY_QUESTION_ANSWER)[0]);
        pendingUser.setPassword(params.get(PASSWORD_PARAMETER)[0]);
        pendingUser.setOpcoUUid(params.get(OPCO_U_UID_PARAMETER)[0]);
        if (params.containsKey(ADDITIONAL_INFO)) {
            pendingUser.setAdditionalInfo(params.get(ADDITIONAL_INFO)[0]);
        }
        pendingUser.setOpcoCName(params.get(OPCO_C_NAME_PARAMETER)[0]);
        return pendingUser;
    }

    @BodyParser.Of(BodyParser.FormUrlEncoded.class)
    public Result getPendingUsers(final Integer offset, final Integer limit)
            throws Exception {
        final OrderBy orderBy;
        if (request().body() != null && request().body().asFormUrlEncoded() != null) {
            try {
                orderBy = OrderBy.buildFromQueryString(request().body().asFormUrlEncoded());
            } catch ( IllegalArgumentException ex ) {
                return badRequest("Bad order by");
            }
        } else {
            orderBy = OrderBy.NAN_ORDER;
        }

        Query<PendingUser> query = orderBy.apply(Ebean.find(PendingUser.class));
        query.where().eq("rejected", false);
        final QueryIterator<PendingUser> iterator = User.pageQuery(query, offset, limit).findIterate();

        try {
            return CompanyInfo.streamEntityList(new Callable<QueryIterator<PendingUser>>() {
                @Override
                public QueryIterator<PendingUser> call() throws Exception {
                    return iterator;
                }
            }, new Function<PendingUser, Object>() {
                @Override
                public Object apply(PendingUser input) {
                    return input.getId();
                }
            }, "users", query.findRowCount(), executorService
                    );
        } catch (InnerFunctionException e) {
            throw new RuntimeException(e);
        }
    }
    
    @SuppressWarnings("unused")
    public Result getPendingUser(Integer id) {
        final PendingUser user = Ebean.find(PendingUser.class, id);

        if (user == null) {
            return notFound();
        }
        
        //Kinda fun way of adding a custom field to serialized json object. Ihaaaa!
        // -- Janek the Unicorn
        JsonNode objectNode = Json.toJson(
                new Object() {
            @JsonUnwrapped(enabled = true)
            public PendingUser pendingUser = user;
        });
        return ok(Json.toJson(objectNode));
    }

    public Result removePendingUser(Integer id) {
        PendingUser pendingUser = Ebean.find(PendingUser.class, id);
        pendingUser.delete();

        return ok();
    }

    private com.ntti3.gums.register.models.User initUserFromPending(PendingUser pendingUser) {
        com.ntti3.gums.register.models.User user = new com.ntti3.gums.register.models.User();
        user.setFirstName(pendingUser.getFirstName());
        user.setLastName(pendingUser.getLastName());
        user.setEmail(pendingUser.getEmail());
        user.setMobilePhone(pendingUser.getMobilePhone());
        user.setPassword(pendingUser.getPassword());
        user.setRecoveryQuestion(pendingUser.getSecurityQuestion());
        user.setRecoveryAnswer(pendingUser.getSecurityAnswer());
        user.setLogin(pendingUser.getOpcoUUid());
        return user;
    }
}
