package com.ntti3.gumsapp.controllers;

import com.avaje.ebean.Ebean;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gumsapp.models.Flag;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.List;

/**
 * @author jan.karwowski@ntti3.com
 */
@ControllerExceptionSupport.ExceptionHandler
public class FlagsInfo  extends Controller {
    public Result get() {
        List<Flag> flags = Ebean.find(Flag.class).findList();
        ObjectNode retNode = Json.newObject();
        ArrayNode array = retNode.putArray(GumsProtocolConstants.FLAGS_PARAMETER);
        for(Flag flag: flags){
            array.add(flag.getName());
        }
        return ok(retNode);
    }
}
