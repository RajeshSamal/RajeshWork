package com.ntti3.gumsapp.registration;

import com.avaje.ebean.Ebean;
import com.google.inject.Inject;
import com.ntti3.gumsapp.controllers.UsersToRejectQueue;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.gumsapp.models.PendingUser;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.mailing.connector.exceptions.ApiException;
import com.ntti3.mailing.connector.models.Recipient;
import com.ntti3.mailing.connector.models.SendingMessage;
import play.Logger;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;

import static com.ntti3.gums.GumsProtocolConstants.EMAIL_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.FIRST_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.LAST_NAME_PARAMETER;

/**
 * @author jacek.swiderski@ntti3.com
 */
public class RejectionProcessingTask extends AbstractProcessingTask<Integer> {

    @Inject
    public RejectionProcessingTask(@UsersToRejectQueue BlockingQueue<Integer> userProcessingQueue,
            MailingSystemConnector mailingSystemConnector, OpcoUpdatersStore opcoUpdatersStore,
            @RejectEmailTemplate String emailTemplate) {
        super(userProcessingQueue,mailingSystemConnector,opcoUpdatersStore,emailTemplate);
    }

    @Override
    protected boolean processUser(Integer id) {
        PendingUser user = Ebean.find(PendingUser.class, id);
        if (user == null)
        {
            Logger.debug("PendingUser to process with id {} not found",id);
            return true;
        }
        return processUser(user);
    }

    private boolean processUser(PendingUser user) {
        SendingMessage sendingMessage = new SendingMessage.Builder().templateName(emailTemplate)
                .addRecipient(new Recipient(user.getEmail(), user.getFirstName() + ' ' + user.getLastName(), 
                Recipient.RecipientType.TO)).addVariable(FIRST_NAME_PARAMETER, user.getFirstName())
                .addVariable(LAST_NAME_PARAMETER, user.getLastName())
                .addVariable(EMAIL_PARAMETER, user.getEmail()).subject("").build();
        try {
            mailingSystemConnector.sendTemplateMessage(sendingMessage);
        } catch (IOException | ApiException e) {
            Logger.error("Mailing system connection failed", e);
            return false;
        }
        user.setEmailSent(true);
        user.save();
        return true;
    }
}
