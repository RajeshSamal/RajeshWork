package com.ntti3.gumsapp.registration;

import com.avaje.ebean.Ebean;
import com.google.inject.Inject;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gumsapp.controllers.UsersToAcceptQueue;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.mailing.connector.exceptions.ApiException;
import com.ntti3.mailing.connector.models.Recipient;
import com.ntti3.mailing.connector.models.SendingMessage;
import play.Logger;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;

import static com.ntti3.gums.GumsProtocolConstants.EMAIL_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.FIRST_NAME_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.LAST_NAME_PARAMETER;

/**
 * @author jacek.swiderski@ntti3.com
 */
public class AcceptanceProcessingTask extends AbstractProcessingTask<UUID> {

    @Inject
    public AcceptanceProcessingTask(@UsersToAcceptQueue BlockingQueue<UUID> userProcessingQueue,
            MailingSystemConnector mailingSystemConnector, OpcoUpdatersStore opcoUpdatersStore,
            @AcceptEmailTemplate String emailTemplate) {
        super(userProcessingQueue,mailingSystemConnector,opcoUpdatersStore,emailTemplate);
    }

    protected boolean processUser(@Nonnull UUID id) {
        com.ntti3.gumsapp.models.User user = Ebean.find(com.ntti3.gumsapp.models.User.class, id);
        if (user == null)
        {
            Logger.debug("User to process with id {} not found",id);
            return true;
        }
        return processUser(user);
    }

    private boolean processUser(com.ntti3.gumsapp.models.User user) {
        try {
            if(!opcoUpdatersStore.isOpcoUpdateable(user.getOpcoUid()))
            {
                Logger.warn("Opco {} not updateable for user {}", user.getOpcoName(), user.getOpcoUUid());
                return true;
            }
            else
            {
                UserRegistrationConnector opcoUpdater = opcoUpdatersStore.getOpcoUpdater(user.getOpcoUid());
                try {
                    opcoUpdater.activateUser(user.getOpcoUUid());
                } catch (com.ntti3.gums.register.exceptions.UserNotFoundException ex) {
                    Logger.error("User should exist ", ex);
                    throw new RuntimeException(ex);
                }
                SendingMessage sendingMessage = new SendingMessage.Builder().templateName(emailTemplate)
                        .addRecipient(new Recipient(user.getEmail(), user.getFirstName() + ' ' + user
                                .getLastName(), Recipient.RecipientType.TO))
                        .addVariable(FIRST_NAME_PARAMETER, user.getFirstName())
                        .addVariable(LAST_NAME_PARAMETER, user.getLastName())
                        .addVariable(EMAIL_PARAMETER, user.getEmail())
                        .subject("")
                        .build();
                try {
                    mailingSystemConnector.sendTemplateMessage(sendingMessage);
                } catch (IOException | ApiException e) {
                    Logger.error("Mailing system connection failed", e);
                    return false;
                }
                user.setActiveInOpCo(true);
                user.save();
                return true;
            }
        } catch (IOException | RegistrationProtocolException e) {
            Logger.error("Error when registering user in opco", e);
            return false;
        }
    }
}
