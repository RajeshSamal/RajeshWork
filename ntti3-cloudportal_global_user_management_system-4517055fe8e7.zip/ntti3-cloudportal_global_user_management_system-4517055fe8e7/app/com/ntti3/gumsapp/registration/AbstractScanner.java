package com.ntti3.gumsapp.registration;

import com.avaje.ebean.QueryIterator;
import com.google.common.base.Preconditions;
import play.Logger;

import java.util.concurrent.BlockingQueue;

/**
 * @author jacek.swiderski@ntti3.com
 */
public abstract class AbstractScanner<K,U> implements Runnable {
    protected final long frequencyMs;
    protected final BlockingQueue<K> idsToProcess;

  	public AbstractScanner(BlockingQueue<K> idsToProcess,
  	        Long frequency) {
  	    Preconditions.checkNotNull(idsToProcess);
  	    Preconditions.checkNotNull(frequency);
  	    this.idsToProcess = idsToProcess;
      	this.frequencyMs = frequency;
  	}
  	
  	@Override
  	public void run() {
  	    while (!Thread.currentThread().isInterrupted()) {
  	        try {
  	            Logger.info("Putting all users in processing queue");
                performPeriodicScan();
                Logger.info("Put all users in processing queue");
                Thread.sleep(frequencyMs);
  	        } catch (InterruptedException e) {
  	            break;
  	        } catch (Exception e) {
  	            Logger.error("Error in ProcessingTask", e);
  	        }
  	    }
  	}
	
    private void performPeriodicScan() throws InterruptedException {
        try (QueryIterator<U> iterator = findIterate()) {
            while (iterator.hasNext() && ! Thread.currentThread().isInterrupted()) {
                K id = getUId(iterator.next());
                Logger.debug("Putting uid: {} into queue", id);
                idsToProcess.put(id);
            }
        }
    }
    
    protected abstract QueryIterator<U> findIterate();
    protected abstract K getUId(U user);
}
