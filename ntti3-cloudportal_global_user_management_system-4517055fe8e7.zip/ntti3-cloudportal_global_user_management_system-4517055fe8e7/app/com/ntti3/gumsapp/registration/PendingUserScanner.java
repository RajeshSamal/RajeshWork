package com.ntti3.gumsapp.registration;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.google.inject.Inject;
import com.ntti3.gumsapp.controllers.UsersToRejectQueue;

import java.util.concurrent.BlockingQueue;

/**
 * @author jacek.swiderski@ntti3.com
 */
public class PendingUserScanner extends AbstractScanner<Integer, com.ntti3.gumsapp.models.PendingUser>{
    @Inject
    public PendingUserScanner(@UsersToRejectQueue BlockingQueue<Integer> idsToProcess,
            @ScanFrequency Long frequency) {
        super(idsToProcess,frequency);
    }

    @Override
    protected QueryIterator<com.ntti3.gumsapp.models.PendingUser> findIterate() {
        return Ebean.find(com.ntti3.gumsapp.models.PendingUser.class).select("id").where().ne("emailSent", true).findIterate();
    }

    @Override
    protected Integer getUId(com.ntti3.gumsapp.models.PendingUser user) {
        return user.getId();
    }
}
