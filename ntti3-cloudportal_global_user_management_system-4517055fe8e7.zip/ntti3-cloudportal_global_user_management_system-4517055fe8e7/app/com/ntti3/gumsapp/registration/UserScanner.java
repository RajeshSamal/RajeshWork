package com.ntti3.gumsapp.registration;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.google.inject.Inject;
import com.ntti3.gumsapp.controllers.UsersToAcceptQueue;
import com.ntti3.gumsapp.models.User;

import java.util.UUID;
import java.util.concurrent.BlockingQueue;

/**
 * @author jan.karwowski@ntti3.com
 */
public class UserScanner extends AbstractScanner<UUID,User> {

    @Inject
    public UserScanner(@UsersToAcceptQueue BlockingQueue<UUID> idsToProcess,
            @ScanFrequency Long frequency) {
        super(idsToProcess,frequency);
    }

    @Override
    protected QueryIterator<User> findIterate() {
        return Ebean.find(User.class).select("guid").where().ne("activeInOpCo", true).findIterate();
    }

    @Override
    protected UUID getUId(User user) {
        return user.getGuid();
    }
}
