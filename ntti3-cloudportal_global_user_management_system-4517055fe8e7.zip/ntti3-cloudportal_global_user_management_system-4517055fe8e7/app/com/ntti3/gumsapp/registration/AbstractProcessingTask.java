package com.ntti3.gumsapp.registration;

import com.google.common.base.Preconditions;
import com.ntti3.gumsapp.misc.opco.OpcoUpdatersStore;
import com.ntti3.mailing.connector.MailingSystemConnector;
import play.Logger;

import javax.annotation.Nonnull;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class AbstractProcessingTask<K> implements Runnable {
    private static final int WAIT_TIME = 1;
    private final BlockingQueue<K> userProcessingQueue;
    protected final MailingSystemConnector mailingSystemConnector;
    protected final OpcoUpdatersStore opcoUpdatersStore;
    protected final String emailTemplate;

    public AbstractProcessingTask(BlockingQueue<K> userProcessingQueue,
                          MailingSystemConnector mailingSystemConnector,
                          OpcoUpdatersStore opcoUpdatersStore,
                          String emailTemplate) {
        Preconditions.checkNotNull(userProcessingQueue);
        Preconditions.checkNotNull(mailingSystemConnector);
        Preconditions.checkNotNull(opcoUpdatersStore);
        Preconditions.checkNotNull(emailTemplate);

        this.userProcessingQueue = userProcessingQueue;
        this.mailingSystemConnector = mailingSystemConnector;
        this.opcoUpdatersStore = opcoUpdatersStore;
        this.emailTemplate = emailTemplate;
    }

    @Override
    public void run() {
        while (!Thread.interrupted()) {
            try {
                K id = userProcessingQueue.take();
                Logger.debug("Processing user id {}", id);
                if (!processUser(id)) {
                    userProcessingQueue.add(id);
                    Thread.sleep(TimeUnit.MINUTES.toMillis(WAIT_TIME));
                    //Wait a while after a failure
                }
                Logger.debug("Processed user id {}", id);
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                Logger.error("Error in ProcessingTask", e);
            }
        }
    }

    protected abstract boolean processUser(@Nonnull K id);
}
