package com.ntti3.cloudportal.models;

import play.data.validation.Constraints.Required;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

public class UserPassword {
	public static final String NEW_PASSWORD_FIELD = "newPassword"; //$NON-NLS-1$
    public static final String NEW_PASSWORD_REPEAT_FIELD = "repeatNewPassword"; //$NON-NLS-1$
    public static final String PASSWORD_TOO_SHORT = "UserRegister.validation.password_too_short";
    public static final String PASSWORD_CAPITAL = "UserRegister.validation.password_one_capital";
    public static final String PASSWORD_DIGIT = "UserRegister.validation.password_one_digit";
    @Required
	private String password;
	@Required
	private String newPassword;
	@Required
	private String repeatNewPassword;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getRepeatNewPassword() {
		return repeatNewPassword;
	}

	public void setRepeatNewPassword(String repeatNewPassword) {
		this.repeatNewPassword = repeatNewPassword;
	}

	public List<ValidationError> validate() {
		final List<ValidationError> validationErrors = new ArrayList<>();
        checkPasswordsMatch(validationErrors);
        checkPasswordMeetPolicy(validationErrors);
        return validationErrors.isEmpty() ? null : validationErrors;
	}

    private void checkPasswordsMatch(List<ValidationError> validationErrors) {
        if (!newPassword.equals(repeatNewPassword)) {
            validationErrors.add(new ValidationError(NEW_PASSWORD_FIELD,
                    "UserRegister.validation.password_not_match"));
            validationErrors.add(new ValidationError(NEW_PASSWORD_REPEAT_FIELD,
                    "UserRegister.validation.password_not_match"));
        }
    }

    private void checkPasswordMeetPolicy(List<ValidationError> validationErrors) {
        // length > 8
        // 1 capital letter
        // 1 digit
        if (newPassword.length() < 8) {
            validationErrors.add(new ValidationError(NEW_PASSWORD_FIELD, PASSWORD_TOO_SHORT));
        }

        if (!newPassword.matches(".*[A-Z]+.*")) {
            validationErrors.add(new ValidationError(NEW_PASSWORD_FIELD, PASSWORD_CAPITAL));
        }

        if (!newPassword.matches(".*[0-9]+.*")) {
            validationErrors.add(new ValidationError(NEW_PASSWORD_FIELD, PASSWORD_DIGIT));
        }
    }
}
