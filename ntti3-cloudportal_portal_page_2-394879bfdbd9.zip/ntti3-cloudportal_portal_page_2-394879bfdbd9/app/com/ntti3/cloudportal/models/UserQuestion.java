package com.ntti3.cloudportal.models;

import play.data.validation.Constraints.MinLength;
import play.data.validation.Constraints.Required;

public class UserQuestion {
	@Required
	private String password;
	@Required
	private String securityQuestion;
	@Required
    @MinLength(value = 4, message = "UserRegister.validation.answer_invalid")
	private String securityAnswer;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

}
