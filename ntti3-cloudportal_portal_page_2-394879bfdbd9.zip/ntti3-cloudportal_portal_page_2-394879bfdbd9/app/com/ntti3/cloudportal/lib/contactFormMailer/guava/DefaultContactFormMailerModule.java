package com.ntti3.cloudportal.lib.contactFormMailer.guava;

import com.google.inject.PrivateModule;
import com.ntti3.cloudportal.lib.contactFormMailer.ContactFormMailer;
import com.ntti3.cloudportal.lib.contactFormMailer.MailingSystemContactFormMailer;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultContactFormMailerModule extends PrivateModule {

	private final Configuration configuration;

	public DefaultContactFormMailerModule(Configuration configuration) {
		this.configuration = configuration;
	}

	@Override
	protected void configure() {
		bind(Configuration.class).toInstance(configuration);
		bind(ContactFormMailer.class).to(MailingSystemContactFormMailer.class);
		expose(ContactFormMailer.class);
	}

	@Override
	public int hashCode() {
		return DefaultContactFormMailerModule.class.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return DefaultContactFormMailerModule.class.equals(obj.getClass());
	}
}
