package com.ntti3.cloudportal.lib.contactFormMailer;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.mailing.connector.exceptions.ApiException;
import com.ntti3.mailing.connector.models.Recipient;
import com.ntti3.mailing.connector.models.SendingMessage;
import play.Configuration;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on
 * 2014-04-22.
 */
public class MailingSystemContactFormMailer implements ContactFormMailer {
	public static final String FROM_ADDRESS = "from-address";
	public static final String FROM_NAME = "from-name";

	private final String fromAddress;
	private final String fromName;
	private final MailingSystemConnector connector;

	@Inject
	public MailingSystemContactFormMailer(Configuration configuration, MailingSystemConnector connector) {
		Preconditions.checkNotNull(connector);
		this.connector = connector;
		this.fromAddress = configuration.getString(FROM_ADDRESS);
		if (fromAddress == null)
			throw new IllegalArgumentException();
		this.fromName = configuration.getString(FROM_NAME);
		if (fromName == null)
			throw new IllegalArgumentException();

	}

	@Override
	public void sendMail(String contactEmail, String firstName, String lastName, String company,
			String msg, List<String> products) throws MessagingException {
		String topic = String
				.format("[Contact form - Demo request] %s %s - %s", firstName, lastName, company);
        String requestedDemos = "";
        for (String p : products){
            requestedDemos += p + " ";
        }
		Recipient recipient = new Recipient(fromAddress, fromName,
				Recipient.RecipientType.TO);

		SendingMessage message = (new SendingMessage.Builder())
				.fromEmail(fromAddress).fromName(fromName).subject(topic)
				.htmlContent(msg).product(requestedDemos).addRecipient(recipient)
				.replyTo(contactEmail).build();
		try {
			connector.sendMessage(message);
		} catch (ApiException e) {
			String errorMessage = String.format("%d - %s \n %s",
					e.getErrorCode(), e.getMessage(), e.getDetails());
			throw new MessagingException(errorMessage, e);
		} catch (IOException e) {
			throw new MessagingException(e.getMessage(), e);
		}
	}
}
