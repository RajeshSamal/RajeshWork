package com.ntti3.cloudportal.aspects;

import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

	@Pointcut("execution(* com.ntti3.cloudportal.*.*(..)) && ! execution(* com.ntti3.cloudportal.Reverse*.*(..))"
			+ "&& ! execution(* com.ntti3.cloudportal.*.*$*(..))")
	@Override
	public void controllerMethodPointcut() {
	}

	@Pointcut("within(com.ntti3.cloudportal.lib..*)")
	@Override
	public void applicationMethodPointcut() {
	}

	@Override
	public String getPathContains() {
		return "Cloud-Portal";
	}
}