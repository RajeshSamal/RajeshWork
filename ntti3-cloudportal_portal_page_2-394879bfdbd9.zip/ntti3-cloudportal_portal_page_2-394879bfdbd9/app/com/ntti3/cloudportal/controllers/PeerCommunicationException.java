package com.ntti3.cloudportal.controllers;

import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;

/**
 * @author jan.karwowski@ntti3.com
 */
@ExceptionHandler
public class PeerCommunicationException extends Exception {
	private static final long serialVersionUID = 2L;

	public PeerCommunicationException() {
	}

	public PeerCommunicationException(String message) {
		super(message);
	}

	public PeerCommunicationException(String message, Throwable cause) {
		super(message, cause);
	}

	public PeerCommunicationException(Throwable cause) {
		super(cause);
	}

	public PeerCommunicationException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
