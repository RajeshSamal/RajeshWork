package com.ntti3.cloudportal.controllers;

import com.google.inject.Inject;
import com.ntti3.cloudportal.controllers.annotations.AfpStartSsoSelector;
import com.ntti3.cloudportal.controllers.annotations.IdpParameterSelector;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.spsso.session.UserSessionManager;
import com.ntti3.urlhelper.UrlHelper;
import org.apache.http.client.utils.URIBuilder;
import play.Logger;
import play.mvc.Call;
import play.mvc.Result;
import views.html.slosuccess;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

/**
 * @author jan.karwowski@ntti3.com
 */
@NoCache
@ExceptionHandler
public class SsoController extends com.ntti3.spsso.SsoController {

    private final VhostInstanceSelector<String> vhostAfpStartSsoSelector;

    @Inject
	public SsoController(
            VhostInstanceSelector<SPProtocolHelper> vhostSPProtocolHelperSelector,
            VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector,
            UserSessionManager userSessionManager,
            @IdpParameterSelector VhostInstanceSelector<String> vhostIdpParameterSelector,
            @AfpStartSsoSelector VhostInstanceSelector<String> vhostAfpStartSsoSelector) {
		super(vhostSPProtocolHelperSelector, vhostUrlHelperSelector, userSessionManager, vhostIdpParameterSelector);
        this.vhostAfpStartSsoSelector = vhostAfpStartSsoSelector;
    }

	@Override
	public Result ssoSuccessResult() {
		return ok(views.html.ssosuccess.render());
	}

	@Override
	public Result sloSuccessResult() {
		return ok(slosuccess.render());
	}

    public Result sloReport(String resume) {
        Logger.warn("SLO Failure");
        if (resume != null && !resume.equals("")) {
            return redirect(resume);
        } else {
            return redirect(routes.Application.index().absoluteURL(request()));
        }
    }

	@Override
	protected Call actionHandlerRoute(String s) {
		return com.ntti3.cloudportal.controllers.routes.SsoController.actionHandler(s);
	}

	@Override
	protected Call sloSuccessRoute() {
		return com.ntti3.cloudportal.controllers.routes.SsoController.sloSuccess();
	}

	@Override
	protected Call sloFailureRoute() {
		return com.ntti3.cloudportal.controllers.routes.SsoController.sloSuccess();
	}

	@Override
	protected String getSsoSuccessTarget() throws MalformedURLException, UnknownVhostException {
		return getUrlHelper(request()).absoluteAddress(
                com.ntti3.cloudportal.controllers.routes.SsoController.ssoSuccessResult());
	}

	public Result pfBaseUrl() throws UnknownVhostException {
		return ok(getSpProtocolHelper(request()).getPFBaseURI().toString());
	}

    public String getStartSsoUrl() throws UnknownVhostException, URISyntaxException {
        URIBuilder builder = new URIBuilder(vhostAfpStartSsoSelector.getInstanceForVhost(request()));
        builder.addParameter("sp",
                getSpProtocolHelper(request()).getHost());
        builder.setParameter("errorUrl",
                com.ntti3.cloudportal.controllers.routes.SsoController.ssoSuccessResult().absoluteURL(request()));
        return builder.build().toString();
    }

    public Result getStartSsoString() throws UnknownVhostException {
        try {
            return ok(getStartSsoUrl());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
