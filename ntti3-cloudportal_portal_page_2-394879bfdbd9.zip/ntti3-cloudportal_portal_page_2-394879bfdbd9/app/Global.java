import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.TypeLiteral;
import com.ntti3.cloudportal.controllers.Messages;
import com.ntti3.cloudportal.controllers.PeerCommunicationException;
import com.ntti3.cloudportal.controllers.UserHandler;
import com.ntti3.cloudportal.controllers.annotations.AfpStartSsoSelector;
import com.ntti3.cloudportal.controllers.annotations.AfpUrlSelector;
import com.ntti3.cloudportal.controllers.annotations.IdpParameterSelector;
import com.ntti3.cloudportal.controllers.annotations.OpcoSelector;
import com.ntti3.cloudportal.lib.contactFormMailer.guava.DefaultContactFormMailerModule;
import com.ntti3.cms.Cms;
import com.ntti3.cms.DefaultCms;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.gums.guice.DefaultGumsConnectorFromConfigModule;
import com.ntti3.mailing.connector.MailingSystemConnector;
import com.ntti3.mailing.connector.MailingSystemConnectorFactory;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelperFactory;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.excetions.handling.SimpleExceptionHandler;
import com.ntti3.play.frontend.JsonResponseBuilder;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.urlhelper.UrlHelper;
import play.Application;
import play.Configuration;
import play.GlobalSettings;
import play.Logger;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Http.Response;
import play.mvc.Results;
import play.mvc.SimpleResult;

import javax.mail.MessagingException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Global extends GlobalSettings {
    private static final String CONFIG_FILE_SP_ENTRY_KEY = "pfhelper.sp";
	private static final String APPLICATION_BASE_URL_CONFIG_KEY = "application.baseUrl";
	public static final String PFHELPER_IDP = "pfhelper.idp";
	public static final String MAILER = "mailer";
	private static final String GUMS_CONFIG_PREFIX = "gums";
	private static final String CLOUDPORTAL = "cloud-portal";
	public static final String MAILING_SYSTEM_HOST = "mailer.mailing-system-host";
    private static final String VHOSTS_CONFIG_KEY = "vhosts";
    public static final String AFP_BASE_URL = "afp.base";
    private static final String OPCO = "opco";
    private static final String AFP_START_SSO = "afp.startSso";

    private volatile Injector injector;

	@Override
	public void onStart(Application app) {
		super.onStart(app);
		final AbstractModule gumsModule;
		final com.ntti3.spsso.session.guava.CookieUserSessionModule cookieUserSessionModule;
		final DefaultContactFormMailerModule defaultContactFormMailerModule;
		final BuildInfoReaderModule buildInfoReaderModule;
		final AbstractModule mailingSystemConnectorModule;
		final AbstractModule exceptionHandlerModule;
        final AbstractModule vHostSelectorsModule;
        final AbstractModule defaultCmsModule;

		try {
			gumsModule = initGumsModule();
			mailingSystemConnectorModule = new AbstractModule() {
				private final String url;
				private final MailingSystemConnector connector;

				{
					url = Configuration.root().getString(MAILING_SYSTEM_HOST);
					Preconditions.checkNotNull(url);
					connector = MailingSystemConnectorFactory
							.getMailingSystemConnector(url);
				}

				@Override
				protected void configure() {
					bind(MailingSystemConnector.class).toInstance(connector);
				}
			};
			cookieUserSessionModule = new com.ntti3.spsso.session.guava.CookieUserSessionModule();
			defaultContactFormMailerModule = new DefaultContactFormMailerModule(
					Configuration.root().getConfig(MAILER));
			buildInfoReaderModule = new BuildInfoReaderModule(CLOUDPORTAL);
			exceptionHandlerModule = new AbstractModule() {
				@Override
				protected void configure() {
					bind(GlobalExceptionsHandler.class).toInstance(
							initGlobalExceptionsHandler());
				}
			};
            vHostSelectorsModule = initVHostSelectorsModule();
            defaultCmsModule = new AbstractModule() {
                private final Cms cms;
                {
                    cms = new DefaultCms();
                }
                @Override
                protected void configure() {
                    bind(Cms.class).toInstance(cms);
                }
            };
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		injector = Guice
				.createInjector(cookieUserSessionModule,
						defaultContactFormMailerModule, gumsModule,
						buildInfoReaderModule, mailingSystemConnectorModule, exceptionHandlerModule,
                        vHostSelectorsModule, defaultCmsModule);
	}

    private AbstractModule initVHostSelectorsModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<UrlHelper> urlHelperSelector;
            final VhostInstanceSelector<SPProtocolHelper> spProtocolHelperSelector;
            final VhostInstanceSelector<String> idpParameterSelector;
            final VhostInstanceSelector<String> afpUrlSelector;
            final VhostInstanceSelector<String> afpStartSsoSelector;
            final VhostInstanceSelector<String> opcoSelector;

            {
                SPProtocolHelperFactory spProtocolHelperFactory = new SPProtocolHelperFactory();
                Map<String, UrlHelper> urlHelpersMap = Maps.newHashMap();
                Map<String, SPProtocolHelper> spProtocolHelpersMap = Maps.newHashMap();
                Map<String, String> idpParametersMap = Maps.newHashMap();
                Map<String, String> afpUrlsMap = Maps.newHashMap();
                Map<String, String> afpStartSsoMap = Maps.newHashMap();
                Map<String, String> opcosMap = Maps.newHashMap();

                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);

                for(String vhost : vhostsConfiguration.subKeys()) {
                    Logger.debug("loading vhost: " + vhost);
                    Configuration vhostConfiguration = Preconditions.checkNotNull(vhostsConfiguration.getConfig("\"" + vhost + "\""),
                            "Can not get vhost configuration for key " + vhost);

                    //url helper
                    urlHelpersMap.put(vhost, new UrlHelper(vhostConfiguration.getString(
                            APPLICATION_BASE_URL_CONFIG_KEY)));

                    // sp protocol helper
                    try {
                        spProtocolHelpersMap.put(vhost, spProtocolHelperFactory.getInstanceFromConfig(
                                Maps.transformValues(
                                        vhostConfiguration
                                                .getConfig(CONFIG_FILE_SP_ENTRY_KEY)
                                                .asMap(), new Function<Object, String>() {
                                    @Override
                                    public String apply(Object input) {
                                        return input.toString();
                                    }
                                }
                                )
                        ));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    //idp parameter
                    idpParametersMap.put(vhost, vhostConfiguration.getString(PFHELPER_IDP));
                    afpUrlsMap.put(vhost, vhostConfiguration.getString(AFP_BASE_URL));
                    afpStartSsoMap.put(vhost, vhostConfiguration.getString(AFP_START_SSO));
                    opcosMap.put(vhost, vhostConfiguration.getString(OPCO));
                }

                urlHelperSelector = new VhostInstanceSelector<>(urlHelpersMap);
                spProtocolHelperSelector = new VhostInstanceSelector<>(spProtocolHelpersMap);
                idpParameterSelector = new VhostInstanceSelector<>(idpParametersMap);
                afpUrlSelector = new VhostInstanceSelector<>(afpUrlsMap);
                afpStartSsoSelector = new VhostInstanceSelector<>(afpStartSsoMap);
                opcoSelector = new VhostInstanceSelector<>(opcosMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<UrlHelper>>() {}).toInstance(urlHelperSelector);
                bind(new TypeLiteral<VhostInstanceSelector<SPProtocolHelper>>(){}).toInstance(spProtocolHelperSelector);
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){}).annotatedWith(IdpParameterSelector.class).toInstance(idpParameterSelector);
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){}).annotatedWith(AfpUrlSelector.class).toInstance(afpUrlSelector);
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){}).annotatedWith(OpcoSelector.class).toInstance(opcoSelector);
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){}).annotatedWith(AfpStartSsoSelector.class).toInstance(afpStartSsoSelector);
            }
        };
    }

	protected GlobalExceptionsHandler initGlobalExceptionsHandler() {
		GlobalExceptionsHandler globalExceptionsHandlerNotShadowingObjectField = new GlobalExceptionsHandler();
		globalExceptionsHandlerNotShadowingObjectField
				.registerHandler(new AbstractExceptionHandler<GumsProtocolExceptionWithErrorResponse>(
						GumsProtocolExceptionWithErrorResponse.class) {
					@Override
					protected SimpleResult handleExceptionWithType(
							GumsProtocolExceptionWithErrorResponse gumsProtocolExceptionWithErrorResponse,
							Http.Response response) {
						Logger.error("Gums error",
								gumsProtocolExceptionWithErrorResponse);
						return Results.badRequest(JsonResponseBuilder.prepareMessage(
								gumsProtocolExceptionWithErrorResponse
										.getResponse().getMessage(),
										gumsProtocolExceptionWithErrorResponse
										.getResponse().getDetails())
										);
					}
				});

		globalExceptionsHandlerNotShadowingObjectField
				.registerHandler(new AbstractExceptionHandler<GumsProtocolException>(
						GumsProtocolException.class) {
					@Override
					protected SimpleResult handleExceptionWithType(
							GumsProtocolException ex, Http.Response response) {
						Logger.error("Gums connection error", ex);
						return Results.internalServerError(JsonResponseBuilder
								.prepareMessage(UserHandler.ERROR_TITLE,
										UserHandler.GUMS_MSG));
					}
				});

		globalExceptionsHandlerNotShadowingObjectField
				.registerHandler(new SimpleExceptionHandler(
						PeerCommunicationException.class,
						ErrorCode.OPERATION_NOT_SUPPORTED, "Temporary failure",
						500));

		globalExceptionsHandlerNotShadowingObjectField
				.registerHandler(new AbstractExceptionHandler<MessagingException>(
						MessagingException.class) {
					@Override
					protected SimpleResult handleExceptionWithType(
							MessagingException arg0, Response arg1) {
						return Results.internalServerError(JsonResponseBuilder.prepareMessage(
								Messages.getString("ContactFormHandler.errorMsg"),
								Messages.getString("ContactFormHandler.error2Msg")));
					}

				});

		return globalExceptionsHandlerNotShadowingObjectField;
	}

	protected AbstractModule initGumsModule() throws Exception {
		return new DefaultGumsConnectorFromConfigModule(Maps.transformValues(
				Configuration.root().getConfig(GUMS_CONFIG_PREFIX).asMap(),
				new Function<Object, String>() {
					@Override
					public String apply(Object input) {
						return input.toString();
					}
				}));
	}

	@Override
	public <A> A getControllerInstance(Class<A> controllerClass)
			throws Exception {
		return injector.getInstance(controllerClass);
	}

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }
}
