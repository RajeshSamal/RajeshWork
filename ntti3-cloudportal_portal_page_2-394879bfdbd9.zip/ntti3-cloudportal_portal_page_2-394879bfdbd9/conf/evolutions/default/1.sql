# --- !Ups

create table content_directory (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  menu                      boolean,
  last_update               timestamp not null,
  constraint uq_content_directory_name unique (name),
  constraint pk_content_directory primary key (id))
;

create table product_content (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  title                     varchar(255),
  short_description         varchar(255),
  long_description          longtext,
  thumbnail_image_path      varchar(255),
  url                       varchar(255),
  last_update               timestamp not null,
  constraint uq_product_content_name unique (name),
  constraint pk_product_content primary key (id))
;

create table question (
   id                        bigint auto_increment not null,
   question                  varchar(255),
   product_id                bigint,
   constraint pk_question primary key (id))
 ;

create table web_page_content (
  id                        bigint auto_increment not null,
  weight                    integer,
  name                      varchar(255),
  removable                 boolean,
  parent_id                 bigint,
  title                     varchar(255),
  url                       varchar(255),
  html_content              longtext,
  last_update               timestamp not null,
  constraint uq_web_page_content_name unique (name),
  constraint uq_web_page_content_url unique (url),
  constraint pk_web_page_content primary key (id))
;

alter table content_directory add constraint fk_content_directory_parent_1 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_content_directory_parent_1 on content_directory (parent_id);
alter table product_content add constraint fk_product_content_parent_2 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_product_content_parent_2 on product_content (parent_id);
alter table question add constraint fk_question_product_3 foreign key (product_id) references product_content (id) on delete restrict on update restrict;
create index ix_question_product_3 on question (product_id);
alter table web_page_content add constraint fk_web_page_content_parent_4 foreign key (parent_id) references content_directory (id) on delete restrict on update restrict;
create index ix_web_page_content_parent_4 on web_page_content (parent_id);

# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table content_directory;

drop table product_content;

drop table question;

drop table web_page_content;

SET FOREIGN_KEY_CHECKS=1;

