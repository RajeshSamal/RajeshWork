#!/bin/bash
set -e


TEMPLATE_PATH=support/deployapp

if [ $# -ge 1 ] ; then 
    . ${TEMPLATE_PATH}/deploy.$1.conf
else 
    . ${TEMPLATE_PATH}/deploy.conf
fi

SVC=${APPNAME:-$1}

play dist

ssh ${DESTINATION} service ${SVC} stop

scp target/scala-2.10/${PACKAGENAME}_2.10-${VERSION}.jar ${DESTINATION}:/home/${USER}/${PROJECTNAME}-${VERSION}/lib/default.${PROJECTNAME}-${VERSION}.jar

ssh ${DESTINATION} service ${SVC} start


