#!/bin/bash
set -e

## REQUIRED a user on target server which whose privileges will app run with

TEMPLATE_PATH=support/deployapp

if [ $# -gt 1 ] ; then
    DEPLOY_CONF=deploy.$1.conf
else
    DEPLOY_CONF=deploy.conf
fi

. ${TEMPLATE_PATH}/${DEPLOY_CONF}

sed "s|%SITE_CERT%|${SITE_CERT}|g" < ${TEMPLATE_PATH}/play.apache |
  sed "s|%SITE_KEY%|${SITE_KEY}|g" |
  sed "s|%SITE_CHAIN%|${SITE_CHAIN}|g" |
  sed "s|%VHOST_NAME%|${VHOST_NAME}|g" > ${APPNAME}.apache.tmp

sed "s|%LAUNCHER_PATH%|${LAUNCHER_PATH}|g" < ${TEMPLATE_PATH}/play.init |
  sed "s|%PIDFILE%|${PIDFILE}|g" |
  sed "s|%WORKDIR%|${WORKDIR}|g" |
  sed "s|%CONF_FILE%|${WORKDIR}/conf/application.conf|g" |
  sed "s|%LOG_CONF%|${WORKDIR}/conf/logger.xml|g" |
  sed "s|%APP_PORT%|${APP_PORT}|g" > ${APPNAME}.init.tmp

play dist

chmod 755 ${APPNAME}.init.tmp

scp ${APPNAME}.init.tmp ${DESTINATION}:/etc/init.d/${APPNAME}
scp ${APPNAME}.apache.tmp ${DESTINATION}:/etc/apache2/sites-available/${APPNAME}
scp target/universal/${PACKAGENAME}-${VERSION}.zip ${DESTINATION}:/home/${USER}/
scp ${TEMPLATE_PATH}/install_app.sh ${DESTINATION}:
scp ${TEMPLATE_PATH}/${DEPLOY_CONF} ${DESTINATION}:deploy.conf

ssh ${DESTINATION} "a2enmod ssl proxy proxy_http&&a2ensite ${APPNAME}&&service apache2 restart&&update-rc.d ${APPNAME} defaults&&./install_app.sh"




