package com.ntti3.afp.helpers.pingfederate;

import com.google.common.collect.Maps;
import com.ntti3.pingfederate.connector.IdPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.TokenException;
import org.apache.http.client.utils.URIBuilder;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.util.MultiMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Created by jan.karwowski@ntti3.com on 28.01.14.
 */
public class FakePF {
    IdPProtocolHelper idpHelper;
    SPProtocolHelper spHelper;
    Handler spStartSsoHandler = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (request.getUri().getPath().equals("/sp/startSSO.ping")) {
                try {
                    if (loginSuccess) {
                        response.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT);
                        Map<String, String> token = Maps.newHashMap();
                        token.put(Agent.TOKEN_SUBJECT, "testTest");
                        token.put("first_name", "Ędward");
                        token.put("last_name", "Dutchman");
                        token.put("email", "email@email.com");
                        token.put("opco_uid", "navy");
                        token.put("opco_name", "Navy");
                        MultiMap<String> params = new MultiMap<>();
                        request.getUri().decodeQueryTo(params);
                        String resumeUrl = params.getString("TargetResource");
                        URIBuilder builder = new URIBuilder(resumeUrl)
                                .addParameter(spHelper.getAgentConfiguration().getTokenName(),
                                        spHelper.buildToken(token));
                        response.setHeader("Location", builder.build().toString());
                        request.setHandled(true);
                        System.err.println("Handling SSO request\n");
                    } else {
                        response.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT);
                        MultiMap<String> params = new MultiMap<>();
                        request.getUri().decodeQueryTo(params);
                        String resumeUrl = params.getString("InErrorResource");
                        request.setHandled(true);
                        URIBuilder builder = new URIBuilder(resumeUrl).addParameter("error", "error")
                                .addParameter("errorDetail", "errorDetails");
                        response.setHeader("Location", builder.build().toString());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }
    };
    Handler idpSsoResume = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (request.getUri().getPath().equals("/idp/resumeSSO")) {
                try {
                    response.setStatus(HttpServletResponse.SC_OK);
                    response.setHeader("Content-type", "text/plain");
                    MultiMap<String> params = new MultiMap<>();
                    request.getUri().decodeQueryTo(params);
                    if (params.containsKey("opentoken")) {
                        idpHelper.readToken(params.getString("opentoken"));
                        response.getWriter().write("OK\n");
                    } else {
                        response.getWriter().write("AUTH FAILED\n");
                    }
                    request.setHandled(true);

                } catch (TokenException ex) {
                    ex.printStackTrace();
                }
            }
        }
    };
    Handler idpSloResume = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (request.getUri().getPath().equals("/idp/resumeSLO")) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.setHeader("Content-type", "text/plain");
                MultiMap<String> params = new MultiMap<>();
                request.getUri().decodeQueryTo(params);
                response.getWriter().write("OK\n");
                request.setHandled(true);
            }
        }
    };
    Handler idpStartSso = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (request.getUri().getPath().equals("/idp/startSSO.ping")) {
                try {
                    MultiMap<String> params = new MultiMap<>();
                    request.getUri().decodeQueryTo(params);
                    idpHelper.readToken(params.getString("opentoken"));
                    String partnerSpId = params.getString("PartnerSpId");
                    String targetResource = params.getString("TargetResource");

                    response.getWriter().write("PartnerSpId: " + partnerSpId + "\nTargetResource: " +
                            targetResource + "\n");
                    response.setStatus(HttpServletResponse.SC_OK);
                    response.setHeader("Content-type", "text/plain");
                    request.setHandled(true);
                } catch (TokenException ex) {
                    ex.printStackTrace();
                }
            }
        }
    };
    Handler idpStartSlo = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (!request.getUri().getPath().equals("/idp/startSLO.ping"))
                return;
            MultiMap<String> params = new MultiMap<>();
            request.getUri().decodeQueryTo(params);
            sloTargetResource = params.getString("TargetResource");
            response.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT);
            response.setHeader("Location", "http://localhost:3333/idp/sloHandler?resume=/idp/targetResumeSLO");
            request.setHandled(true);
        }
    };
    Handler spSloResume = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (request.getUri().getPath().equals("/sp/resumeSLO")) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.setHeader("Content-type", "text/plain");
                MultiMap<String> params = new MultiMap<>();
                request.getUri().decodeQueryTo(params);
                response.getWriter().write("SP SLO OK\n");
                request.setHandled(true);
            }
        }
    };
    Handler targetResumeSlo = new AbstractHandler() {
        @Override
        public void handle(String s, Request request, HttpServletRequest httpServletRequest,
                           HttpServletResponse response) throws IOException, ServletException {
            if (!request.getUri().getPath().equals("/idp/targetResumeSLO"))
                return;
            response.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT);
            response.setHeader("Location", sloTargetResource);
            request.setHandled(true);
        }
    };
    private boolean loginSuccess = true;
    private String sloTargetResource;

    public FakePF(IdPProtocolHelper idpHelper, SPProtocolHelper spHelper) {
        this.idpHelper = idpHelper;
        this.spHelper = spHelper;
    }

    public void setLoginSuccess(boolean loginSuccess) {
        this.loginSuccess = loginSuccess;
    }

    public Server startServer(int port) throws Exception {
        Server server = new Server(port);
        HandlerCollection collection = new HandlerCollection();

        collection.addHandler(idpSsoResume);
        collection.addHandler(spStartSsoHandler);
        collection.addHandler(idpStartSso);
        collection.addHandler(idpSloResume);
        collection.addHandler(targetResumeSlo);
        collection.addHandler(idpStartSlo);
        collection.addHandler(spSloResume);
        server.setHandler(collection);

        server.start();
        return server;
    }

}
