package com.ntti3.afp.helpers.session;

import com.google.common.collect.Maps;
import com.ntti3.afp.models.SsoSession;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import play.mvc.Http;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static junit.framework.TestCase.assertEquals;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

public class SsoSessionHelperTest {

    Calendar validDate;
    Map<String, String> data;
    private play.test.FakeApplication app;

    @Before
    public void before() {
        validDate = Calendar.getInstance();
        validDate.add(Calendar.SECOND, 3600);
        data = Maps.newHashMap();

        data.put("opco_uid", "test");
        data.put("opco_u_uid", "test");

        app = fakeApplication(inMemoryDatabase());
        start(app);
    }

    @After
    public void after() {
        stop(app);
    }

    @Test(expected = NoSessionException.class)
    public void nonexistentSessionTest() throws NoSessionException {
        SsoSessionHelper.getSessionForId(2048L);
    }

    @Test
    public void noBrowserSessionTest() {
        Assert.assertFalse(SsoSessionHelper.isLoggedIn(
                new Http.Session(Collections.<String, String>emptyMap())));
    }

    @Test(expected = NoSessionException.class)
    public void sessionCreation() throws InvocationTargetException, IllegalAccessException, NoSessionException, IntrospectionException {
        final UUID subject = UUID.randomUUID();
        final String opcoUid = "opcoUid";
        final String opcoUUid = "opcoUUid";

        Long id = SsoSessionHelper.loginUser(subject, opcoUUid, opcoUid, validDate);
        Assert.assertNotNull(id);

        SsoSession session = SsoSessionHelper.getSessionForId(id);

        assertEquals(opcoUid, session.getOpcoUid());

        SsoSessionHelper.logoutUser(subject);
        SsoSessionHelper.getSessionForId(id);
    }

    @Test
    public void isLoggedIdTrue() throws InvocationTargetException, IllegalAccessException, IntrospectionException {
        final UUID subject = UUID.randomUUID();
        final String opcoUid = "opcoUid";
        final String opcoUUid = "opcoUUid";

        Long id = SsoSessionHelper.loginUser(subject, opcoUid, opcoUUid, validDate);
        HashMap<String, String> map = Maps.newHashMap();
        map.put(SsoSessionHelper.SESSION_SSOID, id.toString());
        Http.Session session = new Http.Session(map);

        Assert.assertTrue(SsoSessionHelper.isLoggedIn(session));

    }

    @Test
    public void testLoginInSession() throws InvocationTargetException, IllegalAccessException, IntrospectionException {
        final UUID subject = UUID.randomUUID();
        final String opcoUid = "opcoUid";
        final String opcoUUid = "opcoUUid";

        Http.Session session = new Http.Session(Collections.<String, String>emptyMap());
        SsoSessionHelper.loginUserBrowserSession
                (subject, opcoUid, opcoUUid, validDate, session);

        Assert.assertTrue(SsoSessionHelper.isLoggedIn(session));
    }

    @Test(expected = NoSessionException.class)
    public void expirationTest() throws NoSessionException, InvocationTargetException, IllegalAccessException, IntrospectionException {
        final UUID subject = UUID.randomUUID();
        final String opcoUid = "opcoUid";
        final String opcoUUid = "opcoUUid";

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1);
        Long id = SsoSessionHelper.loginUser(subject, opcoUUid, opcoUid, c);

        Assert.assertNotNull(id);

        SsoSessionHelper.getSessionForId(id);
    }

}

