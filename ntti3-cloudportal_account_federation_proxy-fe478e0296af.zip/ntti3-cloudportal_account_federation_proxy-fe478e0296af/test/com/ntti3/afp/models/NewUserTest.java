package com.ntti3.afp.models;

import org.junit.Test;
import play.data.validation.ValidationError;

import java.util.List;

import static org.junit.Assert.*;

public class NewUserTest {

    @Test
    public void tooShortPassword() {
        expectMessageForPassword(NewUser.PASSWORD_TOO_SHORT, "6chaRs");
    }


    @Test
    public void noCapitalLetterPassword() {
        expectMessageForPassword(NewUser.PASSWORD_CAPITAL_LETTER, "13characters");
    }

    @Test
    public void noDigitPassword() {
        expectMessageForPassword(NewUser.PASSWORD_DIGIT, "NoDigitAbcdef");
    }

    @Test
    public void passwordOk() {
        final String password = "1Marchewka";
        NewUser newUser = createProperUser();
        newUser.setPassword(password);
        newUser.setRepeatPassword(password);
        assertNull(newUser.validate());
    }

    public void expectMessageForPassword(String message, String password) {
        NewUser newUser = createProperUser();
        newUser.setPassword(password);
        newUser.setRepeatPassword(password);
        AssertErrorListContainsMessage(newUser.validate(), message);
    }

    private NewUser createProperUser() {
        NewUser newUser = new NewUser();
        newUser.setFirstName("FirstName");
        newUser.setLastName("Lastname");
        newUser.setSecurityQuestion("Question?");
        newUser.setSecurityAnswer("42");
        return newUser;
    }


    private boolean ErrorListContainsMessage(List<ValidationError> errors,String message) {
        for (ValidationError error : errors) {
            if (message == error.message()) { // both nulls or the same string
                return true;
            }

            if (message != null && message.equals(error.message())) {
                return true;
            }
        }
        return false;
    }

    private void AssertErrorListContainsMessage(List<ValidationError> errors,String message) {
        assertTrue("Error list does not contain message '" + message + "'", ErrorListContainsMessage(errors, message));
    }
}