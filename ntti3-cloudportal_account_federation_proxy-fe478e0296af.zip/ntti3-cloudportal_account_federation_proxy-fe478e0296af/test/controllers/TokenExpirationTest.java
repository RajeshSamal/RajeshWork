package controllers;

import com.google.common.collect.Maps;
import com.ntti3.pingfederate.connector.ProtocolHelper;
import org.junit.Before;
import org.junit.Test;
import play.libs.F;
import play.test.TestBrowser;

import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.HTMLUNIT;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.running;
import static play.test.Helpers.testServer;

/**
 * Created by jan.karwowski@ntti3.com on 28.01.14.
 */
public class TokenExpirationTest {
    private play.test.FakeApplication app;

    @Before
    @SuppressWarnings({"unchecked"})
    public void before() throws Exception {
        Map<String, String> config = Maps.newHashMap(inMemoryDatabase());

        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "conf/agent-config.txt");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_SCHEME, "http");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_PORT, "1235");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_HOST, "localhost");

        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "conf/agent-config-idp.txt");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_SCHEME, "http");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_PORT, "1235");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_HOST, "localhost");

        config.put("vhosts.\"localhost:3333\".application.baseUrl", "http://localhost:3333/");
        config.put("vhosts.\"localhost:3333\".idpselector.provider", "nttdd");
        config.put("vhosts.\"localhost:3333\".opco", "nttdd");
        config.put("vhosts.\"localhost:3333\".sp-entities.test", "test");

        app = fakeApplication(config);
    }

    @Test
    public void expiredTest() throws Exception {

        running(testServer(3333, app), HTMLUNIT, new F.Callback<TestBrowser>() {
            public void invoke(TestBrowser browser) {
                // A token valid until 01/13/2014 9:55
                String token = "T1RLAQIDfw5mJj3eWgmE2Ys-mPiQqNB9fhBBiJ62WmGb9qFzo6Elw27QAAEAforC71TiRJXnRiqC_" +
                        "-eBLx-I9eyt4uYYYdXFhknFC_uDljpeuNfyBDlZ0m6ySQ0KHZx6G64_FTujffDZ69ikppjQ6yfnyubb5OLyD" +
                        "CsYdUxhal-Bx2fghwlV4K_px5rqSF5zqdUfHSUHwBDfm3D7VqMZ9fZb4W8TTm5IMd4yErFbrnB0j71C_w7_Lh" +
                        "-riqiE1WAJWtmHCd4oavE47b5Xto9tjfCEvx1bl27LkTasrIlWJXcbwr5pPFvrLp1hYvxPI0YuZjDKu0eijIp" +
                        "xW5q2ysEucyo6OR07oalTPkjAHVWQ6k34XPnMVxSZ4TL0QfoQku6_9b6ePll4OQPn6O1ldA**";
                browser.goTo("http://localhost:3333/sp/aaaa/ssoHandler?"
                        + "opentoken=" + token);
                assertThat(browser.pageSource()).contains("Request expired");
            }
        });
    }

    @Test
    public void invalidTest() throws Exception {
        running(testServer(3333, app), HTMLUNIT, new F.Callback<TestBrowser>() {
            public void invoke(TestBrowser browser) {
                // Invalid token
                String token = "T1RLAQIDfw5mJj3eWgmE2Ys-mPiQqNB9fhBBiJ62WmGb9qFzo6Elw27QAAEAforC71TiRJXnRiqC_" +
                        "-eBLx-I9eyt4uYYYdXFhknFC_uDljpeuNfyBwBDfm3D7VqMZ9fZb4W8TTm5IMd4yErFbrnB0j71C_w7_Lh" +
                        "-riqiE1WAJWtmHCd4oavE47b5Xto9tjfCEvx1bl27LkTasrIlWJXcbwr5pPFvrLp1hYvxPI0YuZjDKu0eijIp" +
                        "xW5q2ysEucyo6OR07oalTPkjAHVWQ6k34XPnMVxSZ4TL0QfoQku6_9b6ePll4OQPn6O1ldA**";
                browser.goTo("http://localhost:3333/sp/aaaa/ssoHandler?"
                        + "opentoken=" + token);
                assertThat(browser.pageSource()).contains("Invalid request");
            }
        });
    }
}
