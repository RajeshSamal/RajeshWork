package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.AbstractModule;
import com.ntti3.afp.helpers.pingfederate.FakePF;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.models.User;
import com.ntti3.pingfederate.connector.IdPProtocolHelper;
import com.ntti3.pingfederate.connector.IdPProtocolHelperFactory;
import com.ntti3.pingfederate.connector.ProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelperFactory;
import org.eclipse.jetty.server.Server;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import play.Configuration;
import play.libs.Json;
import play.test.TestBrowser;
import play.test.TestServer;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static junit.framework.TestCase.assertEquals;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;
import static play.test.Helpers.testBrowser;
import static play.test.Helpers.testServer;

public class PFIdpIntegrationTest {
    Server fakePFServer;
    User gumsUser;
    private GumsConnector fakeGums;
    private play.test.FakeApplication app;
    private TestServer server;
    private TestBrowser browser;
    private FakePF fakePF;
    private WebDriver firefoxDriver;

    @Before
    @SuppressWarnings({"unchecked"})
    public void before() throws Exception {
        Map<String, String> config = Maps.newHashMap(inMemoryDatabase());

        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "conf/agent-config.txt");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_SCHEME, "http");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_PORT, "1235");
        config.put("vhosts.\"localhost:3333\".sp." + ProtocolHelper.CONFIG_FILE_HOST, "localhost");

        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "conf/agent-config-idp.txt");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_SCHEME, "http");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_PORT, "1235");
        config.put("vhosts.\"localhost:3333\".idp." + ProtocolHelper.CONFIG_FILE_HOST, "localhost");

        config.put("vhosts.\"localhost:3333\".application.baseUrl", "http://localhost:3333/");
        config.put("vhosts.\"localhost:3333\".idpselector.provider", "nttdd");
        config.put("vhosts.\"localhost:3333\".opco", "nttdd");
        config.put("vhosts.\"localhost:3333\".sp-entities.test", "test");


        fakeGums = mock(GumsConnector.class);
        app = fakeApplication(config, new com.ntti3.afp.global.Global() {
            @Override
            protected AbstractModule initGumsConnectorModule() throws KeyStoreException, IOException,
                    CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyManagementException,
                    URISyntaxException {
                return new AbstractModule() {
                    @Override
                    protected void configure() {
                        bind(GumsConnector.class).toInstance(fakeGums);
                    }
                };
            }
        });
        server = testServer(3333, app);
        firefoxDriver = new FirefoxDriver();
        browser = testBrowser(firefoxDriver);
        start(server);
        IdPProtocolHelper idPProtocolHelper = new IdPProtocolHelperFactory().getInstanceFromConfig(
                Maps.transformValues(Configuration.root().getConfig("pfhelper.idp").asMap(),
                        new Function<Object, String>() {
                            @Override
                            public String apply(Object input) {
                                return input.toString();
                            }
                        }));
        SPProtocolHelper spProtocolHelper = new SPProtocolHelperFactory().getInstanceFromConfig(
                Maps.transformValues(Configuration.root().getConfig("pfhelper.sp").asMap(),
                        new Function<Object, String>() {
                            @Override
                            public String apply(Object input) {
                                return input.toString();
                            }
                        }));
        fakePF = new FakePF(idPProtocolHelper, spProtocolHelper);

        gumsUser = new User();
        gumsUser.setGuid(new UUID(0, 0));
        gumsUser.setFirstName("Moses");
        gumsUser.setLastName("I");
        gumsUser.setEmail("moses@email.il");
        gumsUser.setOpcoName("NTTDD");
        gumsUser.setOpcoUUid("test");
        gumsUser.setOpcoUid("opcoUid");
        gumsUser.setActive(true);
        gumsUser.setFlags(Lists.<String>newArrayList());
        gumsUser.setProducts(Lists.newArrayList("test"));

        fakePFServer = fakePF.startServer(1235);
        try {
            when(fakeGums.getOrRegisterUser(anyString(), anyString(), anyString(), anyString(), anyString(),
                    anyString(), anyString(), anyString(), any(List.class))).thenReturn(new UUID(0, 0));
            when(fakeGums.getOrRegisterUser(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(),
                    anyString(), anyString(), anyString(), any(List.class))).thenReturn(new UUID(0, 0));
            when(fakeGums.getUser(any(UUID.class))).thenReturn(gumsUser);
            when(fakeGums.getUserGuid(anyString(), anyString())).thenReturn(new UUID(0, 0));
        } catch (IOException | GumsProtocolException e) {
            e.printStackTrace();
        }

    }

    @After
    public void after() throws Exception {
        fakePFServer.stop();
        stop(server);
        firefoxDriver.close();
    }

    @Test
    public void ssoTest() throws Exception {
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");
        assertThat(browser.pageSource()).contains("OK\n");
    }

    @Test
    public void ssoFailureTest() throws Exception {
        fakePF.setLoginSuccess(false);
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");

        assertThat(browser.pageSource()).contains("errorDetail");
        browser.await().atMost(10000).until("#continue").areDisplayed();
        browser.click("#continue");
        assertThat(browser.pageSource()).contains("AUTH FAILED");
    }

    @Test
    public void accountInactiveSsoTest() throws Exception {
        gumsUser.setActive(false);
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");
        assertThat(browser.pageSource()).contains("Your account has been disabled");
    }

    @Test
    public void ssoTestLoggedIn() throws Exception {
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");
        browser.goTo("http://localhost:3333/ajax/logged_in");
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");

        assertThat(browser.pageSource()).contains("OK");
    }

    @Test
    public void spInitiatedSlo() throws Exception {
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");
        //now we are logged in PF
        browser.goTo("http://localhost:3333/idp/sloHandler?resume=%2Fidp%2FresumeSLO");
        assertEquals("OK", browser.text("body").get(0));
        browser.goTo("http://localhost:3333/ajax/logged_in");
        JsonNode node = Json.parse(browser.text("body").get(0));
        assertEquals("false", node.get("logged_in").textValue());

    }

    @Test
    public void spNotLoggedSlo() throws Exception {
        browser.goTo("http://localhost:3333/idp/sloHandler?resume=%2Fsp%2FresumeSLO");
        assertThat(browser.pageSource()).contains("SP SLO OK");
        browser.goTo("http://localhost:3333/ajax/logged_in");
        JsonNode node = Json.parse(browser.text("body").get(0));
        assertEquals("false", node.get("logged_in").textValue());
    }

    @Test
    public void deadGums() throws Exception {
        when(fakeGums.getUser(any(UUID.class))).thenThrow(new GumsProtocolException("Internal Server Error"));
        browser.goTo("http://localhost:3333/idp/ssoHandler?"
                + "spentity=test&resume=%2Fidp%2FresumeSSO");
        browser.click("#nttdd a");

        assertThat(browser.pageSource()).contains("Service unavailable");
    }

}
