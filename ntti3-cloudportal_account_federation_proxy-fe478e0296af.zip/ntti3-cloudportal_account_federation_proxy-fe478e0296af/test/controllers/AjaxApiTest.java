package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Before;
import org.junit.Test;
import play.libs.F;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeRequest;
import play.test.Helpers;
import play.test.TestBrowser;

import static junit.framework.Assert.assertEquals;
import static org.fest.assertions.Assertions.assertThat;
import static play.mvc.Http.Status.OK;
import static play.test.Helpers.HTMLUNIT;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentType;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.header;
import static play.test.Helpers.running;
import static play.test.Helpers.status;
import static play.test.Helpers.testServer;

public class AjaxApiTest {
	private play.test.FakeApplication app;
    
	@Before
	public void setUp() {
		app = Helpers.fakeApplication(Helpers.inMemoryDatabase());
	}

    @Test
    public void testLoggedInFalse() throws Exception {

        running(testServer(3333, app), HTMLUNIT, new F.Callback<TestBrowser>() {
            public void invoke(TestBrowser browser) {
                browser.goTo("http://localhost:3333/ajax/logged_in");
                JsonNode node = Json.parse(browser.pageSource());
                assertEquals("false", node.get("logged_in").textValue());

            }
        });
    }

    @Test
    public void testAccessControlHeaders() throws Exception {
        FakeRequest fakeRequest = fakeRequest("GET", "http://localhost/");
        fakeRequest.withHeader("Referer", "http://localhost/");
        Result result = callAction(
                com.ntti3.afp.controllers.routes.ref.AjaxApi.loggedIn(), fakeRequest
        );
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("application/json");
        assertEquals("localhost", header("access-control-allow-origin", result));
        assertEquals("true", header("access-control-allow-credentials", result));
    }

}
