# --- !Ups

ALTER TABLE ssosessions ADD COLUMN opco_u_uid varchar(255);


# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

ALTER TABLE ssosesions DROP COLUMN opco_u_uid;


SET REFERENTIAL_INTEGRITY TRUE;