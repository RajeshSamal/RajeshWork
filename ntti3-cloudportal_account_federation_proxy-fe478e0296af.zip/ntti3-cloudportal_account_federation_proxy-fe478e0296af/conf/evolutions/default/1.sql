# --- !Ups

create table ssosessions (
  id                        bigint auto_increment not null,
  subject                   varchar(255),
  first_name                varchar(255),
  last_name                 varchar(255),
  email                     varchar(255),
  opco_uid                  varchar(255),
  opco_name                 varchar(255),
  valid_before              timestamp,
  extended_attributes       blob,
  constraint pk_ssosessions primary key (id))
;




# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;

drop table if exists ssosessions;

SET REFERENTIAL_INTEGRITY TRUE;

