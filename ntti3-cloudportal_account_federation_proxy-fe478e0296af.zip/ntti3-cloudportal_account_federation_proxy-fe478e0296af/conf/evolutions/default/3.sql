# --- !Ups

ALTER TABLE ssosessions DROP COLUMN first_name;
ALTER TABLE ssosessions DROP COLUMN last_name;
ALTER TABLE ssosessions DROP COLUMN email;
ALTER TABLE ssosessions DROP COLUMN opco_name;
ALTER TABLE ssosessions DROP COLUMN extended_attributes;
ALTER TABLE ssosessions DROP COLUMN subject;
ALTER TABLE ssosessions ADD COLUMN guid char(36);

# --- !Downs

SET REFERENTIAL_INTEGRITY FALSE;


ALTER TABLE ssosessions ADD COLUMN subject varchar(255);
ALTER TABLE ssosessions ADD COLUMN first_name varchar(255);
ALTER TABLE ssosessions ADD COLUMN last_name varchar(255);
ALTER TABLE ssosessions ADD COLUMN email varchar(255);
ALTER TABLE ssosessions ADD COLUMN opco_name varchar(255);
ALTER TABLE ssosessions ADD COLUMN extended_attributes       blob;
ALTER TABLE ssosessions DROP COLUMN guid;

SET REFERENTIAL_INTEGRITY TRUE;