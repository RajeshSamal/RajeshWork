import com.google.common.base.Function;
import com.google.common.collect.Maps;
import com.google.inject.AbstractModule;
import com.ntti3.gums.guice.DefaultGumsConnectorFromConfigModule;
import play.Configuration;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

public final class Global extends com.ntti3.afp.global.Global {
    private static final String GUMS_CONFIG_PREFIX = "gums";

    @Override
    protected AbstractModule initGumsConnectorModule() throws KeyStoreException, IOException, CertificateException,
            NoSuchAlgorithmException, UnrecoverableKeyException, KeyManagementException, URISyntaxException {

        return new DefaultGumsConnectorFromConfigModule(
                Maps.transformValues(Configuration.root().getConfig(GUMS_CONFIG_PREFIX).asMap(),
                        new Function<Object, String>() {
                            @Override
                            public String apply(Object input) {
                                return input.toString();
                            }
                        }));
    }
}
