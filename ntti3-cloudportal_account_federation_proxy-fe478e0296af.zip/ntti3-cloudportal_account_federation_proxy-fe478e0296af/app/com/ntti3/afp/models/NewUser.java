package com.ntti3.afp.models;

import play.data.validation.Constraints;
import play.data.validation.ValidationError;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jan.karwowski@ntti3.com
 */
public class NewUser {
    public static final String PASSWORD_FIELDS_DO_NOT_MATCH_MESSAGE = "Password fields must match.";
    public static final String PASSWORD_FIELD = "password";
    public static final String PASSWORD_TOO_SHORT = "Password must be at least 8 characters.";
    public static final String PASSWORD_CAPITAL_LETTER = "Password must contain at least one capital letter.";
    public static final String PASSWORD_DIGIT = "Password must contain at least one digit.";
    @Constraints.Required
    private String firstName;
    @Constraints.Required
    private String lastName;
    private String mobilePhone;
    @Constraints.Required
    private String password;
    @Constraints.Required
    private String repeatPassword;
    @Constraints.Required
    private String securityQuestion;
    @Constraints.Required
    private String securityAnswer;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRepeatPassword() {
        return repeatPassword;
    }

    public void setRepeatPassword(String repeatPassword) {
        this.repeatPassword = repeatPassword;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    public List<ValidationError> validate() {
        final List<ValidationError> validationErrors = new ArrayList<>();
        checkPasswordMeetPolicy(validationErrors);
        checkPasswordsMatch(validationErrors);
        return validationErrors.isEmpty() ? null : validationErrors;
    }

    private void checkPasswordMeetPolicy(List<ValidationError> validationErrors) {
        // length > 8
        // 1 capital letter
        // 1 digit
        if (password.length() < 8) {
            validationErrors.add(new ValidationError(PASSWORD_FIELD, PASSWORD_TOO_SHORT));
        }

        if (!password.matches(".*[A-Z]+.*")) {
            validationErrors.add(new ValidationError(PASSWORD_FIELD, PASSWORD_CAPITAL_LETTER));
        }

        if (!password.matches(".*[0-9]+.*")) {
            validationErrors.add(new ValidationError(PASSWORD_FIELD, PASSWORD_DIGIT));
        }
    }

    private void checkPasswordsMatch(List<ValidationError> validationErrors) {
        if (!password.equals(repeatPassword)) {
            validationErrors.add(new ValidationError(PASSWORD_FIELD,
                    PASSWORD_FIELDS_DO_NOT_MATCH_MESSAGE));
        }
    }

}
