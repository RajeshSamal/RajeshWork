package com.ntti3.afp.models;

import play.data.validation.Constraints;

/**
 * @author wojciech.jurczyk@codilime.com
 */
public class NewUserWithEmail extends NewUser {
    @Constraints.Required
    @Constraints.Email
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
