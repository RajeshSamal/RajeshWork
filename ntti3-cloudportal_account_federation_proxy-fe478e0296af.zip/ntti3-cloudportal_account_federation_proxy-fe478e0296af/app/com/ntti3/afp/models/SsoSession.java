package com.ntti3.afp.models;

import com.ntti3.afp.helpers.session.ProtocolName;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Calendar;
import java.util.UUID;

import static com.ntti3.afp.helpers.AfpProtocolConstants.OPCO_U_UID_PARAM;

@Entity
@Table(name = "ssosessions")
public class SsoSession extends Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Constraints.Required
    private UUID guid;

    @Constraints.Required
    private Calendar validBefore;

    @Constraints.Required
    @ProtocolName(OPCO_U_UID_PARAM)
    @Column(name = "opco_u_uid")
    private String opcoUUid;

    private String opcoUid;

    public Long getId() {
        return id;
    }

    public UUID getGuid() {
        return guid;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public Calendar getValidBefore() {
        return validBefore;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public void setOpcoUid(String opcoUid) {
        this.opcoUid = opcoUid;
    }

    public void setValidBefore(Calendar validBefore) {
        this.validBefore = validBefore;
    }

    public void setOpcoUUid(String opcoUUid) {
        this.opcoUUid = opcoUUid;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }
}
