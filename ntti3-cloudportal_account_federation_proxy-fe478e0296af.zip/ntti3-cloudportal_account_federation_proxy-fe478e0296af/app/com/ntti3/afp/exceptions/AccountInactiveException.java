package com.ntti3.afp.exceptions;

import java.util.UUID;

/**
 * Thrown when user credentials are correct, but user account is not active for some reason.
 *
 * @author jan.karwowski@ntti3.com
 */
public class AccountInactiveException extends Exception {
    private UUID uuid;
    private String opcoUid;
    private String opcoUUid;

    public AccountInactiveException(UUID uuid, String opcoUid, String opcoUUid) {
        super("User account " + uuid.toString() + "(" + opcoUid + "," + opcoUUid + ") has been suspended.");
        this.uuid = uuid;
        this.opcoUid = opcoUid;
        this.opcoUUid = opcoUUid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }
}
