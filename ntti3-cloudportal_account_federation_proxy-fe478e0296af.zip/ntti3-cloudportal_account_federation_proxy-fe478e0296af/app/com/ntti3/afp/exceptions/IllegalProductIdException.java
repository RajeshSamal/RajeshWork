package com.ntti3.afp.exceptions;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class IllegalProductIdException extends Exception {

    private static final Long serialVersionUID = 1L;
    
    public IllegalProductIdException() {
    }

    public IllegalProductIdException(String message) {
        super(message);
    }

    public IllegalProductIdException(String message, Throwable cause) {
        super(message, cause);
    }

    public IllegalProductIdException(Throwable cause) {
        super(cause);
    }

    public IllegalProductIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
