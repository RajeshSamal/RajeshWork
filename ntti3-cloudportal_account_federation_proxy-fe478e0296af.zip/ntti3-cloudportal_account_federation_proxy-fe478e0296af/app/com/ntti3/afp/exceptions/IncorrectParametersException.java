package com.ntti3.afp.exceptions;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class IncorrectParametersException extends Exception {

    private static final Long serialVersionUID = 1L;

    public IncorrectParametersException() {
    }

    public IncorrectParametersException(String message, Throwable cause) {
        super(message, cause);
    }

    public IncorrectParametersException(String message) {
        super(message);
    }

    public IncorrectParametersException(Throwable cause) {
        super(cause);
    }

    public IncorrectParametersException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
