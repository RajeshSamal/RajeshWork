package com.ntti3.afp.exceptions;

/**
 * @author Jacek Swiderski (jacek.swiderski@codilime.com)
 */
public class MissingProductException extends Exception {

    private static final Long serialVersionUID = 1L;
    
    public MissingProductException() {
        super();
    }

    public MissingProductException(String message) {
        super(message);
    }

    public MissingProductException(String message, Throwable cause) {
        super(message, cause);
    }

    public MissingProductException(Throwable cause) {
        super(cause);
    }
}
