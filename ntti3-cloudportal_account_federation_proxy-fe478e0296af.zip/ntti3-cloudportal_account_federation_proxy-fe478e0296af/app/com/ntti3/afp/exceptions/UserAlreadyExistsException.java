package com.ntti3.afp.exceptions;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class UserAlreadyExistsException extends Exception {

    private static final Long serialVersionUID = 1L;

    public UserAlreadyExistsException(String message) {
        super(message);
    }
}
