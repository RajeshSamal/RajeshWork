package com.ntti3.afp.exceptions;

import java.util.UUID;

/**
 * Thrown when user credentials are correct, but user account is not active for some reason.
 *
 * @author jan.karwowski@ntti3.com
 */
public class NotAssignedToProductException extends Exception {
    private UUID uuid;
    private String opcoUid;
    private String opcoUUid;
    private String product;

    public NotAssignedToProductException(UUID uuid, String opcoUid, String opcoUUid, String product) {
        super("User account " + uuid.toString() + "(" + opcoUid + "," + opcoUUid + ") has been not assigned to the" +
                "application '" + product + "'");
        this.uuid = uuid;
        this.opcoUid = opcoUid;
        this.opcoUUid = opcoUUid;
        this.product = product;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }

    public String getProduct() {
        return product;
    }
}
