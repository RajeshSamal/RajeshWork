package com.ntti3.afp.exceptions;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class IllegalInviterException extends Exception {

    private static final Long serialVersionUID = 1L;
    
    public IllegalInviterException() {
        super();
    }

    public IllegalInviterException(String message) {
        super(message);
    }

    public IllegalInviterException(String message, Throwable cause) {
        super(message, cause);
    }

    public IllegalInviterException(Throwable cause) {
        super(cause);
    }
}
