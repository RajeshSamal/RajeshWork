package com.ntti3.afp.exceptions;

/**
 * Created by Wojciech Jurczyk (wojciech.jurczyk@codilime.com).
 */
public class WrongInvitationEmailException extends Exception {

    private static final Long serialVersionUID = 1L;
    private final String suppliedEmail;
    private final String requiredEmail;
    private final String tokenId;

    public WrongInvitationEmailException(String suppliedEmail, String requiredEmail, String tokenId) {
        super();
        this.suppliedEmail = suppliedEmail;
        this.requiredEmail = requiredEmail;
        this.tokenId = tokenId;
    }

    public WrongInvitationEmailException(String suppliedEmail, String requiredEmail, Throwable cause, String tokenId) {
        super(cause);
        this.suppliedEmail = suppliedEmail;
        this.requiredEmail = requiredEmail;
        this.tokenId = tokenId;
    }

    public String getSuppliedEmail() {
        return suppliedEmail;
    }

    public String getRequiredEmail() {
        return requiredEmail;
    }

    public String getTokenId() {
        return tokenId;
    }
}
