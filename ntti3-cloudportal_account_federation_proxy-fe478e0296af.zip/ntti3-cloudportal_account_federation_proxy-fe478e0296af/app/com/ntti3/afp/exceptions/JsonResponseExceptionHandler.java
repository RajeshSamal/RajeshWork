package com.ntti3.afp.exceptions;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.badRequest;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class JsonResponseExceptionHandler<T extends Exception> extends AbstractExceptionHandler<T> {
    public JsonResponseExceptionHandler(Class<T> handledType) {
        super(handledType);
    }

    @Override
    protected SimpleResult handleExceptionWithType(T t, Http.Response response) {
        ObjectNode jsonResponse = Json.newObject();
        jsonResponse.put("title", "Error");
        jsonResponse.put("message", t.getMessage());
        return badRequest(jsonResponse);
    }
}
