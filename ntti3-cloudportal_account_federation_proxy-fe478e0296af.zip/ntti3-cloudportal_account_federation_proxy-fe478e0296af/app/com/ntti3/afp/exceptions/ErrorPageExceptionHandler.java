package com.ntti3.afp.exceptions;

import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.ok;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ErrorPageExceptionHandler<T extends Exception> extends AbstractExceptionHandler<T> {

    private final VhostInstanceSelector<String> errorContinueButtonUrlSelector;
    private final String title;
    private final String message;
    private final String details;
    private final String resumeUrl;

    public ErrorPageExceptionHandler(Class<T> handledType, String title, String message, String details, VhostInstanceSelector<String> errorContinueButtonUrlSelector) {
        this(handledType, title, message, details, null, errorContinueButtonUrlSelector);
    }

    public ErrorPageExceptionHandler(Class<T> handledType, String title, String message, String details, String resumeUrl, VhostInstanceSelector<String> errorContinueButtonUrlSelector) {
        super(handledType);
        this.errorContinueButtonUrlSelector = errorContinueButtonUrlSelector;
        this.title = title;
        this.message = message;
        this.details = details;
        this.resumeUrl = resumeUrl;
    }

    @Override
    protected SimpleResult handleExceptionWithType(T exception, Http.Response response) {
        String processedResumeUrl;
        try {
            if (resumeUrl != null && !resumeUrl.equals("")) {
                processedResumeUrl = resumeUrl;
            } else {
                processedResumeUrl = errorContinueButtonUrlSelector.getInstanceForVhost(Controller.request());
            }
        } catch (UnknownVhostException e) {
            processedResumeUrl = "";
        }

        return ok(views.html.main.render("Error", views.html.idperror.render(title, message, details,
                    processedResumeUrl)));
    }
}
