package com.ntti3.afp.global;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.TypeLiteral;
import com.ntti3.afp.controllers.annotations.ErrorButtonUrlSelector;
import com.ntti3.afp.controllers.annotations.IdPProviderSelector;
import com.ntti3.afp.controllers.annotations.OpcoSelector;
import com.ntti3.afp.exceptions.ErrorPageExceptionHandler;
import com.ntti3.afp.exceptions.IllegalInviterException;
import com.ntti3.afp.exceptions.IllegalProductIdException;
import com.ntti3.afp.exceptions.IncorrectParametersException;
import com.ntti3.afp.exceptions.JsonResponseExceptionHandler;
import com.ntti3.afp.exceptions.MissingProductException;
import com.ntti3.afp.exceptions.NotAssignedToProductException;
import com.ntti3.afp.exceptions.UnknownProductException;
import com.ntti3.afp.exceptions.UserAlreadyExistsException;
import com.ntti3.afp.helpers.Messages;
import com.ntti3.afp.helpers.SpEntityMapper;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.pingfederate.connector.IdPProtocolHelper;
import com.ntti3.pingfederate.connector.IdPProtocolHelperFactory;
import com.ntti3.pingfederate.connector.ProtocolParametersException;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelperFactory;
import com.ntti3.pingfederate.connector.TokenNotFoundException;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.tokens.TokenServiceConnector;
import com.ntti3.urlhelper.UrlHelper;
import com.pingidentity.opentoken.TokenException;
import com.pingidentity.opentoken.TokenExpiredException;
import play.Application;
import play.Configuration;
import play.GlobalSettings;
import play.Logger;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.Map;

import static play.mvc.Results.ok;

/**
 * Created by jan.karwowski@ntti3.com on 28.01.14.
 */
public abstract class Global extends GlobalSettings {
    private static final String APPLICATION_NAME = "afp";
    private static final String APPLICATION_BASE_URL_CONFIG_KEY = "application.baseUrl";
    private static final String CONFIG_FILE_IDP_ENTRY_KEY = "idp";
    private static final String CONFIG_FILE_SP_ENTRY_KEY = "sp";
    private static final String VHOSTS_CONFIG_KEY = "vhosts";
    public static final String SP_ENTITIES = "sp-entities";
    public static final String ERROR_CONTINUE_BUTTON_URL = "error-continue-button-url";
    private Injector injector;
    private GlobalExceptionsHandler globalExceptionsHandler;
    private VhostInstanceSelector<String> errorContinueButtonUrlSelector;

    @Override
    public void onStart(Application app) {
        super.onStart(app);

        final AbstractModule gumsConnectorModule;
        final AbstractModule tokenServiceConnectorModule;
        final AbstractModule urlHelperSelectorModule;
        final AbstractModule spProtocolHelperSelectorModule;
        final AbstractModule idpProtocolHelperSelectorModule;
        final AbstractModule idpSelectorModule;
        final AbstractModule opcoSelectorModule;
        final AbstractModule spEntityMapperSelectorModule;
        try {
            gumsConnectorModule = initGumsConnectorModule();
            tokenServiceConnectorModule = initTokenServiceConnectorModule();
            urlHelperSelectorModule = initUrlHelperSelectorModule();
            spProtocolHelperSelectorModule = initSpProtocolHelperSelectorModule();
            idpProtocolHelperSelectorModule = initIdpProtocolHelperSelectorModule();
            idpSelectorModule = initIdpSelectorModule();
            opcoSelectorModule = initOpcoSelectorModule();
            spEntityMapperSelectorModule = initSpEntityMapperSelectorModule();
        } catch (Exception e) {
            //play way of handling problem. Make checked exception unchecked and proceed
            throw new RuntimeException(e);
        }

        initErrorButtonUrlSelector();
        initExceptionHandler();

        final AbstractModule globalExceptionHandlerModule = new AbstractModule() {
            @Override
            protected void configure() {
                bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
            }
        };
        injector = Guice.createInjector(new BuildInfoReaderModule(APPLICATION_NAME),
                gumsConnectorModule, tokenServiceConnectorModule, urlHelperSelectorModule,
                spProtocolHelperSelectorModule, idpProtocolHelperSelectorModule, idpSelectorModule,
                opcoSelectorModule, spEntityMapperSelectorModule, globalExceptionHandlerModule,
                getErrorContinueButtonUrlSelectorModule());
    }

    private AbstractModule getErrorContinueButtonUrlSelectorModule() {
        return new AbstractModule() {
            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){})
                        .annotatedWith(ErrorButtonUrlSelector.class)
                        .toInstance(errorContinueButtonUrlSelector);
            }
        };
    }

    protected AbstractModule initTokenServiceConnectorModule() throws Exception {
        final TokenServiceConnector connector = new TokenServiceConnector(
                new URI(Configuration.root().getString("tokenservice.url")), null);

        return new AbstractModule() {
            @Override
            protected void configure() {
                bind(TokenServiceConnector.class).toInstance(connector);
            }
        };
    }

    public VhostInstanceSelector<String> getErrorContinueButtonUrlSelector() {
        return errorContinueButtonUrlSelector;
    }

    private void initExceptionHandler() {

        globalExceptionsHandler = new GlobalExceptionsHandler() {
            @Override
            public SimpleResult handle(Throwable t, Http.Response response) throws Throwable {
                return super.handle(t, response);
            }
        };

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(TokenException.class,
                "Invalid request",
                "System was unable to understand request from a browser",
                "Please make sure that you are using supported browser",
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(TokenExpiredException.class,
                "Request expired", "Your request has expired. Please try logging in again","",
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(GumsProtocolException.class,
                "Temporary error", "Service unavailable", "",
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(IOException.class,
                "Communication failure", "The system encountered temporary communication failure",
                "Please try again in few minutes",
                getErrorContinueButtonUrlSelector()));

        addBadRequestHandler(TokenNotFoundException.class);
        addBadRequestHandler(ProtocolParametersException.class);

        Messages.getString("OpenTokenIdP.product_not_assigned");

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(NotAssignedToProductException.class,
                "Bad request", Messages.getString("OpenTokenIdP.product_not_assigned"),
                Messages.getString("OpenTokenIdP.product_not_assigned_long"),
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(UnknownProductException.class,
                "Invalid request",
                "Requested product does not exist",
                "Please make contact the administrator",
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(UnknownVhostException.class,
                "Invalid request",
                "Requested host name is unknown",
                "Please make the host name is correct",
                getErrorContinueButtonUrlSelector()));
        
        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(MissingProductException.class,
                "Invalid request",
                "No product specified in token",
                "Please use correct token",
                getErrorContinueButtonUrlSelector()));

        globalExceptionsHandler.registerHandler(new JsonResponseExceptionHandler<>(IllegalInviterException.class));

        globalExceptionsHandler.registerHandler(new JsonResponseExceptionHandler<>(IllegalProductIdException.class));

        globalExceptionsHandler.registerHandler(new JsonResponseExceptionHandler<>(IncorrectParametersException.class));

        globalExceptionsHandler.registerHandler(new JsonResponseExceptionHandler<>(UserAlreadyExistsException.class));
    }

    private void addBadRequestHandler(Class<? extends Exception> exceptionClass) {
        globalExceptionsHandler.registerHandler(new ErrorPageExceptionHandler<>(exceptionClass,
                "Bad request", "The system cannot understand your request",
                "Request sent by the partner was invalid, please make sure you are connecting from" +
                        " authorized peer",
                getErrorContinueButtonUrlSelector()));
    }

    protected abstract AbstractModule initGumsConnectorModule() throws Exception;

    protected AbstractModule initUrlHelperSelectorModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<UrlHelper> urlHelperSelector;

            {
                Map<String, UrlHelper> urlHelpersMap = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);
                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    urlHelpersMap.put(vhost, new UrlHelper(vhostConfiguration.getString(
                            APPLICATION_BASE_URL_CONFIG_KEY)));
                }
                urlHelperSelector = new VhostInstanceSelector<>(urlHelpersMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<UrlHelper>>() {})
                        .toInstance(urlHelperSelector);
            }
        };
    }

    protected void initErrorButtonUrlSelector() {
        Map<String, String> errorContinueButtonUrlMap = Maps.newHashMap();
        Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);
        for (String vhost : vhostsConfiguration.subKeys()) {
            Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
            errorContinueButtonUrlMap.put(vhost, vhostConfiguration.getString(ERROR_CONTINUE_BUTTON_URL));
        }
        errorContinueButtonUrlSelector = new VhostInstanceSelector<>(errorContinueButtonUrlMap);
    }

    protected AbstractModule initSpProtocolHelperSelectorModule() throws IOException {
        return new AbstractModule() {

            final VhostInstanceSelector<SPProtocolHelper> spProtocolHelperSelector;

            {
                SPProtocolHelperFactory spProtocolHelperFactory = new SPProtocolHelperFactory();
                Map<String, SPProtocolHelper> spProtocolHelpersMap = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);

                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    spProtocolHelpersMap.put(vhost, spProtocolHelperFactory.getInstanceFromConfig(
                            Maps.transformValues(
                                    vhostConfiguration
                                            .getConfig(CONFIG_FILE_SP_ENTRY_KEY)
                                            .asMap(), new Function<Object, String>() {
                                @Override
                                public String apply(Object input) {
                                    return input.toString();
                                }
                            })
                    ));
                }
                spProtocolHelperSelector = new VhostInstanceSelector<>(spProtocolHelpersMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<SPProtocolHelper>>() {})
                        .toInstance(spProtocolHelperSelector);
            }
        };
    }

    protected AbstractModule initIdpProtocolHelperSelectorModule() throws IOException {
        return new AbstractModule() {

            final VhostInstanceSelector<IdPProtocolHelper> idpProtocolHelperSelector;

            {
                IdPProtocolHelperFactory idpProtocolHelperFactory = new IdPProtocolHelperFactory();
                Map<String, IdPProtocolHelper> idpProtocolHelpersMap = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);

                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    idpProtocolHelpersMap.put(vhost, idpProtocolHelperFactory.getInstanceFromConfig(
                            Maps.transformValues(
                                    vhostConfiguration
                                            .getConfig(CONFIG_FILE_IDP_ENTRY_KEY)
                                            .asMap(), new Function<Object, String>() {
                                @Override
                                public String apply(Object input) {
                                    return input.toString();
                                }
                            })
                    ));
                }
                idpProtocolHelperSelector = new VhostInstanceSelector<>(idpProtocolHelpersMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<IdPProtocolHelper>>() {})
                        .toInstance(idpProtocolHelperSelector);
            }
        };
    }

    protected AbstractModule initIdpSelectorModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<String> idpProviderSelector;

            {
                Map<String, String> idpProvidersMap = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);
                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    idpProvidersMap.put(vhost, vhostConfiguration.getString("idpselector.provider"));
                }
                idpProviderSelector = new VhostInstanceSelector<>(idpProvidersMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<String>>() {})
                        .annotatedWith(IdPProviderSelector.class).toInstance(idpProviderSelector);
            }
        };
    }

    protected AbstractModule initOpcoSelectorModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<String> opcoSelector;

            {
                Map<String, String> opcosMap = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);
                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    opcosMap.put(vhost, vhostConfiguration.getString("opco"));
                }
                opcoSelector = new VhostInstanceSelector<>(opcosMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<String>>() {})
                        .annotatedWith(OpcoSelector.class).toInstance(opcoSelector);
            }
        };
    }

    protected AbstractModule initSpEntityMapperSelectorModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<SpEntityMapper> spEntityMapperSelector;

            {
                Map<String, SpEntityMapper> spEntityMappers = Maps.newHashMap();
                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);
                for (String vhost : vhostsConfiguration.subKeys()) {
                    Configuration vhostConfiguration = getConfiguration(vhostsConfiguration, vhost);
                    spEntityMappers.put(vhost, new SpEntityMapper(Maps.transformValues(
                            vhostConfiguration
                                    .getConfig(SP_ENTITIES)
                                    .asMap(), new Function<Object, String>() {
                        @Override
                        public String apply(Object input) {
                            return input.toString();
                        }
                    })));
                }
                spEntityMapperSelector = new VhostInstanceSelector<>(spEntityMappers);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<SpEntityMapper>>() {})
                        .toInstance(spEntityMapperSelector);
            }
        };
    }

    private Configuration getConfiguration(Configuration vhostsConfiguration, String vhost) {
        Logger.debug("loading vhost: " + vhost);
        return Preconditions.checkNotNull(vhostsConfiguration.getConfig("\"" + vhost + "\""),
                "Can not get vhost configuration for key " + vhost);
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return injector.getInstance(controllerClass);
    }

    public static String getApplicationName() {
        return APPLICATION_NAME;
    }

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }
}

