package com.ntti3.afp.helpers.session;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Update;
import com.ntti3.afp.models.SsoSession;
import play.Logger;
import play.db.ebean.Model.Finder;
import play.mvc.Http;

import java.sql.Date;
import java.util.Calendar;
import java.util.UUID;

import static com.google.common.base.Preconditions.checkNotNull;

public final class SsoSessionHelper {
    /**
     * Name of browser session variavle used by {@link #isLoggedIn(play.mvc.Http.Session)} and
     * {@link #loginUserBrowserSession(UUID, String, String, java.util.Calendar, play.mvc.Http.Session)}.
     */
    public static final String SESSION_SSOID = "SSOID";

    private SsoSessionHelper() {
    }

    /**
     * Terminates <strong>all</strong> sessions where given user is logged in.
     *
     * @param guid User to log out
     */
    public static void logoutUser(final UUID guid) {
        String dml = "DELETE FROM ssosessions  where guid = :guid";
        Update update = Ebean.createUpdate(SsoSession.class, dml)
                .setParameter("guid", guid);
        update.execute();

        Logger.debug("Terminated all sessions for user " + guid.toString());
    }

    public static Long loginUser(final UUID guid, final String opcoUUid, final String opcoUid, final Calendar validBefore) {
        checkNotNull(guid, "guid");
        SsoSession session = new SsoSession();

        session.setGuid(guid);
        session.setOpcoUUid(opcoUUid);
        session.setOpcoUid(opcoUid);
        session.setValidBefore(validBefore);
        session.save();
        return session.getId();
    }

    /**
     * @param id id of the session
     * @return session or null if there is no such session
     */
    public static SsoSession getSessionForId(final Long id) throws NoSessionException {
        SsoSession session = getSessionForIdNull(id);
        if (session == null)
            throw new NoSessionException();
        return session;
    }

    /**
     * Checks if user is logged in given browser session
     *
     * @param session Browser session
     * @return logeed in
     */
    public static boolean isLoggedIn(Http.Session session) {
        return null != getSessionFromBrowserNull(session);
    }

    /**
     * Returns session object if browser has established session, null otherwise.
     *
     * @param session browser session
     * @return session
     */
    public static SsoSession getSessionFromBrowser(Http.Session session) throws NoSessionException {
        SsoSession session1 = getSessionFromBrowserNull(session);
        if (session1 == null)
            throw new NoSessionException();
        return session1;
    }

    public static void loginUserBrowserSession(final UUID guid, final String opcoUUid, final String opcoUid,
                                               final Calendar validBefore,
                                               Http.Session session) {
        session.put(SESSION_SSOID, loginUser(guid, opcoUUid, opcoUid, validBefore).toString());
    }

    private static SsoSession getSessionForIdNull(Long id) {
        Finder<Long, SsoSession> finder = new Finder<>(Long.class, SsoSession.class);
        return finder.where().ge("validBefore", new Date(System.currentTimeMillis()))
                .idEq(id).findUnique();
    }

    public static SsoSession getSessionFromBrowserNull(Http.Session session) {
        if (!session.containsKey(SESSION_SSOID))
            return null;
        return getSessionForIdNull(Long.parseLong(session.get(SESSION_SSOID)));
    }
}
