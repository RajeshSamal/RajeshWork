package com.ntti3.afp.helpers.session;

/**
 * Created by jan.karwowski@ntti3.com on 28.01.14.
 */
public class NoSessionException extends Exception {
    public NoSessionException() {
    }

    public NoSessionException(String message) {
        super(message);
    }

    public NoSessionException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoSessionException(Throwable cause) {
        super(cause);
    }
}
