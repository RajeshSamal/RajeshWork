package com.ntti3.afp.helpers.session;

import com.google.common.collect.Maps;
import org.apache.commons.beanutils.BeanUtils;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3
 */
public class ProtocolNameBeanMapper {
    public static void populate(Object bean, Map<String, ?> values) throws InvocationTargetException, IllegalAccessException, IntrospectionException {
        Map<String, Object> newMap = Maps.newHashMap();

        Map<String, String> propertyMapping = Maps.newHashMap();

        for (PropertyDescriptor descriptor : Introspector.getBeanInfo(bean.getClass()).getPropertyDescriptors()) {
            ProtocolName protocolName = null;
            protocolName = getAnnotationFromAccessorOrField(bean, descriptor, ProtocolName.class);

            if (protocolName != null) {
                propertyMapping.put(protocolName.value(), descriptor.getName());
            }
        }

        for (Map.Entry<String, ?> entry : values.entrySet()) {
            if (propertyMapping.containsKey(entry.getKey())) {
                newMap.put(propertyMapping.get(entry.getKey()), entry.getValue());
            } else {
                newMap.put(entry.getKey(), entry.getValue());
            }

        }

        BeanUtils.populate(bean, newMap);
    }

    public static Map<String, String> describe(Object bean) throws IllegalAccessException, NoSuchMethodException,
            InvocationTargetException, IntrospectionException {
        Map<String, String> description = BeanUtils.describe(bean);

        Map<String, String> mappedDescription = Maps.newHashMap();

        BeanInfo bi = Introspector.getBeanInfo(bean.getClass());
        PropertyDescriptor[] descriptors = bi.getPropertyDescriptors();

        for (Map.Entry<String, String> entry : description.entrySet()) {
            String name = entry.getKey();
            for (PropertyDescriptor d : descriptors) {
                if (d.getName().equals(entry.getKey())) {
                    ProtocolName protocolName = getAnnotationFromAccessorOrField(bean, d, ProtocolName.class);
                    if (protocolName != null) {
                        name = protocolName.value();
                    }
                }
            }

            mappedDescription.put(name, entry.getValue());
        }
        return mappedDescription;
    }

    private static <T extends Annotation> T getAnnotationFromAccessorOrField(Object bean, PropertyDescriptor descriptor,
                                                                             Class<T> annotation) {
        T annotationInstance = null;
        try {
            if (descriptor.getReadMethod().getAnnotation(annotation) != null) {
                annotationInstance = descriptor.getReadMethod().getAnnotation(annotation);
            }
        } catch (NullPointerException e) {
        }

        try {
            if (descriptor.getWriteMethod().getAnnotation(annotation) != null) {
                annotationInstance = descriptor.getWriteMethod().getAnnotation(annotation);
            }
        } catch (NullPointerException e) {
        }

        try {
            if (bean.getClass().getDeclaredField(descriptor.getName()).isAnnotationPresent(annotation)) {
                annotationInstance = bean.getClass().getDeclaredField(descriptor.getName()).getAnnotation(annotation);
            }
        } catch (NullPointerException | NoSuchFieldException e) {
        }
        return annotationInstance;
    }
}
