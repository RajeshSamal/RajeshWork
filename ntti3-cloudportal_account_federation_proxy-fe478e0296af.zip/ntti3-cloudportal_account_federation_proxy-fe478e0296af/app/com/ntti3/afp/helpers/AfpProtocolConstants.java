package com.ntti3.afp.helpers;

/**
 * Constants defining names used in afp protocol
 *
 * @author jan.karwowski@ntti3.com
 */
public class AfpProtocolConstants {
    public static final String FIRST_NAME_PARAM = "first_name";
    public static final String LAST_NAME_PARAM = "last_name";
    public static final String EMAIL_PARAM = "email";
    public static final String OPCO_UID_PARAM = "opco_uid";
    public static final String OPCO_NAME_PARAM = "opco_name";
    public static final String OPCO_U_UID_PARAM = "opco_u_uid";
    public static final String OPCO_C_UID_PARAM = "opco_c_uid";
    public static final String OPCO_C_NAME_PARAM = "opco_c_uid";
    public static final String FLAGS_PARAM = "flags";

    public static final String IS_OPCO_ADMIN_PARAM = "is_opco_admin";
    public static final String IS_OPCO_C_ADMIN_PARAM = "is_opco_c_admin";

    public static final String ERROR_MESSAGE_PARAM = "errorMessage";
    public static final String MOBILE_PHONE_PARAM = "mobile_phone";
}
