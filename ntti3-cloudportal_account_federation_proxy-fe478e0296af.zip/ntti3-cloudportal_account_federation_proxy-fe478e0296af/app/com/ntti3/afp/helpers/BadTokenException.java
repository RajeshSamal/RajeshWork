package com.ntti3.afp.helpers;

import com.pingidentity.opentoken.TokenException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class BadTokenException extends TokenException {
    public BadTokenException() {
        super("The token does not contain required fields");
    }
}
