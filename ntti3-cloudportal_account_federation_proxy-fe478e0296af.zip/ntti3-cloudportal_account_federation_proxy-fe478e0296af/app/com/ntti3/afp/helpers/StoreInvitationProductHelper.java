package com.ntti3.afp.helpers;

import com.google.common.base.Optional;
import play.mvc.Http;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class StoreInvitationProductHelper {
    private static final String SESSION_ID = "product";

    public static Optional<String> getProductForString(String id, Http.Session session) {
        final String finalId = SESSION_ID + id;
        String resume = session.get(finalId);
        return Optional.fromNullable(resume);
    }

    public static void storeProductInString(String id, String token, Http.Session session) {
        final String finalId = SESSION_ID + id;
        session.put(finalId, token);
    }

    public static void clearProductForString(String id, Http.Session session) {
        final String finalId = SESSION_ID + id;
        session.remove(finalId + id);
    }
}
