package com.ntti3.afp.helpers;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @author Kamil Kawka (kamil.kawka@codilime.com)
 */

public class OktaLogout {
    private static final String BUNDLE_NAME = "com.ntti3.afp.helpers.okta";

    private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
            .getBundle(BUNDLE_NAME);

    private OktaLogout() {
    }

    public static String getString(String key) {
        try {
            return RESOURCE_BUNDLE.getString(key);
        } catch (MissingResourceException e) {
            return '!' + key + '!';
        }
    }
}
