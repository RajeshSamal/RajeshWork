package com.ntti3.afp.helpers;

import com.google.common.base.Optional;
import play.mvc.Http;

import java.util.concurrent.ThreadLocalRandom;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class StoreInvitationTokenHelper {
    private static final String SESSION_ID = "invtok";

    public static Optional<String> getInvitationForString(String id, Http.Session session) {
        final String finalId = SESSION_ID + id;
        String resume = session.get(finalId);
        return Optional.fromNullable(resume);
    }

    public static void storeTokenInString(String id, String token, Http.Session session) {
        final String finalId = SESSION_ID + id;
        session.put(finalId, token);
    }

    public static void clearTokenForString(String id, Http.Session session) {
        final String finalId = SESSION_ID + id;
        session.remove(finalId + id);
    }
}
