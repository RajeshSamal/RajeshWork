package com.ntti3.afp.helpers;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableBiMap;
import com.ntti3.afp.exceptions.UnknownProductException;

import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SpEntityMapper {

    private final ImmutableBiMap<String, String> mapping;

    public SpEntityMapper(Map<String, String> mapping) {
        this.mapping = ImmutableBiMap.copyOf(Preconditions.checkNotNull(mapping, "Mapping can not be null!"));
    }

    public String getSpEntityFor(String product) throws UnknownProductException {
        if (!mapping.containsKey(product)) {
            throw new UnknownProductException("Can not find SP entity for product '" + product + "'!");
        }
        return mapping.get(product);
    }

    public String getProductFor(String spEntity) throws UnknownProductException {
        if (!mapping.containsValue(spEntity)) {
            throw new UnknownProductException("Can not find product for SP entity '" + spEntity + "'!");
        }
        return mapping.inverse().get(spEntity);
    }
}
