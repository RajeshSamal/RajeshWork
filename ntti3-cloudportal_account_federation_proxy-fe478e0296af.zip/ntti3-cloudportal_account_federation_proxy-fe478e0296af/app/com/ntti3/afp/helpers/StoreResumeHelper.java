package com.ntti3.afp.helpers;

import play.mvc.Http;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by jan.karwowski@ntti3.com on 27.01.14.
 */
public class StoreResumeHelper {
    public static final int resumeLength = 4;

    public static enum UrlType {
        RESUME, ERROR
    }

    public static String generateUniqueKey(UrlType type, Http.Session session) {
        String key;
        char[] arr = new char[resumeLength];
        do {
            for (int i = 0; i < resumeLength; i++) {
                arr[i] = (char) (ThreadLocalRandom.current().nextInt('z' - 'a') + 'a');
            }
            key = new String(arr);
        } while (session.containsKey(type.toString() + key));
        return key;
    }

    public static String getResumeForString(String id, UrlType type, Http.Session session) {
        String resume = session.get(type.toString() + id);
        session.remove(type.toString() + id);
        return resume;
    }

    public static String storeResumeInString(String resume, UrlType type, Http.Session session) {
        String id = generateUniqueKey(type, session);
        session.put(type.toString() + id, resume);
        return id;
    }

    public static void clearResumeForString(String id, Http.Session session) {
        for (UrlType type : UrlType.values()) {
            session.remove(type.toString() + id);
        }
    }
}
