package com.ntti3.afp.helpers;

import com.google.common.collect.Multimap;

import java.util.Arrays;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class TokenValidator {
    public static <T> boolean containsAllKeys(Map<T, ?> map, T... args) {
        return map.keySet().containsAll(Arrays.asList(args));
    }

    public static void validateIdPToken(Multimap<String, String> multimap) throws BadTokenException {
        if (!containsAllKeys(multimap.asMap(),
                AfpProtocolConstants.FIRST_NAME_PARAM, AfpProtocolConstants.LAST_NAME_PARAM,
                AfpProtocolConstants.EMAIL_PARAM, AfpProtocolConstants.OPCO_UID_PARAM,
                AfpProtocolConstants.OPCO_NAME_PARAM)) {
            throw new BadTokenException();
        }
    }
}
