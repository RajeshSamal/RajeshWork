package com.ntti3.afp.aspects;

import com.ntti3.afp.global.Global;
import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

    @Pointcut("execution(* com.ntti3.afp.controllers.*.*(..)) && ! execution(* com.ntti3.afp.controllers.*.*$*(..))")
    @Override
    public void controllerMethodPointcut() {
    }


    @Pointcut("within(com.ntti3.afp.helpers..*)")
    @Override
    public void applicationMethodPointcut() {

    }

    @Override
    public String getPathContains() {
        return Global.getApplicationName();
    }
}
