package com.ntti3.afp.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.afp.controllers.annotations.OpcoSelector;
import com.ntti3.afp.exceptions.IllegalInviterException;
import com.ntti3.afp.exceptions.IllegalProductIdException;
import com.ntti3.afp.exceptions.IncorrectParametersException;
import com.ntti3.afp.exceptions.UserAlreadyExistsException;
import com.ntti3.afp.helpers.StoreInvitationProductHelper;
import com.ntti3.afp.helpers.StoreInvitationTokenHelper;
import com.ntti3.afp.models.NewUser;
import com.ntti3.afp.models.NewUserWithEmail;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.exceptions.GumsProtocolEntityExistsException;
import com.ntti3.gums.exceptions.GumsProtocolIncorrectParameterFormatException;
import com.ntti3.gums.exceptions.GumsProtocolProductNotFoundException;
import com.ntti3.gums.exceptions.GumsProtocolUserNotFoundException;
import com.ntti3.gums.models.User;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.tokens.Token;
import com.ntti3.tokens.TokenServiceConnector;
import com.ntti3.tokens.exceptions.TokenServiceException;
import play.Configuration;
import play.Logger;
import play.data.Form;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * @author jan.karwowski@ntti3.com
 */
@ControllerExceptionSupport.ExceptionHandler()
public class Invitation extends Controller {
    private static final String INVITER_GUID = "inviterGuid";
    private static final String REGISTRATION_TOKEN_LABEL = "registration";
    private static final String REGISTER_TITLE = "Thank you for registering!";
    private static final String REGISTER_MSG = "Your registration is completed. You can now log in using your credentials.";
    private static final String ERROR_TITLE = "Error!";
    private static final String REGISTER_ERROR_MSG = "Invitation failed because an internal server error occurred. Please try again later";
    public static final String INVALID_TOKEN = "Invitation token is incorrect or has expired";
    private final GumsConnector gumsConnector;
    private final TokenServiceConnector tokenServiceConnector;
    private final VhostInstanceSelector<String> vhostOpcoSelector;

    @Inject
    public Invitation(GumsConnector gumsConnector, TokenServiceConnector tokenServiceConnector,
                      @OpcoSelector VhostInstanceSelector<String> vhostOpcoSelector) {
        this.vhostOpcoSelector = Preconditions.checkNotNull(vhostOpcoSelector);
        Preconditions.checkNotNull(gumsConnector);
        Preconditions.checkNotNull(tokenServiceConnector);
        this.gumsConnector = gumsConnector;
        this.tokenServiceConnector = tokenServiceConnector;
    }

    public Result process(String tokenId, @Nullable String productId, String resumeId) throws UnknownVhostException, IllegalInviterException, IllegalProductIdException, IncorrectParametersException, UserAlreadyExistsException {
        try {
            Optional<Token> tokenOptional = tokenServiceConnector.checkToken(REGISTRATION_TOKEN_LABEL, tokenId);
            boolean activate = tokenOptional.isPresent();
            Logger.debug("Token {}, status {}", tokenId, activate);

            if (!activate) {
                return badRequest(ResponseJsonGenerator.returnMessage(ERROR_TITLE, INVALID_TOKEN));
            }

            final Token token = tokenOptional.get();
            final Optional<String> product;
            final UUID inviterUUID;
            final User inviter;
            final Optional<String> email;

            if (token.getMetadata().isEmpty()) { /// TODO Remove this "Invitation Revert" hack!
                email = Optional.absent();
                if (productId == null) {
                    Logger.warn("Token's metadata is empty but no productId was supplied");
                    throw new IllegalProductIdException("Product ID was not supplied");
                } else {
                    product = Optional.fromNullable(productId);
                }
                inviterUUID = UUID.fromString(Configuration.root().getString(INVITER_GUID));
            } else {
                email = token.getMetadata("email"); // Not required
                product = token.getMetadata("productId");
                if (!product.isPresent()) {
                    throw new IllegalProductIdException("Invitation token is invalid: product ID was not supplied");
                }
                try {
                    inviterUUID = UUID.fromString(token.getMetadata("inviter").get());
                } catch (IllegalArgumentException e) {
                    throw new IllegalInviterException("Provided inviter GUID is incorrect");
                } catch (NullPointerException e) {
                    throw new IllegalInviterException("Provided inviter GUID can not be null");
                } catch (IllegalStateException e) {
                    throw new IllegalInviterException("Inviter GUID has to be present");
                }
            }
            try {
                inviter = gumsConnector.getUser(inviterUUID);
            } catch (GumsProtocolUserNotFoundException e) {
                throw new IllegalInviterException("Inviter with provided GUID does not exist");
            }

            Logger.debug("product {}, inviter {}", product, inviter.getGuid().toString());

            final String firstName;
            final String lastName;
            final String emailFromForm;
            final String opcoName = inviter.getOpcoName();
            final String opco = vhostOpcoSelector.getInstanceForVhost(Controller.request());
            final String opcoCUid = inviter.getOpcoCUid();
            final String opcoCName = inviter.getOpcoCUid() == null ? null : inviter.getOpcoCName();
            final String password;
            final String securityQuestion;
            final String securityAnswer;
            final List<String> products = Arrays.asList(product.or(""));

            if (!email.isPresent()) {
                Form<NewUserWithEmail> form = Form.form(NewUserWithEmail.class).bindFromRequest();
                if (form.hasErrors()) {
                    return badRequest(ResponseJsonGenerator.invalidFields(form.errorsAsJson()));
                }
                NewUserWithEmail newUser = form.get();
                firstName = newUser.getFirstName();
                lastName = newUser.getLastName();
                emailFromForm = newUser.getEmail(); // email from form
                password = newUser.getPassword();
                securityQuestion = newUser.getSecurityQuestion();
                securityAnswer = newUser.getSecurityAnswer();
            } else {
                Form<NewUser> form = Form.form(NewUser.class).bindFromRequest();
                if (form.hasErrors()) {
                    return badRequest(ResponseJsonGenerator.invalidFields(form.errorsAsJson()));
                }
                NewUser newUser = form.get();
                firstName = newUser.getFirstName();
                lastName = newUser.getLastName();
                emailFromForm = email.get(); // email from token
                password = newUser.getPassword();
                securityQuestion = newUser.getSecurityQuestion();
                securityAnswer = newUser.getSecurityAnswer();
            }

            gumsConnector.createUser(firstName,
                    lastName,
                    emailFromForm,
                    opco,
                    opcoName,
                    emailFromForm,
                    opcoCUid,
                    opcoCName,
                    password,
                    securityQuestion,
                    securityAnswer,
                    products);

            if (!tokenServiceConnector.useToken(REGISTRATION_TOKEN_LABEL, tokenId)) {
                Logger.error("Eating token race condition: attempt to eat token twice");
            }

            return ok(ResponseJsonGenerator.returnMessage(REGISTER_TITLE, REGISTER_MSG));
        } catch (GumsProtocolProductNotFoundException e) {
            throw new IllegalProductIdException("Supplied product ID is not correct");
        } catch (GumsProtocolEntityExistsException e) {
            throw new UserAlreadyExistsException("User with provided e-mail already exists.");
        } catch (GumsProtocolIncorrectParameterFormatException e) {
            throw new IncorrectParametersException("Incorrect parameter format. Details: "+e.getResponse().getDetails());
        } catch (TokenServiceException | IOException | GumsProtocolException ex) {
            Logger.error("Could not finalizeInvitation user because of an exception:", ex);
            return internalServerError(ResponseJsonGenerator.returnMessage(ERROR_TITLE, REGISTER_ERROR_MSG));
        }
    }

    public Result products() throws IOException, GumsProtocolException {
        return ok(Json.toJson(gumsConnector.getProducts()));
    }

    private static class ResponseJsonGenerator {

        public static JsonNode returnMessage(String title, String message) {
            ObjectNode response = Json.newObject();
            response.put("title", title);
            response.put("message", message);
            return response;
        }

        public static JsonNode invalidFields(JsonNode errors) {
            ObjectNode response = Json.newObject();
            response.put("invalidFields", errors);
            return response;
        }
    }
}
