package com.ntti3.afp.controllers;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.afp.helpers.session.SsoSessionHelper;
import com.ntti3.play.annotations.CrossOriginAjax;
import com.ntti3.play.annotations.CrossOriginAjaxController;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.BodyParser.Of;
import play.mvc.Http;
import play.mvc.Result;

import java.net.URI;

@CrossOriginAjax(AjaxApi.class)
public class AjaxApi extends CrossOriginAjaxController {

    private static final String LOGGED_IN_API_FIELD = "logged_in";

    @Of(BodyParser.Json.class)
    public Result loggedIn() {
        ObjectNode result = Json.newObject();
        result.put(LOGGED_IN_API_FIELD, Boolean.toString(SsoSessionHelper.isLoggedIn(session())));
        return ok(result);
    }

    @Override
    public String getAllowOrigin(Http.Request request) {
        if (request.getHeader("ORIGIN") != null) {
            return request.getHeader("ORIGIN");
        }
        try {
            URI uri = URI.create(request.getHeader("REFERER"));
            return uri.getHost();
        } catch (NullPointerException ex) {
            return "*";
        }
    }

    @Override
    public boolean isAllowCredentials() {
        return true;
    }
}
