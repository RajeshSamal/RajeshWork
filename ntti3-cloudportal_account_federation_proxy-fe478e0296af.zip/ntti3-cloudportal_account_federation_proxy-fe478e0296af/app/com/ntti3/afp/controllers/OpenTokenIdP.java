package com.ntti3.afp.controllers;

import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.ntti3.afp.controllers.annotations.ErrorButtonUrlSelector;
import com.ntti3.afp.controllers.annotations.IdPProviderSelector;
import com.ntti3.afp.controllers.annotations.OpcoSelector;
import com.ntti3.afp.exceptions.AccountInactiveException;
import com.ntti3.afp.exceptions.MissingProductException;
import com.ntti3.afp.exceptions.NotAssignedToProductException;
import com.ntti3.afp.exceptions.UnknownProductException;
import com.ntti3.afp.exceptions.WrongInvitationEmailException;
import com.ntti3.afp.helpers.AfpProtocolConstants;
import com.ntti3.afp.helpers.BadTokenException;
import com.ntti3.afp.helpers.Messages;
import com.ntti3.afp.helpers.OktaLogout;
import com.ntti3.afp.helpers.SpEntityMapper;
import com.ntti3.afp.helpers.StoreInvitationProductHelper;
import com.ntti3.afp.helpers.StoreInvitationTokenHelper;
import com.ntti3.afp.helpers.StoreResumeHelper;
import com.ntti3.afp.helpers.TokenValidator;
import com.ntti3.afp.helpers.session.NoSessionException;
import com.ntti3.afp.helpers.session.SsoSessionHelper;
import com.ntti3.afp.models.SsoSession;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolConstants;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.gums.exceptions.GumsProtocolUserNotFoundException;
import com.ntti3.gums.models.User;
import com.ntti3.pingfederate.connector.IdPProtocolHelper;
import com.ntti3.pingfederate.connector.ProtocolHelper;
import com.ntti3.pingfederate.connector.ProtocolParametersException;
import com.ntti3.pingfederate.connector.RequestHandlerException;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.TokenNotFoundException;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.tokens.Token;
import com.ntti3.tokens.TokenServiceConnector;
import com.ntti3.tokens.exceptions.TokenServiceException;
import com.ntti3.urlhelper.UrlHelper;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.TokenException;
import com.pingidentity.opentoken.TokenExpiredException;
import org.apache.http.client.utils.URIBuilder;
import play.Configuration;
import play.Logger;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.SimpleResult;

import javax.annotation.Nullable;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Set;
import java.util.UUID;

/**
 * A controller which handles request requiring communication with Ping Federate's OpenToken.
 * <p/>
 *
 * @author jan.karwowski@ntti3.com
 */
@ControllerExceptionSupport.ExceptionHandler()
public class OpenTokenIdP extends Controller {

    private static final String USER_SESSION_DAYS_VALIDCONFIG_KEY = "user.session.daysValid";
    public static final String SP_ENTITY_ID_KEY = "spEntityId";
    public static final String SP_ENTITY_ID = "sp_entity_id";
    private final int daysValidSession;
    private final GumsConnector gumsConnector;
    private static final String REGISTRATION_TOKEN_LABEL = "registration";
    private final boolean autoRegisterUsers;

    private final VhostInstanceSelector<IdPProtocolHelper> vhostIdPProtocolHelperSelector;
    private final VhostInstanceSelector<SPProtocolHelper> vhostSPProtocolHelperSelector;
    private final VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector;
    private final VhostInstanceSelector<String> vhostIdPProviderSelector;
    private final VhostInstanceSelector<SpEntityMapper> vhostSpEntityMapperSelector;
    private final VhostInstanceSelector<String> vhostOpcoSelector;
    private final TokenServiceConnector tokenServiceConnector;
    private final VhostInstanceSelector<String> errorContinueButtonUrlSelector;

    @Inject
    public OpenTokenIdP(VhostInstanceSelector<IdPProtocolHelper> vhostIdPProtocolHelperSelector,
                        VhostInstanceSelector<SPProtocolHelper> vhostSPProtocolHelperSelector,
                        VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector,
                        @IdPProviderSelector VhostInstanceSelector<String> vhostIdPProviderSelector,
                        @OpcoSelector VhostInstanceSelector<String> vhostOpcoSelector,
                        GumsConnector gumsConnector, VhostInstanceSelector<SpEntityMapper> vhostSpEntityMapperSelector,
                        TokenServiceConnector tokenServiceConnector,
                        @ErrorButtonUrlSelector VhostInstanceSelector<String> errorContinueButtonUrlSelector) {
        this.errorContinueButtonUrlSelector = Preconditions.checkNotNull(errorContinueButtonUrlSelector);
        this.vhostSpEntityMapperSelector = Preconditions.checkNotNull(vhostSpEntityMapperSelector);
        this.vhostIdPProtocolHelperSelector = Preconditions.checkNotNull(vhostIdPProtocolHelperSelector);
        this.vhostSPProtocolHelperSelector = Preconditions.checkNotNull(vhostSPProtocolHelperSelector);
        this.vhostUrlHelperSelector = Preconditions.checkNotNull(vhostUrlHelperSelector);
        this.vhostIdPProviderSelector = Preconditions.checkNotNull(vhostIdPProviderSelector);
        this.vhostOpcoSelector = Preconditions.checkNotNull(vhostOpcoSelector);
        this.gumsConnector = Preconditions.checkNotNull(gumsConnector);
        this.daysValidSession = Configuration.root().getInt(USER_SESSION_DAYS_VALIDCONFIG_KEY, 7);
        this.tokenServiceConnector = Preconditions.checkNotNull(tokenServiceConnector);
        this.autoRegisterUsers = Preconditions.checkNotNull(Configuration.root().getBoolean("auto-register-users", false));
    }

    @NoCache
    public Result initiatedSsoHandler(String sp, String idp, String resumeUrl, String errorUrl)
            throws IOException, TokenException, GumsProtocolException, UnknownVhostException, NotAssignedToProductException, UnknownProductException {
        try {
            SsoSession session = SsoSessionHelper.getSessionFromBrowser(session());
            UUID guid = gumsConnector.getUserGuid(session.getOpcoUid(), session.getOpcoUUid());
            if (idp == null)
                try {
                    return temporaryRedirect(
                            getIdpHelper().buildStartSsoUrl(sp, resumeUrl,
                                    getUrlHelper().absoluteAddress(routes.OpenTokenIdP.failure(Messages.getString("OpenTokenIdP.sp"))), //$NON-NLS-1$
                                    gumsGenerateToken(guid, sp)).toString());
                } catch (AccountInactiveException e) {
                    return temporaryRedirect(logoutUser(routes.OpenTokenIdP.showAccountInactive(e.getMessage(), resumeUrl).absoluteURL(request())));
                }
            else if (errorUrl != null) {
                URIBuilder builder = new URIBuilder(errorUrl).addParameter(AfpProtocolConstants.ERROR_MESSAGE_PARAM,
                        Messages.getString("OpenTokenIdP.already_logged_message")); //$NON-NLS-1$
                return temporaryRedirect(builder.build().toString());
            } else {
                return ok(views.html.main.render(Messages.getString("OpenTokenIdP.error"), views.html.idperror.render(Messages.getString("OpenTokenIdP.already_logged_title"), //$NON-NLS-1$ //$NON-NLS-2$
                        Messages.getString("OpenTokenIdP.already_logged_message2"), //$NON-NLS-1$
                        Messages.getString("OpenTokenIdP.please_logout_msg") //$NON-NLS-1$
                        , null)));
            }
        } catch (NoSessionException | GumsProtocolExceptionWithErrorResponse ex) {
            if (ex instanceof GumsProtocolExceptionWithErrorResponse) {
                if(!(ex instanceof GumsProtocolUserNotFoundException)) {
                    throw (GumsProtocolExceptionWithErrorResponse)ex;
                }
            }

            String resumeId = StoreResumeHelper.storeResumeInString(resumeUrl, StoreResumeHelper.UrlType.RESUME,
                    session());
            String inError;
            final UrlHelper urlHelper = getUrlHelper();
            if (errorUrl == null)
                inError = urlHelper.absoluteAddress(routes.OpenTokenIdP.failure(Messages.getString("OpenTokenIdP.idp"))); //$NON-NLS-1$
            else
                inError = urlHelper.absoluteAddress(routes.OpenTokenIdP.initiatedSsoFailure(
                        StoreResumeHelper.storeResumeInString(errorUrl, StoreResumeHelper.UrlType.ERROR, session()), sp));
            return idpInitiatesSsoRedirect(sp, idp, resumeId, inError);
        } catch (URISyntaxException e) {
            Logger.error(Messages.getString("OpenTokenIdP.unexpected_problem"), e); //$NON-NLS-1$
            throw new RuntimeException(e); // Burn Rome!!
        }// -- Nero
    }

    private SimpleResult idpInitiatesSsoRedirect(String sp, String idp, String resumeId, String inError) throws MalformedURLException, UnknownVhostException {
        return temporaryRedirect(
                getSpHelper().buildSsoUrl(idp,
                        getUrlHelper().absoluteAddress(routes.OpenTokenIdP.initiatedSsoSuccess(resumeId, sp)),
                        inError
                ).toString());
    }

    @NoCache
    public Result initiatedSsoSuccess(String resumeId, String spEntityId)
            throws TokenException, IOException, TokenNotFoundException, GumsProtocolException, UnknownVhostException,
            UnknownProductException, NotAssignedToProductException, TokenServiceException {
        UUID guid = startUserSession(getSpHelper().parseTokenInRequestMulti(request()), response(), session());
        try {
            gumsProcessInvitation(guid, resumeId);
            Multimap<String, String> token = gumsGenerateToken(guid, spEntityId);
            return seeOther(
                    getIdpHelper()
                            .buildStartSsoUrl(spEntityId, StoreResumeHelper.getResumeForString(
                                    resumeId, StoreResumeHelper.UrlType.RESUME, session()),
                                    getUrlHelper().absoluteAddress(routes.OpenTokenIdP
                                            .failure(Messages.getString("OpenTokenIdP.idp"))), //$NON-NLS-1$
                                    token).toString());
        } catch (AccountInactiveException e) {
            String resumeUrl = routes.OpenTokenIdP.showAccountInactive(e.getMessage(), StoreResumeHelper
                    .getResumeForString(resumeId, StoreResumeHelper.UrlType.ERROR, session())).absoluteURL(request());
            return temporaryRedirect(logoutUser(resumeUrl));
        } catch (URISyntaxException e) {
            Logger.error(Messages.getString("OpenTokenIdP.unexpected_condition"), e); //$NON-NLS-1$
            throw new RuntimeException(e);
        } catch (WrongInvitationEmailException e) {
            return ok(views.html.main.render("Error",views.html.emailMessage.render(
                    "Wrong email",
                    "You are logged in as "+e.getSuppliedEmail() +" but the invitation was meant to be for " + e.getRequiredEmail(),
                    "Please logout and proceed with the invitation...",
                    logoutUser(routes.OpenTokenIdP.invitationForm(e.getTokenId(), null, null).absoluteURL(request())))
            ));
        } finally {
            StoreResumeHelper.clearResumeForString(resumeId, session());
            StoreInvitationProductHelper.clearProductForString(resumeId, session());
            StoreInvitationTokenHelper.clearTokenForString(resumeId, session());
        }
    }

    @NoCache
    public Result showAccountInactive(String message, String url) throws UnknownVhostException {
        return showIdpError(Messages.getString("OpenTokenIdP.account_inactive"),
                Messages.getString("OpenTokenIdP.account_disabled_message"),
                message, url);
    }

    @NoCache
    public Result initiatedSsoFailure(String resumeId, String sp) throws UnknownVhostException {
        try {
            URIBuilder builder = new URIBuilder(StoreResumeHelper.getResumeForString(resumeId,
                    StoreResumeHelper.UrlType.ERROR, session())).addParameter(AfpProtocolConstants.ERROR_MESSAGE_PARAM,
                    Messages.getString("OpenTokenIdP.sso_failure"));
            return showIdpError(Messages.getString("OpenTokenIdP.auth_failure"),
                    Messages.getString("OpenTokenIdP.auth_failure"),
                    "", builder.build().toString());
        } catch (URISyntaxException e) {
            Logger.error(Messages.getString("OpenTokenIdP.unexpected_condition") + e); //$NON-NLS-1$
            throw new RuntimeException(e);
        } finally {
            StoreResumeHelper.clearResumeForString(resumeId, session());
        }
    }

    public Result handleRequest(String type) throws ProtocolParametersException,
            GumsProtocolException, UnknownVhostException, IOException, TokenException, URISyntaxException, NotAssignedToProductException, UnknownProductException {
        try {
            return getIdpHelper().handleRequest(type, request(), new IdPProtocolHelper.RequestHandler() {
                @Override
                public Result ssoRequest(ProtocolHelper.ResumePath resumePath, String spEntityId) throws RequestHandlerException {
                    try {
                        final SsoSession session = SsoSessionHelper.getSessionFromBrowserNull(session());
                        final UUID guid;
                        if (session != null) {
                            guid = getUserGuid(session);
                        } else {
                            guid = null;
                        }

                        if (guid != null) {
                            Multimap<String, String> token;
                            try {
                                token = gumsGenerateToken(guid, spEntityId);
                            } catch (AccountInactiveException e) {
                                String resumeUrl = routes.OpenTokenIdP.showAccountInactive(e.getMessage(), null).absoluteURL(request());
                                return temporaryRedirect(logoutUser(resumeUrl));
                            }
                            String url = getIdpHelper().buildSsoResponse(resumePath.getPath(), token).toString();
                            response().setHeader(Http.HeaderNames.CACHE_CONTROL, "NO-CACHE");
                            return seeOther(url);
                        } else {
                            flash().put(SP_ENTITY_ID_KEY, spEntityId);
                            String resumeId = StoreResumeHelper.storeResumeInString(resumePath.getPath(),
                                    StoreResumeHelper.UrlType.RESUME, session());
                            return idpLoginSPInitiatedFlow(resumeId, getIdPProvider());
                        }
                    } catch ( GumsProtocolException | TokenException | IOException | UnknownVhostException
                            | URISyntaxException | NotAssignedToProductException | UnknownProductException e) {
                        throw new RequestHandlerException(e);
                    }
                }

                @Override
                public Result sloRequest(ProtocolHelper.ResumePath resumePath) throws RequestHandlerException {
                    response().setHeader(Http.HeaderNames.CACHE_CONTROL, "NO-CACHE");
                    try {
                        return seeOther(logoutUser(resumePath.getUrl()));
                    } catch (MalformedURLException e) {
                        throw new RequestHandlerException(e);
                    }
                }
            });
        } catch (RequestHandlerException ex) {
            unwrapRequestHandlerException(ex);
            throw new RuntimeException("Avoiding unreachable code error");
        }
    }

    private static void unwrapRequestHandlerException(RequestHandlerException ex) throws URISyntaxException, UnknownVhostException, IOException, TokenException, GumsProtocolException, NotAssignedToProductException, UnknownProductException {
        try {
            throw ex.getCause();
        } catch (GumsProtocolException | TokenException | IOException | UnknownVhostException
                | URISyntaxException | NotAssignedToProductException | UnknownProductException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private UUID getUserGuid(SsoSession session) throws IOException, GumsProtocolException {
        try {
            return gumsConnector.getUserGuid(session.getOpcoUid(), session.getOpcoUUid());
        } catch (GumsProtocolUserNotFoundException e) {
            return null;
        }
    }

    public Result failure(String side) {
        return ok(String.format(Messages.getString("OpenTokenIdP.known_failure"), side));
    }

    private SimpleResult idpInitiatedSsoRedirect(String sp, String idp, String resumeId, String inError)
            throws MalformedURLException, UnknownVhostException {
        return temporaryRedirect(
                getSpHelper().buildSsoUrl(idp,
                        getUrlHelper().absoluteAddress(routes.OpenTokenIdP.initiatedSsoSuccess(resumeId, sp)),
                        inError
                ).toString());
    }

    public Result handleSpRequest(String type, final String resumeId) throws ProtocolParametersException,
            TokenNotFoundException, TokenException, GumsProtocolException, UnknownVhostException,
            RequestHandlerException, URISyntaxException, IOException, UnknownProductException,
            NotAssignedToProductException {
        Logger.debug(Messages.getString("OpenTokenIdP.request_received_debug_message") + type); //$NON-NLS-1$
        try {
            return getSpHelper().handleRequest(type, request(), new SPProtocolHelper.RequestHandler() {
                @Override
                public Result sloRequest(ProtocolHelper.ResumePath resumePath) throws RequestHandlerException {
                    try {
                        return temporaryRedirect(logoutUser(resumePath.getUrl()));
                    } catch (MalformedURLException e) {
                        throw new RequestHandlerException(e);
                    }
                }

                @Override
                public Result ssoSuccess(String resumeUrl, Multimap<String, String> token) {
                    return notFound();
                }

                @Override
                public Result ssoSuccess(Multimap<String, String> token) throws RequestHandlerException {
                    try {
                        UUID guid = startUserSession(token, response(), session());
                        gumsProcessInvitation(guid, resumeId);
                        Multimap<String, String> token1 = gumsGenerateToken(guid,
                                Preconditions.checkNotNull(flash(SP_ENTITY_ID_KEY),  "SpEntityId not set!"));
                        return proceedWithSso(token1, resumeId, session());
                    } catch (IOException | TokenException | UnknownVhostException | UnknownProductException
                            | URISyntaxException | NotAssignedToProductException | TokenServiceException
                            | GumsProtocolException e) {
                        throw new RequestHandlerException(e);
                    } catch (AccountInactiveException e) {
                        String resumeUrl = routes.OpenTokenIdP.showAccountInactive(e.getMessage(), StoreResumeHelper
                                .getResumeForString(resumeId, StoreResumeHelper.UrlType.ERROR, session())).absoluteURL(request());
                        return temporaryRedirect(logoutUser(resumeUrl));
                    } catch (WrongInvitationEmailException e) {
                        return ok(views.html.main.render("Error",views.html.emailMessage.render(
                                "Wrong email",
                                "You are logged in as "+e.getSuppliedEmail() +" but the invitation was meant to be for " + e.getRequiredEmail(),
                                "Please logout and proceed with the invitation...",
                                logoutUser(routes.OpenTokenIdP.invitationForm(e.getTokenId(), null, null).absoluteURL(request())))
                        ));
                    } finally {
                        StoreResumeHelper.clearResumeForString(resumeId, session());
                        StoreInvitationProductHelper.clearProductForString(resumeId, session());
                        StoreInvitationTokenHelper.clearTokenForString(resumeId, session());
                    }
                }

                @Override
                public Result ssoFailure(String error, String details) throws RequestHandlerException {
                    response().setHeader(Http.HeaderNames.CACHE_CONTROL, "NO-CACHE"); //$NON-NLS-1$
                    try {
                        return showIdpErrorWithHtmlTitle(Messages.getString("OpenTokenIdP.error"),
                                Messages.getString("OpenTokenIdP.auth_error"), error, details,
                                getIdpHelper()
                                        .buildSsoErrorResponse(StoreResumeHelper
                                                .getResumeForString(resumeId, StoreResumeHelper.UrlType.RESUME,
                                                        session()), error, details).toString());
                    } catch (UnknownVhostException | URISyntaxException e) {
                        throw new RequestHandlerException(e);
                    } finally {
                        StoreResumeHelper.clearResumeForString(resumeId, session());
                    }
                }
            });
        } catch (RequestHandlerException ex) {
            unwrapRequestHandlerException(ex);
            throw new RuntimeException("Avoiding unreachable code error");
        }
    }

    private void gumsProcessInvitation(UUID guid, String resumeId) throws IOException, GumsProtocolException, TokenExpiredException, TokenServiceException, WrongInvitationEmailException {
        Optional<String> invitationToken = StoreInvitationTokenHelper.getInvitationForString(resumeId, session());
        if (invitationToken.isPresent()) {
            Optional<Token> tokenOptional = tokenServiceConnector.checkToken(REGISTRATION_TOKEN_LABEL, invitationToken.get());
            if(!tokenOptional.isPresent()) {
                throw new TokenExpiredException("Token has expired");
            }
            Optional<String> email = tokenOptional.get().getMetadata("email");
            if (email.isPresent()) {
                User user = gumsConnector.getUser(guid);
                final String requiredEmail = email.get();
                final String suppliedEmail = user.getOpcoUUid();
                if (!requiredEmail.equals(suppliedEmail)) {
                    throw new WrongInvitationEmailException(suppliedEmail, requiredEmail, invitationToken.get());
                }
            }

            Set<String> userProducts = Sets.newHashSet(gumsConnector.getUserProductWhitelist(guid));
            userProducts.add(StoreInvitationProductHelper.getProductForString(resumeId, session()).get());
            gumsConnector.setUserProductWhitelist(guid, Lists.<String>newArrayList(userProducts));
            tokenServiceConnector.useToken(REGISTRATION_TOKEN_LABEL, invitationToken.get());
        }
    }

    public static <K, V> V getFirstFromMultimap(Multimap<K, V> map, K key) {
        if (map.containsKey(key)) {
            return map.get(key).iterator().next();
        }
        return null;
    }

    private Result idpLoginIdPInitiatedFlow(String resumeId, String idpId, String product) throws UnknownVhostException {
        try {
            return idpInitiatedSsoRedirect(product, idpId, resumeId,
                    getUrlHelper().absoluteAddress(routes.OpenTokenIdP.failure(Messages.getString("OpenTokenIdP.idp"))));
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    private Result idpLoginSPInitiatedFlow(String resumeId, String idpId)
            throws MalformedURLException, UnknownVhostException {
        return temporaryRedirect(
                getSpHelper().buildSsoUrl(idpId, getUrlHelper().absoluteAddress(routes.OpenTokenIdP
                        .handleSpRequest(SPProtocolHelper.RequestType.SSO_SUCCESS_HANDLER.getUrlName(),
                                resumeId)),
                        getUrlHelper().absoluteAddress(routes.OpenTokenIdP
                                .handleSpRequest(SPProtocolHelper.RequestType.SSO_ERROR_HANDLER.getUrlName(),
                                        resumeId))).toString()
        );
    }

    public Result invitationForm(String tokenId,
                                 @Nullable String productFromRequest,
                                 @Nullable String resumeUrlFromRequest) throws IOException,
            GumsProtocolException, UnknownVhostException, TokenServiceException, TokenExpiredException, UnknownProductException, MissingProductException {
        Optional<Token> tokenOptional = tokenServiceConnector.checkToken(REGISTRATION_TOKEN_LABEL, tokenId);
        if(!tokenOptional.isPresent()) {
            throw new TokenExpiredException("Token has expired");
        }

        final Token token = tokenOptional.get();
        Logger.info("Invitation form for token {} = {}", tokenId, token);

        final Optional<String> resumeUrl;
        final Optional<String> product;
        final Optional<String> invitedUserEmail;

        if (token.getMetadata().isEmpty()) { /// L33tH4x for backward compatibility
            resumeUrl = Optional.fromNullable(resumeUrlFromRequest);
            product = Optional.fromNullable(productFromRequest);
            invitedUserEmail = Optional.absent();
        } else {
            resumeUrl = token.getMetadata("resume");
            product = token.getMetadata("productId");
            invitedUserEmail = token.getMetadata("email");
        }
        if (!product.isPresent()) {
            throw new MissingProductException("Invitation token is invalid: product ID was not supplied");
        }

        final String emailFromToken = invitedUserEmail.orNull();

        String resumeIdWithToken = StoreResumeHelper.storeResumeInString(resumeUrl.or(""), StoreResumeHelper.UrlType.RESUME, session());
        StoreInvitationTokenHelper.storeTokenInString(resumeIdWithToken, tokenId, session());
        StoreInvitationProductHelper.storeProductInString(resumeIdWithToken, product.get(), session());

        String resumeIdNoToken = StoreResumeHelper.storeResumeInString(resumeUrl.or(""), StoreResumeHelper.UrlType.RESUME, session());

        if (invitedUserEmail.isPresent()) {
            if (gumsConnector.loginUsed(vhostOpcoSelector.getInstanceForVhost(request()), invitedUserEmail.get())) {
                return ok(views.html.main.render("Please login",views.html.emailMessage.render(
                        "Please login",
                        "There is already an account with "+ invitedUserEmail.get() + " email",
                        "Continue to login",
                        routes.OpenTokenIdP.idpLoginWithVhostOpco(resumeIdWithToken, product.or("")).absoluteURL(request()))
                ));
            } else {
                return getRegistrationForm(tokenId, resumeIdWithToken, resumeIdNoToken, product, emailFromToken);
            }
        } else {
            // show the registration form with a link to login (finalize invitation with existing account)
            return getRegistrationForm(tokenId, resumeIdWithToken, resumeIdNoToken, product, emailFromToken);
        }
    }

    private Result getRegistrationForm(String tokenId, String resumeIdWithToken, String resumeIdNoToken, Optional<String> product, @Nullable String emailFromToken) throws IOException, GumsProtocolException {
        return ok(views.html.main.render(Messages.getString("OpenTokenIdP.idp_selector"),
                views.html.invitationform.render(resumeIdWithToken, resumeIdNoToken, gumsConnector.getUpdateableOpcos(), product.or(""), tokenId,
                        emailFromToken)));
    }

    public Result idpLoginWithVhostOpco(String resumeId, @Nullable String product) throws IOException,
            GumsProtocolException, UnknownVhostException, UnknownProductException  {
        return idpLoginIdPInitiatedFlow(resumeId, getIdPProvider(), getSpEntityMapper().getSpEntityFor(product));
    }

    private Result proceedWithSso(Multimap<String, String> token, String resumeId, Http.Session session)
            throws URISyntaxException, TokenException, UnknownVhostException {
        String url = getIdpHelper().buildSsoResponse(
                StoreResumeHelper.getResumeForString(resumeId, StoreResumeHelper.UrlType.RESUME,
                        session), token).toString();
        StoreResumeHelper.clearResumeForString(resumeId, session());
        response().setHeader(Http.HeaderNames.CACHE_CONTROL, "NO-CACHE"); //$NON-NLS-1$
        return seeOther(url);
    }

    private UUID startUserSession(Multimap<String, String> token, Http.Response response, Http.Session session)
            throws IOException, GumsProtocolException, BadTokenException {
        TokenValidator.validateIdPToken(token);
        Logger.debug(Messages.getString("OpenTokenIdP.debug_received_token"), token); //$NON-NLS-1$
        String subject = getFirstFromMultimap(token, Agent.TOKEN_SUBJECT);
        String opcoUid = getFirstFromMultimap(token, AfpProtocolConstants.OPCO_UID_PARAM);
        Logger.debug(Messages.getString("OpenTokenIdP.debug_starting_session") + subject); //$NON-NLS-1$
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, daysValidSession);

        final UUID guid;
        if (autoRegisterUsers) {
            guid = gumsRegisterUser(token);
        } else {
            guid = gumsConnector.getUserGuid(opcoUid, subject);
        }

        SsoSessionHelper.loginUserBrowserSession(guid,
                subject, opcoUid,
                cal, session);
        Logger.debug(Messages.getString("OpenTokenIdP.debug_started_session"), guid); //$NON-NLS-1$
        return guid;
    }

    private UUID gumsRegisterUser(Multimap<String, String> token) throws IOException, GumsProtocolException {
        return gumsConnector.getOrRegisterUser(getFirstFromMultimap(token, AfpProtocolConstants.FIRST_NAME_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.LAST_NAME_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.EMAIL_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.MOBILE_PHONE_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.OPCO_UID_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.OPCO_NAME_PARAM),
                getFirstFromMultimap(token, Agent.TOKEN_SUBJECT),
                getFirstFromMultimap(token, AfpProtocolConstants.OPCO_C_UID_PARAM),
                getFirstFromMultimap(token, AfpProtocolConstants.OPCO_C_NAME_PARAM),
                Lists.newArrayList(token.get(AfpProtocolConstants.FLAGS_PARAM)));
    }


    private Multimap<String, String> gumsGenerateToken(UUID guid, String spEntityId) throws IOException,
            GumsProtocolException, AccountInactiveException, UnknownVhostException, UnknownProductException, NotAssignedToProductException {
        com.ntti3.gums.models.User user = gumsConnector.getUser(guid);
        Multimap<String, String> token = HashMultimap.create();

        if (!user.isActive()) {
            throw new AccountInactiveException(user.getGuid(), user.getOpcoUUid(), user.getOpcoUid());
        }

        String productFromSpEntity = getSpEntityMapper().getProductFor(spEntityId);

        if (!user.getProducts().contains(productFromSpEntity)) {
            throw new NotAssignedToProductException(user.getGuid(), user.getOpcoUUid(), user.getOpcoUid(), productFromSpEntity);
        }

        token.put(Agent.TOKEN_SUBJECT, user.getGuid().toString());
        token.put(GumsProtocolConstants.ACTIVE_PARAMETER, Boolean.toString(user.isActive()));
        token.put(GumsProtocolConstants.COMPANY_GUID_PARAMETER, user.getCompanyGuid());
        token.put(GumsProtocolConstants.EMAIL_PARAMETER, user.getEmail());
        token.put(GumsProtocolConstants.FIRST_NAME_PARAMETER, user.getFirstName());
        token.put(GumsProtocolConstants.LAST_NAME_PARAMETER, user.getLastName());
        token.putAll(GumsProtocolConstants.FLAGS_PARAMETER, user.getFlags());
        token.put(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, user.getOpcoCName());
        token.put(GumsProtocolConstants.OPCO_C_UID_PARAMETER, user.getOpcoCUid());
        token.put(GumsProtocolConstants.OPCO_NAME_PARAMETER, user.getOpcoName());
        token.put(GumsProtocolConstants.OPCO_U_UID_PARAMETER, user.getOpcoUUid());
        token.put(GumsProtocolConstants.OPCO_UID_PARAMETER, user.getOpcoUid());
        token.putAll(GumsProtocolConstants.PRODUCTS_PARAMETER, user.getProducts());
        token.put(SP_ENTITY_ID, spEntityId);

        return token;
    }

    private static void terminateUserSession(Http.Session session) {
        try {
            SsoSessionHelper.logoutUser(SsoSessionHelper.getSessionFromBrowser(session).getGuid());
            Logger.debug(Messages.getString("OpenTokenIdP.debug_terminated_session")); //$NON-NLS-1$
        } catch (NoSessionException ex) {
            Logger.debug("Tried to terminate nonexistent user session");
        }
    }

    public IdPProtocolHelper getIdpHelper() throws UnknownVhostException {
        return vhostIdPProtocolHelperSelector.getInstanceForVhost(request());
    }

    public SPProtocolHelper getSpHelper() throws UnknownVhostException {
        return vhostSPProtocolHelperSelector.getInstanceForVhost(request());
    }

    public UrlHelper getUrlHelper() throws UnknownVhostException {
        return vhostUrlHelperSelector.getInstanceForVhost(request());
    }

    public IdPProtocolHelper getIdpHelper(Http.Request request) throws UnknownVhostException {
        return vhostIdPProtocolHelperSelector.getInstanceForVhost(request);
    }

    public SPProtocolHelper getSpHelper(Http.Request request) throws UnknownVhostException {
        return vhostSPProtocolHelperSelector.getInstanceForVhost(request);
    }

    public UrlHelper getUrlHelper(Http.Request request) throws UnknownVhostException {
        return vhostUrlHelperSelector.getInstanceForVhost(request);
    }

    public SpEntityMapper getSpEntityMapper() throws UnknownVhostException {
        return vhostSpEntityMapperSelector.getInstanceForVhost(request());
    }

    public String getIdPProvider() throws UnknownVhostException {
        return vhostIdPProviderSelector.getInstanceForVhost(request());
    }

    private static URIBuilder getOktaLogoutURIBuilder() {
        return new URIBuilder()
            .setScheme(OktaLogout.getString("OktaLogout.scheme"))
            .setHost(OktaLogout.getString("OktaLogout.host"))
            .setPath(OktaLogout.getString("OktaLogout.path"));
    }

    private static String logoutUser(String redirectUrl) {
        // close afp session
        terminateUserSession(session());
        try {
            // logout from okta
            return getOktaLogoutURIBuilder()
                    .addParameter(OktaLogout.getString("OktaLogout.redirect"), redirectUrl)
                    .build()
                    .toString();
        } catch (URISyntaxException e) {
            throw  new RuntimeException(e);
        }
    }

    private Result showIdpError(String title,
                                String description, String details, String resume) throws UnknownVhostException {
        return showIdpErrorWithHtmlTitle(title, title, description, details, resume);
    }

    private Result showIdpErrorWithHtmlTitle(String htmlTitle, String title,
                                             String description, String details, String resume) throws UnknownVhostException {
        final String selectedResume;
        if (resume != null && !resume.equals("")) {
            selectedResume = resume;
        } else {
            selectedResume = errorContinueButtonUrlSelector.getInstanceForVhost(request());
        }
        return ok(views.html.main.render(htmlTitle,
                views.html.idperror.render(title, description, details, selectedResume)));
    }
}
