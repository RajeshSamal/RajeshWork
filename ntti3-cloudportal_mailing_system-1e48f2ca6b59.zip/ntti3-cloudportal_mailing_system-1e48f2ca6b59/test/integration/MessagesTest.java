package integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertEquals;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

public class MessagesTest {
    private final static ObjectMapper objectMapper = new ObjectMapper();
    private final static DefaultHttpClient httpClient = new DefaultHttpClient();

    @Test
    public void sendMessageTest() throws IOException, InterruptedException {
        String recipient = randomAlphabetic(8)+"-codilime-test@mailinator.com";
        JsonNode response = TestUtils.sendMessage(recipient);
        for(JsonNode msg : response) {
            assertEquals(recipient, msg.findPath("email").asText());
        }
        Thread.sleep(2000);
        TestUtils.assertMail(recipient, TestUtils.SUBJECT, TestUtils.FROM, TestUtils.MAIL_CONTENT);
    }

    @Test
    public void getMessageTest() throws IOException {
        String recipient = randomAlphabetic(8)+"-codilime-test@mailinator.com";
        JsonNode response = TestUtils.sendMessage(recipient);

        for(JsonNode msg : response) {
            String id = msg.findPath("id").asText();
            HttpUriRequest request = new HttpGet( TestUtils.HOST + "/messages/" + id );

            HttpResponse httpResponse = httpClient.execute( request );
            TestUtils.assertResponseCodeIs(httpResponse, 200);

            JsonNode msgResponse = objectMapper.readTree(httpResponse.getEntity().getContent());
            assertEquals(TestUtils.PRODUCT, msgResponse.findPath("product").asText());
            assertEquals(recipient.toLowerCase(), msgResponse.findPath("recipient").asText().toLowerCase());
            assertEquals(id, msgResponse.findPath("id").asText());
        }
    }

    @Test
    public void searchMessageTest() throws IOException, InterruptedException {


        String recipient = randomAlphanumeric(8) +"-codilime-test@mailinator.com";
        String product = TestUtils.PRODUCT + randomAlphanumeric(8);
        String sender = randomAlphanumeric(8) + TestUtils.FROM;
        List<String> tags = new ArrayList<>();
        for(int i=0; i<3; ++i) {
            tags.add("tag"+randomAlphanumeric(8));
        }

        Map<String, Object> body = Maps.newHashMap();

        TestUtils.sendMessage(recipient, sender, product, tags);
        TestUtils.sendMessage(recipient, sender, product, tags);

        body.put("recipient", recipient);
        body.put("product", product);
        body.put("sender", sender);
        body.put("tags", tags);

        StringEntity input = new StringEntity(objectMapper.writeValueAsString(body));
        input.setContentType("application/json");
        HttpPost postRequest = new HttpPost( TestUtils.HOST + "/messages/search/" );
        postRequest.setEntity(input);

        HttpResponse httpResponse = httpClient.execute(postRequest);
        TestUtils.assertResponseCodeIs(httpResponse, 200);

        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        postRequest.releaseConnection();

        assertTrue(response.isArray());
        assertEquals(2, response.size());
        for(JsonNode n : response) {
            assertEquals(recipient, n.findPath("recipient").asText());
            assertEquals(product, n.findPath("product").asText());
            assertEquals(sender, n.findPath("sender").asText());
        }

    }
}
