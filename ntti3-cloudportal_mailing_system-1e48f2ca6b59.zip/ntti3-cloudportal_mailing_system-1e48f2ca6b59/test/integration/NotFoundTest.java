package integration;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Test;

import java.io.IOException;
import java.net.URLEncoder;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class NotFoundTest {
    //region 404 errors
    @Test
    public void messageDoesNotExistTest() throws IOException {
        final HttpClient httpClient = new DefaultHttpClient();
        String name = randomAlphabetic( 8 );
        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/messages/" + name );

        // When
        HttpResponse httpResponse = httpClient.execute( request );

        // Then
        TestUtils.assertResponseCodeIs(httpResponse, 404);
    }

    @Test
    public void templateDoesNotExistTest() throws IOException {
        final HttpClient httpClient = new DefaultHttpClient();
        String name = randomAlphabetic( 8 );
        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/template/" + name );

        // When
        HttpResponse httpResponse = httpClient.execute( request );

        // Then
        TestUtils.assertResponseCodeIs(httpResponse, 404);
    }

    @Test
    public void tagDoesNotExistTest() throws IOException {
        final HttpClient httpClient = new DefaultHttpClient();
        String name = randomAlphabetic( 8 );
        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/statistics/tag/" + name );

        // When
        HttpResponse httpResponse = httpClient.execute( request );

        // Then
        TestUtils.assertResponseCodeIs(httpResponse, 404);
    }

    @Test
    public void urlDoesNotExistTest() throws IOException {
        final HttpClient httpClient = new DefaultHttpClient();
        String name = URLEncoder.encode("http://www.+" + randomAlphabetic(8) + ".com", "UTF-8");
        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/statistics/url/" + name );

        // When
        HttpResponse httpResponse = httpClient.execute( request );

        // Then
        TestUtils.assertResponseCodeIs(httpResponse, 404);
    }
    //endregion
}
