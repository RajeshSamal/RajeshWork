package integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static junit.framework.TestCase.fail;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
class TestUtils {
    final static String SUBJECT = "test-subject";
    final static String PRODUCT = "testProduct";
    final static String FROM = "bartlomiej.biernacki@codilime.com";
    final static String MAIL_CONTENT = "test";

    private final static ObjectMapper objectMapper = new ObjectMapper();
    final static String HOST = "http://216.69.79.143:9006";

    static String getMessageRequest(String recipient, String sender, String product, List<String> tags) throws JsonProcessingException {
        Map<String, Object> body = Maps.newHashMap();
        Map<String, String> to = Maps.newHashMap();
        to.put("email", recipient);
        to.put("name", "Example");
        to.put("type", "bcc");
        List<Map<String, String>> recipients = new ArrayList<>();
        recipients.add(to);
        body.put("from_email", sender);
        body.put("to", recipients);
        body.put("subject", SUBJECT);
        body.put("html_content", MAIL_CONTENT);
        body.put("text_content", MAIL_CONTENT);
        body.put("product", product);
        body.put("tags", tags);

        Map<String,String> attachment = Maps.newHashMap();
        attachment.put("name", "test");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        List<Map<String,String>> attachments = new ArrayList<>();
        attachments.add(attachment);
        attachment = Maps.newHashMap();
        attachment.put("name", "test2");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        attachments.add(attachment);

        body.put("attachments", attachments);
        body.put("images", attachments);

        return objectMapper.writeValueAsString(body);
    }

    static String getMessageRequest(String recipient) throws JsonProcessingException {
        return getMessageRequest(recipient, FROM, PRODUCT, asList("tag1","tag2", "tag3"));
    }

    static String getMessageTemplateRequest(String recipient, String templateName, String varName, String varContent) throws JsonProcessingException {
        Map<String, Object> body = Maps.newHashMap();
        Map<String, Object> to = Maps.newHashMap();
        to.put("email", recipient);
        to.put("name", "Example");
        to.put("type", "bcc");
        List<Map<String, String>> variables = new ArrayList<>();
        Map<String,String> variable = Maps.newHashMap();
        variable.put("name", varName);
        variable.put("content", varContent);
        variables.add(variable);
        to.put("variables", variables);

        List<Map<String, Object>> recipients = new ArrayList<>();
        recipients.add(to);
        body.put("template_name", templateName);
        body.put("from_email", FROM);
        body.put("to", recipients);
        body.put("SUBJECT", SUBJECT);
        body.put("PRODUCT", PRODUCT);
        body.put("tags", asList("tag1","tag2", "tag3"));

        Map<String,String> attachment = Maps.newHashMap();
        attachment.put("name", "test");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        List<Map<String,String>> attachments = new ArrayList<>();
        attachments.add(attachment);
        attachment = Maps.newHashMap();
        attachment.put("name", "test2");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        attachments.add(attachment);

        body.put("attachments", attachments);
        body.put("images", attachments);

        return objectMapper.writeValueAsString(body);
    }

    static void assertResponseCodeIs
            (final HttpResponse httpResponse, final int expectedCode) throws IOException {
        final int statusCode = httpResponse.getStatusLine().getStatusCode();
        if(statusCode != expectedCode) {
            fail("Expected code: " + expectedCode + ", recivied: " + statusCode + " \n" +
                    IOUtils.toString(httpResponse.getEntity().getContent()));
        }
    }

    static void assertMail(String inbox, String title, String from, String contentContain) throws IOException {
        final HttpClient httpClient = new DefaultHttpClient();
        HttpUriRequest request = new HttpGet( "https://api.mailinator.com/api/inbox?to="+inbox+"&token=71d8c49ac81c4973bbb050a6e7df2788" );
        HttpResponse httpResponse = httpClient.execute( request );
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        JsonNode messages = response.findPath("messages");
        assertTrue(messages.size() > 0);
        JsonNode message = messages.get(0);
        assertEquals(title.toLowerCase(), message.findPath("subject").asText().toLowerCase());
        assertEquals(from.toLowerCase(), message.findPath("fromfull").asText().toLowerCase());
        assertEquals(inbox.toLowerCase(), message.findPath("to").asText().toLowerCase());
        assertTrue("Content does not match: \n" +
                "Required: " + contentContain.toLowerCase() +"\n" +
                "Found:" + message.findPath("snippet").asText().toLowerCase(),
                message.findPath("snippet").asText().toLowerCase().contains(contentContain.toLowerCase()));
    }

    static void assertTemplateResult(JsonNode node, String name, String subject, String product) {
        if(name != null) {
            assertEquals(name, node.findPath("template_name").textValue());
        }
        assertEquals(subject, node.findPath("subject").textValue());
        assertEquals(product, node.findPath("product").textValue());
    }

    private static JsonNode sendMessage(StringEntity input) throws IOException {
        HttpClient httpClient = new DefaultHttpClient();
        HttpPost postRequest = new HttpPost( HOST + "/messages/send/" );
        input.setContentType("application/json");
        postRequest.setEntity(input);

        HttpResponse httpResponse = httpClient.execute(postRequest);
        assertResponseCodeIs(httpResponse, 200);


        JsonNode response =objectMapper.readTree(httpResponse.getEntity().getContent());
        postRequest.releaseConnection();
        return response;
    }

    static JsonNode sendMessage(String recipient) throws IOException {
        String message = getMessageRequest(recipient);
        StringEntity input = new StringEntity(message);
        return sendMessage(input);
    }

    static JsonNode sendMessage(String recipient, String sender, String product, List<String> tags) throws IOException {
        String message = getMessageRequest(recipient, sender, product, tags);
        StringEntity input = new StringEntity(message);
        return sendMessage(input);
    }
}
