package integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Test;

import java.io.IOException;
import java.net.URLEncoder;

import static junit.framework.TestCase.assertTrue;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class StatisticsTest {
    final HttpClient httpClient = new DefaultHttpClient();
    private final static ObjectMapper objectMapper = new ObjectMapper();

    private final String existingTag = "tag1";
    private final String existingURL = "http://codilime.com";

    @Test
    public void tagTest() throws IOException, InterruptedException {
        HttpGet request = new HttpGet( TestUtils.HOST + "/statistics/tag/" + existingTag );
        HttpResponse httpResponse = httpClient.execute(request);
        TestUtils.assertResponseCodeIs(httpResponse, 200);
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        request.releaseConnection();
        assertTrue(response.findPath("sent").isInt());
        assertTrue(response.findPath("hard_bounces").isInt());
        assertTrue(response.findPath("soft_bounces").isInt());
        assertTrue(response.findPath("rejects").isInt());
        assertTrue(response.findPath("complaints").isInt());
        assertTrue(response.findPath("opens").isInt());
        assertTrue(response.findPath("clicks").isInt());
    }

    @Test
    public void urlTest() throws IOException {
        String name = URLEncoder.encode(existingURL, "UTF-8");
        HttpGet request = new HttpGet( TestUtils.HOST + "/statistics/url/" + name);
        HttpResponse httpResponse = httpClient.execute(request);
        TestUtils.assertResponseCodeIs(httpResponse, 200);
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        request.releaseConnection();
        assertTrue(response.findPath("sent").isInt());
        assertTrue(response.findPath("clicks").isInt());
        assertTrue(response.findPath("unique_clicks").isInt());
    }
}
