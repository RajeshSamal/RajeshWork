package integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class TemplateCallsTest {
    private final static ObjectMapper objectMapper = new ObjectMapper();
    private DefaultHttpClient httpClient= new DefaultHttpClient();

    private String createTemplate(String label) throws IOException {
        Map<String, Object> body = Maps.newHashMap();
        String templateName = "TEST_TEMPLATE_" + randomAlphabetic(8);
        body.put("template_name", templateName);
        body.put("subject", TestUtils.SUBJECT);
        body.put("html_content", "<b>*|VAR|*</b>");
        body.put("text_content", "*|VAR|*");
        body.put("product", TestUtils.PRODUCT);
        body.put("labels", asList(label));
        StringEntity input = new StringEntity(objectMapper.writeValueAsString(body));
        input.setContentType("application/json");

        HttpPut putRequest = new HttpPut(
                TestUtils.HOST + "/template/"+templateName);
        putRequest.setEntity(input);

        HttpResponse httpResponse = httpClient.execute(putRequest);
        TestUtils.assertResponseCodeIs(httpResponse, 201);

        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        TestUtils.assertTemplateResult(response, templateName, TestUtils.SUBJECT, TestUtils.PRODUCT);

        putRequest.releaseConnection();

        return templateName;
    }

    private void deleteTemplate(String templateName) throws IOException {
        HttpDelete deleteRequest = new HttpDelete(TestUtils.HOST + "/template/"+templateName);
        HttpResponse httpResponse = httpClient.execute(deleteRequest);
        TestUtils.assertResponseCodeIs(httpResponse, 200);
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        TestUtils.assertTemplateResult(response, templateName, TestUtils.SUBJECT, TestUtils.PRODUCT);
        deleteRequest.releaseConnection();
    }

    @Test
    public void createSendDeleteTemplateTest() throws IOException, InterruptedException {
        final String templateContent = "ŻÓŁW KLEOFAS ma kota";

        String templateName = createTemplate("testlabel");

        String recipient = randomAlphabetic(8)+"-codilime-test@mailinator.com";
        String message = TestUtils.getMessageTemplateRequest(recipient, templateName, "VAR", templateContent);

        StringEntity input = new StringEntity(message, ContentType.create("application/json", "UTF-8"));

        HttpPost postRequest = new HttpPost(TestUtils.HOST + "/messages/send-template/");

        postRequest.setEntity(input);
        postRequest.setHeader("Content-type", "application/json; charset=utf-8");

        HttpResponse httpResponse = httpClient.execute(postRequest);
        TestUtils.assertResponseCodeIs(httpResponse, 200);

        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        for(JsonNode msg : response) {
            assertEquals(recipient, msg.findPath("email").asText());
        }
        Thread.sleep(2500);
        TestUtils.assertMail(recipient, TestUtils.SUBJECT, TestUtils.FROM, templateContent);
        postRequest.releaseConnection();
    }

    @Test
    public void createGetDeleteTemplateTest() throws IOException {
        Map<String, Object> body = Maps.newHashMap();
        String templateName = createTemplate("testlabel");

        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/template/" + templateName );

        HttpResponse httpResponse = httpClient.execute( request );
        TestUtils.assertResponseCodeIs(httpResponse, 200);
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());
        TestUtils.assertTemplateResult(response, templateName, TestUtils.SUBJECT, TestUtils.PRODUCT);

        deleteTemplate(templateName);
    }

    @Test
    public void createSearchDeleteTemplateTest() throws IOException {
        final String label = "labelSearchTest" + randomAlphanumeric(4);
        String templateName1 = createTemplate(label);
        String templateName2 = createTemplate(label);

        HttpUriRequest request = new HttpGet( TestUtils.HOST + "/template/list/" + label );
        HttpResponse httpResponse = httpClient.execute( request );
        TestUtils.assertResponseCodeIs(httpResponse, 200);
        JsonNode response = objectMapper.readTree(httpResponse.getEntity().getContent());

        assertTrue(response.isArray());
        assertEquals(2, response.size());

        for(JsonNode node : response) {
            TestUtils.assertTemplateResult(node, null, TestUtils.SUBJECT, TestUtils.PRODUCT);
        }

        deleteTemplate(templateName1);
        deleteTemplate(templateName2);
    }
}
