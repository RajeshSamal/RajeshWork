package com.ntti3.mailingsystem.global;

import com.ntti3.mandrill.connector.MandrillConnector;
/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public class MockGlobal extends Global {
    MandrillConnector mocked = null;

    public MockGlobal(MandrillConnector mocked) {
        this.mocked = mocked;
    }


    @Override
    protected MandrillConnector getMandrillConnector() {
        return mocked;
    }
}
