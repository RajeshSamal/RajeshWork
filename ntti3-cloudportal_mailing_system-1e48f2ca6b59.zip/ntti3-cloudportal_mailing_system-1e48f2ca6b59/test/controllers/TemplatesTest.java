package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mailingsystem.global.MockGlobal;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.calls.MandrillTemplatesCalls;
import com.ntti3.mandrill.connector.exceptions.TemplateNotFoundException;
import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.Date;
import java.util.Map;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public class TemplatesTest {
    private FakeApplication app;
    private final static ObjectMapper objectMapper = new ObjectMapper();

    private void assertTemplateResult(JsonNode node) {
        assertEquals("tname", node.findPath("template_name").textValue());
        assertEquals("subject", node.findPath("subject").textValue());
        assertEquals("<b>test</b>", node.findPath("html_content").textValue());
        assertEquals("test", node.findPath("text_content").textValue());
        assertEquals("p1", node.findPath("product").textValue());
    }


    @Before
    public void setUp() throws Exception {
        MandrillConnector mocked = mock(MandrillConnector.class);
        MandrillTemplatesCalls templatesCalls = mock(MandrillTemplatesCalls.class);

        when(mocked.getTemplatesCalls()).thenReturn(templatesCalls);

        TemplateResponse tr = new TemplateResponse(
                "tname", "tname", asList("#p1", "testlabel"), "<b>test</b>", "subject",
                null, null, "test", null, null, null, null, null, new Date(), new Date(), new Date()
        );


        when(templatesCalls.info("tname")).thenReturn(tr);
        when(templatesCalls.delete("tname")).thenReturn(tr);
        when(templatesCalls.list("testlabel")).thenReturn(asList(tr));
        when(templatesCalls.list(null)).thenReturn(asList(tr));
        when(templatesCalls.update(any(Template.class))).thenThrow(new TemplateNotFoundException(11, "error", Properties.TEMPLATE_NOT_FOUND, ""));
        when(templatesCalls.add(any(Template.class))).thenReturn(tr);

        app = fakeApplication(inMemoryDatabase(), new MockGlobal(mocked));
        start(app);
    }

    @Test
    public void addTemplateTest() {
        Map<String, Object> body = Maps.newHashMap();

        body.put("template_name", "asdfg");
        body.put("subject", "subject");
        body.put("html_content", "<b>test</b>");
        body.put("text_content","test");
        body.put("product","p1");
        body.put("labels", asList("testlabel"));

        FakeRequest request = fakeRequest();
        request.withJsonBody(objectMapper.valueToTree(body));
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Templates.put("asdfg"), request);
        JsonNode node = Json.parse(contentAsString(result));
        assertTemplateResult(node);
    }

    @Test
    public void removeTemplateTest() {
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Templates.delete("tname"));
        JsonNode node = Json.parse(contentAsString(result));
        assertTemplateResult(node);
    }

    @Test
    public void getTemplateTest() {
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Templates.get("tname"));
        JsonNode node = Json.parse(contentAsString(result));
        assertTemplateResult(node);
    }

    @Test
    public void listAllTemplatesTest() {
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Templates.list(null));
        JsonNode node = Json.parse(contentAsString(result));
        for(JsonNode n : node) {
            assertTemplateResult(n);
        }
    }

    @Test
    public void listLabelTemplatesTest() {
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Templates.list("testlabel"));
        JsonNode node = Json.parse(contentAsString(result));
        for(JsonNode n : node) {
            assertTemplateResult(n);
        }
    }

    @After
    public void tearDown() throws Exception {
        stop(app);
    }

}
