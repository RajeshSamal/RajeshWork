package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.ntti3.mailingsystem.global.MockGlobal;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.calls.MandrillTagsCalls;
import com.ntti3.mandrill.connector.calls.MandrillUrlsCalls;
import com.ntti3.mandrill.connector.exceptions.TagNotFoundException;
import com.ntti3.mandrill.connector.responses.TagInfoResponse;
import com.ntti3.mandrill.connector.responses.UrlResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public class StatisticsTest {
    FakeApplication app;
    static final String existingTag = "existingTag";
    static final String notExistingTag = "notExistingTag";
    static final String existingURL = "http://example.com";

    @Before
    public void setUp() throws Exception {
        MandrillConnector mocked = mock(MandrillConnector.class);
        MandrillTagsCalls tags = mock(MandrillTagsCalls.class);
        MandrillUrlsCalls urls = mock(MandrillUrlsCalls.class);

        when(mocked.getTagsCalls()).thenReturn(tags);
        when(mocked.getUrlsCalls()).thenReturn(urls);

        when(tags.info(existingTag)).thenReturn(new TagInfoResponse(existingTag, 1, 2, 3, 4, 5, 0, 6, 7, null));
        when(tags.info(notExistingTag)).thenThrow(new TagNotFoundException(1,"error","Invalid_Tag_Name","no such tag \""+ notExistingTag+"\""));

        when(urls.search(existingURL)).thenReturn(
                asList(
                        new UrlResponse(existingURL, 3, 2, 1),
                        new UrlResponse(existingURL+"/suburl", 6, 5, 4)
                )
        );


        app = fakeApplication(inMemoryDatabase(), new MockGlobal(mocked));
        start(app);
    }

    @Test
    public void tagTest() {
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Statistics.tag(existingTag));
        JsonNode node = Json.parse(contentAsString(result));
        assertEquals(1, node.findPath("sent").asInt());
        assertEquals(2, node.findPath("hard_bounces").asInt());
        assertEquals(3, node.findPath("soft_bounces").asInt());
        assertEquals(4, node.findPath("rejects").asInt());
        assertEquals(5, node.findPath("complaints").asInt());
        assertEquals(6, node.findPath("opens").asInt());
        assertEquals(7, node.findPath("clicks").asInt());
    }


    @Test
    public void urlTest() throws Exception {
        String url = java.net.URLEncoder.encode(existingURL, "UTF-8");
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Statistics.url(url));
        JsonNode node = Json.parse(contentAsString(result));
        assertEquals(3, node.findPath("sent").asInt());
        assertEquals(2, node.findPath("clicks").asInt());
        assertEquals(1, node.findPath("unique_clicks").asInt());
    }


    @After
    public void tearDown() throws Exception {
        stop(app);
    }

}
