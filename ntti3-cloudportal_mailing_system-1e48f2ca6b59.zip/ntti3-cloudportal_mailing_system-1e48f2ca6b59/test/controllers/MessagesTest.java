package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.google.common.collect.Maps;
import com.ntti3.mailingsystem.global.MockGlobal;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.calls.MandrillMessagesCalls;
import com.ntti3.mandrill.connector.calls.MandrillTemplatesCalls;
import com.ntti3.mandrill.connector.models.Message;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.models.Recipient;
import com.ntti3.mandrill.connector.responses.MessageInfoResponse;
import com.ntti3.mandrill.connector.responses.SendResponse;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import play.libs.Json;
import play.mvc.Result;
import play.test.FakeApplication;
import play.test.FakeRequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static play.test.Helpers.callAction;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.fakeRequest;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.start;
import static play.test.Helpers.stop;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public class MessagesTest {

    private FakeApplication app;
    private final static ObjectMapper objectMapper = new ObjectMapper();
    private final static String recipient = "recipient@example.com";
    private final static String subject = "subject";
    private final static String product = "testproduct";

    private Message getMessage() {
        Message msg = new Message();
        msg.addTo(new Recipient(recipient, "Example", Recipient.Type.bcc));
        return msg;
    }

    private void assertSendResult(Result result) {
        JsonNode node = Json.parse(contentAsString(result));
        for(JsonNode resp : node) {
            assertEquals(null, resp.findValue("reject_reason"));
        }
    }


    private Result sendMessage() throws  Exception {
        FakeRequest request = fakeRequest();
        Map<String, Object> body = Maps.newHashMap();
        Map<String, String> to = Maps.newHashMap();
        to.put("email", recipient);
        to.put("name", "Example");
        to.put("type", "bcc");
        List<Map<String, String>> recipients = new ArrayList<>();
        recipients.add(to);
        body.put("to", recipients);
        body.put("subject", subject);
        body.put("html_content","<b>asd</b>");
        body.put("text_content","asd");
        body.put("product", product);
        body.put("tags", asList("tag1","tag2", "tag3"));

        Map<String,String> attachment = Maps.newHashMap();
        attachment.put("name", "test");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        List<Map<String,String>> attachments = new ArrayList<>();
        attachments.add(attachment);
        attachment = Maps.newHashMap();
        attachment.put("name", "test2");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        attachments.add(attachment);

        body.put("attachments", attachments);
        body.put("images", attachments);

        request.withJsonBody(objectMapper.valueToTree(body));
        return callAction(com.ntti3.mailingsystem.controllers.routes.ref.Messages.send(), request);
    }


    @Before
    public void setUp() throws Exception {
        MandrillConnector mocked = mock(MandrillConnector.class);
        MandrillMessagesCalls messages = mock(MandrillMessagesCalls.class);

        MandrillTemplatesCalls templatesCalls = mock(MandrillTemplatesCalls.class);

        when(mocked.getTemplatesCalls()).thenReturn(templatesCalls);
        when(mocked.getMessagesCalls()).thenReturn(messages);

        TemplateResponse tr = new TemplateResponse(
                "tname", "tname", asList("#p1", "testlabel"), "<b>test</b>", "subject",
                null, null, "test", null, null, null, null, null, new Date(), new Date(), new Date()
        );

        when(templatesCalls.info(anyString())).thenReturn(tr);

        Integer id = 0;
        Answer sendAnswer = new Answer<List<SendResponse>>() {
            @Override
            public List<SendResponse> answer(InvocationOnMock invocation) throws Throwable {
                Message msg = null;
                for(Object o : invocation.getArguments()) {
                    if(o instanceof Message) {
                        msg = (Message) o;
                    }
                }
                List<SendResponse> responseList = new ArrayList<SendResponse>();
                for(Recipient r : msg.getTo()) {
                    SendResponse resp = new SendResponse(r.getEmail(), "sent", null, Double.toHexString(Math.random()));
                    responseList.add(resp);
                }
                return responseList;
            }
        };

        when(messages.send(any(Message.class), eq(true))).thenAnswer(sendAnswer);

        when(messages.send_template(eq("asdfg"), anyListOf(NameContentElement.class), any(Message.class), eq(true)))
                .thenAnswer(sendAnswer);

        when(messages.info(anyString())).thenReturn(new MessageInfoResponse(
                123, Double.toHexString(Math.random()), "sender@example.com", null, subject, "recipient@example.com",
                null, 321, null, 456, null, "sent", null, null
        ));

        app = fakeApplication(inMemoryDatabase(), new MockGlobal(mocked));
        start(app);
    }

    @Test
    public void sendTest() throws Exception {
        Result result = sendMessage();
        assertSendResult(result);
    }

    @Test
    public void sendTestTemplate() throws Exception {
        FakeRequest request = fakeRequest();
        Map<String, Object> body = Maps.newHashMap();
        Map<String, Object> to = Maps.newHashMap();

        List<Map<String, String>> variables = new ArrayList<>();
        Map<String,String> variable = Maps.newHashMap();
        variable.put("name", "asd");
        variable.put("content", "ala ma kota");
        variables.add(variable);

        to.put("email", recipient);
        to.put("name", "Example");
        to.put("type", "bcc");
        to.put("variables", variables);

        List<Map<String, Object>> recipients = new ArrayList<>();
        recipients.add(to);
        body.put("to", recipients);
        body.put("product", product);
        body.put("tags", asList("tag1","tag2", "tag3"));

        Map<String,String> attachment = Maps.newHashMap();
        attachment.put("name", "test");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        List<Map<String,String>> attachments = new ArrayList<>();
        attachments.add(attachment);
        attachment = Maps.newHashMap();
        attachment.put("name", "test2");
        attachment.put("mime_type", "image/gif");
        attachment.put("content", "R0lGODlhDwAPAKECAAAAzMzM/////\n" +
                "wAAACwAAAAADwAPAAACIISPeQHsrZ5ModrLlN48CXF8m2iQ3YmmKqVlRtW4ML\n" +
                "wWACH+H09wdGltaXplZCBieSBVbGVhZCBTbWFydFNhdmVyIQAAOw==");
        attachments.add(attachment);

        body.put("attachments", attachments);
        body.put("images", attachments);

        body.put("template_name", "asdfg");
        body.put("variables", variables);
        body.put("product","dsa");
        body.put("tags", asList("tag1","tag2", "tag3"));
        request.withJsonBody(objectMapper.valueToTree(body));
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Messages.sendTemplate(), request);
        assertSendResult(result);
    }

    @Test
    public void getMessageTest() throws Exception {
        Result result = sendMessage();
        JsonNode node = Json.parse(contentAsString(result));
        String id = node.findPath("id").asText();
        result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Messages.get(id));
        node = Json.parse(contentAsString(result));
        assertEquals(id, node.findPath("id").asText());
        assertEquals(recipient, node.findPath("recipient").asText());
        assertEquals(subject, node.findPath("subject").asText());
        assertEquals(321, node.findPath("opens").asInt());
        assertEquals(456, node.findPath("clicks").asInt());
    }

    @Test
    public void searchMessageTest() throws Exception {
        final int msgNo = 2;
        //send message before date filter
        sendMessage();
        Thread.sleep(100);

        Map<String, Object> body = Maps.newHashMap();
        body.put("date_from", (new Date()).getTime());

        for(int i=0; i<msgNo; ++i) {
            sendMessage();
        }

        body.put("recipient", recipient);
        body.put("date_to", (new Date()).getTime());

        Thread.sleep(100);
        //send message after date filter
        sendMessage();

        body.put("tags", asList("tag1","tag2"));
        FakeRequest request = fakeRequest();

        request.withJsonBody(objectMapper.valueToTree(body));
        Result result = callAction(com.ntti3.mailingsystem.controllers.routes.ref.Messages.search(), request);
        ArrayNode node = (ArrayNode) Json.parse(contentAsString(result));
        assertEquals(msgNo, node.size());
        for(JsonNode n : node) {
            assertEquals(recipient, n.findPath("recipient").asText());
            assertEquals(product, n.findPath("product").asText());
        }
    }

    @After
    public void tearDown() throws Exception {
        stop(app);
    }
}
