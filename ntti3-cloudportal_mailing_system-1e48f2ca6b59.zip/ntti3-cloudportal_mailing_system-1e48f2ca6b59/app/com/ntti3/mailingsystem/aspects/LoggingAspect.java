package com.ntti3.mailingsystem.aspects;


import com.ntti3.aspects.logging.PlayLoggingAspect;
import com.ntti3.mailingsystem.global.Global;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

    @Override
    @Pointcut("execution(public * com.ntti3.mailingsystem.models..* (..)) && !execution(public * com.ntti3.mailingsystem.models.*._ebean* (..))")
    public void applicationMethodPointcut() {

    }

    @Override
    @Pointcut("execution(play.mvc.Result com.ntti3.mailingsystem.controllers.*.*(..)) && ! execution(* com.ntti3.mailingsystem.controllers.Reverse*.*(..))")
    public void controllerMethodPointcut() {
    }

    @Override
    public String getPathContains() {
        return Global.MAILINGSYSTEM;
    }
}