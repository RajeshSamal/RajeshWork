package com.ntti3.mailingsystem.controllers.constants;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public final class Properties {
    //Mandrill api errors
    public static final String MESSAGE_NOT_FOUND = "Unknown_Message";
    public static final String TEMPLATE_NOT_FOUND = "Unknown_Template";
    public static final String VALIDATION_ERROR = "ValidationError";
    public static final String GENERAL_ERROR = "GeneralError";
    public static final String INVALID_KEY = "Invalid_Key";
    public static final String TAG_NOT_FOUND = "Invalid_Tag_Name";

    public static final String FROM_EMAIL = "from_email";
    public static final String FROM_NAME = "from_name";
    public static final String SUBJECT = "subject";
    public static final String HTML_CONTENT = "html_content";
    public static final String TEXT_CONTENT = "text_content";
    public static final String PRODUCT = "product";
    public static final String TAGS = "tags";
    public static final String TO = "to";
    public static final String EMAIL = "email";
    public static final String REJECT_REASON = "reject_reason";
    public static final String TEMPLATE_NAME = "template_name";

    public static final String OPENS = "opens";
    public static final String CLICKS = "clicks";
    public static final String TIMESTAMP = "timestamp";
    public static final String RECIPIENT = "recipient";
    public static final String SENDER = "sender";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String RECIPIENT_TYPE = "recipient_type";
    public static final String MIME_TYPE = "mime_type";
    public static final String CONTENT = "content";
    public static final String ATTACHMENTS = "attachments";
    public static final String IMAGES = "images";
    public static final String CC = "cc";
    public static final String BCC = "bcc";
    public static final String DATE = "date";
    public static final String DATE_FROM = "date_from";
    public static final String DATE_TO = "date_to";
    public static final String SENT = "sent";
    public static final String HARD_BOUNCES = "hard_bounces";
    public static final String SOFT_BOUNCES = "soft_bounces";
    public static final String REJECTS = "rejects";
    public static final String COMPLAINTS = "complaints";
    public static final String UNIQUE_CLICKS = "unique_clicks";
    public static final String VARIABLES = "variables";
    public static final String LABELS = "labels";

    public static final int CREATED_STATUS = 201;
    public static final int MANDRILL_ERROR_OFFSET = 1000;
    public static final int VALIDATION_ERROR_STATUS = 555;
}
