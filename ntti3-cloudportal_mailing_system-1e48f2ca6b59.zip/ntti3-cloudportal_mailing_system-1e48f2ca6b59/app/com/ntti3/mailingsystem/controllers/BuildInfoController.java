package com.ntti3.mailingsystem.controllers;

import com.google.inject.Inject;
import com.ntti3.play.build.BuildInfoReader;
import play.mvc.Result;

import static play.mvc.Results.ok;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class BuildInfoController {

    private BuildInfoReader buildInfoReader;

    @Inject
    public BuildInfoController(BuildInfoReader buildInfoReader) {
        if(buildInfoReader == null) {
            throw new IllegalArgumentException("BuildInfoReader cannot be null!");
        }
        this.buildInfoReader = buildInfoReader;
    }

    public Result index() {
        return ok(buildInfoReader.getHumanReadable());
    }
}