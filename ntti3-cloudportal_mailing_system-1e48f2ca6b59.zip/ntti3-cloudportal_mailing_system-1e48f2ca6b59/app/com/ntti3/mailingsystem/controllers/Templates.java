package com.ntti3.mailingsystem.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.Inject;
import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mailingsystem.exceptions.InvalidMailingRequestException;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.exceptions.TemplateNotFoundException;
import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import org.apache.commons.lang3.StringUtils;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
@ControllerExceptionSupport.ExceptionHandler()
public class Templates extends Controller {
    private final MandrillConnector connector;
    private final static String productPrefix = "#";

    private static Map<String,Object> processTemplateResponse(TemplateResponse response) {
        Map<String,Object> singleResult = new HashMap<>();
        singleResult.put(Properties.TEMPLATE_NAME, response.getName());
        singleResult.put(Properties.SUBJECT, response.getSubject());
        singleResult.put(Properties.HTML_CONTENT, response.getCode());
        singleResult.put(Properties.TEXT_CONTENT, response.getText());
        List<String> labels = new ArrayList<>();
        for(String label : response.getLabels()) {
            if(label.startsWith(productPrefix)) {
                singleResult.put(Properties.PRODUCT, label.substring(productPrefix.length()));
            }
            else {
                labels.add(label);
            }
        }
        singleResult.put(Properties.LABELS, labels);
        return singleResult;
    }

    private static List<Map<String,Object>> processTemplateResponses(List<TemplateResponse> responses) {
        List<Map<String,Object>> result = new ArrayList<>();
        for(TemplateResponse response : responses) {
            result.add(processTemplateResponse(response));
        }
        return result;
    }

    @Inject
    public Templates(MandrillConnector connector) {
        this.connector = connector;
    }

    public Result list(String label) throws IOException, ErrorResponseException, InvalidMailingRequestException {
        if(label != null && !StringUtils.isAlphanumeric(label)){
            throw new InvalidMailingRequestException("Label '"+label+"' contains invalid characters",
                    InvalidMailingRequestException.VALIDATION_EXCEPTION);
        }
        List<TemplateResponse> responseList = connector.getTemplatesCalls().list(label);
        return ok(Json.toJson(processTemplateResponses(responseList)));
    }

    public Result get(String name) throws IOException, ErrorResponseException {
        TemplateResponse response = connector.getTemplatesCalls().info(name);
        return ok(Json.toJson(processTemplateResponse(response)));
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result put(String name) throws IOException, ErrorResponseException, InvalidMailingRequestException {
        JsonNode json = request().body().asJson();
        Template t = new Template();
        String templateName = json.findPath(Properties.TEMPLATE_NAME).asText();
        if(!templateName.equals(name)) {
            throw new InvalidMailingRequestException("Template names does not match",
                    InvalidMailingRequestException.VALIDATION_EXCEPTION);
        }
        String subject = json.findPath(Properties.SUBJECT).asText();
        String htmlContent = json.findPath(Properties.HTML_CONTENT).asText();
        String textContent = json.findPath(Properties.TEXT_CONTENT).asText();
        String product = json.findPath(Properties.PRODUCT).asText();
        JsonNode labels = json.findPath(Properties.LABELS);

        if(subject.isEmpty()) {
            throw new InvalidMailingRequestException("Subject cannot be empty",
                    InvalidMailingRequestException.NULL_EXCEPTION);
        }
        if(templateName.isEmpty()) {
            throw new InvalidMailingRequestException("Template name cannot be empty",
                    InvalidMailingRequestException.NULL_EXCEPTION);
        }
        if(htmlContent.isEmpty() && textContent.isEmpty()) {
            throw new InvalidMailingRequestException("Content (HTML or TEXT) have to be set",
                    InvalidMailingRequestException.NULL_EXCEPTION);
        }

        t.setName(templateName);
        t.setSubject(subject);
        t.setCode(htmlContent);
        t.setText(textContent);
        if(!product.isEmpty()) {
            t.addLabel(productPrefix +product);
        }

        for(JsonNode labelNode : labels) {
            String label = labelNode.asText();
            if(!StringUtils.isAlphanumeric(label)){
                throw new InvalidMailingRequestException("Label '"+label+"' contains invalid characters",
                        InvalidMailingRequestException.VALIDATION_EXCEPTION);
            }
            t.addLabel(label);
        }

        t.setPublish(true);
        TemplateResponse response;
        try {
            response = connector.getTemplatesCalls().update(t);
            return ok(Json.toJson(processTemplateResponse(response)));
        } catch(TemplateNotFoundException ex) {
            response = connector.getTemplatesCalls().add(t);
            return status(Properties.CREATED_STATUS, Json.toJson(processTemplateResponse(response)));
        }
    }

    public Result delete(String name) throws IOException, ErrorResponseException {
        TemplateResponse response = connector.getTemplatesCalls().delete(name);
        return ok(Json.toJson(processTemplateResponse(response)));
    }
}
