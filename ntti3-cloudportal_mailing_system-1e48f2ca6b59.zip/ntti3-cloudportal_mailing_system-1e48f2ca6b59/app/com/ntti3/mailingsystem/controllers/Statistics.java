package com.ntti3.mailingsystem.controllers;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.inject.Inject;
import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mailingsystem.exceptions.InvalidMailingRequestException;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.TagInfoResponse;
import com.ntti3.mandrill.connector.responses.UrlResponse;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-10.
 */
@ControllerExceptionSupport.ExceptionHandler()
public class Statistics extends Controller {
    private final MandrillConnector connector;

    private static UrlResponse findResponse(List<UrlResponse> responses, String url) throws InvalidMailingRequestException {
        //search returns all links matching url i.e. for example.com it can match also something.example.com or example.com/something
        for(UrlResponse r : responses) {
            if(r.getUrl().equalsIgnoreCase(url)){
                return r;
            }
        }
        throw new InvalidMailingRequestException("Tag not found", InvalidMailingRequestException.NOT_FOUND, InvalidMailingRequestException.NOT_FOUND);
    }

    @Inject
    public Statistics(MandrillConnector connector) {
        this.connector = connector;
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result tag(String tag) throws IOException, ErrorResponseException {
        TagInfoResponse response = connector.getTagsCalls().info(tag);
        ObjectNode result = Json.newObject();
        result.put(Properties.SENT, response.getSent());
        result.put(Properties.HARD_BOUNCES, response.getHardBounces());
        result.put(Properties.SOFT_BOUNCES, response.getSoftBounces());
        result.put(Properties.REJECTS, response.getRejects());
        result.put(Properties.COMPLAINTS, response.getComplaints());
        result.put(Properties.OPENS, response.getOpens());
        result.put(Properties.CLICKS, response.getClicks());
        return ok(result);
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result url(String url) throws IOException, ErrorResponseException, InvalidMailingRequestException {
        List<UrlResponse> responses;
        url = java.net.URLDecoder.decode(url, "UTF-8");
        responses = connector.getUrlsCalls().search(url);

        UrlResponse response = findResponse(responses, url);

        ObjectNode result = Json.newObject();
        result.put(Properties.SENT, response.getSent());
        result.put(Properties.CLICKS, response.getClicks());
        result.put(Properties.UNIQUE_CLICKS, response.getUniqueClicks());
        return ok(result);
    }
}
