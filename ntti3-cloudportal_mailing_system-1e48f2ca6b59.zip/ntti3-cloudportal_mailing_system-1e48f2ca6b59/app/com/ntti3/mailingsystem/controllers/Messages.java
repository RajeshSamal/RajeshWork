package com.ntti3.mailingsystem.controllers;

import com.avaje.ebean.ExpressionList;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.inject.Inject;
import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mailingsystem.exceptions.InvalidMailingRequestException;
import com.ntti3.mailingsystem.models.Message;
import com.ntti3.mailingsystem.models.Tag;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.exceptions.MessageNotFoundException;
import com.ntti3.mandrill.connector.models.Attachment;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.models.Recipient;
import com.ntti3.mandrill.connector.models.RecipientMergeVariables;
import com.ntti3.mandrill.connector.responses.MessageInfoResponse;
import com.ntti3.mandrill.connector.responses.SendResponse;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import org.apache.commons.lang3.StringUtils;
import play.Play;
import play.libs.Akka;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import scala.concurrent.duration.Duration;

import javax.persistence.PersistenceException;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-10.
 */
@ControllerExceptionSupport.ExceptionHandler()
public class Messages extends Controller {
    private static final String PRODUCT_PREFIX = "#";
    private static final String defaultSender = Play.application().configuration().getString("mandrill.default_sender_mail");
    private static final String defaultFromName = Play.application().configuration().getString("mandrill.default_sender_name");

    private final MandrillConnector connector;

    private static Attachment processAttachment(JsonNode attachmentNode) {
        return new Attachment(attachmentNode.findPath(Properties.MIME_TYPE).asText(),
                attachmentNode.findPath(Properties.NAME).asText(),
                attachmentNode.findPath(Properties.CONTENT).asText());
    }

    private static Recipient.Type getType(String s) {
        switch (s) {
            case Properties.CC:
                return Recipient.Type.cc;
            case Properties.BCC:
                return Recipient.Type.bcc;
            case Properties.TO:
            default:
                return Recipient.Type.to;
        }
    }

    private static com.ntti3.mandrill.connector.models.Message buildMessage(JsonNode json) throws InvalidMailingRequestException {
        String fromEmail = json.findPath(Properties.FROM_EMAIL).asText();
        if(fromEmail.isEmpty()) {
            fromEmail = defaultSender;
        }
        String fromName = json.findPath(Properties.FROM_NAME).asText();
        if(fromName.isEmpty()) {
            fromName = defaultFromName;
        }
        JsonNode recipients = json.findPath(Properties.TO);

        com.ntti3.mandrill.connector.models.Message message = new com.ntti3.mandrill.connector.models.Message();
        message.setFromEmail(fromEmail);
        message.setFromName(fromName);

        for(JsonNode recipient : recipients) {
            Recipient r = new Recipient(
                    recipient.findPath(Properties.EMAIL).asText(),
                    recipient.findPath(Properties.NAME).asText()
            );
            if(r.getEmail().isEmpty()) {
                throw new InvalidMailingRequestException("Recipient e-mail address cannot be empty",
                        InvalidMailingRequestException.NULL_EXCEPTION);
            }
            String type = recipient.findPath(Properties.RECIPIENT_TYPE).asText();
            r.setType(getType(type));
            message.addTo(r);
        }
        if(message.getTo().size() == 0) {
            throw new InvalidMailingRequestException("Recipients array cannot be empty",
                    InvalidMailingRequestException.NULL_EXCEPTION);
        }

        String product = json.findPath(Properties.PRODUCT).asText();
        JsonNode tags = json.findPath(Properties.TAGS);

        message.addTag(PRODUCT_PREFIX + product);
        for(JsonNode tagNode : tags) {
            String tag = tagNode.asText();
            if(!StringUtils.isAlphanumeric(tag)) {
                throw new InvalidMailingRequestException("Tag '"+tag+"' contains invalid characters",
                        InvalidMailingRequestException.VALIDATION_EXCEPTION);
            }
            message.addTag(tag);
        }

        JsonNode attachments = json.findPath(Properties.ATTACHMENTS);
        JsonNode images = json.findPath(Properties.IMAGES);

        for(JsonNode attachmentNode : attachments) {
            message.addAttachment(processAttachment(attachmentNode));
        }
        for(JsonNode attachmentNode : images) {
            try {
                message.addImage(processAttachment(attachmentNode));
            } catch(IllegalArgumentException ex) {
                throw new InvalidMailingRequestException("Wrong image MIME type.",
                        InvalidMailingRequestException.WRONG_MIME);
            }
        }
        if(json.findPath("reply_to").isTextual()) {
            message.addHeader("Reply-To", json.findPath("reply_to").asText());
        }
        return message;
    }

    private List<Map<String,String>> processSendResponses(List<SendResponse> responses, com.ntti3.mandrill.connector.models.Message message, JsonNode json, boolean subjectFromTemplate) {
        List<Map<String,String>> result = new ArrayList<>();
        final List<UUID> dbMessages = new LinkedList<>();
        String product = json.findPath(Properties.PRODUCT).asText();
        JsonNode tags = json.findPath(Properties.TAGS);
        Map<String,String> singleResult;
        for(SendResponse r : responses) {
            singleResult = new HashMap<>();
            singleResult.put(Properties.EMAIL, r.getEmail());
            Message dbMessage = new Message();
            dbMessage.setProduct(product);
            dbMessage.setRecipient(r.getEmail());
            dbMessage.setSender(message.getFromEmail());
            for(JsonNode tag : tags) {
                dbMessage.addTag(tag.asText());
            }
            if(!subjectFromTemplate) {
                dbMessage.setSubject(message.getSubject());
            }
            dbMessage.setMandrillId(r.getId());
            dbMessage.save();

            singleResult.put(Properties.ID, dbMessage.getId().toString());
            dbMessages.add(dbMessage.getId());

            if(r.getRejectReason() != null) {
                singleResult.put(Properties.REJECT_REASON, r.getRejectReason());
            }
            result.add(singleResult);
        }

        if(subjectFromTemplate) { //get subject from template
            final String templateName = json.findPath(Properties.TEMPLATE_NAME).asText();
            Akka.system().scheduler().scheduleOnce(
                    Duration.create(1, TimeUnit.MILLISECONDS),
                    new Runnable() {
                        public void run() {
                            try {
                                TemplateResponse templateResponse = connector.getTemplatesCalls().info(templateName);
                                if(templateResponse != null) {
                                    for(UUID id : dbMessages) {
                                        try {
                                            Message message = Message.find.byId(id);
                                            message.setSubject(templateResponse.getSubject());
                                            message.save();
                                        } catch(PersistenceException ignored){}
                                    }
                                }
                            } catch (IOException | ErrorResponseException ignored2) {}
                        }
                    },
                    Akka.system().dispatcher()
            );
        }
        return result;
    }

    private List<Map<String,String>> processSendResponses(List<SendResponse> responses,
                                                          com.ntti3.mandrill.connector.models.Message message,
                                                          JsonNode json) {
        return processSendResponses(responses, message, json, false);
    }

    @Inject
    public Messages(MandrillConnector connector) {
        this.connector = connector;
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result send() throws InvalidMailingRequestException, IOException, ErrorResponseException {
        JsonNode json = request().body().asJson();

        String subject = json.findPath(Properties.SUBJECT).asText();
        String htmlContent = json.findPath(Properties.HTML_CONTENT).asText();
        String textContent = json.findPath(Properties.TEXT_CONTENT).asText();

        if(subject.isEmpty()) {
            throw new InvalidMailingRequestException("Subject cannot be empty",
                    InvalidMailingRequestException.NULL_EXCEPTION);
        }
        if(htmlContent.isEmpty() && textContent.isEmpty()) {
           throw new InvalidMailingRequestException("Content (HTML or TEXT) have to be set.",
                   InvalidMailingRequestException.NULL_EXCEPTION);
        }

        com.ntti3.mandrill.connector.models.Message message = buildMessage(json);

        message.setSubject(subject);
        message.setHtml(htmlContent);
        message.setText(textContent);

        List<SendResponse> responses = connector.getMessagesCalls().send(message, true);
        return ok(Json.toJson(processSendResponses(responses, message, json)));
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result sendTemplate() throws InvalidMailingRequestException, IOException, ErrorResponseException {
        JsonNode json = request().body().asJson();
        com.ntti3.mandrill.connector.models.Message message = buildMessage(json);
        String templateName = json.findPath(Properties.TEMPLATE_NAME).asText();

        JsonNode globalVariablesJson = json.findPath(Properties.VARIABLES);

        for(JsonNode variableJson : globalVariablesJson) {
            message.addGlobalMergeVar(new NameContentElement(
                    variableJson.findPath(Properties.NAME).asText(),
                    variableJson.findPath(Properties.CONTENT).asText()));
        }

        JsonNode recipients = json.findPath(Properties.TO);

        for(JsonNode recipient : recipients) {
            RecipientMergeVariables recipientMergeVariables = new RecipientMergeVariables(recipient.findPath(Properties.EMAIL).asText());
            for(JsonNode variableJson : recipient.findPath(Properties.VARIABLES)) {
                recipientMergeVariables.addMergeVar(new NameContentElement(
                        variableJson.findPath(Properties.NAME).asText(),
                        variableJson.findPath(Properties.CONTENT).asText()));
            }
            message.addRecipientMergeVar(recipientMergeVariables);
        }
        message.setMerge(true);
        List<SendResponse> responses = connector.getMessagesCalls().send_template(templateName, null, message, true);
        return ok(Json.toJson(processSendResponses(responses, message, json, true)));
    }

    public Result get(String id) throws IOException, ErrorResponseException, InvalidMailingRequestException {
        Message message = null;
        try {
            message = Message.find.byId(UUID.fromString(id));
        } catch(IllegalArgumentException ignored) {}
        //User may try something not valid, we will just return 404 in this case
        if(message == null) {
            throw new InvalidMailingRequestException("Message not found", InvalidMailingRequestException.NOT_FOUND, InvalidMailingRequestException.NOT_FOUND);
        }

        Map<String,Object> result = new HashMap<>();
        try {
            MessageInfoResponse resp = connector.getMessagesCalls().info(message.getMandrillId());
            if(resp.getTemplate() != null) {
                result.put(Properties.TEMPLATE_NAME, resp.getTemplate());
            }
            result.put(Properties.OPENS, resp.getOpens());
            result.put(Properties.CLICKS, resp.getClicks());
        } catch(MessageNotFoundException ex) {
            //getting here means Mandrill returns "no message" for a valid id - message has been sent recently
            //and is not yet visible in Mandrill.
            result.put(Properties.OPENS, 0);
            result.put(Properties.CLICKS, 0);

        }

        result.put(Properties.TIMESTAMP, message.getDate().getTime());
        result.put(Properties.RECIPIENT, message.getRecipient());
        result.put(Properties.SENDER, message.getSender());
        result.put(Properties.SUBJECT, message.getSubject());
        result.put(Properties.ID, message.getId().toString());
        if(message.getProduct() != null) {
            result.put(Properties.PRODUCT, message.getProduct());
        }

        Set<Tag> tags = message.getTags();
        if(tags.size() > 0) {
            List<String> tagNames = new LinkedList<>();
            for(Tag tag : tags) {
                tagNames.add(tag.getName());
            }
            result.put(Properties.TAGS, tagNames);
        }
        return ok(Json.toJson(result));
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result search() {
        JsonNode json = request().body().asJson();
        String recipient = json.findPath(Properties.RECIPIENT).asText();
        String sender = json.findPath(Properties.SENDER).asText();
        String product = json.findPath(Properties.PRODUCT).asText();
        JsonNode tags = json.findPath(Properties.TAGS);

        long timestamp;
        ExpressionList<Message> query = Message.find.where();
        if(!recipient.isEmpty()) {
            query = query.eq(Message.RECIPIENT, recipient);
        }
        if(!sender.isEmpty()) {
            query = query.eq(Message.SENDER, sender);
        }
        if(!product.isEmpty()) {
            query = query.eq(Message.PRODUCT, product);
        }
        if(json.findValue(Properties.DATE_FROM) != null){
            timestamp = json.findValue(Properties.DATE_FROM).asLong();
            query = query.ge(Message.DATE, new Timestamp(timestamp));
        }
        if(json.findValue(Properties.DATE_TO) != null){
            timestamp = json.findValue(Properties.DATE_TO).asLong();
            query = query.le(Message.DATE, new Timestamp(timestamp));
        }

        if(tags.isArray() && tags.size() > 0) {
            //tags are last, as they are ORed
            query = query.disjunction();
            for (JsonNode tag : tags) {
                query = query.eq(Message.TAGS_ID, tag.asText());
            }
        }

        List<Message> messages = query.findList();
        List<Map<String,Object>> result = new ArrayList<>();
        for(Message message : messages) {
            Map<String,Object> messageMap = new HashMap<>();
            messageMap.put(Properties.ID, message.getId());
            messageMap.put(Properties.SENDER, message.getSender());
            messageMap.put(Properties.RECIPIENT, message.getRecipient());
            if(message.getProduct() != null && !message.getProduct().isEmpty()) {
                messageMap.put(Properties.PRODUCT, message.getProduct());
            }
            Set<Tag> dbTags = message.getTags();
            if(dbTags.size() > 0) {
                List<String> tagsNames = new ArrayList<>();
                for (Tag tag : dbTags) {
                    tagsNames.add(tag.getName());
                }
                messageMap.put(Properties.TAGS, tagsNames);
            }
            messageMap.put(Properties.SUBJECT, message.getSubject());
            messageMap.put(Properties.TIMESTAMP, message.getDate().getTime());
            result.add(messageMap);
        }
        return ok(Json.toJson(result));
    }
}
