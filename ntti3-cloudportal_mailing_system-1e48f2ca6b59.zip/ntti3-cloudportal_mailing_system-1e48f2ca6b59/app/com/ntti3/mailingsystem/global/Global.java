/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-10.
 */
package com.ntti3.mailingsystem.global;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.ntti3.mailingsystem.exceptions.handlers.ErrorResponseExceptionHandler;
import com.ntti3.mailingsystem.exceptions.handlers.InvalidMailingRequestExceptionHandler;
import com.ntti3.mailingsystem.exceptions.handlers.NotFoundExceptionHandler;
import com.ntti3.mailingsystem.exceptions.handlers.ValidationErrorExceptionHandler;
import com.ntti3.mandrill.connector.MandrillConnector;
import com.ntti3.mandrill.connector.MandrillConnectorFactory;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.Application;
import play.Configuration;
import play.GlobalSettings;
import play.Play;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Results;
import play.mvc.SimpleResult;

import java.lang.reflect.Method;

public class Global extends GlobalSettings {
    public static final String MAILINGSYSTEM = "mailing-system";

    private Injector injector;
    private GlobalExceptionsHandler globalExceptionsHandler = new GlobalExceptionsHandler();
    private MandrillConnector connector = null;

    protected MandrillConnector getMandrillConnector() {
        return connector;
    }

    @Override
    public void onStart(Application app) {
        super.onStart(app);
        globalExceptionsHandler.registerHandler(new NotFoundExceptionHandler());
        globalExceptionsHandler.registerHandler(new ValidationErrorExceptionHandler());
        globalExceptionsHandler.registerHandler(new ErrorResponseExceptionHandler());
        globalExceptionsHandler.registerHandler(new InvalidMailingRequestExceptionHandler());
        Configuration configuration = Play.application().configuration();

        String senderMail = configuration.getString("mandrill.default_sender_mail");
        if(senderMail==null || senderMail.isEmpty()) {
            throw configuration.reportError("mandrill.default_sender_mail", "Default sender mail is not set", null);
        }
        String apiKey = configuration.getString("mandrill.key");
        if(apiKey==null || apiKey.isEmpty()) {
            throw configuration.reportError("mandrill.key", "Mandrill API key is not set", null);
        }

        connector = (new MandrillConnectorFactory()).makeMandrillConnector(apiKey);


        injector = Guice.createInjector(
                new Module() {
                    @Override
                    public void configure(Binder binder) {
                        binder.bind(MandrillConnector.class).toInstance(getMandrillConnector());
                    }
                },
                new Module() {
                    @Override
                    public void configure(Binder binder) {
                        binder.bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
                    }
                },
                new BuildInfoReaderModule(MAILINGSYSTEM)
        );
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return injector.getInstance(controllerClass);
    }

    @Override
    public F.Promise<SimpleResult> onBadRequest(Http.RequestHeader request,
                                                String error) {
        return handleBadRequest(request);
    }

    @Override
    public F.Promise<SimpleResult> onHandlerNotFound(Http.RequestHeader request) {
        return handleBadRequest(request);
    }

    private static F.Promise<SimpleResult> handleBadRequest(Http.RequestHeader request) {
        return F.Promise.<SimpleResult>pure(Results
                .badRequest(ResponseHelper.errorResponse(
                        ErrorCode.INCORRECT_CALL, "Bad request path",
                        "Request path: " + request.path() + " is incorrect")));
    }

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }
}