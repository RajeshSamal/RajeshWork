package com.ntti3.mailingsystem.models;

import play.db.ebean.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-14.
 */
@Entity
public class Tag extends Model {
    @Id
    private String name;

    @ManyToMany(mappedBy = "tags")
    private Set<Message> messages = new HashSet<>();

    private void setName(String name) {
        this.name = name;
    }

    public static Finder<String, Tag> find = new Finder<>(
            String.class, Tag.class
    );

    public String getName() {
        return name;
    }

    public static Tag getOrCreate(String tag) {
        Tag result = find.byId(tag);
        if(result == null) {
            result = new Tag();
            result.setName(tag);
            result.save();
        }
        return result;
    }

    public Set<Message> getMessages() {
        return Collections.unmodifiableSet(messages);
    }
}
