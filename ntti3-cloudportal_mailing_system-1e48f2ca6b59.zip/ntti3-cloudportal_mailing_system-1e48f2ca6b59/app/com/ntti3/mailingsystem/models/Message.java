package com.ntti3.mailingsystem.models;

import com.avaje.ebean.annotation.CreatedTimestamp;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-14.
 */
@Entity
public class Message extends Model {
    public static final String RECIPIENT = "recipient";
    public static final String SENDER = "sender";
    public static final String PRODUCT = "product";
    public static final String TAGS_ID = "tags.name";
    public static final String DATE = "date";
    @Id
    private UUID id;

    @Column(unique = true)
    private String mandrillId;

    @Constraints.Required
    private String sender;

    @Constraints.Required
    private String recipient;

    private String product;

    private String subject;

    @ManyToMany
    private Set<Tag> tags = new HashSet<>();

    @CreatedTimestamp
    private Timestamp date;

    public static Finder<UUID, Message> find = new Finder<>(
            UUID.class, Message.class
    );

    public Set<Tag> getTags() {
        return Collections.unmodifiableSet(tags);
    }

    public void addTag(String tag) {
        tags.add(Tag.getOrCreate(tag));
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getMandrillId() {
        return mandrillId;
    }

    public void setMandrillId(String mandrillId) {
        this.mandrillId = mandrillId;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }
}
