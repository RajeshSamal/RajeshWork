package com.ntti3.mailingsystem.exceptions;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-11.
 */
public class InvalidMailingRequestException extends Exception {
    /**
     * Status indicating that required parameter is null or missing
     */
    public final static int NULL_EXCEPTION = 101;
    public final static int WRONG_MIME = 102;
    public static final int VALIDATION_EXCEPTION = 103;

    public final static int NOT_FOUND = 404;
    public final static int BAD_REQUEST = 400;
    public final static int SERVER_ERROR = 500;

    private int status;
    private int detailedStatus;
    private String details;

    public InvalidMailingRequestException(String error, int detailedStatus) {
        super(error);
        this.status = BAD_REQUEST;
        this.detailedStatus = detailedStatus;
    }

    public InvalidMailingRequestException(String error, int status, int detailedStatus) {
        super(error);
        this.status = status;
        this.detailedStatus = detailedStatus;
    }

    public int getDetailedStatus() {
        return detailedStatus;
    }

    public InvalidMailingRequestException(String error, String details, int status, int detailedStatus) {
        super(error);
        this.details = details;
        this.status = status;
        this.detailedStatus = detailedStatus;
    }

    public int getStatus() {
        return status;
    }

    public String getDetails() {
        return details;
    }
}
