package com.ntti3.mailingsystem.exceptions.handlers;

import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mandrill.connector.exceptions.ValidationErrorException;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.badRequest;

/**
* Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-16.
*/
public class ValidationErrorExceptionHandler extends AbstractExceptionHandler<ValidationErrorException> {
    public ValidationErrorExceptionHandler() {
        super(ValidationErrorException.class);
    }

    @Override
    protected SimpleResult handleExceptionWithType(ValidationErrorException e, Http.Response response) {
        ErrorContainer error = new ErrorContainer(Properties.VALIDATION_ERROR_STATUS, e.getName(), e.getMessage());
        return badRequest(Json.toJson(error));
    }
}
