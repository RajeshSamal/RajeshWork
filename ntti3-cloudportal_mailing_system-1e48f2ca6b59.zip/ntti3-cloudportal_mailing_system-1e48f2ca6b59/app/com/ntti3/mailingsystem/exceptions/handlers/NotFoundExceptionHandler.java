package com.ntti3.mailingsystem.exceptions.handlers;

import com.ntti3.mailingsystem.controllers.constants.Properties;
import com.ntti3.mandrill.connector.exceptions.NotFoundException;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.notFound;

/**
* Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-16.
*/
public class NotFoundExceptionHandler extends AbstractExceptionHandler<NotFoundException> {
    public NotFoundExceptionHandler() {
        super(NotFoundException.class);
    }

    @Override
    protected SimpleResult handleExceptionWithType(NotFoundException e, Http.Response response) {
        ErrorContainer error = new ErrorContainer(e.getCode() + Properties.MANDRILL_ERROR_OFFSET, e.getName(), e.getMessage());
        return notFound(Json.toJson(error));
    }
}
