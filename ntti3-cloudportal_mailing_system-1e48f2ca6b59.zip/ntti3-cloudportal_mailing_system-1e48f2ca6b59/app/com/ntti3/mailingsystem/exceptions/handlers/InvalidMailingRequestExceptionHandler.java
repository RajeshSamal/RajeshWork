package com.ntti3.mailingsystem.exceptions.handlers;

import com.ntti3.mailingsystem.exceptions.InvalidMailingRequestException;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.status;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-15.
 */
public class InvalidMailingRequestExceptionHandler extends AbstractExceptionHandler<InvalidMailingRequestException> {
    public InvalidMailingRequestExceptionHandler() {
        super(InvalidMailingRequestException.class);
    }

    @Override
    protected SimpleResult handleExceptionWithType(InvalidMailingRequestException e, Http.Response response) {
        ErrorContainer error = new ErrorContainer(e.getDetailedStatus(), e.getMessage(), e.getDetails());
        return status(e.getStatus(), Json.toJson(error));
    }
}
