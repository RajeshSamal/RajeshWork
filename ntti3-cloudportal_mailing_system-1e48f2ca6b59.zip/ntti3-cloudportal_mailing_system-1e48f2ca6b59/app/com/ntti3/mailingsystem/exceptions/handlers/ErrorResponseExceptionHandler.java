package com.ntti3.mailingsystem.exceptions.handlers;

import com.ntti3.mailingsystem.exceptions.InvalidMailingRequestException;
import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.play.excetions.handling.AbstractExceptionHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.SimpleResult;

import static play.mvc.Results.badRequest;

/**
* Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-16.
*/
public class ErrorResponseExceptionHandler extends AbstractExceptionHandler<ErrorResponseException> {
    public ErrorResponseExceptionHandler() {
        super(ErrorResponseException.class);
    }

    @Override
    protected SimpleResult handleExceptionWithType(ErrorResponseException e, Http.Response response) {
        ErrorContainer error = new ErrorContainer(InvalidMailingRequestException.SERVER_ERROR, "Server error");
        return badRequest(Json.toJson(error));
    }
}
