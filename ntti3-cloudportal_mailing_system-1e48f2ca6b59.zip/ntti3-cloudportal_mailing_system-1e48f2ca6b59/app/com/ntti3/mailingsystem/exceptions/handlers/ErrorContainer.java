package com.ntti3.mailingsystem.exceptions.handlers;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-16.
 */
public class ErrorContainer {
    private int code;
    private String message;
    private String details;

    public ErrorContainer(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public ErrorContainer(int code, String message, String details) {
        this.code = code;
        this.details = details;
        this.message = message;
    }

    public int getCode() {

        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getDetails() {
        return details;
    }
}
