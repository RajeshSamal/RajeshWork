public class Global extends com.ntti3.mailingsystem.global.Global {

}