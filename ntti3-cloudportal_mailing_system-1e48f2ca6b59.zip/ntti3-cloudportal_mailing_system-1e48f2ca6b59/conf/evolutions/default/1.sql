# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table message (
  id                        varchar(40) not null,
  mandrill_id               varchar(255),
  sender                    varchar(255),
  recipient                 varchar(255),
  product                   varchar(255),
  subject                   varchar(255),
  date                      datetime not null,
  constraint uq_message_mandrill_id unique (mandrill_id),
  constraint pk_message primary key (id))
;

create table tag (
  name                      varchar(255) not null,
  constraint pk_tag primary key (name))
;


create table message_tag (
  message_id                     varchar(40) not null,
  tag_name                       varchar(255) not null,
  constraint pk_message_tag primary key (message_id, tag_name))
;



alter table message_tag add constraint fk_message_tag_message_01 foreign key (message_id) references message (id) on delete restrict on update restrict;

alter table message_tag add constraint fk_message_tag_tag_02 foreign key (tag_name) references tag (name) on delete restrict on update restrict;

# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table message;

drop table message_tag;

drop table tag;

SET FOREIGN_KEY_CHECKS=1;

