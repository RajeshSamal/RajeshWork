package com.ntti3.urlhelper;

import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;

import static junit.framework.TestCase.assertEquals;

public class UrlHelperTest {

    private UrlHelper helper;

    @Before
    public void before() {
        helper = new UrlHelper("http://www.example.com");
    }

    @Test
    public void simpleJoinTest() throws MalformedURLException {
        assertEquals("http://www.example.com/path", helper.absoluteAddress("/path"));
    }

    @Test
    public void queryParamsTest() throws MalformedURLException {
        assertEquals("http://www.example.com/path?a=a&b=b", helper.absoluteAddress("path?a=a&b=b"));
    }

    @Test
    public void nestedPathTest() throws MalformedURLException {
        UrlHelper helper2 = new UrlHelper("http://www.example.com/path/");
        assertEquals("http://www.example.com/path/path2?a=a&b=b", helper2.absoluteAddress("path2?a=a&b=b"));
    }

    @Test
    public void nestedPathWithoutTrailingSlashTest() throws MalformedURLException {
        UrlHelper helper2 = new UrlHelper("http://www.example.com/path/");
        assertEquals("http://www.example.com/path/path2?a=a&b=b", helper2.absoluteAddress("/path2?a=a&b=b"));
    }
}
