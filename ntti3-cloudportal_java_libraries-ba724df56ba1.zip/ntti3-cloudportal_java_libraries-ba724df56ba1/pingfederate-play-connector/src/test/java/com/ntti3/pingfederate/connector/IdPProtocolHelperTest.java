package com.ntti3.pingfederate.connector;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.TokenException;
import junit.framework.TestCase;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs;
import play.mvc.Http;
import play.mvc.Result;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.fail;
import static org.mockito.Mockito.*;

public class IdPProtocolHelperTest {
    private IdPProtocolHelper helper;

    @Before
    public void setUp() throws Exception {
        Map<String, String> confMap = Maps.newHashMap();

        confMap.put(ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "agent-config.txt");
        confMap.put(ProtocolHelper.CONFIG_FILE_SCHEME, "https");
        confMap.put(ProtocolHelper.CONFIG_FILE_PORT, "1234");
        confMap.put(ProtocolHelper.CONFIG_FILE_HOST, "www.example.com");

        helper = new IdPProtocolHelperFactory().getInstanceFromConfig(confMap);
    }

    @Test
    public void testBuildSsoResponse() throws Exception {
        Map<String, String> token = Maps.newHashMap();
        token.put(Agent.TOKEN_SUBJECT, "user");
        token.put("attr1", "val1");

        URI uri = helper.buildSsoResponse("/resume", token);

        assertEquals("https", uri.getScheme());
        assertEquals("/resume", uri.getPath());
        assertEquals("www.example.com", uri.getHost());
        assertEquals(1234, uri.getPort());

        List<NameValuePair> list = URLEncodedUtils.parse(uri, "utf-8");
        HashMap<String, String> map = Maps.newHashMap();
        for (NameValuePair pair : list) {
            map.put(pair.getName(), pair.getValue());
        }

        token = helper.readToken(map.get("opentoken"));
        assertEquals(token.get(Agent.TOKEN_SUBJECT), "user");
        assertEquals(token.get("attr1"), "val1");

    }

    @Test
    public void testBuildSloUrl() throws Exception {
        URI uri = helper.buildSloUrl("success", "failure");

        assertEquals("https", uri.getScheme());
        assertEquals(1234, uri.getPort());
        assertEquals("www.example.com", uri.getHost());
        TestCase.assertEquals("/idp/startSLO.ping", uri.getPath());
        List<NameValuePair> list = URLEncodedUtils.parse(uri, "utf-8");
        HashMap<String, String> map = Maps.newHashMap();
        for (NameValuePair pair : list) {
            map.put(pair.getName(), pair.getValue());
        }
        assertEquals("failure", map.get("InErrorResource"));
        assertEquals("success", map.get("TargetResource"));
    }

    @Test
    public void buildBaseUrl() throws Exception {
        URI base = helper.getPFBaseURI();
        assertEquals("https", base.getScheme());
        assertEquals(1234, base.getPort());
        assertEquals("www.example.com", base.getHost());
        assertEquals("", base.getPath());
    }

    @Test(expected = TokenNotFoundException.class)
    public void getNonexistentToken() throws Exception {
        Http.Request request = mock(Http.Request.class);
        when(request.queryString()).thenReturn(Collections.<String, String[]>emptyMap());
        Http.RequestBody body = mock(Http.RequestBody.class);
        when(body.asFormUrlEncoded()).thenReturn(Collections.<String, String[]>emptyMap());
        when(request.body()).thenReturn(body);

        helper.parseTokenInRequest(request);
    }

    @Test
    public void buildStartSsoUrl() throws TokenException, URISyntaxException {
        Multimap<String, String> token = HashMultimap.create();
        token.put("param1", "a");
        token.put("param1", "b");
        token.put(Agent.TOKEN_SUBJECT, "subject");

        URI uri = helper.buildStartSsoUrl("testSP", "testSuccess", "testFailure", token);

        List<NameValuePair> list = URLEncodedUtils.parse(uri, "utf-8");
        HashMap<String, String> map = Maps.newHashMap();
        for (NameValuePair pair : list) {
            map.put(pair.getName(), pair.getValue());
        }

        assertEquals("testSuccess", map.get("TargetResource"));
        assertEquals("testFailure", map.get("InErrorResource"));
        assertEquals("testSP", map.get("PartnerSpId"));
        token = helper.readTokenToMultiMap(map.get("opentoken"));

        assertTrue(token.containsEntry("param1", "a"));
        assertTrue(token.containsEntry("param1", "b"));
        assertTrue(token.containsEntry(Agent.TOKEN_SUBJECT, "subject"));
    }

    @Test
    public void parseTokenInRequest() throws TokenException, TokenNotFoundException {
        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        Multimap<String, String> token = HashMultimap.create();
        token.put("param1", "a");
        token.put("param1", "b");
        token.put(Agent.TOKEN_SUBJECT, "subject");

        String[] string = {helper.buildToken(token)};
        when(request.queryString().containsKey("opentoken")).thenReturn(true);
        when(request.queryString().get("opentoken")).thenReturn(string);
        Multimap<String, String> map = helper.parseTokenInRequestMulti(request);
        assertTrue(map.containsEntry("param1", "a"));
        assertTrue(map.containsEntry("param1", "b"));
        assertTrue(map.containsEntry(Agent.TOKEN_SUBJECT, "subject"));
    }

    @Test
    public void resumePath() throws MalformedURLException {
        ProtocolHelper.ResumePath path = helper.new ResumePath("testPath2");
        TestCase.assertEquals("testPath2", path.getPath());
        TestCase.assertEquals("https://www.example.com:1234/testPath2", path.getUrl());
    }

    @Test
    public void handleSloRequest() throws ProtocolParametersException, RequestHandlerException {
        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        when(request.queryString().get("resume")).thenReturn(new String[]{"testResumePath"});

        helper.handleRequest(IdPProtocolHelper.RequestType.SLO_REQUEST, request,
                new IdPProtocolHelper.RequestHandler() {
                    @Override
                    public Result ssoRequest(ProtocolHelper.ResumePath resumePath, String spEntityId) {
                        fail("Bad request");
                        return null;
                    }

                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        TestCase.assertEquals("testResumePath", resumePath.getPath());
                        return null;
                    }
                });
    }

    @Test
    public void handleSsoRequest() throws ProtocolParametersException, RequestHandlerException {
        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        when(request.queryString().get("resume")).thenReturn(new String[]{"testResumePath"});
        when(request.queryString().get("spentity")).thenReturn(new String[]{"testEntityID"});

        helper.handleRequest(IdPProtocolHelper.RequestType.SSO_REQUEST, request,
                new IdPProtocolHelper.RequestHandler() {
                    @Override
                    public Result ssoRequest(ProtocolHelper.ResumePath resumePath, String spEntityId) {
                        TestCase.assertEquals("testResumePath", resumePath.getPath());
                        TestCase.assertEquals("testEntityID", spEntityId);
                        return null;
                    }

                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        fail("Bad request");
                        return null;
                    }
                });
    }
}
