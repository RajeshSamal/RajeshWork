package com.ntti3.pingfederate.connector;

import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.TokenException;
import junit.framework.TestCase;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.stubbing.defaultanswers.ReturnsDeepStubs;
import play.mvc.Http;
import play.mvc.Result;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static junit.framework.TestCase.fail;
import static org.mockito.Mockito.*;

public class SPProtocolHelperTest {
    private SPProtocolHelper helper;

    @Before
    public void setUp() throws Exception {
        Map<String, String> confMap = Maps.newHashMap();
        confMap.put(ProtocolHelper.CONFIG_FILE_AGENT_CONFIG, "agent-config.txt");
        confMap.put(ProtocolHelper.CONFIG_FILE_SCHEME, "https");
        confMap.put(ProtocolHelper.CONFIG_FILE_PORT, "1234");
        confMap.put(ProtocolHelper.CONFIG_FILE_HOST, "www.example.com");

        helper = new SPProtocolHelperFactory().getInstanceFromConfig(confMap);
    }

    @Test
    public void testBuildSsoUrl() throws Exception {
        URI uri = helper.buildSsoUrl("fakeIdP", "fakeSuccess", "fakeError");
        assertEquals("https", uri.getScheme());
        assertEquals(1234, uri.getPort());
        assertEquals("www.example.com", uri.getHost());
        TestCase.assertEquals("/sp/startSSO.ping", uri.getPath());
        List<NameValuePair> list = URLEncodedUtils.parse(uri, "utf-8");
        HashMap<String, String> map = Maps.newHashMap();
        for (NameValuePair pair : list) {
            map.put(pair.getName(), pair.getValue());
        }

        TestCase.assertEquals("fakeError", map.get("InErrorResource"));
        TestCase.assertEquals("fakeSuccess", map.get("TargetResource"));
        TestCase.assertEquals("fakeIdP", map.get("PartnerIdpId"));
    }

    @Test
    public void testBuildSloUrl() throws Exception {
        URI uri = helper.buildSloUrl("user", "fakeSuccess", "fakeError");
        assertEquals("https", uri.getScheme());
        assertEquals(1234, uri.getPort());
        assertEquals("www.example.com", uri.getHost());
        TestCase.assertEquals("/sp/startSLO.ping", uri.getPath());
        List<NameValuePair> list = URLEncodedUtils.parse(uri, "utf-8");
        HashMap<String, String> map = Maps.newHashMap();
        for (NameValuePair pair : list) {
            map.put(pair.getName(), pair.getValue());
        }
        TestCase.assertEquals("fakeError", map.get("InErrorResource"));
        TestCase.assertEquals("fakeSuccess", map.get("TargetResource"));

        Map token = helper.getAgent().readToken(map.get("opentoken"));
        assertEquals("user", token.get(Agent.TOKEN_SUBJECT));
    }

    @Test
    public void ssoSuccess() throws TokenException, ProtocolParametersException, TokenNotFoundException, RequestHandlerException {
        Map<String, String> fakeToken = Maps.newHashMap();
        fakeToken.put(Agent.TOKEN_SUBJECT, "testSubject");

        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        String fakeTokenString = helper.getAgent().writeToken(fakeToken);

        when(request.queryString().containsKey("opentoken")).thenReturn(true);
        when(request.queryString().get("opentoken")).thenReturn(new String[]{fakeTokenString});

        helper.handleRequest(SPProtocolHelper.RequestType.SSO_SUCCESS_HANDLER, request,
                new SPProtocolHelper.RequestHandler() {
                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(String resumePath,
                                             Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(Multimap<String, String> token) {
                        assertTrue(token.containsEntry(Agent.TOKEN_SUBJECT, "testSubject"));
                        return null;
                    }

                    @Override
                    public Result ssoFailure(String error, String details) {
                        fail("bad request");
                        return null;
                    }
                });
    }

    @Test
    public void ssoSuccessResumePath() throws TokenException, ProtocolParametersException, TokenNotFoundException, RequestHandlerException {
        Map<String, String> fakeToken = Maps.newHashMap();
        fakeToken.put(Agent.TOKEN_SUBJECT, "testSubject");

        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        String fakeTokenString = helper.getAgent().writeToken(fakeToken);

        when(request.queryString().containsKey("opentoken")).thenReturn(true);
        when(request.queryString().get("opentoken")).thenReturn(new String[]{fakeTokenString});
        when(request.queryString().containsKey("resume")).thenReturn(true);
        when(request.queryString().get("resume")).thenReturn(new String[]{"testResume"});

        helper.handleRequest(SPProtocolHelper.RequestType.SSO_SUCCESS_HANDLER, request,
                new SPProtocolHelper.RequestHandler() {
                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(String resumePath,
                                             Multimap<String, String> token) {
                        assertTrue(token.containsEntry(Agent.TOKEN_SUBJECT, "testSubject"));
                        TestCase.assertEquals("testResume", resumePath);
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoFailure(String error, String details) {
                        fail("bad request");
                        return null;
                    }
                });
    }

    @Test
    public void ssoFailure() throws TokenException, ProtocolParametersException, TokenNotFoundException, RequestHandlerException {
        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());

        when(request.queryString().get("error")).thenReturn(new String[]{"testError"});
        when(request.queryString().get("errorDetail")).thenReturn(new String[]{"testDetails"});

        helper.handleRequest(SPProtocolHelper.RequestType.SSO_ERROR_HANDLER, request,
                new SPProtocolHelper.RequestHandler() {
                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(String resumePath,
                                             Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoFailure(String error, String details) {
                        TestCase.assertEquals("testError", error);
                        assertEquals("testDetails", details);
                        return null;
                    }
                });
    }

    @Test
    public void sloRequest() throws TokenException, ProtocolParametersException, TokenNotFoundException, RequestHandlerException {
        Http.Request request = mock(Http.Request.class, new ReturnsDeepStubs());
        when(request.queryString().get("resume")).thenReturn(new String[]{"testResume"});

        helper.handleRequest(SPProtocolHelper.RequestType.SLO_REQUEST, request,
                new SPProtocolHelper.RequestHandler() {
                    @Override
                    public Result sloRequest(ProtocolHelper.ResumePath resumePath) {
                        assertEquals("testResume", resumePath.getPath());
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(String resumePath,
                                             Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoSuccess(Multimap<String, String> token) {
                        fail("bad request");
                        return null;
                    }

                    @Override
                    public Result ssoFailure(String error, String details) {
                        fail("bad request");
                        return null;
                    }
                });
    }

}
