package com.ntti3.pingfederate.connector;

import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;

import java.io.IOException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class ProtocolHelperFactory<T extends ProtocolHelper> {

    protected abstract T getInstanceWithAgent(AgentConfiguration agentConfiguration, Agent agent, String scheme,
                                           String host, int port);

    public T getInstanceFromConfig(Map<String, String> config) throws IOException {
        String scheme = config.get(ProtocolHelper.CONFIG_FILE_SCHEME);
        String host = config.get(ProtocolHelper.CONFIG_FILE_HOST);
        int port = Integer.parseInt(config.get(ProtocolHelper.CONFIG_FILE_PORT));
        String agentConfigurationPath = config.get(ProtocolHelper.CONFIG_FILE_AGENT_CONFIG);
        AgentConfiguration agentConfiguration = new AgentConfiguration(agentConfigurationPath);
        Agent agent = new Agent(agentConfiguration);
        return getInstanceWithAgent(agentConfiguration,agent, scheme, host, port);
    }
}
