package com.ntti3.pingfederate.connector;

import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;

/**
 * @author jan.karwowski@ntti3.com
 */
public class IdPProtocolHelperFactory extends ProtocolHelperFactory<IdPProtocolHelper> {
    @Override
    public IdPProtocolHelper getInstanceWithAgent(AgentConfiguration agentConfiguration, Agent agent,
                                                  String scheme, String host, int port) {
        return new IdPProtocolHelper(agentConfiguration,agent,scheme,host,port);
    }
}
