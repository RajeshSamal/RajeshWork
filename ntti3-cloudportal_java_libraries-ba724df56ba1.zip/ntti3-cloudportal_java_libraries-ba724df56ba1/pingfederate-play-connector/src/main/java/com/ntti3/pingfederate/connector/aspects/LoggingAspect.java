package com.ntti3.pingfederate.connector.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * @author Mateusz Piękos (mateusz.piekos@codilime.com).
 */
@Aspect
public class LoggingAspect extends com.ntti3.connectors.aspects.LoggingAspect {
    @Pointcut("(execution(public * com.ntti3.pingfederate.connector..* (..)) || execution(public * com.ntti3.urlhelper..* (..))) && !execution(public * com.ntti3.pingfederate.connector.aspects.* (..))" )
    public void publicMethodPointcut() {
    }
}
