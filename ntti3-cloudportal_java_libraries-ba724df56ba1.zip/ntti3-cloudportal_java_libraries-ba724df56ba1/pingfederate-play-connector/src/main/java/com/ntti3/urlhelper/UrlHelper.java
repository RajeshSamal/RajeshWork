package com.ntti3.urlhelper;

import play.mvc.Call;

import java.net.MalformedURLException;
import java.net.URL;

public class UrlHelper {
    private final String baseUrl;

    /**
     * @param baseUrl Base url for page. Must end with /
     */
    public UrlHelper(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public URL buildAbsoluteUrl(String path) throws MalformedURLException {
        // we do not want paths beginning with / to be treated as absolute URL
        if (path.startsWith("/")) {
            path = path.substring(1);
        }
        URL base = new URL(baseUrl);
        return new URL(base, path);
    }

    public String absoluteAddress(String path) throws MalformedURLException {
        return buildAbsoluteUrl(path).toString();
    }

    public String absoluteAddress(Call call) throws MalformedURLException {
        return absoluteAddress(call.url());
    }
}
