package com.ntti3.pingfederate.connector;

import com.ntti3.urlhelper.UrlHelper;
import com.google.common.base.Preconditions;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;
import com.pingidentity.opentoken.TokenException;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.http.client.utils.URIBuilder;
import play.Logger;
import play.mvc.Http;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Map;

/**
 * A class integrating PingFederate OpenToken API with Play framework. This
 * class provides methods generating URLs used to communicate with PingFederate
 * OpenToken interface as SP application. Unless application needs connecting to
 * several PF instances, there is no need having more than one instance of this
 * class. It is possible to get the default instance using
 * getDefaultInstance() method of one of its subclasses.
 * <p/>
 * An object of the class needs reading an PF OT agent configuration file before
 * it is ready to use. A class constructor does not try to read config file as
 * it can cause {@link IOException}. It is required to
 * {@link #createAgent()} before using any other method of the object.
 * <p/>
 *
 * @author jan.karwowski@ntti3.com
 * @see SPProtocolHelper
 * @see IdPProtocolHelper
 */
public class ProtocolHelper {

    public static final String CONFIG_FILE_AGENT_CONFIG = "agent-config";
    public static final String CONFIG_FILE_PORT = "port";
    public static final String CONFIG_FILE_HOST = "host";
    public static final String CONFIG_FILE_SCHEME = "scheme";

    private final Agent agent;
    private final AgentConfiguration agentConfiguration;
    private final UrlHelper urlHelper;
    private final String scheme;
    private final String host;
    private final int port;

    protected ProtocolHelper(AgentConfiguration agentConfiguration, Agent agent, String scheme,
                             String host, int port) {
        Logger.debug("Creating {}, with token password: {}", this.getClass().getCanonicalName(), agentConfiguration.getPassword());
        this.agentConfiguration = agentConfiguration;
        this.agent = agent;
        this.scheme = scheme;
        this.host = host;
        this.port = port;
        urlHelper = new UrlHelper(getPFBaseURI().toString());
    }

    public URI getPFBaseURI() {
        try {
            return getBasePFAddress().build();
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Reads a token from POST or GET query parameter, checks its validity and parses
     * it.
     *
     * @param request The http request containing token
     * @return All key&ndash;value pairs contained in the token. If token contains multiple
     * values only first value is in the map. Please use {@link #parseTokenInRequestMulti}
     * for reading multiple values of attribute.
     * @throws TokenException when the token is invalid
     */
    @SuppressWarnings("unchecked")
    public Map<String, String> parseTokenInRequest(Http.Request request) throws TokenException, TokenNotFoundException {
        String token = extractTokenFromRequest(request);
        play.Logger.debug("Token data: " + token);
        Agent agent = new Agent(agentConfiguration);
        return agent.readToken(token);
    }

    /**
     * Reads a token from POST form or GET query parameters, checks its validity and parses
     * key-value pairs.
     *
     * @param request The http request containing a token
     * @return A multi map containing all token attributes
     * @throws TokenException whe token is invalid or expired {@link com.pingidentity.opentoken.TokenExpiredException}
     */
    public Multimap<String, String> parseTokenInRequestMulti(Http.Request request) throws TokenException,
            TokenNotFoundException {
        String token = extractTokenFromRequest(request);

        return readTokenToMultiMap(token);
    }

    // due to poor api -- Agent#readToken returns Map
    // we need to do unchecked cast to Map<String, String>
    @SuppressWarnings("unchecked")
    public Multimap<String, String> readTokenToMultiMap(String token) throws TokenException {
        MultiMap multimap = agent.readTokenToMultiMap(token);
        Logger.debug("Unicode test: í Parsed token: " + multimap);
        Multimap<String, String> ret = HashMultimap.create();

        for (Object key : multimap.keySet()) {
            String k = (String) key;
            Collection<String> vals = (Collection<String>) multimap.get(key);
            ret.putAll(k, vals);
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> readToken(String token) throws TokenException {
        return getAgent().readToken(token);
    }

    public String buildToken(Multimap<String, String> map) throws TokenException {
        MultiMap temp = new MultiValueMap();
        for (String key : map.keySet()) {
            for (String value : map.get(key)) {
                temp.put(key, value);
            }
        }

        Logger.debug("Transformed token: " + temp.toString());
        return agent.writeToken(temp);
    }

    public String buildToken(Map<String, String> map) throws TokenException {
        return agent.writeToken(map);
    }

    /**
     * In some cases, e.g. SLO request PF interface needs to be called using
     * special, one-time path. This method is used to build such path.
     *
     * @param path A path received from PF server
     * @return Absolute URI pointing to the path
     * @throws URISyntaxException When given path is invalid
     */
    public URI buildUrlForPath(String path) throws URISyntaxException {
        return getBasePFAddress().setPath(path).build();
    }

    public String getScheme() {
        return scheme;
    }


    public String getHost() {
        return host;
    }


    public int getPort() {
        return port;
    }

    public Agent getAgent() {
        return agent;
    }

    public UrlHelper getUrlHelper() {
        return urlHelper;
    }

    public AgentConfiguration getAgentConfiguration() {
        return agentConfiguration;
    }

    protected URIBuilder getBasePFAddress() {
        return new URIBuilder()
                .setPort(port)
                .setHost(host)
                .setScheme(scheme);
    }

    protected URIBuilder buildPFUriWithSuccessErrorPaths(String pfPath, String successUrl, String failureUrl) {
        return getBasePFAddress()
                .setPath(pfPath)
                .addParameter(ProtocolConstants.TARGET_RESOURCE_URL_PARAM, successUrl)
                .addParameter(ProtocolConstants.IN_ERROR_RESOURCE_URL_PARAM, failureUrl);
    }

    protected String buildSubjectToken(String subject)
            throws TokenException {
        Map<String, String> tokenParams = Maps.newHashMap();
        tokenParams.put(Agent.TOKEN_SUBJECT, subject);
        return agent.writeToken(tokenParams);
    }

    private String extractTokenFromRequest(Http.Request request) throws TokenNotFoundException {
        if (request.queryString().containsKey(agentConfiguration.getTokenName())) {
            return request.queryString().get(agentConfiguration.getTokenName())[0];
        } else if (request.body().asFormUrlEncoded().containsKey(agentConfiguration.getTokenName())) {
            return request.body().asFormUrlEncoded().get(agentConfiguration.getTokenName())[0];
        } else {
            throw new TokenNotFoundException();
        }
    }

    public class ResumePath {
        private final String path;

        public ResumePath(String path) {
            this.path = Preconditions.checkNotNull(path);
        }

        public String getPath() {
            return path;
        }

        public String getUrl() throws MalformedURLException {
            return getUrlHelper().absoluteAddress(getPath());
        }
    }
}
