package com.ntti3.pingfederate.connector;

import com.google.common.collect.Multimap;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;
import com.pingidentity.opentoken.TokenException;
import play.mvc.Http;
import play.mvc.Result;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

/**
 * Provides support for IdP part of PingFederate OpenToken protocol.
 * <p/>
 */
public class IdPProtocolHelper extends ProtocolHelper {

    IdPProtocolHelper(AgentConfiguration agentConfiguration, Agent agent, String scheme, String host, int port) {
        super(agentConfiguration, agent, scheme, host, port);
    }

    public Result handleRequest(String type, Http.Request request, RequestHandler handler)
            throws ProtocolParametersException, RequestHandlerException {
        return handleRequest(RequestType.fromUrl(type), request, handler);
    }

    public Result handleRequest(RequestType type, Http.Request request, RequestHandler handler)
            throws ProtocolParametersException, RequestHandlerException {
        return type.proccessRequest(this, request, handler);
    }

    public URI buildSsoResponse(String resume, Map<String, String> token)
            throws URISyntaxException, TokenException {
        return buildSsoResponse(resume, getAgent().writeToken(token));
    }

    public URI buildSsoResponse(String resume, Multimap<String, String> token)
            throws URISyntaxException, TokenException {
        return buildSsoResponse(resume, buildToken(token));
    }

    public URI buildSsoErrorResponse(String resume, String error, String message) throws URISyntaxException {
        //TODO error and errorDetail are not supported by PF. How shall we pass those?
        //TODO -- add carrier pidgeon to transport error messages
        return getBasePFAddress()
                .setPath(resume)
                .setParameter("error", error)
                .setParameter("errorDetail", message)
                .build();
    }

    public URI buildSsoResponse(String resume, String token) throws URISyntaxException {
        return getBasePFAddress()
                .setPath(resume)
                .setParameter(getAgentConfiguration().getTokenName(), token)
                .build();
    }

    public URI buildSloUrl(String successUrl, String failureUrl)
            throws TokenException, URISyntaxException {
        return buildPFUriWithSuccessErrorPaths(ProtocolConstants.IDP_START_SLO_PATH, successUrl, failureUrl)
                .setPath(ProtocolConstants.IDP_START_SLO_PATH)
                .build();

    }

    public URI buildStartSsoUrl(String sp, String successUrl, String failureUrl, Multimap<String, String> token)
            throws TokenException, URISyntaxException {
        return getBasePFAddress()
                .setPath(ProtocolConstants.IDP_START_SSO_PATH)
                .setParameter(getAgentConfiguration().getTokenName(), buildToken(token))
                .setParameter(ProtocolConstants.SP_PARTNER_SP_ID, sp)
                .setParameter(ProtocolConstants.TARGET_RESOURCE_URL_PARAM, successUrl)
                .setParameter(ProtocolConstants.IN_ERROR_RESOURCE_URL_PARAM, failureUrl)
                .build();
    }

    public static enum RequestType {
        SSO_REQUEST("ssoHandler", new IdpRequestHandlerCaller() {
            @Override
            public Result processRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException {
                final ResumePath resumePath;
                final String spEntityId;
                resumePath = protocolHelper.new ResumePath(ProtocolParametersHelper
                        .get(request, ProtocolConstants.RESUME_PATH_PARAM));
                spEntityId = ProtocolParametersHelper
                        .get(request, ProtocolConstants.SP_ENTITY_ID_PARAM);
                return handler.ssoRequest(resumePath, spEntityId);
            }
        }),
        SLO_REQUEST("sloHandler", new IdpRequestHandlerCaller() {
            @Override
            public Result processRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException {
                final ResumePath resumePath;
                resumePath = protocolHelper.new ResumePath(ProtocolParametersHelper
                        .get(request, ProtocolConstants.RESUME_PATH_PARAM));
                return handler.sloRequest(resumePath);
            }
        });

        private final String urlName;
        private final IdpRequestHandlerCaller caller;

        private RequestType(String urlName, IdpRequestHandlerCaller caller) {
            this.urlName = urlName;
            this.caller = caller;
        }

        public static RequestType fromUrl(String param) {
            for (RequestType t : values()) {
                if (t.getUrlName().equals(param)) {
                    return t;
                }
            }
            throw new IllegalArgumentException("No such request type: " + param);
        }

        public Result proccessRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                throws RequestHandlerException, ProtocolParametersException {
            return caller.processRequest(protocolHelper, request, handler);
        }

        @Override
        public String toString() {
            return urlName;
        }

        public String getUrlName() {
            return urlName;
        }

        private interface IdpRequestHandlerCaller {
            Result processRequest(ProtocolHelper protocolHelper, Http.Request request, IdPProtocolHelper.RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException;
        }
    }

    public static interface RequestHandler {
        public Result ssoRequest(ResumePath resumePath, String spEntityId) throws RequestHandlerException;

        public Result sloRequest(ResumePath resumePath) throws RequestHandlerException;
    }
}
