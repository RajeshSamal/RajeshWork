package com.ntti3.pingfederate.connector;

import play.mvc.Http;

/**
* @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
*/
public final class ProtocolParametersHelper {

    private ProtocolParametersHelper() {}

    /**
     * Extracts 'key' parameter from the HTTP request's query string. Never returns <code>null</code>.
     * @param request
     * @return 'key' from the query string
     * @throws ProtocolParametersException if 'key' could not be read from query string or is <code>null</code>
     */
    public static String get(Http.Request request, String key) throws ProtocolParametersException {
        final String[] values = request.queryString().get(key);
        if (values == null || values[0] == null) {
            throw new ProtocolParametersException(String.format("No '%s' param supplied", key));
        } else {
            return values[0];
        }
    }
}
