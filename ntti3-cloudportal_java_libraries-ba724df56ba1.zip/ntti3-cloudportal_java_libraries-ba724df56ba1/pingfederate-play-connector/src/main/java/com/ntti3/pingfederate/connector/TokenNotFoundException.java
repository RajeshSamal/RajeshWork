package com.ntti3.pingfederate.connector;

/**
 * Created by jan.karwowski@ntti3.com on 23.01.14.
 */
public class TokenNotFoundException extends Exception {
    public TokenNotFoundException() {
    }

    public TokenNotFoundException(String message) {
        super(message);
    }

    public TokenNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenNotFoundException(Throwable cause) {
        super(cause);
    }

    public TokenNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    @Override
    public String toString() {
        return "TokenNotFoundException: " + getMessage();
    }
}
