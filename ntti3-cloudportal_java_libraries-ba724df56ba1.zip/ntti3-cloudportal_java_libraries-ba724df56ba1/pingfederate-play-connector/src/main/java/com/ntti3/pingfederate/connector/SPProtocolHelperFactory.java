package com.ntti3.pingfederate.connector;

import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;

/**
 * @author jan.karwowski@ntti3.com
 */
public class SPProtocolHelperFactory extends ProtocolHelperFactory<SPProtocolHelper> {
    @Override
    public SPProtocolHelper getInstanceWithAgent(AgentConfiguration agentConfiguration, Agent agent,
                                                 String scheme, String host, int port) {
       return new SPProtocolHelper(agentConfiguration, agent, scheme, host, port);
    }
}
