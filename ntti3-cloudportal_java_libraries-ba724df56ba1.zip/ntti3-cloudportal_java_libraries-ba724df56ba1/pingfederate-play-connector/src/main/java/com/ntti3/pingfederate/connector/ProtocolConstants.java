package com.ntti3.pingfederate.connector;

/**
 * This class contains set of constants which are needed to communicate with
 * PingFederate server through OpenToken protocol.
 *
 * @author jan.karwowski@ntti3.com
 */
public final class ProtocolConstants {
    public static final String TARGET_RESOURCE_URL_PARAM = "TargetResource";
    public static final String IN_ERROR_RESOURCE_URL_PARAM = "InErrorResource";
    public static final String RESUME_PATH_PARAM = "resume";
    public static final String SP_ENTITY_ID_PARAM = "spentity";
    public static final String ERROR_PARAM = "error";
    public static final String ERROR_DETAIL_PARAM = "errorDetail";
    //SP paths
    public static final String SP_START_SSO_PATH = "/sp/startSSO.ping";
    public static final String SP_START_SLO_PATH = "/sp/startSLO.ping";
    public static final String SP_PARTNER_IDP_ID = "PartnerIdpId";
    public static final String SP_PARTNER_SP_ID = "PartnerSpId";
    //IdP paths
    public static final String IDP_START_SLO_PATH = "/idp/startSLO.ping";
    public static final String IDP_START_SSO_PATH = "/idp/startSSO.ping";

}
