package com.ntti3.pingfederate.connector.guice;

import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelperFactory;
import com.google.inject.AbstractModule;

import java.io.IOException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class SPProtocolHelperModule extends AbstractModule {

    private final SPProtocolHelper instance;

    public SPProtocolHelperModule(Map<String, String> configuration) throws IOException {
        instance=new SPProtocolHelperFactory().getInstanceFromConfig(configuration);
    }

    @Override
    protected void configure() {
        bind(SPProtocolHelper.class).toInstance(instance);
    }
}