package com.ntti3.pingfederate.connector;

/**
 * Created by jan.karwowski@ntti3.com on 27.01.14.
 */
public class ProtocolParametersException extends Exception {
    public ProtocolParametersException() {
    }

    public ProtocolParametersException(String message) {
        super(message);
    }

    public ProtocolParametersException(String message, Throwable cause) {
        super(message, cause);
    }

    public ProtocolParametersException(Throwable cause) {
        super(cause);
    }

    public ProtocolParametersException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
