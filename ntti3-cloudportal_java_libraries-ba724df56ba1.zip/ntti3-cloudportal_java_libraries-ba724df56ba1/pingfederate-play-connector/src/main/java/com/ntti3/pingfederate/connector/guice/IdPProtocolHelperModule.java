package com.ntti3.pingfederate.connector.guice;

import com.ntti3.pingfederate.connector.IdPProtocolHelper;
import com.ntti3.pingfederate.connector.IdPProtocolHelperFactory;
import com.google.inject.AbstractModule;

import java.io.IOException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class IdPProtocolHelperModule extends AbstractModule {

    private final IdPProtocolHelper instance;

    public IdPProtocolHelperModule(Map<String, String> configuration) throws IOException {
        instance=new IdPProtocolHelperFactory().getInstanceFromConfig(configuration);
    }

    @Override
    protected void configure() {
        bind(IdPProtocolHelper.class).toInstance(instance);
    }
}
