package com.ntti3.pingfederate.connector;

import com.google.common.collect.Multimap;
import com.pingidentity.opentoken.Agent;
import com.pingidentity.opentoken.AgentConfiguration;
import com.pingidentity.opentoken.TokenException;
import play.Logger;
import play.mvc.Http;
import play.mvc.Result;

import java.net.URI;
import java.net.URISyntaxException;

import static com.ntti3.pingfederate.connector.ProtocolConstants.*;

/**
 * Provides support for SP part of PingFederate OpenToken protocol.
 */
public class SPProtocolHelper extends ProtocolHelper {
    SPProtocolHelper(AgentConfiguration agentConfiguration, Agent agent, String scheme, String host, int port) {
        super(agentConfiguration, agent, scheme, host, port);
    }

    public Result handleRequest(RequestType type, Http.Request request, RequestHandler handler)
            throws TokenException, TokenNotFoundException, ProtocolParametersException, RequestHandlerException {
        return type.proccessRequest(this, request, handler);
    }

    public Result handleRequest(String type, Http.Request request, RequestHandler handler)
            throws TokenException, TokenNotFoundException, ProtocolParametersException, RequestHandlerException {
        return handleRequest(RequestType.fromUrl(type), request, handler);
    }

    public URI buildSsoUrl(String idPId, String successUrl, String failureUrl) {
        try {
            return buildPFUriWithSuccessErrorPaths(SP_START_SSO_PATH, successUrl, failureUrl)
                    .addParameter(ProtocolConstants.SP_PARTNER_IDP_ID, idPId)
                    .build();
        } catch (URISyntaxException e) {
            Logger.error("Error:", e);
            throw new RuntimeException(e);
        }
    }

    public URI buildSloUrl(String subject, String successUrl, String failureUrl)
            throws TokenException, URISyntaxException {
        String token = buildSubjectToken(subject);
        return buildPFUriWithSuccessErrorPaths(SP_START_SLO_PATH, successUrl, failureUrl)
                .setParameter(getAgentConfiguration().getTokenName(), token)
                .build();
    }

    public static enum RequestType {
        SLO_REQUEST("sloHandler", new SpRequestHandlerCaller() {
            @Override
            public Result processRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException {
                return handler.sloRequest(protocolHelper.new ResumePath(ProtocolParametersHelper.get(request, RESUME_PATH_PARAM)));
            }
        }),

        SSO_SUCCESS_HANDLER("ssoHandler", new SpRequestHandlerCaller() {
            @Override
            public Result processRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException, TokenException, TokenNotFoundException {
                Multimap<String, String> token = protocolHelper.parseTokenInRequestMulti(request);
                if (request.queryString().containsKey(RESUME_PATH_PARAM)) {
                    return handler.ssoSuccess(ProtocolParametersHelper.get(request, RESUME_PATH_PARAM), token);
                }
                return handler.ssoSuccess(token);
            }
        }),

        SSO_ERROR_HANDLER("ssoFailure", new SpRequestHandlerCaller() {
            @Override
            public Result processRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException, TokenException, TokenNotFoundException {
                return handler.ssoFailure(ProtocolParametersHelper.get(request, ERROR_PARAM),
                        ProtocolParametersHelper.get(request, ERROR_DETAIL_PARAM));
            }
        });

        private final String urlName;
        private final SpRequestHandlerCaller caller;

        private RequestType(String urlName, SpRequestHandlerCaller caller) {
            this.urlName = urlName;
            this.caller = caller;
        }

        public Result proccessRequest(ProtocolHelper protocolHelper, Http.Request request, RequestHandler handler)
                throws RequestHandlerException, ProtocolParametersException, TokenException, TokenNotFoundException {
            return caller.processRequest(protocolHelper, request, handler);
        }

        public static RequestType fromUrl(String param) {
            for (RequestType t : values()) {
                if (t.getUrlName().equals(param)) {
                    return t;
                }
            }
            throw new IllegalArgumentException("No such request type: " + param);
        }

        @Override
        public String toString() {
            return urlName;
        }

        public String getUrlName() {
            return urlName;
        }

        private interface SpRequestHandlerCaller {
            Result processRequest(ProtocolHelper protocolHelper, Http.Request request, SPProtocolHelper.RequestHandler handler)
                    throws RequestHandlerException, ProtocolParametersException, TokenException, TokenNotFoundException;
        }
    }

    public static interface RequestHandler {
        Result sloRequest(ResumePath resumePath) throws RequestHandlerException;

        Result ssoSuccess(String resumeUrl, Multimap<String, String> token) throws RequestHandlerException;

        Result ssoSuccess(Multimap<String, String> token) throws RequestHandlerException;

        Result ssoFailure(String error, String details) throws RequestHandlerException;
    }

}
