package com.ntti3.pingfederate.connector;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class RequestHandlerException extends Exception {
    public RequestHandlerException() {
        super();
    }

    public RequestHandlerException(String message) {
        super(message);
    }

    public RequestHandlerException(String message, Exception cause) {
        super(message, cause);
    }

    public RequestHandlerException(Exception cause) {
        super(cause);
    }

    @Override
    public synchronized Exception getCause() {
        return (Exception)super.getCause();
    }
}
