package com.ntti3.play.frontend;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;

/**
 * @author jan.karwowski@ntti3.com
 */
public class JsonResponseBuilder {
    public static final String TITLE_JSON_FIELD = "title";
    public static final String TITLE_JSON_MESSAGE = "message";
    public static final String INVALID_FIELDS_JSON_FIELDS = "invalidFields";

    public static JsonNode prepareMessage(String title, String message) {
        ObjectNode response = Json.newObject();
        response.put(TITLE_JSON_FIELD, title);
        response.put(TITLE_JSON_MESSAGE, message);

        return response;
    }

    public static JsonNode prepareErrorMessage(ErrorCode errorCode) {
        return prepareMessage(errorCode.toString(), errorCode.toString());
    }

    public static JsonNode invalidFields(JsonNode errors) {
        ObjectNode response = Json.newObject();
        response.put(INVALID_FIELDS_JSON_FIELDS, errors);

        return response;
    }
}
