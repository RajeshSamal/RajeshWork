package com.ntti3.play.frontend;

/**
 * @author jan.karwowski@ntti3.com
 */
public enum ErrorCode {
    UNAUTHORIZED, TEMPORARY_FAILURE, BAD_REQUEST
}
