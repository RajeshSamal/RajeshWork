package com.ntti3.play.excetions.handling;

import java.util.Map;

import play.mvc.Http;
import play.mvc.SimpleResult;

import com.google.common.collect.Maps;


/**
 * This class performs exception handling with given set of handlers. It is meant to be used with
 * {@link ControllerExceptionSupport.ExceptionHandler}
 *
 * @author jan.karwowski@ntti3.com
 */
public class GlobalExceptionsHandler {
    private Map<Class<? extends Throwable>, ExceptionHandler> handlers = Maps.newHashMap();

    /**
     * Registers handler for exceptions of type {@link ExceptionHandler#getHandledType()}. If handler for this type
     * is already registered it is overwritten.
     * @param handler handler to be registered
     */
    public void registerHandler(ExceptionHandler handler) {
        handlers.put(handler.getHandledType(), handler);
    }

    public SimpleResult handle(Throwable t, Http.Response response) throws Throwable {
        Class<?> type = t.getClass();
        
        if(!(t instanceof Exception))
        	throw t;
        Exception e = (Exception)t;

        do {
            if (handlers.containsKey(type)) {
                ExceptionHandler handler = handlers.get(type);
                return handler.handleException(e, response);
            }
            type = type.getSuperclass();
        } while (type != Object.class);

        throw t;
    }
}
