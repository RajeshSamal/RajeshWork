package com.ntti3.play.excetions.handling;

import play.mvc.Http;
import play.mvc.Results;
import play.mvc.SimpleResult;

import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;

/**
 * @author jan.karwowski@ntti3.com
 */
public class SimpleExceptionHandler implements ExceptionHandler {
    private final Class<? extends Exception> type;
    private final ErrorCode code;
    private final String errorMessage;
    private final int httpCode;

    @Override
    public Class<? extends Exception> getHandledType() {
        return type;
    }

    @Override
    public SimpleResult handleException(Exception exception, Http.Response response) {
        response.setHeader("Content-type", "application/json");
        return Results.status(httpCode, ResponseHelper.errorResponse(code, errorMessage, exception.getMessage()));
    }

	public SimpleExceptionHandler(Class<? extends Exception> type, ErrorCode code, String errorMessage, int httpCode) {
        this.type = type;
        this.code = code;
        this.errorMessage = errorMessage;
        this.httpCode = httpCode;
    }

    public SimpleExceptionHandler(Class<? extends Exception> type, ErrorCode code, String errorMessage) {
        this(type, code, errorMessage, 400);
    }
}
