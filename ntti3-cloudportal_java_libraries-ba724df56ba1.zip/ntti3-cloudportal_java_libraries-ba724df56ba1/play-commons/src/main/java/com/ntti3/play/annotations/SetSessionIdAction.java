package com.ntti3.play.annotations;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import org.slf4j.MDC;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;

import java.util.UUID;

/**
 * This action puts into the {@link play.mvc.Http.Session} an unique session Id
 * (if it is not set yet) and adds the unique session Id to {@link org.slf4j.MDC}
 * allowing to distinguish logs from different sessions.
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SetSessionIdAction extends Action<Void> {

    public static final String DEFAULT_SESSION_ID_KEY = "sessionId";

    private final String sessionIdKey;

    /**
     * Creates the action.
     * @param sessionIdKey The unique session Id is stored in {@link play.mvc.Http.Session}
     *                     and in {@link org.slf4j.MDC} under this key.
     */
    @Inject
    public SetSessionIdAction(@SessionIdKey String sessionIdKey) {
        this.sessionIdKey = Preconditions.checkNotNull(sessionIdKey, "sessionIdKey can not be null");
    }

    public String getSessionIdKey() {
        return sessionIdKey;
    }

    @Override
    public F.Promise<SimpleResult> call(Http.Context context) throws Throwable {
        Http.Session session = context.session();
        final String sessionIdValue;
        if (!session.containsKey(sessionIdKey)) {
            sessionIdValue = UUID.randomUUID().toString();
            session.put(sessionIdKey, sessionIdValue);
        } else {
            sessionIdValue = session.get(sessionIdKey);
        }
        MDC.put(sessionIdKey, sessionIdValue);
        try {
            return delegate.call(context);
        } finally {
            MDC.remove(sessionIdKey);
        }
    }
}
