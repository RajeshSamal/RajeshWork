package com.ntti3.play.annotations;

import play.mvc.Controller;
import play.mvc.Http;

/**
 * @author jan.karwowski@ntti3.com
 */
public class CrossOriginAjaxController extends Controller {
    @SuppressWarnings("unused")
    public String getAllowOrigin(Http.Request request) {
        return "*";
    }

    public boolean isAllowCredentials() {
        return false;
    }
}
