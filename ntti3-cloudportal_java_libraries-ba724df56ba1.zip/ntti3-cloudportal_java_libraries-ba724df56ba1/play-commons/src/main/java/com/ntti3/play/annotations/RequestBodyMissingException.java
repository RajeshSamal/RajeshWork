package com.ntti3.play.annotations;

import play.mvc.BodyParser;

/**
 * @author jan.karwowski@ntti3.com
 */
public class RequestBodyMissingException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private Class<? extends BodyParser> requiredType;

    public RequestBodyMissingException(Class<? extends BodyParser> requiredType) {
        super("Required request body of type "+requiredType.getName()+ " not found");
        this.requiredType = requiredType;
    }

    public Class<? extends BodyParser> getRequiredType() {
        return requiredType;
    }
}
