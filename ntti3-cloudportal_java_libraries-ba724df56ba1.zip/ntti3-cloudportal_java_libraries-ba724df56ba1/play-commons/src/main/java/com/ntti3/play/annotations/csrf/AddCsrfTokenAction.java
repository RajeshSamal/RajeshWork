package com.ntti3.play.annotations.csrf;

import java.util.UUID;

import play.libs.F.Promise;
import play.mvc.Action;
import play.mvc.Http.Context;
import play.mvc.SimpleResult;

public class AddCsrfTokenAction extends Action<AddCsrfToken> {
	@Override
	public Promise<SimpleResult> call(Context ctx) throws Throwable {
		if(!ctx.session().containsKey(configuration.tokenFieldName()))
			ctx.session().put(configuration.tokenFieldName(), UUID.randomUUID().toString());
			
		return delegate.call(ctx);
	}

}
