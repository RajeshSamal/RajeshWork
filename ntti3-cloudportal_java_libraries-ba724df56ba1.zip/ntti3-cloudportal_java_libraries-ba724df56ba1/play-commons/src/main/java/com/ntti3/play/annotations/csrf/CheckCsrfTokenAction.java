package com.ntti3.play.annotations.csrf;

import play.libs.F;
import play.libs.F.Promise;
import play.mvc.Action;
import play.mvc.Results;
import play.mvc.Http.Context;
import play.mvc.SimpleResult;

public class CheckCsrfTokenAction extends Action<CheckCsrfToken> {

	@Override
	public Promise<SimpleResult> call(Context ctx) throws Throwable {
		if(ctx.session().get(configuration.tokenFieldName())== null ||
				! ctx.session().get(configuration.tokenFieldName()).
				equals(ctx.request().getQueryString(configuration.tokenFieldName())))
			return F.Promise.<SimpleResult>pure(Results.unauthorized());
			
		return delegate.call(ctx);
	}
}
