package com.ntti3.play.excetions.handling;

import play.mvc.Http;
import play.mvc.SimpleResult;

/**
 * @author jan.karwowski@ntti3.com
 */
public interface ExceptionHandler {
    Class<? extends Exception> getHandledType();

    SimpleResult handleException(Exception exception, Http.Response response);
}
