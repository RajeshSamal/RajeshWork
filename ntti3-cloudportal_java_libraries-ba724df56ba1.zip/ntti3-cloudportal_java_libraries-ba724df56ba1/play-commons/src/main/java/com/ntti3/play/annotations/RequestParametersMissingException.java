package com.ntti3.play.annotations;

import java.util.List;

import com.google.common.collect.ImmutableList;

public class RequestParametersMissingException extends Exception {
    private static final long serialVersionUID = 2L;

    private final List<String> missingParams;

    public RequestParametersMissingException(Iterable<String> missingParams) {
        this.missingParams = ImmutableList.copyOf(missingParams);
    }

    public RequestParametersMissingException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace,
            Iterable<String> missingParams) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.missingParams = ImmutableList.copyOf(missingParams);
    }

    public RequestParametersMissingException(String message, Throwable cause,
            Iterable<String> missingParams) {
        super(message, cause);
        this.missingParams = ImmutableList.copyOf(missingParams);
    }

    public RequestParametersMissingException(String message,
            Iterable<String> missingParams) {
        super(message);
        this.missingParams = ImmutableList.copyOf(missingParams);
    }

    public RequestParametersMissingException(Throwable cause,
            Iterable<String> missingParams) {
        super(cause);
        this.missingParams = ImmutableList.copyOf(missingParams);
    }

    @Override
    public String toString() {
        return "RequestParametersMissingException [missingParams="
                + missingParams + "]";
    }

    @Override
    public String getMessage() {
        return super.getMessage() +" Missing params: " + missingParams;
    }

    public Iterable<String> getMissingParams() {
        return missingParams;
    }
}
