package com.ntti3.play.data.exceptions;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;


/**
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class ConstraintViolationExceptionWithToString extends ConstraintViolationException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	public ConstraintViolationExceptionWithToString(String message, Set<? extends ConstraintViolation<?>>
            constraintViolations) {
        super(message, constraintViolations);
    }

    public ConstraintViolationExceptionWithToString(Set<? extends ConstraintViolation<?>> constraintViolations) {
        super(constraintViolations);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (ConstraintViolation<?> violation : getConstraintViolations()) {
            sb.append(violation);
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public String getMessage() {
        return super.getMessage() + "\n" + toString();
    }
}
