package com.ntti3.play.annotations;

import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;

/**
 * @author jan.karwowski@ntti3.com
 */
public class NoCacheHeaderAction extends Action<NoCache> {
    @Override
    public F.Promise<SimpleResult> call(Http.Context context) throws Throwable {
        context.response().setHeader(Http.HeaderNames.CACHE_CONTROL,"NO-CACHE");
        return delegate.call(context);
    }
}
