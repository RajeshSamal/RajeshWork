package com.ntti3.aspects.logging;

import com.ntti3.play.build.BuildInfoReader;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import play.Configuration;
import play.Logger;
import play.mvc.Controller;
import play.mvc.Http;

@Aspect
public abstract class PlayLoggingAspect {

    @Pointcut("execution(play.mvc.Result controllers.*.*(..)) && ! execution(* controllers.Reverse*.*(..))")
    public void controllerMethodPointcut() {
    }

    @Pointcut("execution(* play.GlobalSettings+.*(..))")
    public void globalMethodPointcut() {
    }

    @Pointcut("execution(* *$*(..))")
    public void anonymousMethodPointcut() {
    }

    @Pointcut("execution(public * *(..))")
    public void publicMethodPointcut() {
    }

    @Pointcut("")
    public abstract void applicationMethodPointcut();

    @Pointcut("applicationMethodPointcut() && publicMethodPointcut() && ! anonymousMethodPointcut()")
    public void publicApplicationMethodPointcut() {
    }

    @Pointcut("execution(* play.GlobalSettings+.onStart(..))")
    public void onStartPointcut() {
    }

    @Before("controllerMethodPointcut()")
    public void logBeforeControllerMethod(JoinPoint joinPoint) {
        if (Controller.request() != null) {
            String description = pointcutDescription(joinPoint);
            String method = Controller.request().method();
            String uri = Controller.request().uri();
            String header = Controller.request().getHeader(Http.HeaderNames.REFERER);
            String s = Controller.request().remoteAddress();
            Logger.info("Called {} Method: {} Url: {} El referer: {} From: {}",
                    description,
                    method,
                    uri,
                    header,
                    s);
            if (Controller.request().body() != null) {
                Logger.trace("Request body: {}", Controller.request().body());
            }
        } else {
            Logger.error("Request is null!");
        }
    }

    @AfterReturning(pointcut = "controllerMethodPointcut()",
            returning = "result")
    public void logAfterControllerReturn(JoinPoint joinPoint, Object result) {
        final String description = pointcutDescription(joinPoint);
        Logger.debug("Returned from {} Method: {} Url: {} El referer: {} From: {} Response: {}",
                description,
                Controller.request().method(), Controller.request().uri(),
                Controller.request().getHeader(Http.HeaderNames.REFERER),
                Controller.request().remoteAddress(), result);
    }

    @AfterThrowing(pointcut = "controllerMethodPointcut()", throwing = "ex")
    public void logAfterControllerException(JoinPoint joinPoint, Throwable ex) {
        final String description = pointcutDescription(joinPoint);

        if (Controller.request() != null) {
            Logger.error(String.format("Thrown from %s Method: %s Url: %s El referer: %s From: %s",
                    description,
                    Controller.request().method(), Controller.request().uri(),
                    Controller.request().getHeader(Http.HeaderNames.REFERER),
                    Controller.request().remoteAddress()), ex);
        } else {
            Logger.error("Request is null!");
        }
    }

    @Before("publicApplicationMethodPointcut()")
    public void logBeforePublicApplicationMethodPointcut(JoinPoint joinPoint) {
        Logger.trace("Called: {}", pointcutDescription(joinPoint));
    }

    @AfterReturning(pointcut = "publicApplicationMethodPointcut()",
            returning = "result")
    public void logAfterPublicApplicationMethodReturn(JoinPoint joinPoint, Object result) {
        if (result == null) {
            Logger.trace("Returned: {} => {}",
                    pointcutDescription(joinPoint), "null");
        } else {
            final String resultClassName = result.getClass().getSimpleName();
            Logger.trace("Returned: {} => {}: {}",
                    pointcutDescription(joinPoint), resultClassName, result.toString());
        }
    }

    @AfterThrowing(pointcut = "publicApplicationMethodPointcut()", throwing = "ex")
    public void logAfterPublicApplicationMethodException(JoinPoint joinPoint, Throwable ex) {
        Logger.error("Thrown from: {}", pointcutDescription(joinPoint), ex);
    }

    @AfterThrowing(pointcut = "globalMethodPointcut()", throwing = "ex")
    public void globalErrorLogging(JoinPoint joinPoint, Throwable ex) {
        Logger.error("Thrown from " +
                joinPoint.getSignature().toShortString(), ex);
    }

    public abstract String getPathContains();

    @Before("onStartPointcut()")
    public void logConfig() {
        Logger.info("App config: \n {}", Configuration.root().asMap());
        Logger.info("App build info: {}", new BuildInfoReader(getPathContains()).getHumanReadable());
    }

    protected String objectsToString(Object[] objects) {
        String[] objectsStrings = new String[objects.length];
        for (int i = 0; i < objects.length; i++) {
            final Object o = objects[i];
            if (o == null) {
                objectsStrings[i] = "null";
            } else {
                objectsStrings[i] = String.format("%s = %s",
                        o.getClass().getSimpleName(),
                        o.toString());
            }
        }
        return StringUtils.join(objectsStrings, ", ");
    }

    protected String pointcutDescription(JoinPoint joinPoint) {
        final String className = joinPoint.getSignature().getDeclaringType().getSimpleName();
        final String methodName = joinPoint.getSignature().getName();
        final String args = objectsToString(joinPoint.getArgs());
        return String.format("%s.%s(%s)", className, methodName, args);
    }
}

