package com.ntti3.play.excetions.handling;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;

import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;
import play.mvc.With;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ControllerExceptionSupport {
    
    /**
     * 
     * Attaches exception handler to controller/method.
     * The {@link GlobalExceptionsHandler} must be injected in newInstance method of
     * play's Global object.
     * 
     * @see ExceptionHandlingAction#ExceptionHandlingAction(GlobalExceptionsHandler)
     * @author jan.karwowski@ntti3.com
     */
    @With(ExceptionHandlingAction.class)
    @Target({ElementType.TYPE, ElementType.METHOD})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface ExceptionHandler {
    }

    public static class ExceptionHandlingAction extends Action<ExceptionHandler> {
        private final GlobalExceptionsHandler globalExceptionsHandler;

        @Inject
        public ExceptionHandlingAction(GlobalExceptionsHandler globalExceptionsHandler) {
            this.globalExceptionsHandler = Preconditions.checkNotNull(globalExceptionsHandler);
        }

        @Override
        public F.Promise<SimpleResult> call(Http.Context ctx) throws Throwable {
            try {
                return delegate.call(ctx);
            } catch (Throwable t) {
                return F.Promise.pure(globalExceptionsHandler.handle(t, ctx.response()));
            }
        }
    }
}

