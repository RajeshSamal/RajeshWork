package com.ntti3.play.data;

import com.ntti3.play.data.exceptions.ConstraintViolationExceptionWithToString;
import play.data.validation.Validation;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

/**
 * The validator that has exceptions powers of the elder. The only validator that does its work flawlessly and
 * performs the perfectest validation. The validator uses power of ancient ConstraintViolationException to
 * notify thou of validation failure.
 *
 * @author jan.karwowski@ntti3.com
 */
public class PowerValidator {
    public static void validate(Object bean) throws ConstraintViolationException {
        Set<ConstraintViolation<Object>> set = Validation.getValidator().validate(bean);
        if (set.size() > 0)
            throw new ConstraintViolationExceptionWithToString(set);
    }
}
