package com.ntti3.play.annotations;

import play.mvc.With;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Adds Access-Control-* headers to http response to allow X origin ajax requests.
 * 
 * @author jan.karwowski@ntti3.com
 */
@With(CrossOriginAjaxAction.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CrossOriginAjax {
    Class<? extends CrossOriginAjaxController> value() default CrossOriginAjaxController.class;
}
