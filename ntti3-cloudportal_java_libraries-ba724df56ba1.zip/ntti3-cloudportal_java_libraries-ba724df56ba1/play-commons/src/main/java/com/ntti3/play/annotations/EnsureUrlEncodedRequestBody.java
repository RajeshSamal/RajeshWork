package com.ntti3.play.annotations;

import play.mvc.With;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Proceeds only if request contains the body and the body is of type form url encoded.
 * 
 * Throws an expection {@link RequestBodyMissingException}
 * when body is missing or not urlencoded 
 * <p>
 * {@link RequestParametersMissingException} when some parameters are missing
 * 
 * @author jan.karwowski@ntti3.com
 */
@With(EnsureUrlEncodedRequestBodyAction.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface EnsureUrlEncodedRequestBody {
    String[] requiredParams() default {};
}
