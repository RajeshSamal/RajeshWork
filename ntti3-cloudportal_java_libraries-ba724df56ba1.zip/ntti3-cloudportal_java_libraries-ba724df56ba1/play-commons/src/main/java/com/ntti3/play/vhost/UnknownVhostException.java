package com.ntti3.play.vhost;

public class UnknownVhostException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 2L;

    public UnknownVhostException() {
        super();
    }

    public UnknownVhostException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public UnknownVhostException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnknownVhostException(String message) {
        super(message);
    }

    public UnknownVhostException(Throwable cause) {
        super(cause);
    }

}
