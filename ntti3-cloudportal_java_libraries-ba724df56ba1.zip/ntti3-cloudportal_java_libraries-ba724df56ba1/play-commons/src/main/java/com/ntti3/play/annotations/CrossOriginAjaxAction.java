package com.ntti3.play.annotations;

import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;

/**
 * @author jan.karwowski@ntti3.com
 */
public class CrossOriginAjaxAction extends Action<CrossOriginAjax> {
    @Override
    public F.Promise<SimpleResult> call(Http.Context ctx) throws Throwable {
        CrossOriginAjaxController ajaxController = configuration.value().newInstance();
        Http.Request request = ctx.request();
        Http.Response response = ctx.response();

        response.setHeader("access-control-allow-origin", ajaxController.getAllowOrigin(request));
        response.setHeader("access-control-allow-credentials",
                Boolean.toString(ajaxController.isAllowCredentials()));
        if (request.method().equals("OPTIONS")) {
            response.setHeader("access-control-allow-methods", "GET, OPTIONS");
            response.setHeader("access-control-allow-headers", "content-type, accept");
            response.setHeader("access-control-max-age", "1000");

            return F.Promise.<SimpleResult>pure(noContent());
        }

        return delegate.call(ctx);
    }
}
