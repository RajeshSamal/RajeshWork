package com.ntti3.play.annotations;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import play.libs.F;
import play.mvc.Action;
import play.mvc.BodyParser;
import play.mvc.Http;
import play.mvc.SimpleResult;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Sets;

/**
 * @author jan.karwowski@ntti3.com
 */
public class EnsureUrlEncodedRequestBodyAction extends
        Action<EnsureUrlEncodedRequestBody> {
    @Override
    public F.Promise<SimpleResult> call(Http.Context context) throws Throwable {
        if (context.request().body() == null
                || context.request().body().asFormUrlEncoded() == null) {
            throw new RequestBodyMissingException(
                    BodyParser.FormUrlEncoded.class);
        } else if (configuration.requiredParams() != null
                && configuration.requiredParams().length > 0) {
            Map<String, String[]> params = context.request().body()
                    .asFormUrlEncoded();
            Set<String> missingParams = getMissingParams(params,
                    configuration.requiredParams());
            if(! missingParams.isEmpty())
                throw new RequestParametersMissingException(missingParams);
        }

        return delegate.call(context);
    }

    private static Set<String> getMissingParams(Map<String, String[]> params,
            String... requiredParams) {
        return Sets.difference(Sets.newHashSet(Arrays.asList(requiredParams)), Sets.newCopyOnWriteArraySet(Collections2.transform(Collections2.filter(params.entrySet(),
                new Predicate<Map.Entry<String, String[]>>() {

                    @Override
                    public boolean apply(Entry<String, String[]> input) {
                        return input.getValue() != null
                                && input.getValue().length > 0
                                && input.getValue()[0] != null;
                    }
                }), new Function<Map.Entry<String, String[]>, String> () {

                    @Override
                    public String apply(Map.Entry<String, String[]> input) {
                        return input.getKey();
                    }} )));
    }
}
