package com.ntti3.play.annotations.csrf;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import play.mvc.With;

/**
 * Checks if token send in {@link play.mvc.Http.Session} equals the token 
 * sent in request query string. The names of parameters in both query string and 
 * the session is the name specified in {@link #tokenFieldName()}.
 * 
 * If any of tokens is not present or tokens to not match, unauthorized HTTP response is issued
 * instead of calling controller method.
 * 
 * @author jan.karwowski@ntti3.com
 *
 */
@With(CheckCsrfTokenAction.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckCsrfToken {
	String tokenFieldName() default  Constants.TOKEN_NAME;
}
