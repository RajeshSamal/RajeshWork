package com.ntti3.play.vhost;

import java.util.Map;

import play.mvc.Http;
import play.mvc.Http.Request;

import com.google.common.collect.ImmutableMap;

public class VhostInstanceSelector<T> {
    private final Map<String, T> instances;
    
    public VhostInstanceSelector(Map<String, T> map) {
        this.instances = ImmutableMap.copyOf(map);
    }

    public T getInstanceForVhost(String vhost) throws UnknownVhostException {
        if(!instances.containsKey(vhost))
            throw new UnknownVhostException("No vhost configured for "+vhost);
        return instances.get(vhost);
    }
    
    public T getInstanceForVhost(Request request) throws UnknownVhostException {
        if(request.getHeader(Http.HeaderNames.HOST) == null)
            throw new UnknownVhostException("No Host header was sent");
        return getInstanceForVhost(request.getHeader(Http.HeaderNames.HOST));       
    }
}
