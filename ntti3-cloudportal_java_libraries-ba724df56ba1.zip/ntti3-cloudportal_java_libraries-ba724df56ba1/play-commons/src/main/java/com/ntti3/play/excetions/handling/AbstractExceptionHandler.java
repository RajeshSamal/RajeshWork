package com.ntti3.play.excetions.handling;

import com.google.common.base.Preconditions;

import play.Logger;
import play.mvc.Http;
import play.mvc.Results;
import play.mvc.SimpleResult;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class AbstractExceptionHandler<T extends Exception> implements ExceptionHandler {
    private final Class<T> handledType;

    @Override
    public Class<T> getHandledType() {
        return handledType;
    }

    protected AbstractExceptionHandler(Class<T> handledType) {
        this.handledType = Preconditions.checkNotNull(handledType);
    }

    @Override
    // GlobalException Handler will call this method only when exception can be cast to T
    @SuppressWarnings("unchecked")
    public SimpleResult handleException(Exception exception, Http.Response response) {
        if(!handledType.isAssignableFrom(exception.getClass())) {
            Logger.error("Bad exception type, expected: "+ handledType.getClass(), exception);
            return Results.internalServerError("Bad exception type");
        }
        return handleExceptionWithType((T) exception, response);
    }

    protected abstract SimpleResult handleExceptionWithType(T exception, Http.Response response);
}
