package com.ntti3.play.annotations.csrf;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import play.mvc.With;

/**
 * 
 * The token must be explicitly send to client in controller code.
 * The token is stored under name given in {@link #tokenFieldName()}
 * in play {@link play.mvc.Http.Session}.
 * Client code must send token to to controllers which're using {@link CheckCsrfToken}
 * in http query parameter.
 * 
 * @author jan.karwowski@ntti3.com
 *
 */
@With(AddCsrfTokenAction.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface AddCsrfToken {
	String tokenFieldName() default Constants.TOKEN_NAME;
}
