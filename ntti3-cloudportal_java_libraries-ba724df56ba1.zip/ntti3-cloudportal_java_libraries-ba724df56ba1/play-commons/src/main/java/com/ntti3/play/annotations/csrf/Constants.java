package com.ntti3.play.annotations.csrf;

public class Constants {
	public static final String TOKEN_NAME = "csrfToken";
}
