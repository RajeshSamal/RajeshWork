package com.ntti3.play.excetions.handling;

import org.junit.Test;
import play.mvc.Http;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GlobalExceptionsHandlerTest {
    public static class Exception1 extends Exception {
    }

    public static class Exception2 extends Exception1 {
    }

    @Test
    public void testFindHadler() throws Throwable {
        GlobalExceptionsHandler globalHandler = new GlobalExceptionsHandler();
        AbstractExceptionHandler<Exception1> handler = mock(AbstractExceptionHandler.class);
        when(handler.getHandledType()).thenReturn(Exception1.class);
        when(handler.handleException(any(Exception.class), any(Http.Response.class))).thenReturn(null);

        globalHandler.registerHandler(handler);

        Exception2 ex = new Exception2();
        globalHandler.handle(ex, null);

        verify(handler).handleException(ex, null);
    }

    @Test(expected = NullPointerException.class)
    public void testHandlerNotFound() throws Throwable {
        GlobalExceptionsHandler globalHandler = new GlobalExceptionsHandler();
        AbstractExceptionHandler<Exception1> handler = mock(AbstractExceptionHandler.class);
        when(handler.getHandledType()).thenReturn(Exception1.class);
        when(handler.handleException(any(Exception.class), any(Http.Response.class))).thenReturn(null);

        globalHandler.registerHandler(handler);
        globalHandler.handle(new NullPointerException(), null);
    }
}
