package com.ntti3.play.annotations;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Http.Context;
import play.mvc.Http.RequestBody;


public class EnsureUrlEncodedRequestBodyActionTest {

    Action<?> innerAction;
    EnsureUrlEncodedRequestBodyAction action;
    Http.RequestBody body;
    
    @Before
    public void setUp() {
        body = Mockito.mock(RequestBody.class);
        innerAction = Mockito.mock(Action.class);
        try {
            Mockito.when(innerAction.call(Mockito.any(Context.class))).thenReturn(null);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        
        action = new EnsureUrlEncodedRequestBodyAction();
        action.delegate=innerAction;
    }
    
    @Test(expected = RequestBodyMissingException.class)
    public void testNoBody() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(null);
        
        action.call(context);
    }
    
    @Test(expected = RequestBodyMissingException.class)
    public void testBadBody() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Mockito.when(body.asFormUrlEncoded()).thenReturn(null);
                
        action.call(context);
    }
    
    @Test
    public void testGoodBody() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Mockito.when(body.asFormUrlEncoded()).thenReturn(new HashMap<String, String[]>());
                
        action.call(context);
        
        Mockito.verify(body, Mockito.atLeast(1)).asFormUrlEncoded();
        Mockito.verify(action.configuration, Mockito.atLeast(1)).requiredParams();
    }
    
    @Test(expected = RequestParametersMissingException.class)
    public void testGoodBodyWithoutParams() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {"a","b","c"});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Mockito.when(body.asFormUrlEncoded()).thenReturn(new HashMap<String, String[]>());
                
        action.call(context);
    }
    
    @Test
    public void testGoodBodyParamsOk() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {"a","b","c"});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Map<String, String[]> map = new HashMap<>();
        map.put("a", new String[]{"v"});
        map.put("b", new String[]{"v"});
        map.put("c", new String[]{"v"});
        map.put("d", new String[]{"v"});
        Mockito.when(body.asFormUrlEncoded()).thenReturn(map);
                
        action.call(context);
        
        Mockito.verify(body, Mockito.atLeast(1)).asFormUrlEncoded();
        Mockito.verify(action.configuration, Mockito.atLeast(1)).requiredParams();
    }
    
    @Test(expected = RequestParametersMissingException.class)
    public void testOneParamMissing() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {"a","b","c"});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Map<String, String[]> map = new HashMap<>();
        map.put("a", new String[]{"v"});
        map.put("b", new String[]{"v"});
        map.put("d", new String[]{"v"});
        Mockito.when(body.asFormUrlEncoded()).thenReturn(map);
                
        action.call(context);
        
        Mockito.verify(body, Mockito.atLeast(1)).asFormUrlEncoded();
        Mockito.verify(action.configuration, Mockito.atLeast(1)).requiredParams();
    }
    
    @Test(expected = RequestParametersMissingException.class)
    public void testOneParamNull() throws Throwable {
        action.configuration = Mockito.mock(EnsureUrlEncodedRequestBody.class);
        Mockito.when(action.configuration.requiredParams()).thenReturn(new String[] {"a","b","c"});
        
        Http.Context context = Mockito.mock(Http.Context.class, Mockito.RETURNS_DEEP_STUBS);
        Mockito.when(context.request().body()).thenReturn(body);
        Map<String, String[]> map = new HashMap<>();
        map.put("a", new String[]{"v"});
        map.put("b", new String[]{"v"});
        map.put("c", new String[]{null});
        Mockito.when(body.asFormUrlEncoded()).thenReturn(map);
                
        action.call(context);
        
        Mockito.verify(body, Mockito.atLeast(1)).asFormUrlEncoded();
        Mockito.verify(action.configuration, Mockito.atLeast(1)).requiredParams();
    }
}
