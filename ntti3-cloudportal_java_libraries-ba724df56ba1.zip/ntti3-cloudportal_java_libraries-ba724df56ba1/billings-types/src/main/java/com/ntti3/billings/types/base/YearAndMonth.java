package com.ntti3.billings.types.base;

import com.google.common.base.Preconditions;

/**
 * @author Tomasz Roda (tomasz.roda@codilime.com)
 */
public class YearAndMonth {

    private final int year;
    private final int month;

    private YearAndMonth(int year, int month) {
        this.year = year;
        this.month = month;
        verify();
    }

    private void verify() {
        Preconditions.checkArgument(month >= 1, "Month must be greater or equal 1!");
        Preconditions.checkArgument(month <= 12, "Month must be less or equal 12!");
    }

    public static YearAndMonth fromInts(int year, int month) {
        return new YearAndMonth(year, month);
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    @Override
    public String toString() {
        return "YearAndMonth{" +
                "year=" + year +
                ", month=" + month +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        YearAndMonth that = (YearAndMonth) o;

        return month == that.month && year == that.year;

    }

    @Override
    public int hashCode() {
        int result = year;
        result = 31 * result + month;
        return result;
    }
}
