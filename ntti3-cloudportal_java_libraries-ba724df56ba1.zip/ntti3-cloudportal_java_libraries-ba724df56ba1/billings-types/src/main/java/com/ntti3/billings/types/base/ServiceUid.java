package com.ntti3.billings.types.base;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Each service has to be added here manually.
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum ServiceUid {

    PLN("PLN", "Plan"),
    MGR("MGR", "Migrate"),
    DVP("DVP", "Develop");

    private final String textRepresentation;
    private final String serviceName;

    private ServiceUid(String textRepresentation, String serviceName) {
        this.textRepresentation = textRepresentation;
        this.serviceName = serviceName;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public String getServiceName() {
        return serviceName;
    }

    public static ServiceUid fromString(String str) {
        for (ServiceUid serviceUid : values()) {
            if (serviceUid.getTextRepresentation().equals(str)) {
                return serviceUid;
            }
        }
        throw new IllegalArgumentException("unrecognized service unique ID for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }

    public final static class ServiceUidJsonSerializer extends StdSerializer<ServiceUid> {

        public ServiceUidJsonSerializer() {
            super(ServiceUid.class);
        }

        @Override
        public void serialize(ServiceUid value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
            jgen.writeStartObject();
            jgen.writeFieldName("uid");
            jgen.writeString(value.getTextRepresentation());
            jgen.writeFieldName("name");
            jgen.writeString(value.getServiceName());
            jgen.writeEndObject();
        }
    }
}
