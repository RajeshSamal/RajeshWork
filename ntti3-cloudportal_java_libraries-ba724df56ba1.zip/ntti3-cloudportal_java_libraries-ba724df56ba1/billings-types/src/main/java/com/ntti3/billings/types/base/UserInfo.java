package com.ntti3.billings.types.base;

import com.google.common.base.Preconditions;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public final class UserInfo {

    public static final class Builder {

        private String firstName;
        private String lastName;
        private String companyName;
        private OpcoUid opcoUid;
        private OpcoCustomerUid opcoCustomerUid;
        private OpcoUserUid opcoUserUid;

        public UserInfo build() {
            return new UserInfo(this);
        }

        public Builder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder companyName(String companyName) {
            this.companyName = companyName;
            return this;
        }

        public Builder opcoUid(OpcoUid opcoUid) {
            this.opcoUid = opcoUid;
            return this;
        }

        public Builder opcoCustomerUid(OpcoCustomerUid opcoCustomerUid) {
            this.opcoCustomerUid = opcoCustomerUid;
            return this;
        }

        public Builder opcoUserUid(OpcoUserUid opcoUserUid) {
            this.opcoUserUid = opcoUserUid;
            return this;
        }
    }

    private final String firstName;
    private final String lastName;
    private final String companyName;
    private final OpcoUid opcoUid;
    private final OpcoCustomerUid opcoCustomerUid;
    private final OpcoUserUid opcoUserUid;

    public static Builder builder() {
        return new Builder();
    }

    private UserInfo(Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.companyName = builder.companyName;
        this.opcoUid = builder.opcoUid;
        this.opcoCustomerUid = builder.opcoCustomerUid;
        this.opcoUserUid = builder.opcoUserUid;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(this.firstName, "First name must not be null");
        Preconditions.checkNotNull(this.lastName, "Last name must not be null");
        Preconditions.checkNotNull(this.companyName, "Company name must not be null");
        Preconditions.checkNotNull(this.opcoUid, "OpcoUid name must not be null");
        Preconditions.checkNotNull(this.opcoCustomerUid, "OpcoCustomerUid name must not be null");
        Preconditions.checkNotNull(this.opcoUserUid, "OpcoUserUid name must not be null");
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public OpcoUid getOpcoUid() {
        return opcoUid;
    }

    public OpcoCustomerUid getOpcoCustomerUid() {
        return opcoCustomerUid;
    }

    public OpcoUserUid getOpcoUserUid() {
        return opcoUserUid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserInfo userInfo = (UserInfo) o;

        if (companyName != null ? !companyName.equals(userInfo.companyName) : userInfo.companyName != null)
            return false;
        if (opcoCustomerUid != null ? !opcoCustomerUid.equals(userInfo.opcoCustomerUid) : userInfo.opcoCustomerUid != null)
            return false;
        if (opcoUid != null ? !opcoUid.equals(userInfo.opcoUid) : userInfo.opcoUid != null)
            return false;
        if (opcoUserUid != null ? !opcoUserUid.equals(userInfo.opcoUserUid) : userInfo.opcoUserUid != null)
            return false;
        if (firstName != null ? !firstName.equals(userInfo.firstName) : userInfo.firstName != null) return false;
        if (lastName != null ? !lastName.equals(userInfo.lastName) : userInfo.lastName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = firstName != null ? firstName.hashCode() : 0;
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        result = 31 * result + (opcoUid != null ? opcoUid.hashCode() : 0);
        result = 31 * result + (opcoCustomerUid != null ? opcoCustomerUid.hashCode() : 0);
        result = 31 * result + (opcoUserUid != null ? opcoUserUid.hashCode() : 0);
        return result;
    }
}
