package com.ntti3.billings.types.base;

import com.fasterxml.jackson.annotation.JsonValue;
import com.google.common.base.Preconditions;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Embeddable
@Immutable
public final class OpcoUid implements Serializable {

    public static final int MAX_LENGTH = 64;

    @Column(length = MAX_LENGTH)
    private final String value;

    public static OpcoUid fromString(String str) {
        return new OpcoUid(str);
    }

    private OpcoUid(String value) {
        this.value = value;
        verify();
    }

    private OpcoUid() {
        this.value = null;
    }

    private void verify() {
        Preconditions.checkNotNull(value, "OpcoUid value must not be null!");
        Preconditions.checkArgument(value.length() <= MAX_LENGTH,
                String.format("OpcoUid value must not exceed %d characters", MAX_LENGTH));
    }

    @JsonValue(true)
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpcoUid opcoUid = (OpcoUid) o;

        return !(value != null ? !value.equals(opcoUid.value) : opcoUid.value != null);

    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }
}
