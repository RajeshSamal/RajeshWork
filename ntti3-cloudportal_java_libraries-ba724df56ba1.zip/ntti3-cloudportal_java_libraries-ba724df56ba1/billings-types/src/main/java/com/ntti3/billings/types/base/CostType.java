package com.ntti3.billings.types.base;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum CostType {

    PAID("paid"),
    UNPAID("unpaid");

    private final String textRepresentation;

    private CostType(String textRepresentation) {
        this.textRepresentation = textRepresentation;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public static CostType fromString(String str) {
        for (CostType costType : values()) {
            if (costType.getTextRepresentation().equals(str)) {
                return costType;
            }
        }
        throw new IllegalArgumentException("unrecognized cost type for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }
}
