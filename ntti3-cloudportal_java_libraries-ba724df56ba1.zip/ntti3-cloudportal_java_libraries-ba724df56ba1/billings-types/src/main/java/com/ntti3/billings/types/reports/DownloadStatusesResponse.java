package com.ntti3.billings.types.reports;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.http.annotation.Immutable;

import java.util.Collection;
import java.util.Collections;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class DownloadStatusesResponse {
    private final Collection<UsageReportDownloadStatus> downloadStatuses;

    @JsonCreator
    public DownloadStatusesResponse(
            @JsonProperty(value = "download_statuses")
            Collection<UsageReportDownloadStatus> downloadStatuses) {
        this.downloadStatuses = downloadStatuses;
    }

    public Collection<UsageReportDownloadStatus> getDownloadStatuses() {
        return Collections.unmodifiableCollection(downloadStatuses);
    }
}
