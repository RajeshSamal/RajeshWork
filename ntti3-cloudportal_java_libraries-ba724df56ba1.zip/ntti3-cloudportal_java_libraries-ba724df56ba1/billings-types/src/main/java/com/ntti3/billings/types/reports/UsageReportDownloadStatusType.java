package com.ntti3.billings.types.reports;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum UsageReportDownloadStatusType {

    // The order here is important for sorting!
    OK("ok"),
    FAILED("failed"),
    PENDING("pending");

    private final String textRepresentation;

    UsageReportDownloadStatusType(String textRepresentation) {
        this.textRepresentation = textRepresentation;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public static UsageReportDownloadStatusType fromString(String str) {
        for (UsageReportDownloadStatusType usageReportDownloadStatusType : values()) {
            if (usageReportDownloadStatusType.getTextRepresentation().equals(str)) {
                return usageReportDownloadStatusType;
            }
        }
        throw new IllegalArgumentException("unrecognized UsageReportDownloadStatusType for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }

    public final static class UsageReportDownloadStatusTypeJsonSerializer extends JsonSerializer<UsageReportDownloadStatusType> {
        @Override
        public void serialize(UsageReportDownloadStatusType value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
            jgen.writeString(value.toString());
        }
    }

    public final static class UsageReportDownloadStatusTypeJsonDeserializer extends JsonDeserializer<UsageReportDownloadStatusType> {
        @Override
        public UsageReportDownloadStatusType deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
            String stringValue = jp.getValueAsString();
            for (UsageReportDownloadStatusType usageReportDownloadStatusType : values()) {
                if (usageReportDownloadStatusType.getTextRepresentation().equals(stringValue)) {
                    return usageReportDownloadStatusType;
                }
            }
            throw new IllegalArgumentException("unrecognized UsageReportDownloadStatusType for '" + stringValue + "'");
        }
    }
}
