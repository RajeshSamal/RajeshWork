package com.ntti3.billings.types.base;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum Status {

    P("P", "pending"),
    B("B", "busy"),
    D("D", "done"),
    F("F", "failed");

    private final String textRepresentation;
    private final String humanReadableRepresentation;

    private Status(String textRepresentation, String humanReadableRepresentation) {
        this.textRepresentation = textRepresentation;
        this.humanReadableRepresentation = humanReadableRepresentation;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public String getHumanReadableRepresentation() {
        return humanReadableRepresentation;
    }

    public static Status fromString(String str) {
        for (Status status : values()) {
            if (status.getTextRepresentation().equals(str)) {
                return status;
            }
        }
        throw new IllegalArgumentException("unrecognized status for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }
}
