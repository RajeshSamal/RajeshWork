package com.ntti3.billings.types.base;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum Currency {

    USD("USD");

    private final String textRepresentation;

    private Currency(String textRepresentation) {
        this.textRepresentation = textRepresentation;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public static Currency fromString(String str) {
        for (Currency currency : values()) {
            if (currency.getTextRepresentation().equals(str)) {
                return currency;
            }
        }
        throw new IllegalArgumentException("unrecognized currency for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }
}
