package com.ntti3.billings.types.base;

import com.google.common.base.Preconditions;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Embeddable
@Immutable
public final class UserGuid implements Serializable {

    private static final int MAX_LENGTH = 64;

    @Column(length = MAX_LENGTH)
    private final String value;

    public static UserGuid fromString(String str) {
        return new UserGuid(str);
    }

    private UserGuid(String value) {
        this.value = value;
        verify();
    }

    private UserGuid() {
        this.value = null;
    }

    private void verify() {
        Preconditions.checkNotNull(value, "UserGuid value must not be null!");
        Preconditions.checkArgument(value.length() <= MAX_LENGTH,
                String.format("UserGuid value must not exceed %d characters", MAX_LENGTH));
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserGuid userGuid = (UserGuid) o;

        return !(value != null ? !value.equals(userGuid.value) : userGuid.value != null);

    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }
}
