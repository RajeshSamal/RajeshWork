package com.ntti3.billings.types.base;

import com.google.common.base.Preconditions;


import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Embeddable
@Immutable
public final class UsageUid implements Serializable {

    public static final int MAX_LENGTH = 64;

    // XXX: do not remove! hack for bug in Ebean library ( https://github.com/ebean-orm/avaje-ebeanorm/issues/67 )
    @Column(name = "usage_uid", length = MAX_LENGTH)
    private final String value;

    public static UsageUid fromString(String str) {
        return new UsageUid(str);
    }

    private UsageUid(String value) {
        this.value = value;
        verify();
    }

    private UsageUid() {
        this.value = null;
    }

    private void verify() {
        Preconditions.checkNotNull(value, "UsageUid value must not be null!");
        Preconditions.checkArgument(value.length() <= MAX_LENGTH,
                String.format("UsageUid value must not exceed %d characters", MAX_LENGTH));
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UsageUid usageUid = (UsageUid) o;

        return !(value != null ? !value.equals(usageUid.value) : usageUid.value != null);

    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }
}
