package com.ntti3.billings.types.reports;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import org.joda.time.DateTime;
import com.ntti3.billings.types.base.ServiceUid;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class UsageReportDownloadStatus {

    private static class Builder {

        private OpcoUid opcoUid;
        private ServiceUid serviceUid;
        private Integer year;
        private Integer month;
        private DateTime downloadTime;
        private ReportType reportType;
        private UsageReportDownloadStatusType usageReportDownloadStatusType;

        public Builder opcoUid(OpcoUid opcoUid) {
            this.opcoUid = opcoUid;
            return this;
        }

        public Builder serviceUid(ServiceUid serviceUid) {
            this.serviceUid = serviceUid;
            return this;
        }
    
        
        public Builder year(Integer year) {
            this.year = year;
            return this;
        }

        public Builder month(Integer month) {
            this.month = month;
            return this;
        }

        public Builder downloadTime(DateTime downloadTime) {
            this.downloadTime = downloadTime;
            return this;
        }

        public Builder reportType(ReportType reportType) {
            this.reportType = reportType;
            return this;
        }

        public Builder usageReportDownloadStatusType(UsageReportDownloadStatusType usageReportDownloadStatusType) {
            this.usageReportDownloadStatusType = usageReportDownloadStatusType;
            return this;
        }

        public UsageReportDownloadStatus build() {
            return new UsageReportDownloadStatus(this);
        }
    }

    public static final String OPCO_UID = "opco_uid";
    public static final String SERVICE_UID = "service_uid";
    public static final String YEAR = "year";
    public static final String MONTH = "month";
    public static final String DOWNLOAD_TIME = "download_time";
    public static final String REPORT_TYPE = "report_type";
    public static final String USAGE_REPORT_DOWNLOAD_STATUS_TYPE = "status";

    @JsonIgnore
    private final OpcoUid opcoUid;

    @JsonProperty(value = OPCO_UID, required = true)
    private String getOpcoUidAsString() {
        return opcoUid.toString();
    }

    @JsonProperty(value = SERVICE_UID, required = true)
    private final ServiceUid serviceUid;

    @JsonProperty(value = YEAR, required = true)
    private final Integer year;

    @JsonProperty(value = MONTH, required = true)
    private final Integer month;

    @JsonIgnore
    private final DateTime downloadTime;

    @JsonProperty(value = DOWNLOAD_TIME, required = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String getDownloadTimeAsString() {
        if (downloadTime == null) {
            return null;
        } else {
            return downloadTime.toString();
        }
    }

    @JsonProperty(value = REPORT_TYPE, required = true)
    @JsonSerialize(using = ReportType.ReportTypeJsonSerializer.class)
    private final ReportType reportType;

    @JsonProperty(value = USAGE_REPORT_DOWNLOAD_STATUS_TYPE, required = true)
    @JsonSerialize(using = UsageReportDownloadStatusType.UsageReportDownloadStatusTypeJsonSerializer.class)
    private final UsageReportDownloadStatusType usageReportDownloadStatusType;

    public static Builder builder() {
        return new Builder();
    }

    private UsageReportDownloadStatus(Builder builder) {
        this.opcoUid = builder.opcoUid;
        this.serviceUid = builder.serviceUid;
        this.year = builder.year;
        this.month = builder.month;
        this.reportType = builder.reportType;
        this.downloadTime = builder.downloadTime;
        if (downloadTime == null) {
            this.usageReportDownloadStatusType = UsageReportDownloadStatusType.PENDING;
        } else {
            this.usageReportDownloadStatusType = builder.usageReportDownloadStatusType;
        }

        verify();
    }

    // Constructor for deserialization from Json
    @JsonCreator
    public UsageReportDownloadStatus(
            @JsonProperty(value = OPCO_UID)
            String opcoUid,

            @JsonProperty(value = SERVICE_UID)
            String serviceUid,

            @JsonProperty(value = YEAR)
            Integer year,

            @JsonProperty(value = MONTH)
            Integer month,

            @JsonProperty(value = DOWNLOAD_TIME, required = false)
            String downloadTime,

            @JsonProperty(value = REPORT_TYPE)
            @JsonDeserialize(using = ReportType.ReportTypeJsonDeserializer.class)
            ReportType reportType,

            @JsonProperty(value = USAGE_REPORT_DOWNLOAD_STATUS_TYPE)
            @JsonDeserialize(using = UsageReportDownloadStatusType.UsageReportDownloadStatusTypeJsonDeserializer.class)
            UsageReportDownloadStatusType usageReportDownloadStatusType) {

        this.opcoUid = OpcoUid.fromString(opcoUid);
        this.serviceUid = ServiceUid.fromString(serviceUid);
        this.year = year;
        this.month = month;
        if (downloadTime == null) {
            this.downloadTime = null;
        } else {
            this.downloadTime = DateTime.parse(downloadTime);
        }
        this.reportType = reportType;
        this.usageReportDownloadStatusType = usageReportDownloadStatusType;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(opcoUid, "OpcoUid must not be null");
        Preconditions.checkNotNull(serviceUid, "ServiceUid must not be null");
        Preconditions.checkNotNull(reportType, "ReportType must not be null");
        Preconditions.checkNotNull(year, "Year must not be null");
        Preconditions.checkNotNull(month, "Month must not be null");
        Preconditions.checkNotNull(usageReportDownloadStatusType, "UsageReportDownloadStatusType must not be null");

        // p->q  <=> ~q v p
        Preconditions.checkState(
                usageReportDownloadStatusType != UsageReportDownloadStatusType.PENDING || downloadTime == null,
                "Pending report can not have download time!");

        Preconditions.checkState(
                usageReportDownloadStatusType == UsageReportDownloadStatusType.PENDING || downloadTime != null,
                "Failed/Downloaded reports must have download time!");
    }


    public static UsageReportDownloadStatus pending(OpcoUid opcoUid, ServiceUid serviceUid, Integer year,
                                                    Integer month, ReportType reportType) {
        return getUsageReportDownloadStatusBuilder(opcoUid, serviceUid, year, month, reportType).build();

    }

    public static UsageReportDownloadStatus downloaded(OpcoUid opcoUid, ServiceUid serviceUid, Integer year,
                                                       Integer month, DateTime downloadTime,
                                                       ReportType reportType) {
        return getUsageReportDownloadStatusBuilder(opcoUid, serviceUid, year, month, reportType)
                .downloadTime(downloadTime)
                .usageReportDownloadStatusType(UsageReportDownloadStatusType.OK)
                .build();
    }

    public static UsageReportDownloadStatus failed(OpcoUid opcoUid, ServiceUid serviceUid, Integer year,
                                                   Integer month, DateTime downloadTime,
                                                   ReportType reportType) {
        return getUsageReportDownloadStatusBuilder(opcoUid, serviceUid, year, month, reportType)
                .downloadTime(downloadTime)
                .usageReportDownloadStatusType(UsageReportDownloadStatusType.FAILED)
                .build();
    }

    private static Builder getUsageReportDownloadStatusBuilder(OpcoUid opcoUid, ServiceUid serviceUid, Integer year, Integer month, ReportType reportType) {
        return UsageReportDownloadStatus.builder()
                .opcoUid(opcoUid)
                .serviceUid(serviceUid)
                .year(year)
                .month(month)
                .reportType(reportType);
    }

    public OpcoUid getOpcoUid() {
        return opcoUid;
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getMonth() {
        return month;
    }

    public DateTime getDownloadTime() {
        return downloadTime;
    }

    public ReportType getReportType() {
        return reportType;
    }

    public UsageReportDownloadStatusType getUsageReportDownloadStatusType() {
        return usageReportDownloadStatusType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UsageReportDownloadStatus that = (UsageReportDownloadStatus) o;

        if (usageReportDownloadStatusType != that.usageReportDownloadStatusType) return false;
        // Notice: using getMillis()
        if (downloadTime != null && that.downloadTime != null && downloadTime.getMillis() != that.downloadTime.getMillis()) return false;
        if ((downloadTime != null && that.downloadTime == null) || (downloadTime == null && that.downloadTime != null)) return false;
        if (month != null ? !month.equals(that.month) : that.month != null) return false;
        if (opcoUid != null ? !opcoUid.equals(that.opcoUid) : that.opcoUid != null) return false;
        if (reportType != that.reportType) return false;
        if (serviceUid != that.serviceUid) return false;
        if (year != null ? !year.equals(that.year) : that.year != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = opcoUid != null ? opcoUid.hashCode() : 0;
        result = 31 * result + (serviceUid != null ? serviceUid.hashCode() : 0);
        result = 31 * result + (year != null ? year.hashCode() : 0);
        result = 31 * result + (month != null ? month.hashCode() : 0);
        // Notice: using getMillis()
        result = 31 * result + (downloadTime != null ? (int)downloadTime.getMillis() : 0);
        result = 31 * result + (reportType != null ? reportType.hashCode() : 0);
        result = 31 * result + (usageReportDownloadStatusType != null ? usageReportDownloadStatusType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UsageReportDownloadStatus{" +
                "opcoUid=" + opcoUid +
                ", serviceUid=" + serviceUid +
                ", year=" + year +
                ", month=" + month +
                ", downloadTime=" + downloadTime +
                ", reportType=" + reportType +
                ", usageReportDownloadStatusType=" + usageReportDownloadStatusType +
                "}\n";
    }
}
