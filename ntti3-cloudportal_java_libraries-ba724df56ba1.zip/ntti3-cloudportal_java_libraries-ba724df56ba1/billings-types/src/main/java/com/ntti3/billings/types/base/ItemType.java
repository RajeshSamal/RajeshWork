package com.ntti3.billings.types.base;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum ItemType {

    SCC("StorageCloudCost"),
    JCC("JobCloudCost");

    private final String textRepresentation;

    private ItemType(String textRepresentation) {
        this.textRepresentation = textRepresentation;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public static ItemType fromString(String str) {
        for (ItemType itemType : values()) {
            if (itemType.getTextRepresentation().equals(str)) {
                return itemType;
            }
        }
        throw new IllegalArgumentException("unrecognized item type for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }
}
