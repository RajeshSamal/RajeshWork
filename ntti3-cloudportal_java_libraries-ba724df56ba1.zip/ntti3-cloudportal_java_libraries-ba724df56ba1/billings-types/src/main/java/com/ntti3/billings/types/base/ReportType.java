package com.ntti3.billings.types.base;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum ReportType {

    CS("customer_summary", "CS", "Customer Summary Report"),
    SPS("service_provider_summary", "SPS", "Service Provider Summary Report");

    private final String jsonValue;
    private final String textRepresentation;
    private final String humanReadableName;

    private ReportType(String jsonValue, String textRepresentation, String humanReadableName) {
        this.jsonValue = jsonValue;
        this.textRepresentation = textRepresentation;
        this.humanReadableName = humanReadableName;
    }

    public String getTextRepresentation() {
        return textRepresentation;
    }

    public String getHumanReadableName() {
        return humanReadableName;
    }

    public static ReportType fromString(String str) {
        for (ReportType reportType : values()) {
            if (reportType.getTextRepresentation().equals(str)) {
                return reportType;
            }
        }
        throw new IllegalArgumentException("unrecognized report type for '" + str + "'");
    }

    @Override
    public String toString() {
        return getTextRepresentation();
    }

    public String getJsonValue() {
        return jsonValue;
    }

    public static final class ReportTypeJsonSerializer extends JsonSerializer<ReportType> {
        @Override
        public void serialize(ReportType value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
            jgen.writeString(value.getJsonValue());
        }
    }

    public static final class ReportTypeJsonDeserializer extends JsonDeserializer<ReportType> {
        @Override
        public ReportType deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
            String stringValue = jp.getValueAsString();
            for (ReportType reportType : values()) {
                if (reportType.getJsonValue().equals(stringValue)) {
                    return reportType;
                }
            }
            throw new IllegalArgumentException("unrecognized report type for '" + stringValue + "'");
        }
    }
}
