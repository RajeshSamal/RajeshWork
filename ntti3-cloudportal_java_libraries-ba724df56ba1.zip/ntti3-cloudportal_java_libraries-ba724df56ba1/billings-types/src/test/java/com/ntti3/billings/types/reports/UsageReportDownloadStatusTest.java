package com.ntti3.billings.types.reports;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import org.joda.time.DateTime;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UsageReportDownloadStatusTest {

    public static final Integer YEAR = 2014;
    public static final Integer MONTH = 4;
    public static final ReportType CUSTOMER_SUMMARY = ReportType.CS;
    public static final String OPCO_UID = "opcoUid";
    public static final String NTTI_3 = "ntti3";
    public static final OpcoUid NTTI_3_OPCO_UID = OpcoUid.fromString(NTTI_3);

    @Test
    @SuppressWarnings("unchecked")
    public void okJson() throws IOException {
        DateTime now = DateTime.now();
        final ServiceUid expectedServiceUid = ServiceUid.MGR;
        UsageReportDownloadStatus usageReportDownloadStatus = UsageReportDownloadStatus.downloaded(
                OpcoUid.fromString(OPCO_UID),
                expectedServiceUid,
                YEAR,
                MONTH,
                now,
                CUSTOMER_SUMMARY
        );

        ObjectMapper mapper = new ObjectMapper();
        String jsonString = mapper.writeValueAsString(usageReportDownloadStatus);
        Map<String, Object> usageReportDownloadStatusMap = mapper.readValue(jsonString, HashMap.class);

        assertEquals(usageReportDownloadStatusMap.keySet().size(), 7);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.OPCO_UID), OPCO_UID);
        assertEquals(expectedServiceUid.toString(), usageReportDownloadStatusMap.get(UsageReportDownloadStatus.SERVICE_UID));
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.YEAR), YEAR);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.MONTH), MONTH);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.DOWNLOAD_TIME), now.toString());
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.REPORT_TYPE), CUSTOMER_SUMMARY.getJsonValue());
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.USAGE_REPORT_DOWNLOAD_STATUS_TYPE), UsageReportDownloadStatusType.OK.toString());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void unknownJson() throws IOException {
        final ServiceUid expectedServiceUid = ServiceUid.MGR;
        UsageReportDownloadStatus usageReportDownloadStatus = UsageReportDownloadStatus.pending(
                OpcoUid.fromString(OPCO_UID),
                expectedServiceUid,
                YEAR,
                MONTH,
                CUSTOMER_SUMMARY
        );

        ObjectMapper mapper = new ObjectMapper();
        String jsonString = mapper.writeValueAsString(usageReportDownloadStatus);
        Map<String, Object> usageReportDownloadStatusMap = mapper.readValue(jsonString, HashMap.class);

        assertEquals(usageReportDownloadStatusMap.keySet().size(), 6);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.OPCO_UID), OPCO_UID);
        assertEquals(expectedServiceUid.toString(), usageReportDownloadStatusMap.get(UsageReportDownloadStatus.SERVICE_UID));
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.YEAR), YEAR);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.MONTH), MONTH);
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.REPORT_TYPE), CUSTOMER_SUMMARY.getJsonValue());
        assertEquals(usageReportDownloadStatusMap.get(UsageReportDownloadStatus.USAGE_REPORT_DOWNLOAD_STATUS_TYPE), UsageReportDownloadStatusType.PENDING.toString());
    }

    @Test
    public void deserializationUnknown() throws IOException {
        String jsonStringUnknown = "{\"service_uid\":\"MGR\",\"year\":" + YEAR + ",\"month\": "
                + MONTH + ",\"report_type\":\"service_provider_summary\",\"status\":\"pending\"" +
                ",\"opco_uid\":\"" + NTTI_3_OPCO_UID + "\"}";
        ObjectMapper mapper = new ObjectMapper();
        UsageReportDownloadStatus usageReportDownloadStatus = mapper.readValue(jsonStringUnknown, UsageReportDownloadStatus.class);

        assertEquals(usageReportDownloadStatus.getOpcoUid(), NTTI_3_OPCO_UID);
        assertEquals(usageReportDownloadStatus.getYear(), YEAR);
        assertEquals(usageReportDownloadStatus.getMonth(), MONTH);
        assertEquals(usageReportDownloadStatus.getReportType(), ReportType.SPS);
        assertEquals(usageReportDownloadStatus.getUsageReportDownloadStatusType(), UsageReportDownloadStatusType.PENDING);
        assertEquals(usageReportDownloadStatus.getServiceUid(), ServiceUid.MGR);
        Assert.assertNull(usageReportDownloadStatus.getDownloadTime());
    }

    @Test
    public void deserializationDownloaded() throws IOException {
        String dateTimeString = "2014-02-10T11:39:06.866+01:00";
        DateTime testDateTime = DateTime.parse(dateTimeString);
        String jsonStringUnknown = "{\"service_uid\":\"MGR\",\"year\":" + YEAR + ",\"month\":"
                + MONTH + ",\"report_type\":\"service_provider_summary\"," +
                "\"status\":\"ok\",\"opco_uid\":\"" + NTTI_3_OPCO_UID + "\"," +
                " \"download_time\" : \"" + dateTimeString + "\"}";
        ObjectMapper mapper = new ObjectMapper();
        UsageReportDownloadStatus usageReportDownloadStatus = mapper.readValue(jsonStringUnknown, UsageReportDownloadStatus.class);

        assertEquals(usageReportDownloadStatus.getOpcoUid(), OpcoUid.fromString(NTTI_3));
        assertEquals(usageReportDownloadStatus.getYear(), YEAR);
        assertEquals(usageReportDownloadStatus.getMonth(), MONTH);
        assertEquals(usageReportDownloadStatus.getReportType(), ReportType.SPS);
        assertEquals(usageReportDownloadStatus.getUsageReportDownloadStatusType(), UsageReportDownloadStatusType.OK);
        assertEquals(usageReportDownloadStatus.getServiceUid(), ServiceUid.MGR);
        assertEquals(usageReportDownloadStatus.getDownloadTime(), testDateTime);
    }
}
