package com.ntti3.billings.types.base;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.*;
/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceUidTest {

    private ObjectMapper objectMapper;

    @Before
    public void setup() {
        objectMapper = new ObjectMapper();
        SimpleModule module = new SimpleModule("AMA Protocol", new Version(1, 0, 0, null, null, null));
        ServiceUid.ServiceUidJsonSerializer serializer = new ServiceUid.ServiceUidJsonSerializer();
        module.addSerializer(serializer);
        objectMapper.registerModule(module);
    }

    @Test
    public void serialization() throws JsonProcessingException {
        for (ServiceUid serviceUid : ServiceUid.values()) {
            String serialized = objectMapper.writeValueAsString(serviceUid);
            String expected = serializeByHand(serviceUid).toString();
            assertEquals(expected, serialized);
        }
    }

    private ObjectNode serializeByHand(ServiceUid serviceUid) {
        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("uid", serviceUid.getTextRepresentation());
        objectNode.put("name", serviceUid.getServiceName());
        return objectNode;
    }
}
