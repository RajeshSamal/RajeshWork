package com.ntti3.gums.register;

import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.UserExistsException;
import com.ntti3.gums.register.exceptions.UserNotFoundException;
import com.ntti3.gums.register.models.User;

import javax.annotation.Nonnull;
import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
public interface UserRegistrationConnector {
    /**
     *
     * @param user
     * @return opco_u_uid of registered user or null if user is already registered
     */
    String registerUser(@Nonnull User user) throws UserExistsException, RegistrationProtocolException;
    void updatePassword(String opcoUUid, String newPassword) throws IOException,
            RegistrationProtocolException, UserNotFoundException;

    void activateUser(@Nonnull String opcoUUid) throws RegistrationProtocolException,
            IOException, UserNotFoundException;

    /**
     *
     * @param opcoUUid
     * @param oldPassword
     * @param newPassword
     * @return true if oldPassword is correct
     */
    boolean updatePassword(@Nonnull String opcoUUid, @Nonnull String oldPassword, @Nonnull String newPassword)
            throws RegistrationProtocolException, UserNotFoundException;

    void updateRecoveryQuestion(String opcoUUid, String question, String answer)
            throws RegistrationProtocolException, UserNotFoundException;

    /**
     *
     * @param opcoUUid
     * @param oldPassword
     * @param question
     * @param answer
     * @return true if oldPassword is correct, false otherwise
     */
    boolean updateRecoveryQuestion(@Nonnull String opcoUUid, @Nonnull String oldPassword, @Nonnull String question,
                                   @Nonnull String answer)
            throws RegistrationProtocolException, UserNotFoundException;

    void unlockUser(@Nonnull String opcoUUid)
            throws RegistrationProtocolException, UserNotFoundException;


    public void editUser(@Nonnull User user) throws
            RegistrationProtocolException, UserNotFoundException;

    public boolean userExists(@Nonnull String login) throws RegistrationProtocolException;
}
