package com.ntti3.gums.register.exceptions;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class InvalidParametersException extends RegistrationProtocolException{
    protected InvalidParametersException() {
    }

    protected InvalidParametersException(String message) {
        super(message);
    }

    protected InvalidParametersException(String message, Throwable cause) {
        super(message, cause);
    }

    protected InvalidParametersException(Throwable cause) {
        super(cause);
    }

    protected InvalidParametersException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
