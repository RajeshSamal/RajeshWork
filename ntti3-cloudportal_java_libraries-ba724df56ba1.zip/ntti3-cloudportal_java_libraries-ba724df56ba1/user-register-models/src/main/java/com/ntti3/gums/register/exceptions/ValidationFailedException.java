package com.ntti3.gums.register.exceptions;

import java.util.Collection;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class ValidationFailedException extends RegistrationProtocolException {
    public ValidationFailedException() {
    }

    public ValidationFailedException(String message) {
        super(message);
    }

    public ValidationFailedException(String message, Throwable cause) {
        super(message, cause);
    }

    public ValidationFailedException(Throwable cause) {
        super(cause);
    }

    public ValidationFailedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public abstract Collection<?> getValidationMessages();
}
