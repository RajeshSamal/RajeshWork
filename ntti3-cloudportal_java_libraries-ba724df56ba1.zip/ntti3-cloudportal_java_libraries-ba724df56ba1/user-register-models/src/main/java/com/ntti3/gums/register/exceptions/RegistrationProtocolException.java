package com.ntti3.gums.register.exceptions;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class RegistrationProtocolException extends Exception {
    protected RegistrationProtocolException() {
    }

    protected RegistrationProtocolException(String message) {
        super(message);
    }

    protected RegistrationProtocolException(String message, Throwable cause) {
        super(message, cause);
    }

    protected RegistrationProtocolException(Throwable cause) {
        super(cause);
    }

    protected RegistrationProtocolException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
