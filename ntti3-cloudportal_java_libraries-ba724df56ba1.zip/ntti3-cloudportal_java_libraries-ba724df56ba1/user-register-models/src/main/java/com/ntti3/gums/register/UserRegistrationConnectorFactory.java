package com.ntti3.gums.register;

import java.util.Properties;

/**
 * @author jan.karwowski@ntti3.com
 */
public interface UserRegistrationConnectorFactory {
    UserRegistrationConnector getInstance(Properties connectorProperties) throws Exception;
}
