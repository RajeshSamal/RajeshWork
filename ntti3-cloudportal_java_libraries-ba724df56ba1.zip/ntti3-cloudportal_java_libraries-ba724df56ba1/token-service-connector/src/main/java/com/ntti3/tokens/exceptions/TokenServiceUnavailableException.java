package com.ntti3.tokens.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceUnavailableException extends TokenServiceException {
    public TokenServiceUnavailableException() {
        super();
    }

    public TokenServiceUnavailableException(String message) {
        super(message);
    }

    public TokenServiceUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenServiceUnavailableException(Throwable cause) {
        super(cause);
    }
}
