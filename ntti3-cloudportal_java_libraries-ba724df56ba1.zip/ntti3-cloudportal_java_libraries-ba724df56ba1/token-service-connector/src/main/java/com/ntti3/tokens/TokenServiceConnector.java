package com.ntti3.tokens;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.ntti3.connectors.BaseConnector;
import com.ntti3.protocol.ErrorResponse;
import com.ntti3.tokens.exceptions.TokenServiceException;
import com.ntti3.tokens.exceptions.TokenServiceIllegalResponseException;
import com.ntti3.tokens.exceptions.TokenServiceInvalidApiCallException;
import com.ntti3.tokens.exceptions.TokenServiceUnavailableException;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.params.HttpParams;

import javax.annotation.Nullable;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceConnector extends BaseConnector {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    public TokenServiceConnector(URI baseAddress, @Nullable HttpParams params) {
        super(baseAddress, params);
    }

    public TokenServiceConnector(URI baseAddress, @Nullable HttpParams params, Collection<Scheme> schemes) {
        super(baseAddress, params, schemes);
    }

    public TokenServiceConnector(URI baseAddress, @Nullable HttpParams params, @Nullable SSLSocketFactory httpsSocketFactory) {
        super(baseAddress, params, httpsSocketFactory);
    }

    public Token createToken(String label) throws IOException, TokenServiceException {
        return createToken(label, null, null);
    }

    public Token createToken(String label, @Nullable Long validityDurationSeconds, @Nullable Integer length) throws IOException, TokenServiceException {
        return performRequest(TokenServiceRequests.create(label, validityDurationSeconds, length, null), new ResponseProcessor<Token>() {
            @Override
            public Token process(HttpResponse response) throws TokenServiceException, IOException {
                if (safeGetStatusLine(response).getStatusCode() == HttpStatus.SC_OK) {
                    return MAPPER.readValue(safeGetEntity(response).getContent(), Token.class);
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    public Token createToken(String label, @Nullable Long validityDurationSeconds, @Nullable Integer length, Map<String, String> metadata) throws IOException, TokenServiceException {
        return performRequest(TokenServiceRequests.create(label, validityDurationSeconds, length, metadata), new ResponseProcessor<Token>() {
            @Override
            public Token process(HttpResponse response) throws TokenServiceException, IOException {
                if (safeGetStatusLine(response).getStatusCode() == HttpStatus.SC_OK) {
                    return MAPPER.readValue(safeGetEntity(response).getContent(), Token.class);
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    public boolean useToken(String label, String value) throws IOException, TokenServiceException {
        return performRequest(TokenServiceRequests.use(label, value), new ResponseProcessor<Boolean>() {
            @Override
            public Boolean process(HttpResponse response) throws TokenServiceException, IOException {
                switch (safeGetStatusLine(response).getStatusCode()) {
                    case HttpStatus.SC_OK:
                        return true;
                    case HttpStatus.SC_NOT_FOUND:
                        return false;
                    default:
                        throw handleError(response);
                }
            }
        });
    }

    public Optional<Token> checkToken(String label, String value) throws IOException, TokenServiceException {
        return Optional.fromNullable(performRequest(TokenServicePaths.getCheckTokenPath(label, value), new HttpGet(), new ResponseProcessor<Token>() {
            @Override
            public Token process(HttpResponse response) throws TokenServiceException, IOException {
                switch (safeGetStatusLine(response).getStatusCode()) {
                    case HttpStatus.SC_OK:
                        return MAPPER.readValue(safeGetEntity(response).getContent(), Token.class);
                    case HttpStatus.SC_NOT_FOUND:
                        return null;
                    default:
                        throw handleError(response);
                }
            }
        }));
    }

    private interface ResponseProcessor<T> {
        T process(HttpResponse response) throws TokenServiceException, IOException;
    }

    private <T> T performRequest(TokenServiceRequest tokenServiceRequest, ResponseProcessor<T> processor)
            throws IOException, TokenServiceException {
        return performRequest(tokenServiceRequest.getPath(), tokenServiceRequest.getRequest(), processor);
    }

    private <T> T performRequest(String path, HttpRequestBase request, ResponseProcessor<T> processor)
            throws IOException, TokenServiceException {
        try {
            request.setURI(getBaseBuilder().setPath(path).build());
            HttpResponse response = getHttpClient().execute(request);
            try {
                return processor.process(response);
            } finally {
                request.releaseConnection();
            }
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    private static class Error {
        public ErrorResponse error;
    }

    private TokenServiceException handleError(HttpResponse response) throws IOException {
        final StatusLine statusLine;
        try {
            statusLine = safeGetStatusLine(response);
        } catch (TokenServiceIllegalResponseException e) {
            return e;
        }
        switch (statusLine.getStatusCode()) {
            case HttpStatus.SC_INTERNAL_SERVER_ERROR:
                return new TokenServiceException("Internal Server Error");
            case HttpStatus.SC_BAD_REQUEST:
                ErrorResponse errorResponse = null;
                final HttpEntity entity;
                try {
                    entity = safeGetEntity(response);
                } catch (TokenServiceException e) {
                    return e;
                }

                final Header contentType = entity.getContentType();
                if (contentType == null) {
                    return new TokenServiceIllegalResponseException("Got a http response with unknown content type (empty)");
                }

                final String contentTypeValue = contentType.getValue();
                if (contentTypeValue == null) {
                    return new TokenServiceIllegalResponseException("Got a http response with unknown content type value (empty)");
                }

                if (contentTypeValue.contains("application/json")) {
                    errorResponse = MAPPER.readValue(response.getEntity().getContent(),
                            Error.class).error;
                }
                if (errorResponse == null) {
                    return new TokenServiceInvalidApiCallException();
                } else {
                    return new TokenServiceInvalidApiCallException(errorResponse);
                }
            case HttpStatus.SC_SERVICE_UNAVAILABLE:
                return new TokenServiceUnavailableException();
        }

        return new TokenServiceUnavailableException("UnknownError");
    }

    private HttpEntity safeGetEntity(HttpResponse response) throws TokenServiceIllegalResponseException {
        final HttpEntity entity = response.getEntity();
        return ensureNotNull(entity, "Got a http response without a entity field");
    }

    private StatusLine safeGetStatusLine(HttpResponse response) throws TokenServiceIllegalResponseException {
        final StatusLine statusLine = response.getStatusLine();
        return ensureNotNull(statusLine, "Got a http response without a status line!");
    }

    private <T> T ensureNotNull(T object, @Nullable String exceptionMessage) throws TokenServiceIllegalResponseException {
        if (object == null) {
            throw new TokenServiceIllegalResponseException(exceptionMessage);
        } else {
            return object;
        }
    }
}
