package com.ntti3.tokens.exceptions;

import com.ntti3.protocol.ErrorResponse;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceInvalidApiCallException extends TokenServiceException {
    private final ErrorResponse response;

    public TokenServiceInvalidApiCallException(ErrorResponse response) {
        super(response.getMessage() + ": " + response.getDetails());
        this.response = response;
    }

    public TokenServiceInvalidApiCallException() {
        super("Unknown error");
        response = null;
    }

    public ErrorResponse getResponse() {
        return response;
    }
}
