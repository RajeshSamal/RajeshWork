package com.ntti3.tokens;

import com.google.common.base.Preconditions;
import org.apache.commons.lang3.StringUtils;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServicePaths {

    public static final String TOKEN = "/token";

    public static String getCreateTokenPath() {
        return TOKEN;
    }

    public static String getUseTokenPath(String label, String value) {
        checkNotNull(label, value);
        return buildPath(TOKEN, label, value);
    }

    public static String getCheckTokenPath(String label, String value) {
        checkNotNull(label, value);
        return buildPath(TOKEN, label, value);
    }

    private static String buildPath(String... strings) {
        return StringUtils.join(strings, "/");
    }

    private static void checkNotNull(String label, String value) {
        Preconditions.checkNotNull(label, "Label can not be null!");
        Preconditions.checkNotNull(value, "Value can not be null!");
    }
}
