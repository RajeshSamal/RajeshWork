package com.ntti3.tokens;

import com.google.common.collect.Lists;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import javax.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceRequests {

    public static final String ENCODING = "UTF-8";

    public static TokenServiceRequest create(String label, @Nullable Long seconds, @Nullable Integer length, Map<String, String> metadataMap) {
        HttpPost request = new HttpPost();
        List<NameValuePair> parameters = Lists.newArrayList();
        parameters.add(new BasicNameValuePair("label", label));
        if (seconds != null) {
            parameters.add(new BasicNameValuePair("seconds", seconds.toString()));
        }

        if (length != null) {
            parameters.add(new BasicNameValuePair("length", length.toString()));
        }

        if (metadataMap != null) {
            List<NameValuePair> metadata = Lists.newArrayList();

            for(Map.Entry<String, String> entry : metadataMap.entrySet()) {
                metadata.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            parameters.add(new BasicNameValuePair("metadata", URLEncodedUtils.format(metadata, ENCODING)));
        }

        try {
            request.setEntity(new UrlEncodedFormEntity(parameters, ENCODING));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        return new TokenServiceRequest(TokenServicePaths.getCreateTokenPath(), request);
    }

    public static TokenServiceRequest check(String label, String value) {
        return new TokenServiceRequest(TokenServicePaths.getCheckTokenPath(label, value), new HttpGet());
    }

    public static TokenServiceRequest use(String label, String value) {
        return new TokenServiceRequest(TokenServicePaths.getCheckTokenPath(label, value), new HttpDelete());
    }
}
