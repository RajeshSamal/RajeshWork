package com.ntti3.tokens;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class Token {

    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    private final String value;
    private final String label;
    private final Calendar validUntil;
    private final ImmutableMap<String, String> metadataMap;

    public Token(String value, String label, Calendar validUntil) {
        this(value, label, validUntil, null);
    }

    public Token(String value, String label, Calendar validUntil, @Nullable Map<String, String> metadataMap) {
        this.value = value;
        this.label = label;
        this.validUntil = (Calendar)validUntil.clone();
        this.metadataMap = ImmutableMap.copyOf(Optional.fromNullable(metadataMap).or(Collections.<String, String>emptyMap()));
        verify();
    }

    @JsonCreator
    public Token(@JsonProperty("value") String value,
                 @JsonProperty("label") String label,
                 @JsonProperty("validUntil") String validUntil,
                 @JsonProperty("metadata") Map<String, String> metadataMap) throws ParseException {
        this(value, label, calendarFromString(validUntil), metadataMap);
    }

    private void verify() {
        Preconditions.checkNotNull(value);
        Preconditions.checkNotNull(label);
        Preconditions.checkNotNull(validUntil);
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public Calendar getValidUntil() {
        return (Calendar)validUntil.clone();
    }

    public ImmutableMap<String, String> getMetadata() { return metadataMap; }

    public Optional<String> getMetadata(String key) {
        return Optional.fromNullable(metadataMap.get(key));
    }

    public static Calendar calendarFromString(String dateString) throws ParseException {
        Calendar c = Calendar.getInstance();
        c.setTime(new SimpleDateFormat(DATE_FORMAT).parse(dateString));
        return c;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Token token = (Token) o;

        if (label != null ? !label.equals(token.label) : token.label != null) return false;
        if (validUntil != null ? !validUntil.equals(token.validUntil) : token.validUntil != null) return false;
        if (value != null ? !value.equals(token.value) : token.value != null) return false;
        if (metadataMap != null ? !metadataMap.equals(token.metadataMap) : token.metadataMap != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = value != null ? value.hashCode() : 0;
        result = 31 * result + (label != null ? label.hashCode() : 0);
        result = 31 * result + (validUntil != null ? validUntil.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Token{" +
                "value='" + value + '\'' +
                ", label='" + label + '\'' +
                ", validUntil=" + validUntil +
                '}';
    }

}
