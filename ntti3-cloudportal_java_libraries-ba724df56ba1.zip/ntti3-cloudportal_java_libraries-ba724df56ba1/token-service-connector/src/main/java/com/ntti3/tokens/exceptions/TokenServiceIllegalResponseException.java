package com.ntti3.tokens.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceIllegalResponseException extends TokenServiceException {
    public TokenServiceIllegalResponseException() {
        super();
    }

    public TokenServiceIllegalResponseException(String message) {
        super(message);
    }

    public TokenServiceIllegalResponseException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenServiceIllegalResponseException(Throwable cause) {
        super(cause);
    }
}
