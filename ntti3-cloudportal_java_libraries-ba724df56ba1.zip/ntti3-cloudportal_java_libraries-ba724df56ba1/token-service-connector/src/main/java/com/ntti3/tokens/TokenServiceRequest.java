package com.ntti3.tokens;

import com.google.common.base.Preconditions;
import org.apache.http.client.methods.HttpRequestBase;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServiceRequest {

    private final String path;
    private final HttpRequestBase request;

    public TokenServiceRequest(String path, HttpRequestBase request) {
        this.path = path;
        this.request = request;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(path);
        Preconditions.checkNotNull(request);
    }

    public String getPath() {
        return path;
    }

    public HttpRequestBase getRequest() {
        return request;
    }
}
