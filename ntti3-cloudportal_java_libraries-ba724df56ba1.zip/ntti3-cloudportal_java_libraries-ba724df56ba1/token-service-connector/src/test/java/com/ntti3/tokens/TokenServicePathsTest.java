package com.ntti3.tokens;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenServicePathsTest {
    @Test
    public void testGetCreateTokenPath() throws Exception {
        String path = TokenServicePaths.getCreateTokenPath();
        Assert.assertEquals("/token", path);
    }

    @Test
    public void testGetUseTokenPath() throws Exception {
        final String label = "abc";
        final String value = "l33th4x";
        String path = TokenServicePaths.getUseTokenPath(label, value);
        Assert.assertEquals(String.format("/token/%s/%s", label, value), path);
    }

    @Test
    public void testGetCheckTokenPath() throws Exception {
        final String label = "abc";
        final String value = "l33th4x";
        String path = TokenServicePaths.getCheckTokenPath(label, value);
        Assert.assertEquals(String.format("/token/%s/%s", label, value), path);
    }
}
