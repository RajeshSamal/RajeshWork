package com.ntti3.tokens;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenTest {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static final String VALUE = "B2XnSj";
    public static final String TEST_LABEL = "testLabel";

    @Test
    public void deserializationTest() throws IOException {
        final String date = "2014-04-17T08:25:51.448Z";
        final long millis = 1397723151448L;
        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("value", VALUE);
        objectNode.put("label", TEST_LABEL);
        objectNode.put("validUntil", date);
        Token t = objectMapper.readValue(objectNode.toString(), Token.class);
        Assert.assertEquals(VALUE, t.getValue());
        Assert.assertEquals(TEST_LABEL, t.getLabel());
        Assert.assertEquals(millis, t.getValidUntil().getTimeInMillis());
    }
}
