package com.ntti3.connectors.aspects;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jan.karwowski@ntti3.com
 */
@Aspect
public abstract class LoggingAspect {
    @Pointcut("")
    public abstract void publicMethodPointcut();

    @Before("publicMethodPointcut()")
    public void logBeforePublicMethod(JoinPoint joinPoint) {
        final Logger logger = getLogger(joinPoint);
        logger.trace("Called: {}", pointcutDescription(joinPoint));
    }

    private Logger getLogger(JoinPoint joinPoint) {
        final Logger logger;
        if(joinPoint.getSignature().getDeclaringType().getCanonicalName() == null) {
            Logger localLogger = LoggerFactory.getLogger(this.getClass());
            String name = joinPoint.getSignature().getDeclaringType().getName();
            localLogger.warn("getCanonicalName() = null, using getName() instead: {}", name);
            logger = LoggerFactory.getLogger(name);
        } else {
            logger = LoggerFactory.getLogger(joinPoint.getSignature().getDeclaringType().getCanonicalName());
        }
        return logger;
    }

    @AfterReturning(pointcut = "publicMethodPointcut()",
            returning = "result")
    public void logAfterPublicApplicationMethodReturn(JoinPoint joinPoint, Object result) {
        final Logger logger = getLogger(joinPoint);
        if (result == null) {
            logger.trace("Returned: {} => {}",
                    pointcutDescription(joinPoint), "null");
        } else {
            final String resultClassName = result.getClass().getSimpleName();
            logger.trace("Returned: {} => {}: {}",
                    pointcutDescription(joinPoint), resultClassName, result.toString());
        }
    }

    @AfterThrowing(pointcut = "publicMethodPointcut()", throwing = "ex")
    public void logAfterPublicApplicationMethodException(JoinPoint joinPoint, Throwable ex) {
        getLogger(joinPoint).error("Thrown from: {}", pointcutDescription(joinPoint), ex);
    }

    protected String objectsToString(Object[] objects) {
        String[] objectsStrings = new String[objects.length];
        for (int i = 0; i < objects.length; i++) {
            final Object o = objects[i];
            if (o == null) {
                objectsStrings[i] = "null";
            } else {
                objectsStrings[i] = String.format("%s = %s",
                        o.getClass().getSimpleName(),
                        o.toString());
            }
        }
        return StringUtils.join(objectsStrings, ", ");
    }

    protected String pointcutDescription(JoinPoint joinPoint) {
        final String className = joinPoint.getSignature().getDeclaringType().getSimpleName();
        final String methodName = joinPoint.getSignature().getName();
        final String args = objectsToString(joinPoint.getArgs());
        return String.format("%s.%s(%s)", className, methodName, args);
    }
}
