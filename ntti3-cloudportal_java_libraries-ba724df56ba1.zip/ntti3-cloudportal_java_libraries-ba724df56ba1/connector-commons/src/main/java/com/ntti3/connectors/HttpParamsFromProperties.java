package com.ntti3.connectors;

import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author jan.karwowski@ntti3.com
 */
public class HttpParamsFromProperties {
    public static final String PROPERTIES_DEFAULTS_PATH = "params.properties";
    private static volatile Properties globalDefaults;

    public static HttpParams getParams(Properties properties) {
        HttpParams httpParams = new BasicHttpParams();
        for (String propertyName : properties.stringPropertyNames()) {
            httpParams.setParameter(propertyName, parse(properties.getProperty(propertyName)));
        }

        return httpParams;
    }

    public static HttpParams getParams(String filename, Properties defaults) throws IOException {
        try (InputStream inputStream = new FileInputStream(filename)) {
            return getParams(inputStream, defaults);
        }
    }

    public static HttpParams getParams(InputStream inputStream, Properties defaults) throws IOException {
        Properties properties = new Properties(defaults);
        properties.load(inputStream);
        return getParams(properties);
    }

    public static HttpParams getParams(InputStream inputStream) throws IOException {
        return getParams(inputStream, getGlobalDefaults());
    }

    public static HttpParams getParams() {
        return getParams(getGlobalDefaults());
    }

    private static Properties getGlobalDefaults() {
        if (globalDefaults != null)
            return globalDefaults;
        Properties elDefaults = new Properties();
        try (InputStream inputStream = HttpParamsFromProperties.class
                .getResourceAsStream(PROPERTIES_DEFAULTS_PATH)) {
            elDefaults.load(inputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return globalDefaults = elDefaults;
    }

    private static Object parse(String property) {
        try {
            return Integer.parseInt(property);
        } catch (NumberFormatException e) {
            if (Boolean.TRUE.toString().equalsIgnoreCase(property)) {
                return Boolean.TRUE;
            }
            if (Boolean.FALSE.toString().equalsIgnoreCase(property)) {
                return Boolean.FALSE;
            }
            return property;
        }
    }
}
