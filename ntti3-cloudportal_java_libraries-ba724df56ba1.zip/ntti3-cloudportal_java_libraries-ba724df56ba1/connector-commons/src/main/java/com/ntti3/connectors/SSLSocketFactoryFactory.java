package com.ntti3.connectors;

import com.google.common.base.Preconditions;
import org.apache.http.conn.ssl.SSLSocketFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class SSLSocketFactoryFactory {
    public static final String USE_CLIENT_CERT_CONFIG_KEY = "useClientCert";
    public static final String KEY_STORE_PATH_CONFIG_KEY = "keyStorePath";
    public static final String TRUST_STORE_PATH_CONFIG_KEY = "trustStorePath";
    public static final String KEY_STORE_PASS_CONFIG_KEY = "keyStorePass";
    public static final String TRUST_STORE_PASS_CONFIG_KEY = "trustStorePass";

    public static  SSLSocketFactory getSSLSocketFactoryInstance(KeyStore keyStore,
                                                        String keyStorePassword, KeyStore trustStore)
            throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        return new SSLSocketFactory(keyStore, keyStorePassword, trustStore);
    }

    public static SSLSocketFactory getSSLSocketFactoryInstance(KeyStore keyStore,
                                                        String keyStorePassword)
            throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        return new SSLSocketFactory(keyStore, keyStorePassword);
    }

    public static SSLSocketFactory getSSLSocketFactoryInstance(String keyStorePath, String keyStorePassword,
                                                        String trustStorePath, String trustStorePassword)
            throws IOException, KeyStoreException, CertificateException, NoSuchAlgorithmException,
            UnrecoverableKeyException, KeyManagementException {
        try (FileInputStream keyStoreStream = new FileInputStream(keyStorePath);
             FileInputStream trustStoreStream = new FileInputStream(trustStorePassword)) {
            return getSSLSocketFactoryInstance(keyStoreStream, keyStorePassword, trustStoreStream, trustStorePassword);
        }
    }

    public static SSLSocketFactory getSSLSocketFactoryInstance(String keyStorePath, String keyStorePassword)
            throws IOException, KeyStoreException, CertificateException, NoSuchAlgorithmException,
            UnrecoverableKeyException, KeyManagementException {
        try (FileInputStream keyStoreStream = new FileInputStream(keyStorePath)) {
            return getSSLSocketFactoryInstance(keyStoreStream, keyStorePassword);
        }
    }

    public static SSLSocketFactory getSSLSocketFactoryInstance(InputStream keyStoreStream, String keyStorePassword,
                                                        InputStream trustStoreStream, String trustStorePassword)
            throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException,
            UnrecoverableKeyException, KeyManagementException {
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(keyStoreStream, keyStorePassword.toCharArray());
        trustStore.load(trustStoreStream, trustStorePassword.toCharArray());

        return getSSLSocketFactoryInstance(keyStore, keyStorePassword, trustStore);
    }


    public static SSLSocketFactory getSSLSocketFactoryInstance(InputStream keyStoreStream, String keyStorePassword)
            throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException,
            UnrecoverableKeyException, KeyManagementException {
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(keyStoreStream, keyStorePassword.toCharArray());

        return getSSLSocketFactoryInstance(keyStore, keyStorePassword);
    }


    public static SSLSocketFactory getSSLSocketFactoryInstance(Map<String, String> config)
            throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException,
            KeyManagementException, KeyStoreException {
        mapContainsPrecondition(config, USE_CLIENT_CERT_CONFIG_KEY);
        if (config.get(USE_CLIENT_CERT_CONFIG_KEY).equals("true")) {
            mapContainsPrecondition(config, KEY_STORE_PATH_CONFIG_KEY);
            mapContainsPrecondition(config, KEY_STORE_PASS_CONFIG_KEY);
            if (config.containsKey(TRUST_STORE_PASS_CONFIG_KEY) && config.containsKey(TRUST_STORE_PATH_CONFIG_KEY)) {
                return getSSLSocketFactoryInstance(config.get(KEY_STORE_PATH_CONFIG_KEY),
                        config.get(KEY_STORE_PASS_CONFIG_KEY),
                        config.get(TRUST_STORE_PATH_CONFIG_KEY), config.get(TRUST_STORE_PASS_CONFIG_KEY));
            } else {
                return getSSLSocketFactoryInstance(config.get(KEY_STORE_PATH_CONFIG_KEY),
                        config.get(KEY_STORE_PASS_CONFIG_KEY));
            }
        } else {
            return SSLSocketFactory.getSocketFactory();
        }
    }

    private static void mapContainsPrecondition(Map<String, String> config, String property) {
        Preconditions.checkArgument(config.containsKey(property),
                "Config map must contain %s", property);
    }
}
