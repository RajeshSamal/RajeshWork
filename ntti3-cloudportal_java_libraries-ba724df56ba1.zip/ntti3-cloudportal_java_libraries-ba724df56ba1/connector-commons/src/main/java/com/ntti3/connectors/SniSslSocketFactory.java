package com.ntti3.connectors;

import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.scheme.SchemeLayeredSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.params.HttpParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.security.ssl.SSLSocketImpl;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/** Fixes SNI bug in Apache HttpClient Library 4.2.1 (a simple backport)
 * See: https://github.com/cmbntr/httpclient/commit/1f9898495624dbd10d5c12ae4e0ea9ea50071c85
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SniSslSocketFactory implements SchemeLayeredSocketFactory {
    private static final Logger logger = LoggerFactory.getLogger(SniSslSocketFactory.class);
    private final SSLSocketFactory sslSocketFactory;
    private final String host;

    public SniSslSocketFactory(SSLSocketFactory sslSocketFactory, String host) {
        this.sslSocketFactory = sslSocketFactory;
        this.host = host;
    }

    @Override
    public Socket createSocket(HttpParams params) throws IOException {
        return setHostForSni(sslSocketFactory.createSocket(params));
    }

    @Override
    public Socket connectSocket(Socket sock, InetSocketAddress remoteAddress, InetSocketAddress localAddress, HttpParams params) throws IOException, UnknownHostException, ConnectTimeoutException {
        return setHostForSni(sslSocketFactory.connectSocket(sock, remoteAddress, localAddress, params));
    }

    @Override
    public boolean isSecure(Socket sock) throws IllegalArgumentException {
        return sslSocketFactory.isSecure(sock);
    }

    @Override
    public Socket createLayeredSocket(Socket socket, String target, int port, HttpParams params) throws IOException, UnknownHostException {
        return setHostForSni(sslSocketFactory.createLayeredSocket(socket, target, port, params));
    }

    private Socket setHostForSni(Socket socket) {
        if (socket instanceof SSLSocketImpl) {
            SSLSocketImpl impl = (SSLSocketImpl) socket;
            impl.setHost(host);
            return impl;
        } else {
            logger.warn("Could not set host for SNI as 'socket' is not an instance of SSLSocketImpl; 'socket' = "
                    + socket.toString());
            return socket;
        }
    }
}
