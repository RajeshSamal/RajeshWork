package com.ntti3.connectors;

import com.google.common.base.Preconditions;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeLayeredSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.impl.conn.SchemeRegistryFactory;
import org.apache.http.params.HttpParams;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URI;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class BaseConnector {
    public static final String NULL_BASE_ADDR_MESSAGE = "baseAddress can't be null";
    private final DefaultHttpClient httpClient;
    private final URI baseAddress;
    private final ClientConnectionManager connectionManager;

    protected BaseConnector(@Nonnull URI baseAddress, @Nullable HttpParams params) {
        this(baseAddress, params, (SSLSocketFactory) null);
    }

    protected BaseConnector(@Nonnull URI baseAddress, @Nullable HttpParams params, Collection<Scheme> schemes) {
        Preconditions.checkNotNull(baseAddress, NULL_BASE_ADDR_MESSAGE);
        if(params == null){
            params = HttpParamsFromProperties.getParams();
        }
        this.baseAddress = baseAddress;
        this.connectionManager = initConnectionManager();
        this.httpClient = initHttpClient(params);

        for(Scheme scheme : schemes){
            httpClient.getConnectionManager().getSchemeRegistry().register(scheme);
        }
        verify();
    }

    protected BaseConnector(@Nonnull URI baseAddress, @Nullable HttpParams params,
                            @Nullable SSLSocketFactory httpsSocketFactory) {
        if(params == null){
            params = HttpParamsFromProperties.getParams();
        }
        Preconditions.checkNotNull(baseAddress, NULL_BASE_ADDR_MESSAGE);
        this.baseAddress = baseAddress;
        this.connectionManager = initConnectionManager();
        if(httpsSocketFactory != null) {
            this.connectionManager.getSchemeRegistry().register(
                    new Scheme("https", 443, new SniSslSocketFactory(httpsSocketFactory, baseAddress.getHost())));
        }
        this.httpClient = initHttpClient(params);
        verify();
    }

    protected void verify() {
        Preconditions.checkNotNull(baseAddress, "Connector's base address can not be null!");
    }

    protected DefaultHttpClient initHttpClient(@Nullable HttpParams params) {
        if(params == null){
            params = HttpParamsFromProperties.getParams();
        }

            return new DefaultHttpClient(connectionManager, params);
    }

    protected ClientConnectionManager initConnectionManager() {
        return new PoolingClientConnectionManager(SchemeRegistryFactory.createDefault(), 1, TimeUnit.SECONDS);
    }

    protected URIBuilder getBaseBuilder() {
        return new URIBuilder(baseAddress);
    }

    protected DefaultHttpClient getHttpClient() {
        return httpClient;
    }

    public static boolean isStatusOk(int statusCode) {
        return (statusCode - HttpStatus.SC_OK) < 100;
    }

    public static boolean isStatusOk(StatusLine statusLine) {
        return statusLine != null && isStatusOk(statusLine.getStatusCode());
    }

    public static boolean isStatusOk(HttpResponse response) {
        return response != null && isStatusOk(response.getStatusLine());
    }

    abstract class SSLNtti3SocketFactory implements SchemeLayeredSocketFactory {

    }
}
