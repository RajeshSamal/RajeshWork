package com.ntti3.protocol;


import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ErrorCodeSerializer extends StdSerializer<ErrorCode> {
    @Override
    public void serialize(ErrorCode value, JsonGenerator jgen, SerializerProvider provider) throws IOException,
            JsonProcessingException {
        jgen.writeNumber(value.getCode());
    }

    public ErrorCodeSerializer() {
        super(ErrorCode.class);
    }
}
