package com.ntti3.protocol;

import java.io.Closeable;
import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
public interface CloseableIOIterator<T> extends Closeable {
    T next() throws IOException;

    boolean hasNext() throws IOException;

    @Override
    void close() throws IOException;
}
