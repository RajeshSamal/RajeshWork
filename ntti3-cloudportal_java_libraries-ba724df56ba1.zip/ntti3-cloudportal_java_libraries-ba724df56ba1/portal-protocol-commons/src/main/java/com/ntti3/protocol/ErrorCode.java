package com.ntti3.protocol;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * Protocol defined error codes
 *
 * @author jan.karwowski@ntti3.com
 */
@JsonDeserialize(using = ErrorCodeDeserializer.class)
@JsonSerialize(using = ErrorCodeSerializer.class)
public enum ErrorCode {
    //RESOURCE_NOT_FOUND(1002),
    USER_NOT_FOUND(1003),
    OPCO_NOT_FOUND(1004),
    COMPANY_NOT_FOUND(1005),
    PRODUCT_NOT_FOUND(1006),
    FLAG_NOT_SET(1008),
    MISSING_PARAMETERS(2001),
    INCORRECT_PARAMETER_FORMAT(2002),
    INCORRECT_CALL(2004),
    ENTITY_EXISTS(2005),
    OPERATION_NOT_SUPPORTED(2019);

    private ErrorCode(int code) {
        this.code = code;
    }

    private int code;

    public int getCode() {
        return code;
    }

    public static ErrorCode valueOf(int code) {
        for (ErrorCode ec : values()) {
            if (ec.getCode() == code)
                return ec;
        }

        throw new IllegalArgumentException("Unknown error code: " + code);
    }
}
