package com.ntti3.protocol;


import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ResponseHelper {
    private static ObjectMapper mapper = new ObjectMapper();

    static {
        SimpleModule module = new SimpleModule("AMA Protocol", new Version(1, 0, 0, null, null, null));
        ErrorCodeSerializer serializer = new ErrorCodeSerializer();
        module.addSerializer(serializer);
        mapper.registerModule(module);
    }

    public static ObjectNode errorResponse(ErrorResponse response) {
        ObjectNode main = JsonNodeFactory.instance.objectNode();
        main.put("error", mapper.valueToTree(response));
        return main;
    }

    public static ObjectNode errorResponse(ErrorCode code, String message, String details) {
        return errorResponse(new ErrorResponse(code, message, details));
    }
}
