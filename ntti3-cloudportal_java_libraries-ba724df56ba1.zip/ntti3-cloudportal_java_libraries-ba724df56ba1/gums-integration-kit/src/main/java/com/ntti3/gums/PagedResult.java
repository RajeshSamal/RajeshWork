package com.ntti3.gums;

import com.ntti3.protocol.CloseableIOIterator;

/**
 *
 * @author jan.karwowski@ntti3.com
 */
public class PagedResult<T> {
    private CloseableIOIterator<T> resultPage;
    private int allResultsCount;

    public PagedResult(CloseableIOIterator<T> resultPage, int allResultsCount) {
        this.resultPage = resultPage;
        this.allResultsCount = allResultsCount;
    }

    /**
     * @return Number of all results available in GUMS (not only in sent page)
     */
    public int getAllResultsCount() {
        return allResultsCount;
    }

    /**
     * @return Result page contained requested number of results (or less)
     */
    public CloseableIOIterator<T> getResultPage() {
        return resultPage;
    }
}
