package com.ntti3.gums;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GumsProtocolException extends Exception {
    public GumsProtocolException(String message) {
        super(message);
    }
}
