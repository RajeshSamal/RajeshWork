package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author jan.karwowski@ntti3.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PendingUser extends PendingUserBase {
    private int id;
    private Status status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

	@Override
	public String toString() {
		return "PendingUser [id=" + id + ", status=" + status
				+ ", getOpcoUid()=" + getOpcoUid() + ", getEmail()="
				+ getEmail() + ", getOpcoUUid()=" + getOpcoUUid()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getMobilePhone()=" + getMobilePhone()
                + "]";
	}
    
    
}
