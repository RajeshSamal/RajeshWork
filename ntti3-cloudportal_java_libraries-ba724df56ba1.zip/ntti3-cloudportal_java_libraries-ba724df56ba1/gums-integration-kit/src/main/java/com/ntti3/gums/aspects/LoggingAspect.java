package com.ntti3.gums.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * @author jan.karwowski@ntti3.com
 */
@Aspect
public class LoggingAspect extends com.ntti3.connectors.aspects.LoggingAspect {
    @Pointcut("execution(public * com.ntti3.gums.GumsConnector+.*(..))" )
    public void publicMethodPointcut(){}
}
