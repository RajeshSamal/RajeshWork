package com.ntti3.gums.exceptions.factories;

import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.exceptions.GumsProtocolMissingParametersException;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class MissingParameterExceptionFactory implements ExceptionFactory {
    @Override
    public GumsProtocolException create(ErrorResponse errorResponse) {
        return new GumsProtocolMissingParametersException(errorResponse);
    }
}
