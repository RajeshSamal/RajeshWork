package com.ntti3.gums.models;

/**
 * @author jan.karwowski@ntti3.com
 */
public enum Status {
    PENDING, ACCEPTED, REJECTED
}
