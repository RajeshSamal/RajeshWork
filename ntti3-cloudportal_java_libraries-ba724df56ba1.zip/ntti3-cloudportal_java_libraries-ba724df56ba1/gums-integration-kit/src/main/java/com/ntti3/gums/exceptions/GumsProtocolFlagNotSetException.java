package com.ntti3.gums.exceptions;

import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class GumsProtocolFlagNotSetException extends GumsProtocolExceptionWithErrorResponse {
    public GumsProtocolFlagNotSetException(ErrorResponse response) {
        super(response);
    }
}
