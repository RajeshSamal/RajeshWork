package com.ntti3.gums;

/**
 * Extended GumsConnector interface. Supports caching for some of the read methods.
 * The cached methods are: getUser, getOpco, getCompany. Any updates of these three
 * objects invalidate appropriate caches.
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface CachingGumsConnector extends GumsConnector {

    /**
     * Invalidates all caches.
     */
    void cleanCache();
}
