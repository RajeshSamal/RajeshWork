package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Opco {
    @JsonIgnore
    private String opcoUid;
    @JsonProperty(GumsProtocolConstants.OPCO_NAME_PARAMETER)
    private String opcoName;

    public Opco(@JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER) String opcoUid,
                @JsonProperty(GumsProtocolConstants.OPCO_NAME_PARAMETER) String opcoName) {
        this.opcoUid = opcoUid;
        this.opcoName = opcoName;
    }

    public String getOpcoUid() {
        return opcoUid;
    }

    public String getOpcoName() {
        return opcoName;
    }

    public void setOpcoName(String opcoName) {
        this.opcoName = opcoName;
    }

    @Override
    public String toString() {
        return "Opco{" +
                "opcoUid='" + opcoUid + '\'' +
                ", opcoName='" + opcoName + '\'' +
                '}';
    }
}
