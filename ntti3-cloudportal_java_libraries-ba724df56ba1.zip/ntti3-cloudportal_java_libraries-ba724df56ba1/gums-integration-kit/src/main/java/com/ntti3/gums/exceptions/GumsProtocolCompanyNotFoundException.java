package com.ntti3.gums.exceptions;

import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class GumsProtocolCompanyNotFoundException extends GumsProtocolExceptionWithErrorResponse {
    public GumsProtocolCompanyNotFoundException(ErrorResponse response) {
        super(response);
    }
}
