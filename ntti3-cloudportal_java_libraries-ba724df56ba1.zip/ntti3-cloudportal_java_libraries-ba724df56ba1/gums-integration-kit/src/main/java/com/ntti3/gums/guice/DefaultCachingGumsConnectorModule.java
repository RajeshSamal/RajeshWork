package com.ntti3.gums.guice;

import com.google.inject.AbstractModule;
import com.ntti3.gums.CachingGumsConnector;
import com.ntti3.gums.DefaultCachingGumsConnector;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultCachingGumsConnectorModule extends AbstractModule {
    @Override
    protected void configure() {
        bind(CachingGumsConnector.class).to(DefaultCachingGumsConnector.class);
    }

    @Override
    public int hashCode() {
        return DefaultCachingGumsConnector.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultCachingGumsConnector.class.equals(obj.getClass());
    }
}
