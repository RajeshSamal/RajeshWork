package com.ntti3.gums.util;

import com.google.common.base.Throwables;
import com.google.common.cache.CacheStats;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableMap;
import com.ntti3.gums.GumsProtocolException;

import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;



/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class GumsLoadingCacheWrapper<K ,V> {

    private final LoadingCache<K, V> wrappedCached;

    public GumsLoadingCacheWrapper(LoadingCache<K, V> wrappedCached) {
        this.wrappedCached = wrappedCached;
    }

    /**
     * Returns the value associated with {@code key} in this cache, first loading that value if
     * necessary. No observable state associated with this cache is modified until loading completes.
     *
     * <p>If another call to {@link #get} or {@link #getUnchecked} is currently loading the value for
     * {@code key}, simply waits for that thread to finish and returns its loaded value. Note that
     * multiple threads can concurrently load values for distinct keys.
     *
     * <p>Caches loaded by a {@link CacheLoader} will call {@link CacheLoader#load} to load new values
     * into the cache. Newly loaded values are added to the cache using
     * {@code Cache.asMap().putIfAbsent} after loading has completed; if another value was associated
     * with {@code key} while the new value was loading then a removal notification will be sent for
     * the new value.
     *
     * <p>If the cache loader associated with this cache is known not to throw checked
     * exceptions, then prefer {@link #getUnchecked} over this method.
     *
     * @throws java.util.concurrent.IOException if an IOException exception was thrown while loading the value
     * @throws java.util.concurrent.GumsProtocolException if an GumsProtocolException exception was thrown while
     *     loading the value
     * @throws UncheckedExecutionException if an unchecked exception was thrown while loading the
     *     value
     * @throws ExecutionError if an error was thrown while loading the value
     * @param key
     */
    public V get(K key) throws IOException, GumsProtocolException {
        try {
            return wrappedCached.get(key);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            Throwables.propagateIfInstanceOf(cause, IOException.class);
            Throwables.propagateIfInstanceOf(cause, GumsProtocolException.class);
            throw Throwables.propagate(e);
        }
    }

    /**
     * Performs any pending maintenance operations needed by the cache. Exactly which activities are
     * performed -- if any -- is implementation-dependent.
     */
    public void cleanUp() {
        wrappedCached.cleanUp();
    }

    /**
     * Returns the value associated with {@code key} in this cache, first loading that value if
     * necessary. No observable state associated with this cache is modified until loading
     * completes. Unlike {@link #get}, this method does not throw a checked exception, and thus should
     * only be used in situations where checked exceptions are not thrown by the cache loader.
     *
     * <p>If another call to {@link #get} or {@link #getUnchecked} is currently loading the value for
     * {@code key}, simply waits for that thread to finish and returns its loaded value. Note that
     * multiple threads can concurrently load values for distinct keys.
     *
     * <p>Caches loaded by a {@link CacheLoader} will call {@link CacheLoader#load} to load new values
     * into the cache. Newly loaded values are added to the cache using
     * {@code Cache.asMap().putIfAbsent} after loading has completed; if another value was associated
     * with {@code key} while the new value was loading then a removal notification will be sent for
     * the new value.
     *
     * <p><b>Warning:</b> this method silently converts checked exceptions to unchecked exceptions,
     * and should not be used with cache loaders which throw checked exceptions. In such cases use
     * {@link #get} instead.
     *
     * @throws UncheckedExecutionException if an exception was thrown while loading the value,
     *     regardless of whether the exception was checked or unchecked
     * @throws ExecutionError if an error was thrown while loading the value
     * @param key
     */
    public V getUnchecked(K key) {
        return wrappedCached.getUnchecked(key);
    }

    /**
     * Discards all entries in the cache.
     */
    public void invalidateAll() {
        wrappedCached.invalidateAll();
    }

    /**
     * Associates {@code value} with {@code key} in this cache. If the cache previously contained a
     * value associated with {@code key}, the old value is replaced by {@code value}.
     *
     * <p>Prefer {@link #get(Object, java.util.concurrent.Callable)} when using the conventional "if cached, return;
     * otherwise create, cache and return" pattern.
     *
     * @param key
     * @param value
     */
    public void put(K key, V value) {
        wrappedCached.put(key, value);
    }

    /**
     * Discouraged. Provided to satisfy the {@code Function} interface; use {@link #get} or
     * {@link #getUnchecked} instead.
     *
     * @throws UncheckedExecutionException if an exception was thrown while loading the value,
     *     regardless of whether the exception was checked or unchecked
     * @throws ExecutionError if an error was thrown while loading the value
     * @param key
     */
    public V apply(K key) {
        return wrappedCached.apply(key);
    }

    /**
     * Returns the value associated with {@code key} in this cache, obtaining that value from
     * {@code valueLoader} if necessary. No observable state associated with this cache is modified
     * until loading completes. This method provides a simple substitute for the conventional
     * "if cached, return; otherwise create, cache and return" pattern.
     *
     * <p><b>Warning:</b> as with {@link CacheLoader#load}, {@code valueLoader} <b>must not</b> return
     * {@code null}; it may either return a non-null value or throw an exception.
     *
     * @throws java.util.concurrent.IOException if an IOException exception was thrown while loading the value
     * @throws java.util.concurrent.GumsProtocolException if an GumsProtocolException exception was thrown while
     *     loading the value
     * @throws UncheckedExecutionException if an unchecked exception was thrown while loading the
     *     value
     * @throws ExecutionError if an error was thrown while loading the value
     *
     * @param key
     * @param valueLoader
     */
    public V get(K key, Callable<? extends V> valueLoader) throws IOException, GumsProtocolException {
        try {
            return wrappedCached.get(key, valueLoader);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            Throwables.propagateIfInstanceOf(cause, IOException.class);
            Throwables.propagateIfInstanceOf(cause, GumsProtocolException.class);
            throw Throwables.propagate(e);
        }
    }

    /**
     * Copies all of the mappings from the specified map to the cache. The effect of this call is
     * equivalent to that of calling {@code put(k, v)} on this map once for each mapping from key
     * {@code k} to value {@code v} in the specified map. The behavior of this operation is undefined
     * if the specified map is modified while the operation is in progress.
     *
     * @param m
     */
    public void putAll(Map<? extends K, ? extends V> m) {
        wrappedCached.putAll(m);
    }

    /**
     * Returns the value associated with {@code key} in this cache, or {@code null} if there is no
     * cached value for {@code key}.
     *
     * @param key
     */
    @Nullable
    public V getIfPresent(Object key) {
        return wrappedCached.getIfPresent(key);
    }

    /**
     * Discards any cached value for key {@code key}.
     * @param key
     */
    public void invalidate(Object key) {
        wrappedCached.invalidate(key);
    }

    /**
     * Returns a current snapshot of this cache's cumulative statistics. All stats are initialized
     * to zero, and are monotonically increasing over the lifetime of the cache.
     */
    public CacheStats stats() {
        return wrappedCached.stats();
    }

    /**
     * {@inheritDoc}
     *
     * <p><b>Note that although the view <i>is</i> modifiable, no method on the returned map will ever
     * cause entries to be automatically loaded.</b>
     */
    public ConcurrentMap<K,V> asMap() {
        return wrappedCached.asMap();
    }

    /**
     * Discards any cached values for keys {@code keys}.
     *
     * @param keys
     */
    public void invalidateAll(Iterable<?> keys) {
        wrappedCached.invalidateAll(keys);
    }

    /**
     * Returns the approximate number of entries in this cache.
     */
    public long size() {
        return wrappedCached.size();
    }

    /**
     * Loads a new value for key {@code key}, possibly asynchronously. While the new value is loading
     * the previous value (if any) will continue to be returned by {@code get(key)} unless it is
     * evicted. If the new value is loaded successfully it will replace the previous value in the
     * cache; if an exception is thrown while refreshing the previous value will remain, <i>and the
     * exception will be logged (using {@link java.util.logging.Logger}) and swallowed</i>.
     *
     * <p>Caches loaded by a {@link CacheLoader} will call {@link CacheLoader#reload} if the
     * cache currently contains a value for {@code key}, and {@link CacheLoader#load} otherwise.
     * Loading is asynchronous only if {@link CacheLoader#reload} was overridden with an
     * asynchronous implementation.
     *
     * <p>Returns without doing anything if another thread is currently loading the value for
     * {@code key}. If the cache loader associated with this cache performs refresh asynchronously
     * then this method may return before refresh completes.
     *
     * @param key
     */
    public void refresh(K key) {
        wrappedCached.refresh(key);
    }

    /**
     * Returns a map of the values associated with {@code keys}, creating or retrieving those values
     * if necessary. The returned map contains entries that were already cached, combined with newly
     * loaded entries; it will never contain null keys or values.
     *
     * <p>Caches loaded by a {@link CacheLoader} will issue a single request to
     * {@link CacheLoader#loadAll} for all keys which are not already present in the cache. All
     * entries returned by {@link CacheLoader#loadAll} will be stored in the cache, over-writing
     * any previously cached values. This method will throw an exception if
     * {@link CacheLoader#loadAll} returns {@code null}, returns a map containing null keys or values,
     * or fails to return an entry for each requested key.
     *
     * <p>Note that duplicate elements in {@code keys}, as determined by {@link Object#equals}, will
     * be ignored.
     *
     * @throws java.util.concurrent.IOException if an IOException exception was thrown while loading the value
     * @throws java.util.concurrent.GumsProtocolException if an GumsProtocolException exception was thrown while
     *     loading the value
     * @throws UncheckedExecutionException if an unchecked exception was thrown while loading the
     *     values
     * @throws ExecutionError if an error was thrown while loading the values
     * @param keys
     */
    public ImmutableMap<K,V> getAll(Iterable<? extends K> keys) throws IOException, GumsProtocolException {
        try {
            return wrappedCached.getAll(keys);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            Throwables.propagateIfInstanceOf(cause, IOException.class);
            Throwables.propagateIfInstanceOf(cause, GumsProtocolException.class);
            throw Throwables.propagate(e);
        }

    }

    /**
     * Returns a map of the values associated with {@code keys} in this cache. The returned map will
     * only contain entries which are already present in the cache.
     *
     * @param keys
     */
    public ImmutableMap<K,V> getAllPresent(Iterable<?> keys) {
        return wrappedCached.getAllPresent(keys);
    }
}
