package com.ntti3.gums;

/**
 * This class contains names specified in com.ntti3.gums protocol
 * <p/>
 * Created by jan.karwowski@ntti3.com on 06.02.14.
 */
public class GumsProtocolConstants {
    public static final String FIRST_NAME_PARAMETER = "first_name";
    public static final String LAST_NAME_PARAMETER = "last_name";
    public static final String EMAIL_PARAMETER = "email";
    public static final String ACTIVE_PARAMETER = "active";
    public static final String ACTIVE_IN_OPCO_PARAMETER = "active_in_opco";
    public static final String OPCO_C_UID_PARAMETER = "opco_c_uid";
    public static final String OPCO_C_NAME_PARAMETER = "opco_c_name";
    public static final String OPCO_UID_PARAMETER = "opco_uid";
    public static final String OPCO_NAME_PARAMETER = "opco_name";
    public static final String FLAGS_PARAMETER = "flags";
    public static final String PRODUCTS_PARAMETER = "products";
    public static final String COMPANY_GUID_PARAMETER = "company_guid";
    public static final String OPCO_U_UID_PARAMETER = "opco_u_uid";
    public static final String MOBILE_PHONE_PARAMETER = "mobile_phone";
    public static final String IS_OPCO_EDITABLE_PARAMETER = "is_opco_editable";
    public static final String ROLE_PARAMETER = "role";
    public static final String ADDITIONAL_INFO = "additional_info";

    public static final String OLD_PASSWORD_PARAMETER = "old_password";
    public static final String PASSWORD_PARAMETER = "password";
    public static final String NEW_PASSWORD_PARAMETER = "new_password";
    public static final String RECOVERY_QUESTION_PARAMETER = "recovery_question";
    public static final String RECOVERY_QUESTION_ANSWER = "recovery_answer";

    public static final String WHITELIST_FLAG = "whitelist";
    public static final String GUID_RESPONSE_FIELD = "guid";

    public static final String USER_BASE_PATH = "/public/user";
    public static final String COMPANY_BASE_PATH = "/public/company";
    public static final String OPCO_BASE_PATH = "/public/opco";
    public static final String FLAGS_BASE_PATH = "/public/flags";
    public static final String PRODUCTS_BASE_PATH = "/public/products";
    public static final String LOGIN_USED_BASE_PATH = "/public/login_used";

    public static final String GUID_PATH_SEGMENT = "/guid/";
    public static final String WHITELIST_SUBPATH = "/product_whitelist";
    public static final String COMPANIES_PATH_SEGMENT = "/companies";
    public static final String USERS_PATH_SEGMENT = "/users";
    public static final String PENDING_USERS_PATH_SEGMENT = "/pending_users";
    public static final String COUNT_FIELD_NAME = "count";

    public static final String OFFSET_QUERY_PARAM = "offset";
    public static final String LIMIT_QUERY_PARAM = "limit";

    public static final String OPCO_ADMIN_FLAG = "admin";
    public static final String COMPANY_ADMIN_FLAG = "company_admin";
    public static final String SUPER_ADMIN_FLAG = "super_admin";

    public static final String COMPANY_ARRAY_FIELD = "companies";
    public static final String USER_ARRAY_FIELD = "users";

    public static final String ORDER_QUERY_PARAM = "order";
    public static final String ORDER_BY_QUERY_PARAM = "orderBy";

    public static final String PENDING_USER_PATH = "/public/pending_user";
    public static final String ID_PARAMETER = "id";
    public static final String UNLOCK_PATH_SEGMENT = "/unlock";

    public static final String ADMIN_GUID_PARAMETER = "admin_guid";
    public static final String STATUS_PARAMETER = "status";
    public static final String ROLE_PATH_SEGMENT = "/role";
    public static final String UPDATE_RECOVERY_QUESTION_PATH_SEGMENT = "/update_recovery_question";
    public static final String SET_RECOVERY_QUESTION_PATH_SEGMENT = "/set_recovery_question";
    public static final String PUBLIC_REGISTRABLE_OPCOS_PATH = "/public/registrable_opcos";
    public static final String ACTIVATE_PATH_SEGMENT = "/activate";
    public static final String REJECT_PATH_SEGMENT = "/reject";
}
