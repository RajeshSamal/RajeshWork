package com.ntti3.gums;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GumsProtocolAuthorizationException extends GumsProtocolException {
    public GumsProtocolAuthorizationException() {
        super("Insufficient privileges to perform request");
    }
}
