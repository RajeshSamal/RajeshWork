package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import static com.ntti3.gums.GumsProtocolConstants.ADDITIONAL_INFO;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class PendingUserBase extends CommonUser {
    @JsonProperty(ADDITIONAL_INFO)
    private String additionalInfo;

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
