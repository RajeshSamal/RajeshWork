package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;

/**
 * @author jan.karwowski@ntti3.com
 *
 * This is a core class for all user classes used in system
 */
public abstract class CommonUser {
    @JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER)
    private String opcoUid;
    @JsonProperty(value = GumsProtocolConstants.EMAIL_PARAMETER)
    private String email;
    @JsonProperty(value = GumsProtocolConstants.OPCO_U_UID_PARAMETER)
    private String opcoUUid;
    @JsonProperty(value = GumsProtocolConstants.FIRST_NAME_PARAMETER)
    private String firstName;
    @JsonProperty(value = GumsProtocolConstants.LAST_NAME_PARAMETER)
    private String lastName;
    @JsonProperty(GumsProtocolConstants.MOBILE_PHONE_PARAMETER)
    private String mobilePhone;
    @JsonProperty(GumsProtocolConstants.OPCO_C_NAME_PARAMETER)
    private String opcoCName;

    public String getOpcoUid() {
        return opcoUid;
    }

    public void setOpcoUid(String opcoUid) {
        this.opcoUid = opcoUid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOpcoUUid() {
        return opcoUUid;
    }

    public void setOpcoUUid(String opcoUUid) {
        this.opcoUUid = opcoUUid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getOpcoCName() {
        return opcoCName;
    }

    public void setOpcoCName(String opcoCName) {
        this.opcoCName = opcoCName;
    }

}
