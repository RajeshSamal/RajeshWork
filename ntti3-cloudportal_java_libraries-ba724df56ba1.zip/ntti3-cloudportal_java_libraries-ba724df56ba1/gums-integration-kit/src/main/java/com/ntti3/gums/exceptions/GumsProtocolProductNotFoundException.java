package com.ntti3.gums.exceptions;

import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class GumsProtocolProductNotFoundException extends GumsProtocolExceptionWithErrorResponse {
    public GumsProtocolProductNotFoundException(ErrorResponse response) {
        super(response);
    }
}
