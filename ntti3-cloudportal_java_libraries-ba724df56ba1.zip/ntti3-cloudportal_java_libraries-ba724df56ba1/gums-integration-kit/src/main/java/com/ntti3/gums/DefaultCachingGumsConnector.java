package com.ntti3.gums;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.inject.Inject;
import com.ntti3.gums.models.Company;
import com.ntti3.gums.models.Opco;
import com.ntti3.gums.models.PendingUser;
import com.ntti3.gums.models.RequestedPendingUser;
import com.ntti3.gums.models.User;
import com.ntti3.gums.util.GumsLoadingCacheWrapper;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultCachingGumsConnector implements CachingGumsConnector {

    public static final int MAX_CACHE_SIZE = 1000;
    private final GumsConnector gumsConnector;

    private final GumsLoadingCacheWrapper<UUID, User> usersCache;
    private final GumsLoadingCacheWrapper<UUID, Company> companyCache;
    private final GumsLoadingCacheWrapper<String, Opco> opcoCache;

    @Inject
    public DefaultCachingGumsConnector(GumsConnector gumsConnector) {
        this.gumsConnector = gumsConnector;

        this.usersCache = new GumsLoadingCacheWrapper<>(CacheBuilder.newBuilder()
                .maximumSize(MAX_CACHE_SIZE)
                .build(new CacheLoader<UUID, User>() {
                    @Override
                    public User load(UUID guid) throws IOException, GumsProtocolException {
                        return DefaultCachingGumsConnector.this.gumsConnector.getUser(guid);
                    }
                }));

        this.companyCache = new GumsLoadingCacheWrapper<>(CacheBuilder.newBuilder()
                .maximumSize(MAX_CACHE_SIZE)
                .build(new CacheLoader<UUID, Company>() {
                    @Override
                    public Company load(UUID companyUid) throws IOException, GumsProtocolException {
                        return DefaultCachingGumsConnector.this.gumsConnector.getCompany(companyUid);
                    }
                }));

        this.opcoCache = new GumsLoadingCacheWrapper<>(CacheBuilder.newBuilder()
                .maximumSize(MAX_CACHE_SIZE)
                .build(new CacheLoader<String, Opco>() {
                    @Override
                    public Opco load(String opcoUidString) throws IOException, GumsProtocolException {
                        return DefaultCachingGumsConnector.this.gumsConnector.getOpco(opcoUidString);
                    }
                }));
    }

    @Override
    public void cleanCache() {
        this.usersCache.invalidateAll();
        this.companyCache.invalidateAll();
        this.opcoCache.invalidateAll();
    }

    @Override
    public User getUser(UUID guid) throws IOException, GumsProtocolException {
        return usersCache.get(guid);
    }

    @Override
    public UUID getOrRegisterUser(String firstName, String lastName, String email, String opcoUid, String opcoName, String opcoUUid, String opcoCUid, String opcoCName, List<String> flags) throws IOException, GumsProtocolException {
        return gumsConnector.getOrRegisterUser(firstName, lastName, email, opcoUid, opcoName, opcoUUid, opcoCUid, opcoCName, flags);
    }

    @Override
    public UUID getOrRegisterUser(String firstName, String lastName, String email, String mobilePhone, String opcoUid, String opcoName, String opcoUUid, String opcoCUid, String opcoCName, List<String> flags) throws IOException, GumsProtocolException {
        return gumsConnector.getOrRegisterUser(firstName, lastName, email,
                mobilePhone, opcoUid, opcoName, opcoUUid, opcoCUid, opcoCName, flags);
    }

    @Override
    public void updateUserData(User user) throws IOException, GumsProtocolException {
        gumsConnector.updateUserData(user);
        usersCache.put(user.getGuid(), user);
    }

    @Override
    public List<String> getUserProductWhitelist(UUID guid) throws IOException, GumsProtocolException {
        return gumsConnector.getUserProductWhitelist(guid);
    }

    @Override
    public void setUserProductWhitelist(UUID guid, List<String> whitelist) throws IOException, GumsProtocolException {
        gumsConnector.setUserProductWhitelist(guid, whitelist);
    }

    @Override
    public void addProductToUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException {
        gumsConnector.addProductToUserWhitelist(guid, product);
    }

    @Override
    public boolean isProductInUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException {
        return gumsConnector.isProductInUserWhitelist(guid, product);
    }

    @Override
    public boolean removeProductFromUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException {
        return gumsConnector.removeProductFromUserWhitelist(guid, product);
    }

    @Override
    public UUID getUserGuid(String opcoUid, String opcoUUid) throws IOException, GumsProtocolException {
        return gumsConnector.getUserGuid(opcoUid, opcoUUid);
    }

    @Override
    public Company getCompany(UUID companyGuid) throws IOException, GumsProtocolException {
        return companyCache.get(companyGuid);
    }

    @Override
    public UUID addCompany(String opcoCUid, String opcoCName, String opcoUid) throws IOException, GumsProtocolException {
        return gumsConnector.addCompany(opcoCUid, opcoCName, opcoUid);
    }

    @Override
    public boolean updateCompany(Company company) throws IOException, GumsProtocolException {
        boolean updateCompanyResult = gumsConnector.updateCompany(company);
        if (updateCompanyResult) {
            companyCache.invalidate(company.getCompanyGuid());
        }
        return updateCompanyResult;
    }

    @Override
    public UUID getCompanyGUID(String opcoUid, String opcoCUid) throws IOException, GumsProtocolException {
        return gumsConnector.getCompanyGUID(opcoUid, opcoCUid);
    }

    @Override
    public PagedResult<UUID> getCompanyUsers(UUID companyGuid, Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getCompanyUsers(companyGuid, offset, limit, orderBy);
    }

    @Override
    public Opco getOpco(String opcoUid) throws IOException, GumsProtocolException {
        return opcoCache.get(opcoUid);
    }

    @Override
    public void addOpco(String opcoUid, String opcoName) throws IOException, GumsProtocolException {
        gumsConnector.addOpco(opcoUid, opcoName);
    }

    @Override
    public void updateOpco(Opco opco) throws IOException, GumsProtocolException {
        gumsConnector.updateOpco(opco);
        opcoCache.invalidate(opco.getOpcoUid());
    }

    @Override
    public PagedResult<UUID> getOpcoUsers(String opcoUid, Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getOpcoUsers(opcoUid, offset, limit, orderBy);
    }

    @Override
    public PagedResult<Integer> getOpcoPendingUsers(String opcoUid, Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getOpcoPendingUsers(opcoUid, offset, limit, orderBy);
    }
    
    @Override
    public PagedResult<UUID> getUsers(Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getUsers(offset, limit, orderBy);
    }

    @Override
    public PagedResult<UUID> getOpcoCompanies(String opcoUid, Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getOpcoCompanies(opcoUid, offset, limit, orderBy);
    }

    @Override
    public List<String> getFlags() throws IOException, GumsProtocolException {
        return gumsConnector.getFlags();
    }

    @Override
    public List<String> getProducts() throws IOException, GumsProtocolException {
        return gumsConnector.getProducts();
    }

    @Override
    public void removePendingUser(int id) throws IOException, GumsProtocolException {
        gumsConnector.removePendingUser(id);
    }

    @Override
    public String getUserProductRole(UUID user, String product) throws IOException, GumsProtocolException {
        return gumsConnector.getUserProductRole(user, product);
    }

    @Override
    public void removeUserProductRole(UUID user, String product) throws IOException, GumsProtocolException {
        gumsConnector.removeUserProductRole(user, product);
    }

    @Override
    public void setUserProductRole(UUID user, String product, String role) throws IOException, GumsProtocolException {
        gumsConnector.setUserProductRole(user, product, role);
    }

    @Override
    public Map<String, String> getUserRoles(UUID user) throws IOException, GumsProtocolException {
        return gumsConnector.getUserRoles(user);
    }

    @Override
    public int addPendingUser(RequestedPendingUser user) throws IOException, GumsProtocolException {
        return gumsConnector.addPendingUser(user);
    }
    
    @Override
    public UUID activateUser(Integer id, List<String> products, String opcoCUid, String opcoCName)throws IOException, GumsProtocolException {
    	return gumsConnector.activateUser(id, products, opcoCUid, opcoCName);
    }
    
    @Override
    public void rejectUser(Integer id) throws IOException, GumsProtocolException {
        gumsConnector.rejectUser(id);
    }

    @Override
    public boolean loginUsed(String opcoUid, String login) throws IOException, GumsProtocolException {
        return gumsConnector.loginUsed(opcoUid, login);
    }

    @Override
    public UUID createUser(String firstName, String lastName, String email, String opcoUid, String opcoName, 
            String opcoUUid, String opcoCUid, String opcoCName, String password, String recoveryQuestion, 
            String recoveryAnswer, List<String> products) throws IOException, GumsProtocolException {
    	return gumsConnector.createUser(firstName, lastName, email, opcoUid, opcoName, opcoUUid, opcoCUid, opcoCName, 
    	        password, recoveryQuestion, recoveryAnswer, products);
    }

    @Override
    public PagedResult<Integer> getPendingUsers(Integer offset, Integer limit, OrderBy orderBy) throws IOException, GumsProtocolException {
        return gumsConnector.getPendingUsers(offset, limit, orderBy);
    }

    @Override
    public PendingUser getPendingUser(int id) throws IOException, GumsProtocolException {
        return gumsConnector.getPendingUser(id);
    }

    @Override
    public void unlock(UUID user) throws IOException, GumsProtocolException {
        gumsConnector.unlock(user);
    }

    @Override
    public boolean updatePassword(UUID user, String oldPassword, String newPassword) throws IOException, GumsProtocolException {
        return gumsConnector.updatePassword(user, oldPassword, newPassword);
    }

    @Override
    public void setPassword(UUID user, String newPassword) throws IOException, GumsProtocolException {
        gumsConnector.setPassword(user, newPassword);
    }

    @Override
    public boolean updateRecoveryQuestion(UUID user, String password, String question, String answer) throws IOException, GumsProtocolException {
        return gumsConnector.updateRecoveryQuestion(user, password, question, answer);
    }

    @Override
    public void setRecoveryQuestion(UUID user, String question, String answer) throws IOException, GumsProtocolException {
        gumsConnector.setRecoveryQuestion(user, question, answer);
    }

    @Override
    public List<String> getUpdateableOpcos() throws IOException, GumsProtocolException {
        return gumsConnector.getUpdateableOpcos();
    }
}
