package com.ntti3.gums;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.SerializedString;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ntti3.connectors.BaseConnector;
import com.ntti3.gums.exceptions.factories.CompanyNotFoundExceptionFactory;
import com.ntti3.gums.exceptions.factories.EntityExistsExceptionFactory;
import com.ntti3.gums.exceptions.factories.ExceptionFactory;
import com.ntti3.gums.exceptions.factories.FlagNotSetExceptionFactory;
import com.ntti3.gums.exceptions.factories.IncorrectCallExceptionFactory;
import com.ntti3.gums.exceptions.factories.IncorrectParameterFormatExceptionFactory;
import com.ntti3.gums.exceptions.factories.MissingParameterExceptionFactory;
import com.ntti3.gums.exceptions.factories.OpcoNotFoundExceptionFactory;
import com.ntti3.gums.exceptions.factories.OperationNotSupportedExceptionFactory;
import com.ntti3.gums.exceptions.factories.ProductNotFoundExceptionFactory;
import com.ntti3.gums.exceptions.factories.UserNotFoundExceptionFactory;
import com.ntti3.gums.models.Company;
import com.ntti3.gums.models.Opco;
import com.ntti3.gums.models.PendingUser;
import com.ntti3.gums.models.RequestedPendingUser;
import com.ntti3.gums.models.User;
import com.ntti3.protocol.CloseableIOIterator;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ErrorResponse;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;

/**
 * Helper class used to perform requests to GUMS server. The class is used to
 * perform either SSL and no-SSL requests. A non-SSL mode is only for testing
 * purposes.
 *
 * @author jan.karwowski@ntti3.com
 */
public class DefaultGumsConnector extends BaseConnector implements
        GumsConnector {
    private static final Charset CHARSET_UTF8 = Charset.forName("utf-8");
    private final ObjectMapper mapper = new ObjectMapper();
    private final JsonFactory factory = new JsonFactory();
    private final Map<ErrorCode, ExceptionFactory> exceptionMap;

    {
        Map<ErrorCode, ExceptionFactory> map = new EnumMap<>(ErrorCode.class);
        map.put(ErrorCode.USER_NOT_FOUND, new UserNotFoundExceptionFactory());
        map.put(ErrorCode.COMPANY_NOT_FOUND, new CompanyNotFoundExceptionFactory());
        map.put(ErrorCode.OPCO_NOT_FOUND, new OpcoNotFoundExceptionFactory());
        map.put(ErrorCode.PRODUCT_NOT_FOUND, new ProductNotFoundExceptionFactory());
        map.put(ErrorCode.FLAG_NOT_SET, new FlagNotSetExceptionFactory());
        map.put(ErrorCode.MISSING_PARAMETERS, new MissingParameterExceptionFactory());
        map.put(ErrorCode.INCORRECT_PARAMETER_FORMAT, new IncorrectParameterFormatExceptionFactory());
        map.put(ErrorCode.INCORRECT_CALL, new IncorrectCallExceptionFactory());
        map.put(ErrorCode.ENTITY_EXISTS, new EntityExistsExceptionFactory());
        map.put(ErrorCode.OPERATION_NOT_SUPPORTED, new OperationNotSupportedExceptionFactory());
        exceptionMap = Collections.unmodifiableMap(map);
    }

    public DefaultGumsConnector(URI baseAddress, @Nullable HttpParams params) {
        super(baseAddress, params);
    }

    public DefaultGumsConnector(URI baseAddress, @Nullable HttpParams params,
                                Collection<Scheme> schemes) {
        super(baseAddress, params, schemes);
    }

    public DefaultGumsConnector(URI baseAddress, @Nullable HttpParams params,
                                @Nullable SSLSocketFactory httpsSocketFactory) {
        super(baseAddress, params, httpsSocketFactory);
    }

    @Override
    public User getUser(final UUID guid) throws IOException,
            GumsProtocolException {
        return performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + guid.toString(),
                new HttpGet(), new ResponseProcessor<User>() {
                    @Override
                    public User process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            HttpEntity entity = response.getEntity();
                            User user = mapper.readValue(entity.getContent(),
                                    User.class);
                            user.setGuid(guid);
                            return user;
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public UUID getOrRegisterUser(String firstName, String lastName,
                                  String email, String opcoUid, String opcoName, String opcoUUid,
                                  String opcoCUid, String opcoCName, List<String> flags)
            throws IOException, GumsProtocolException {
        return getOrRegisterUser(firstName, lastName, email, null, opcoUid,
                opcoName, opcoUUid, opcoCUid, opcoCName, flags);
    }

    @Override
    public UUID getOrRegisterUser(String firstName, String lastName,
                                  String email, String mobilePhone, String opcoUid, String opcoName,
                                  String opcoUUid, String opcoCUid, String opcoCName,
                                  List<String> flags) throws IOException, GumsProtocolException {
        HttpPut method = new HttpPut();
        Collection<NameValuePair> params = Lists.newArrayList();

        params.add(new BasicNameValuePair(GumsProtocolConstants.FIRST_NAME_PARAMETER, firstName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.LAST_NAME_PARAMETER, lastName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.EMAIL_PARAMETER, email));
        if (mobilePhone != null)
            params.add(new BasicNameValuePair(GumsProtocolConstants.MOBILE_PHONE_PARAMETER,
                    mobilePhone));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_UID_PARAMETER, opcoUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_NAME_PARAMETER, opcoName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_U_UID_PARAMETER, opcoUUid));
        if (opcoCUid != null) {
            params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_UID_PARAMETER, opcoCUid));
        }
        if (opcoCName != null) {
            params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, opcoCName));
        }
        if (flags != null) {
            for (String flag : flags) {
                params.add(new BasicNameValuePair(GumsProtocolConstants.FLAGS_PARAMETER, flag));
            }
        }

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        method.setEntity(entity);
        return performRequest(GumsProtocolConstants.USER_BASE_PATH, method,
                new ResponseProcessor<UUID>() {
                    @Override
                    public UUID process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            HttpEntity rEntity = response.getEntity();
                            JsonNode node = mapper.readTree(rEntity
                                    .getContent());
                            return UUID.fromString(node
                                    .get(GumsProtocolConstants.GUID_RESPONSE_FIELD).asText());
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void updateUserData(User user) throws IOException,
            GumsProtocolException {
        HttpPut method = new HttpPut();
        Collection<NameValuePair> params = Lists.newArrayList();

        params.add(new BasicNameValuePair(GumsProtocolConstants.FIRST_NAME_PARAMETER, user
                .getFirstName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.LAST_NAME_PARAMETER, user
                .getLastName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.MOBILE_PHONE_PARAMETER, user
                .getMobilePhone()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.EMAIL_PARAMETER, user.getEmail()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_U_UID_PARAMETER, user
                .getOpcoUUid()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.ACTIVE_PARAMETER, Boolean
                .toString(user.isActive())));
        params.add(new BasicNameValuePair(GumsProtocolConstants.COMPANY_GUID_PARAMETER, user
                .getCompanyGuid()));

        params.addAll(Lists.transform(user.getFlags(),
                new Function<String, NameValuePair>() {
                    @Override
                    public NameValuePair apply(String s) {
                        return new BasicNameValuePair(GumsProtocolConstants.FLAGS_PARAMETER, s);
                    }
                }));

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        method.setEntity(entity);
        performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.getGuid().toString(),
                method, new ResponseProcessor<Object>() {
                    @Override
                    public Object process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                        } else {
                            throw handleError(response);
                        }
                        return null;
                    }
                });
    }

    @Override
    public List<String> getUserProductWhitelist(UUID guid) throws IOException,
            GumsProtocolException {
        return baseGetWhitelist(GumsProtocolConstants.USER_BASE_PATH + "/" + guid.toString()
                + GumsProtocolConstants.WHITELIST_SUBPATH);
    }

    @Override
    public void setUserProductWhitelist(UUID guid, List<String> whitelist)
            throws IOException, GumsProtocolException {
        baseSetWhitelist(GumsProtocolConstants.USER_BASE_PATH + "/" + guid.toString()
                + GumsProtocolConstants.WHITELIST_SUBPATH, whitelist);
    }

    @Override
    public void addProductToUserWhitelist(UUID guid, String product)
            throws IOException, GumsProtocolException {
        addProductToWhitelistBase(GumsProtocolConstants.USER_BASE_PATH + "/" + guid.toString()
                + GumsProtocolConstants.WHITELIST_SUBPATH + "/" + product);
    }

    @Override
    public boolean isProductInUserWhitelist(UUID guid, String product)
            throws IOException, GumsProtocolException {
        return isProductInWhitelistBase(GumsProtocolConstants.USER_BASE_PATH + "/" + guid.toString()
                + GumsProtocolConstants.WHITELIST_SUBPATH + "/" + product);
    }

    @Override
    public boolean removeProductFromUserWhitelist(UUID guid, String product)
            throws IOException, GumsProtocolException {
        return removeProductFromWhitelistBase(GumsProtocolConstants.USER_BASE_PATH + "/"
                + guid.toString() + GumsProtocolConstants.WHITELIST_SUBPATH + "/" + product);
    }

    @Override
    public UUID getUserGuid(String opcoUid, String opcoUUid)
            throws IOException, GumsProtocolException {
        return performRequest(GumsProtocolConstants.USER_BASE_PATH + GumsProtocolConstants.GUID_PATH_SEGMENT + opcoUid
                + "/" + opcoUUid, new HttpGet(), new ResponseProcessor<UUID>() {
            @Override
            public UUID process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    JsonNode node = mapper.readTree(response.getEntity()
                            .getContent());
                    return UUID.fromString(node.get(GumsProtocolConstants.GUID_RESPONSE_FIELD)
                            .asText());
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    @Override
    public Company getCompany(UUID companyGuid) throws IOException,
            GumsProtocolException {
        return performRequest(GumsProtocolConstants.COMPANY_BASE_PATH + "/" + companyGuid.toString(),
                new HttpGet(), new ResponseProcessor<Company>() {
                    @Override
                    public Company process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return mapper.readValue(response.getEntity()
                                        .getContent(), Company.class);
                            case 400:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public UUID addCompany(String opcoCUid, String opcoCName, String opcoUid)
            throws IOException, GumsProtocolException {
        HttpPost method = new HttpPost();
        Collection<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, opcoCName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_UID_PARAMETER, opcoCUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_UID_PARAMETER, opcoUid));

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        method.setEntity(entity);

        return performRequest(GumsProtocolConstants.COMPANY_BASE_PATH, method,
                new ResponseProcessor<UUID>() {
                    @Override
                    public UUID process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            return UUID
                                    .fromString(mapper
                                            .readTree(
                                                    response.getEntity()
                                                            .getContent())
                                            .get(GumsProtocolConstants.GUID_RESPONSE_FIELD).asText());
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public boolean updateCompany(Company company) throws IOException,
            GumsProtocolException {
        HttpPut method = new HttpPut();
        Collection<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, company
                .getOpcoCName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_UID_PARAMETER, company
                .getOpcoCUid()));

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        method.setEntity(entity);

        return performRequest(GumsProtocolConstants.COMPANY_BASE_PATH + "/"
                        + company.getCompanyGuid().toString(), method,
                new ResponseProcessor<Boolean>() {
                    @Override
                    public Boolean process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            return true;
                        } else if (response.getStatusLine().getStatusCode() == 404) {
                            return false;
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public UUID getCompanyGUID(String opcoUid, String opcoCUid)
            throws IOException, GumsProtocolException {
        String path = GumsProtocolConstants.COMPANY_BASE_PATH + GumsProtocolConstants.GUID_PATH_SEGMENT + opcoUid;
        if (opcoCUid != null)
            path += "/" + opcoCUid;
        return performRequest(path, new HttpGet(),
                new ResponseProcessor<UUID>() {
                    @Override
                    public UUID process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return UUID
                                        .fromString(mapper.readTree(
                                                response.getEntity().getContent())
                                                .asText());
                            case 404:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public PagedResult<UUID> getCompanyUsers(UUID companyGuid, Integer offset,
                                             Integer limit, OrderBy orderBy) throws IOException,
            GumsProtocolException {
        return getChunkedList(GumsProtocolConstants.COMPANY_BASE_PATH + "/" + companyGuid.toString()
                + GumsProtocolConstants.USERS_PATH_SEGMENT, offset, limit, orderBy);
    }

    @Override
    public Opco getOpco(String opcoUid) throws IOException,
            GumsProtocolException {
        return performRequest(GumsProtocolConstants.OPCO_BASE_PATH + "/" + opcoUid, new HttpGet(),
                new ResponseProcessor<Opco>() {
                    @Override
                    public Opco process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return mapper.readValue(response.getEntity()
                                        .getContent(), Opco.class);
                            case 404:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void addOpco(String opcoUid, String opcoName) throws IOException,
            GumsProtocolException {
        HttpPost request = new HttpPost();
        Collection<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_NAME_PARAMETER, opcoName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_UID_PARAMETER, opcoUid));
        request.setEntity(new UrlEncodedFormEntity(params, CHARSET_UTF8));
        performRequest(GumsProtocolConstants.OPCO_BASE_PATH, request, new ResponseProcessor<Void>() {
            @Override
            public Void process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                switch (response.getStatusLine().getStatusCode()) {
                    case 200:
                        return null;
                    default:
                        throw handleError(response);
                }
            }
        });
    }

    @Override
    public void updateOpco(Opco opco) throws IOException, GumsProtocolException {
        HttpPut request = new HttpPut();
        Collection<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_NAME_PARAMETER, opco
                .getOpcoName()));
        request.setEntity(new UrlEncodedFormEntity(params, CHARSET_UTF8));
        performRequest(GumsProtocolConstants.OPCO_BASE_PATH + "/" + opco.getOpcoUid(), request,
                new ResponseProcessor<Void>() {
                    @Override
                    public Void process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public PagedResult<UUID> getOpcoUsers(String opcoUid, Integer offset,
                                          Integer limit, OrderBy orderBy) throws IOException,
            GumsProtocolException {
        return getChunkedList(GumsProtocolConstants.OPCO_BASE_PATH + "/" + opcoUid
                + GumsProtocolConstants.USERS_PATH_SEGMENT, offset, limit, orderBy);
    }

    @Override
    public PagedResult<Integer> getOpcoPendingUsers(String opcoUid, Integer offset,
                                                    Integer limit, OrderBy orderBy) throws IOException,
            GumsProtocolException {
        URIBuilder builder = getBaseBuilder().setPath(GumsProtocolConstants.OPCO_BASE_PATH + "/" + opcoUid
                + GumsProtocolConstants.PENDING_USERS_PATH_SEGMENT);

        return getChunkedList(builder, new JsonGetNextFunction<Integer>() {
            @Override
            public Integer getNext(JsonParser parser) throws IOException {
                String token = parser.nextTextValue();
                if (token != null) {
                    return Integer.parseInt(token);
                }
                return null;
            }
        }, offset, limit, orderBy);
    }

    @Override
    public PagedResult<UUID> getUsers(Integer offset, Integer limit,
                                      OrderBy orderBy) throws IOException, GumsProtocolException {
        return getChunkedList(GumsProtocolConstants.USER_BASE_PATH, offset, limit, orderBy);
    }

    @Override
    public PagedResult<UUID> getOpcoCompanies(String opcoUid, Integer offset,
                                              Integer limit, OrderBy orderBy) throws IOException,
            GumsProtocolException {
        return getChunkedList(GumsProtocolConstants.OPCO_BASE_PATH + "/" + opcoUid
                + GumsProtocolConstants.COMPANIES_PATH_SEGMENT, offset, limit, orderBy);
    }

    @Override
    public List<String> getFlags() throws IOException, GumsProtocolException {
        return performRequest(GumsProtocolConstants.FLAGS_BASE_PATH, new HttpGet(),
                new ResponseProcessor<List<String>>() {
                    @Override
                    public List<String> process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return readJsonStringArray(response.getEntity()
                                        .getContent(), GumsProtocolConstants.FLAGS_PARAMETER);
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public List<String> getProducts() throws IOException, GumsProtocolException {
        return performRequest(GumsProtocolConstants.PRODUCTS_BASE_PATH, new HttpGet(),
                new ResponseProcessor<List<String>>() {
                    @Override
                    public List<String> process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return readJsonStringArray(response.getEntity()
                                        .getContent(), GumsProtocolConstants.PRODUCTS_PARAMETER);
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void unlock(UUID user) throws IOException, GumsProtocolException {
        performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString()
                        + GumsProtocolConstants.UNLOCK_PATH_SEGMENT, new HttpPut(),
                new ResponseProcessor<Void>() {
                    @Override
                    public Void process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public int addPendingUser(RequestedPendingUser user)
            throws IOException, GumsProtocolException {
        List<NameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_U_UID_PARAMETER, user
                .getOpcoUUid()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_UID_PARAMETER, user.getOpcoUid()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.FIRST_NAME_PARAMETER, user
                .getFirstName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.LAST_NAME_PARAMETER, user
                .getLastName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.EMAIL_PARAMETER, user.getEmail()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.MOBILE_PHONE_PARAMETER, user
                .getMobilePhone()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.PASSWORD_PARAMETER, user
                .getPassword()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_PARAMETER, user
                .getRecoveryQuestion()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_ANSWER, user
                .getRecoveryAnswer()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, user
                .getOpcoCName()));
        params.add(new BasicNameValuePair(GumsProtocolConstants.ADDITIONAL_INFO, user
                .getAdditionalInfo()));

        HttpPost request = new HttpPost();
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        request.setEntity(entity);

        try {
            request.setURI(getBaseBuilder().setPath(GumsProtocolConstants.PENDING_USER_PATH)
                    .build());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        return performRequest(request, new ResponseProcessor<Integer>() {
            @Override
            public Integer process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                switch (response.getStatusLine().getStatusCode()) {
                    case 200:
                        JsonNode node = mapper.readTree(response.getEntity()
                                .getContent());
                        return node.get(GumsProtocolConstants.ID_PARAMETER).asInt();
                    default:
                        throw handleError(response);
                }
            }
        });
    }

    @Override
    public UUID activateUser(Integer id, List<String> products, String opcoCUid, String opcoCName) throws IOException, GumsProtocolException
    {
        List<NameValuePair> params = new ArrayList<>();
        for (String product : products) {
            params.add(new BasicNameValuePair(GumsProtocolConstants.PRODUCTS_PARAMETER, product));
        }
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_UID_PARAMETER, opcoCUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, opcoCName));

        HttpPut request = new HttpPut();
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        request.setEntity(entity);

        try {
            request.setURI(getBaseBuilder().setPath(GumsProtocolConstants.PENDING_USER_PATH + GumsProtocolConstants.ACTIVATE_PATH_SEGMENT + "/" + id)
                    .build());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        return performRequest(request, new ResponseProcessor<UUID>() {
            @Override
            public UUID process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity rEntity = response.getEntity();
                    JsonNode node = mapper.readTree(rEntity
                            .getContent());
                    return UUID.fromString(node
                            .get(GumsProtocolConstants.GUID_RESPONSE_FIELD).asText());
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    @Override
    public void rejectUser(Integer id) throws IOException, GumsProtocolException {
        HttpPut request = new HttpPut();
        try {
            request.setURI(getBaseBuilder().setPath(GumsProtocolConstants.PENDING_USER_PATH + GumsProtocolConstants.REJECT_PATH_SEGMENT + "/" + id)
                    .build());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        performRequest(request, new ResponseProcessor<Void>() {
            @Override
            public Void process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    return null;
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    @Override
    public boolean loginUsed(String opcoUid, String login) throws IOException, GumsProtocolException {
        HttpGet request = new HttpGet();
        try {
            request.setURI(getBaseBuilder().setPath(GumsProtocolConstants.LOGIN_USED_BASE_PATH + "/" + opcoUid + "/" + login).build());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        return performRequest(request, new ResponseProcessor<Boolean>() {
            @Override
            public Boolean process(HttpResponse response) throws GumsProtocolException, IOException {
                switch (response.getStatusLine().getStatusCode()) {
                    case HttpStatus.SC_OK:
                        return true;
                    case HttpStatus.SC_NOT_FOUND:
                        return false;
                    default:
                        throw handleError(response);
                }
            }
        });
    }

    @Override
    public UUID createUser(String firstName, String lastName, String email, String opcoUid, String opcoName,
                           String opcoUUid, String opcoCUid, String opcoCName, String password, String recoveryQuestion,
                           String recoveryAnswer, List<String> products)
            throws IOException, GumsProtocolException
    {
        List<NameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_U_UID_PARAMETER, opcoUUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_UID_PARAMETER, opcoUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.FIRST_NAME_PARAMETER, firstName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.LAST_NAME_PARAMETER, lastName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.EMAIL_PARAMETER, email));
        params.add(new BasicNameValuePair(GumsProtocolConstants.PASSWORD_PARAMETER, password));
        params.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_PARAMETER, recoveryQuestion));
        params.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_ANSWER, recoveryAnswer));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_NAME_PARAMETER, opcoName));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_UID_PARAMETER, opcoCUid));
        params.add(new BasicNameValuePair(GumsProtocolConstants.OPCO_C_NAME_PARAMETER, opcoCName));
        for (String product : products) {
            params.add(new BasicNameValuePair(GumsProtocolConstants.PRODUCTS_PARAMETER, product));
        }

        HttpPost request = new HttpPost();
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        request.setEntity(entity);

        try {
            request.setURI(getBaseBuilder().setPath(GumsProtocolConstants.USER_BASE_PATH).build());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        return performRequest(request, new ResponseProcessor<UUID>() {
            @Override
            public UUID process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity rEntity = response.getEntity();
                    JsonNode node = mapper.readTree(rEntity
                            .getContent());
                    return UUID.fromString(node
                            .get(GumsProtocolConstants.GUID_RESPONSE_FIELD).asText());
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    @Override
    public void setPassword(UUID user, String newPassword) throws IOException,
            GumsProtocolException {
        HttpPut request = new HttpPut();
        List<NameValuePair> map = Lists.newArrayList();
        map.add(new BasicNameValuePair(GumsProtocolConstants.PASSWORD_PARAMETER, newPassword));
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(map);
        request.setEntity(entity);
        performRequest(
                (GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString() + "/set_password"),
                request, new SimpleResponseProcessor<Void>() {
                    @Override
                    protected Void processOkRequest(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        return null;
                    }
                });
    }

    @Override
    public boolean updatePassword(UUID user, String oldPassword,
                                  String newPassword) throws IOException, GumsProtocolException {
        HttpPut request = new HttpPut();
        List<NameValuePair> map = Lists.newArrayList();
        map.add(new BasicNameValuePair(GumsProtocolConstants.NEW_PASSWORD_PARAMETER, newPassword));
        map.add(new BasicNameValuePair(GumsProtocolConstants.OLD_PASSWORD_PARAMETER, oldPassword));
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(map);
        request.setEntity(entity);
        return performRequest(
                (GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString() + "/update_password"),
                request, new ResponseProcessor<Boolean>() {
                    @Override
                    public Boolean process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case HttpStatus.SC_OK:
                                return true;
                            case HttpStatus.SC_UNAUTHORIZED:
                                return false;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public boolean updateRecoveryQuestion(UUID user, String oldPassword,
                                          String question, String answer) throws IOException,
            GumsProtocolException {
        HttpPut request = new HttpPut();
        List<NameValuePair> map = Lists.newArrayList();
        map.add(new BasicNameValuePair(GumsProtocolConstants.OLD_PASSWORD_PARAMETER, oldPassword));
        map.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_PARAMETER, question));
        map.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_ANSWER, answer));
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(map);
        request.setEntity(entity);
        return performRequest(
                (GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString() + GumsProtocolConstants.UPDATE_RECOVERY_QUESTION_PATH_SEGMENT),
                request, new ResponseProcessor<Boolean>() {
                    @Override
                    public Boolean process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case HttpStatus.SC_OK:
                                return true;
                            case HttpStatus.SC_UNAUTHORIZED:
                                return false;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void setRecoveryQuestion(UUID user, String question, String answer)
            throws IOException, GumsProtocolException {
        HttpPut request = new HttpPut();
        List<NameValuePair> map = Lists.newArrayList();
        map.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_PARAMETER, question));
        map.add(new BasicNameValuePair(GumsProtocolConstants.RECOVERY_QUESTION_ANSWER, answer));
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(map);
        request.setEntity(entity);
        performRequest(
                (GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString() + GumsProtocolConstants.SET_RECOVERY_QUESTION_PATH_SEGMENT),
                request, new SimpleResponseProcessor<Void>() {
                    @Override
                    protected Void processOkRequest(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        return null;
                    }
                });
    }

    @Override
    public PagedResult<Integer> getPendingUsers(Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException {
        URIBuilder builder = getBaseBuilder().setPath(GumsProtocolConstants.PENDING_USER_PATH);

        return getChunkedList(builder, new JsonGetNextFunction<Integer>() {
            @Override
            public Integer getNext(JsonParser parser) throws IOException {
                JsonToken token = parser.nextValue();
                if (token != null && token.isNumeric()) {
                    return parser.getIntValue();
                }
                return null;
            }
        }, offset, limit, orderBy);
    }

    @Override
    public PendingUser getPendingUser(int id)
            throws IOException, GumsProtocolException {
        try {
            HttpGet request = new HttpGet(getBaseBuilder()
                    .setPath(GumsProtocolConstants.PENDING_USER_PATH + "/" + id)
                    .build());

            return performRequest(request,
                    new ResponseProcessor<PendingUser>() {
                        @Override
                        public PendingUser process(HttpResponse response)
                                throws GumsProtocolException, IOException {
                            switch (response.getStatusLine().getStatusCode()) {
                                case HttpStatus.SC_OK:
                                    return mapper.reader(PendingUser.class)
                                            .readValue(
                                                    response.getEntity()
                                                            .getContent());
                                case HttpStatus.SC_NOT_FOUND:
                                    return null;
                                default:
                                    throw handleError(response);
                            }
                        }
                    });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getUserProductRole(UUID user, String product)
            throws IOException, GumsProtocolException {
        return performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString()
                        + GumsProtocolConstants.ROLE_PATH_SEGMENT + "/" + product, new HttpGet(),
                new ResponseProcessor<String>() {
                    @Override
                    public String process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                JsonNode node = mapper.readTree(response
                                        .getEntity().getContent());
                                return node.get("role").asText();
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void removeUserProductRole(UUID user, String product)
            throws IOException, GumsProtocolException {
        performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString()
                        + GumsProtocolConstants.ROLE_PATH_SEGMENT + "/" + product, new HttpDelete(),
                new ResponseProcessor<Void>() {
                    @Override
                    public Void process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void setUserProductRole(UUID user, String product, String role)
            throws IOException, GumsProtocolException {
        HttpPut request = new HttpPut();
        List<NameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair(GumsProtocolConstants.ROLE_PARAMETER, role));

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,
                CHARSET_UTF8);
        request.setEntity(entity);

        performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString()
                        + GumsProtocolConstants.ROLE_PATH_SEGMENT + "/" + product, request,
                new ResponseProcessor<Void>() {
                    @Override
                    public Void process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public void removePendingUser(int id) throws IOException,
            GumsProtocolException {
        performRequest(GumsProtocolConstants.PENDING_USER_PATH + "/" + id, new HttpDelete(),
                new ResponseProcessor<Void>() {
                    @Override
                    public Void process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return null;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public Map<String, String> getUserRoles(UUID user) throws IOException,
            GumsProtocolException {
        return performRequest(GumsProtocolConstants.USER_BASE_PATH + "/" + user.toString()
                        + GumsProtocolConstants.ROLE_PATH_SEGMENT, new HttpGet(),
                new ResponseProcessor<Map<String, String>>() {
                    @Override
                    public Map<String, String> process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                JsonNode node = mapper.readTree(response
                                        .getEntity().getContent());
                                Map<String, String> ret = Maps.newHashMap();
                                Iterator<Map.Entry<String, JsonNode>> iterator = node
                                        .fields();
                                while (iterator.hasNext()) {
                                    Map.Entry<String, JsonNode> entry = iterator
                                            .next();
                                    ret.put(entry.getKey(), entry.getValue()
                                            .asText());
                                }
                                return ret;
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    @Override
    public List<String> getUpdateableOpcos() throws IOException,
            GumsProtocolException {
        return performRequest(GumsProtocolConstants.PUBLIC_REGISTRABLE_OPCOS_PATH, new HttpGet(),
                new ResponseProcessor<List<String>>() {
                    @Override
                    public List<String> process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        switch (response.getStatusLine().getStatusCode()) {
                            case 200:
                                return mapper.reader(List.class).readValue(
                                        response.getEntity().getContent());
                            default:
                                throw handleError(response);
                        }
                    }
                });
    }

    private <T> T performRequest(String path, HttpRequestBase request,
                                 ResponseProcessor<T> processor) throws IOException,
            GumsProtocolException {
        try {
            request.setURI(getBaseBuilder().setPath(path).build());
            return performRequest(request, processor);
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    private <T> T performRequest(HttpRequestBase request,
                                 ResponseProcessor<T> processor) throws IOException,
            GumsProtocolException {
        HttpResponse response = getHttpClient().execute(request);
        try {
            return processor.process(response);
        } finally {
            request.releaseConnection();
        }
    }

    private <T> PagedResult<T> getChunkedList(URIBuilder requestURI,
                                              JsonGetNextFunction<T> function, Integer offset, Integer limit,
                                              OrderBy orderBy) throws IOException, GumsProtocolException {
        try {
            if (offset != null)
                requestURI = requestURI.addParameter(GumsProtocolConstants.OFFSET_QUERY_PARAM,
                        offset.toString());
            if (limit != null)
                requestURI = requestURI.addParameter(GumsProtocolConstants.LIMIT_QUERY_PARAM,
                        limit.toString());
            if (orderBy != null)
                for (NameValuePair param : orderBy.buildQueryParams()) {
                    requestURI.addParameter(param.getName(), param.getValue());
                }
            HttpGet get = new HttpGet(requestURI.build());
            HttpResponse response = getHttpClient().execute(get);
            if (response.getStatusLine().getStatusCode() == 200) {
                JsonParser parser = factory.createParser(response.getEntity()
                        .getContent());
                while (!parser.nextFieldName(new SerializedString(
                        GumsProtocolConstants.COUNT_FIELD_NAME)))
                    ;
                parser.nextToken();
                int count = parser.getIntValue();

                while (parser.nextToken() != JsonToken.START_ARRAY)
                    ;
                return new PagedResult<>(new JsonResponseIterator<>(get,
                        parser, function), count);
            } else {
                try {
                    throw handleError(response);
                } finally {
                    get.releaseConnection();
                }
            }
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    private PagedResult<UUID> getChunkedList(String path, Integer offset,
                                             Integer limit, OrderBy orderBy) throws IOException,
            GumsProtocolException {
        try {
            URIBuilder builder = getBaseBuilder().setPath(path);
            if (offset != null)
                builder = builder.addParameter(GumsProtocolConstants.OFFSET_QUERY_PARAM,
                        offset.toString());
            if (limit != null)
                builder = builder.addParameter(GumsProtocolConstants.LIMIT_QUERY_PARAM,
                        limit.toString());
            if (orderBy != null)
                for (NameValuePair param : orderBy.buildQueryParams()) {
                    builder.addParameter(param.getName(), param.getValue());
                }
            HttpGet get = new HttpGet(builder.build());
            HttpResponse response = getHttpClient().execute(get);
            if (response.getStatusLine().getStatusCode() == 200) {
                JsonParser parser = factory.createParser(response.getEntity()
                        .getContent());
                while (!parser.nextFieldName(new SerializedString(
                        GumsProtocolConstants.COUNT_FIELD_NAME)) && parser.hasCurrentToken())
                    ;
                parser.nextToken();
                int count = parser.getIntValue();

                // skip json opening tokens
                while (parser.nextToken() != JsonToken.START_ARRAY
                        && parser.hasCurrentToken())
                    ;

                return new PagedResult<>(
                        new HttpUUIDArrayIterator(get, parser), count);
            } else {
                try {
                    throw handleError(response);
                } finally {
                    get.releaseConnection();
                }
            }
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    private List<String> readJsonStringArray(JsonNode node) {
        return Lists.transform(Lists.newArrayList(node.elements()),
                new Function<JsonNode, String>() {
                    @Override
                    public String apply(JsonNode node) {
                        return node.asText();
                    }
                });
    }

    private List<String> readJsonStringArray(InputStream jsonInput,
                                             String arrayName) throws IOException {
        return readJsonStringArray(mapper.readTree(jsonInput), arrayName);
    }

    private List<String> readJsonStringArray(JsonNode node, String arrayName) {
        return readJsonStringArray(node.get(arrayName));
    }

    private List<String> baseGetWhitelist(String path) throws IOException,
            GumsProtocolException {
        HttpGet method = new HttpGet();
        return performRequest(path, method,
                new ResponseProcessor<List<String>>() {
                    @Override
                    public List<String> process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            return readJsonStringArray(response.getEntity()
                                    .getContent(), GumsProtocolConstants.WHITELIST_FLAG);
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    private void baseSetWhitelist(String path, List<String> whitelist)
            throws IOException, GumsProtocolException {
        HttpPut method = new HttpPut();
        Collection<NameValuePair> params = Lists.transform(whitelist,
                new Function<String, NameValuePair>() {
                    @Override
                    public NameValuePair apply(String s) {
                        return new BasicNameValuePair(GumsProtocolConstants.WHITELIST_FLAG, s);
                    }
                });
        method.setEntity(new UrlEncodedFormEntity(params, CHARSET_UTF8));

        performRequest(path, method, new ResponseProcessor<Object>() {
            @Override
            public Object process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    return null;
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    private boolean isProductInWhitelistBase(String path) throws IOException,
            GumsProtocolException {
        return performRequest(path, new HttpGet(),
                new ResponseProcessor<Boolean>() {
                    @Override
                    public Boolean process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            return true;
                        } else if (response.getStatusLine().getStatusCode() == 404) {
                            return false;
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    private void addProductToWhitelistBase(String path) throws IOException,
            GumsProtocolException {
        performRequest(path, new HttpPost(), new ResponseProcessor<Object>() {
            @Override
            public Object process(HttpResponse response)
                    throws GumsProtocolException, IOException {
                if (response.getStatusLine().getStatusCode() == 200) {
                    return null;
                } else {
                    throw handleError(response);
                }
            }
        });
    }

    private boolean removeProductFromWhitelistBase(String path)
            throws IOException, GumsProtocolException {
        return performRequest(path, new HttpDelete(),
                new ResponseProcessor<Boolean>() {
                    @Override
                    public Boolean process(HttpResponse response)
                            throws GumsProtocolException, IOException {
                        if (response.getStatusLine().getStatusCode() == 200) {
                            return true;
                        } else if (response.getStatusLine().getStatusCode() == 404) {
                            return false;
                        } else {
                            throw handleError(response);
                        }
                    }
                });
    }

    private GumsProtocolException handleError(HttpResponse response)
            throws IOException {
        switch (response.getStatusLine().getStatusCode()) {
            case 500:
                return new GumsProtocolException("Internal Server Error");
            case 403:
                return new GumsProtocolAuthorizationException();
            case 503:
                return new GumsProtocolServiceUnavailable();
        }

        ErrorResponse errorResponse = null;
        if (response.getEntity().getContentType().getValue()
                .contains("application/json"))
            errorResponse = mapper.readValue(response.getEntity().getContent(),
                    Error.class).error;

        if (errorResponse != null) {
            if(exceptionMap.containsKey(errorResponse.getCode())) {
                return exceptionMap.get(errorResponse.getCode()).create(errorResponse);
            }
            return new GumsProtocolExceptionWithErrorResponse(errorResponse);
        }
        return new GumsProtocolException("UnknownError, http response: "
                + response.getStatusLine().getStatusCode());
    }

    protected static interface ResponseProcessor<T> {
        public T process(HttpResponse response) throws GumsProtocolException,
                IOException;
    }

    private interface JsonGetNextFunction<T> {
        public T getNext(JsonParser parser) throws IOException;
    }

    private static class Error {
        public ErrorResponse error;
    }

    private class HttpUUIDArrayIterator implements CloseableIOIterator<UUID> {
        UUID nextUUID = null;
        private HttpRequestBase request;
        private JsonParser parser;

        private HttpUUIDArrayIterator(HttpRequestBase request, JsonParser parser) {
            this.request = request;
            this.parser = parser;
        }

        @Override
        public UUID next() throws IOException {
            if (hasNext())
                try {
                    return nextUUID;
                } finally {
                    nextUUID = null;
                }
            throw new NoSuchElementException("No more elements in stream");
        }

        @Override
        public boolean hasNext() throws IOException {
            if (nextUUID != null)
                return true;
            String token = parser.nextTextValue();
            if (token != null) {
                nextUUID = UUID.fromString(token);
                return true;
            }
            return false;
        }

        @Override
        public void close() throws IOException {
            request.releaseConnection();
        }
    }

    private class JsonResponseIterator<T> implements CloseableIOIterator<T> {
        private final HttpRequestBase request;
        private final JsonParser parser;
        private final JsonGetNextFunction<T> function;
        T next = null;

        private JsonResponseIterator(HttpRequestBase request,
                                     JsonParser parser, JsonGetNextFunction<T> function) {
            this.request = request;
            this.parser = parser;
            this.function = function;
        }

        @Override
        public T next() throws IOException {
            if (hasNext())
                try {
                    return next;
                } finally {
                    next = null;
                }
            throw new NoSuchElementException("No more elements in stream");
        }

        @Override
        public boolean hasNext() throws IOException {
            if (next != null)
                return true;
            next = function.getNext(parser);
            return next != null;
        }

        @Override
        public void close() throws IOException {
            request.releaseConnection();
        }
    }

    private abstract class SimpleResponseProcessor<T> implements
            ResponseProcessor<T> {
        @Override
        public T process(HttpResponse response) throws GumsProtocolException,
                IOException {
            if (response.getStatusLine().getStatusCode() == 200) {
                return processOkRequest(response);
            } else {
                throw handleError(response);
            }
        }

        protected abstract T processOkRequest(HttpResponse respose)
                throws GumsProtocolException, IOException;
    }
}
