package com.ntti3.gums.exceptions.factories;

import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.exceptions.GumsProtocolIncorrectCallException;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class IncorrectCallExceptionFactory implements ExceptionFactory {
    @Override
    public GumsProtocolException create(ErrorResponse errorResponse) {
        return new GumsProtocolIncorrectCallException(errorResponse);
    }
}
