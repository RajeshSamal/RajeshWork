package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * @author jan.karwowski@ntti3.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class User extends CommonUser {
    @JsonProperty(GumsProtocolConstants.GUID_RESPONSE_FIELD)
    private UUID guid;
    @JsonProperty(GumsProtocolConstants.ACTIVE_PARAMETER)
    private boolean active;
    @JsonProperty(GumsProtocolConstants.OPCO_NAME_PARAMETER)
    private String opcoName;
    @JsonProperty(GumsProtocolConstants.OPCO_C_UID_PARAMETER)
    private String opcoCUid;
    @JsonProperty(GumsProtocolConstants.COMPANY_GUID_PARAMETER)
    private String companyGuid;
    @JsonProperty(GumsProtocolConstants.FLAGS_PARAMETER)
    private List<String> flags;
    @JsonProperty(GumsProtocolConstants.PRODUCTS_PARAMETER)
    private List<String> products;
    @JsonProperty(GumsProtocolConstants.IS_OPCO_EDITABLE_PARAMETER)
    private boolean isOpcoEditable;
    @JsonProperty(value = GumsProtocolConstants.ACTIVE_IN_OPCO_PARAMETER)
    private boolean activeInOpCo;

    public User() {
    }

    public UUID getGuid() {
        return guid;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isActiveInOpCo() {
		return activeInOpCo;
	}

	public void setActiveInOpCo(boolean activeInOpCo) {
		this.activeInOpCo = activeInOpCo;
	}

    public String getOpcoName() {
        return opcoName;
    }

    public void setOpcoName(String opcoName) {
        this.opcoName = opcoName;
    }

    public String getOpcoCUid() {
        return opcoCUid;
    }

    public void setOpcoCUid(String opcoCUid) {
        this.opcoCUid = opcoCUid;
    }

    public String getCompanyGuid() {
        return companyGuid;
    }

    public void setCompanyGuid(String companyGuid) {
        this.companyGuid = companyGuid;
    }

    public List<String> getFlags() {
        return flags;
    }

    public void setFlags(List<String> flags) {
        this.flags = flags;
    }

    public List<String> getProducts() {
        return Collections.unmodifiableList(products);
    }

    public void setProducts(List<String> products) {
        this.products = products;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    @Override
    public String toString() {
        return "User{" +
                "guid=" + guid +
                ", active=" + active +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", opcoUid='" + getOpcoUid() + '\'' +
                ", opcoName='" + opcoName + '\'' +
                ", opcoUUid='" + getOpcoUUid() + '\'' +
                ", opcoCUid='" + opcoCUid + '\'' +
                ", opcoCName='" + getOpcoCName() + '\'' +
                ", companyGuid='" + companyGuid + '\'' +
                ", mobilePhone='" + getMobilePhone() + '\'' +
                ", flags=" + flags +
                ", products=" + products +
                '}';
    }

    public boolean isOpcoEditable() {
        return isOpcoEditable;
    }
}
