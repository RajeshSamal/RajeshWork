package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import static com.ntti3.gums.GumsProtocolConstants.PASSWORD_PARAMETER;
import static com.ntti3.gums.GumsProtocolConstants.RECOVERY_QUESTION_ANSWER;
import static com.ntti3.gums.GumsProtocolConstants.RECOVERY_QUESTION_PARAMETER;

/**
 * @author jan.karwowski@ntti3.com
 */
public class RequestedPendingUser extends PendingUserBase {
    @JsonProperty(PASSWORD_PARAMETER)
    String password;
    @JsonProperty(RECOVERY_QUESTION_PARAMETER)
    String recoveryQuestion;
    @JsonProperty(RECOVERY_QUESTION_ANSWER)
    String recoveryAnswer;

    public String getRecoveryAnswer() {
        return recoveryAnswer;
    }

    public void setRecoveryAnswer(String recoveryAnswer) {
        this.recoveryAnswer = recoveryAnswer;
    }

    public String getRecoveryQuestion() {
        return recoveryQuestion;
    }

    public void setRecoveryQuestion(String recoveryQuestion) {
        this.recoveryQuestion = recoveryQuestion;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	@Override
	public String toString() {
		return "RequestedPendingUser [password=" + password + ", recoveryQuestion="
				+ recoveryQuestion + ", recoveryAnswer=" + recoveryAnswer
				+ ", getOpcoUid()=" + getOpcoUid() + ", getEmail()="
				+ getEmail() + ", getOpcoUUid()=" + getOpcoUUid()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getMobilePhone()=" + getMobilePhone()
                + ", getOpcoCName()=" + getOpcoCName() + "]";
	}
    
    
}
