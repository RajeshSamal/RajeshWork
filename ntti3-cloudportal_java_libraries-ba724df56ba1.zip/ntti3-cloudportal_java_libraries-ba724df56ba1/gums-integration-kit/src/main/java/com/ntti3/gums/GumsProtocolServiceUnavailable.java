package com.ntti3.gums;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GumsProtocolServiceUnavailable extends GumsProtocolException {
    GumsProtocolServiceUnavailable() {
        super("Service unavailable");
    }
}
