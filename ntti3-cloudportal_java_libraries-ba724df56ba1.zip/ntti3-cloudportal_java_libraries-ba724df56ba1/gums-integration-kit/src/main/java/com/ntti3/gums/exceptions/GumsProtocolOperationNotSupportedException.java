package com.ntti3.gums.exceptions;

import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class GumsProtocolOperationNotSupportedException extends GumsProtocolExceptionWithErrorResponse {
    public GumsProtocolOperationNotSupportedException(ErrorResponse response) {
        super(response);
    }
}
