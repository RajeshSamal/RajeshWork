package com.ntti3.gums.exceptions.factories;

import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.exceptions.GumsProtocolProductNotFoundException;
import com.ntti3.protocol.ErrorResponse;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class ProductNotFoundExceptionFactory implements ExceptionFactory {
    @Override
    public GumsProtocolException create(ErrorResponse errorResponse) {
        return new GumsProtocolProductNotFoundException(errorResponse);
    }
}
