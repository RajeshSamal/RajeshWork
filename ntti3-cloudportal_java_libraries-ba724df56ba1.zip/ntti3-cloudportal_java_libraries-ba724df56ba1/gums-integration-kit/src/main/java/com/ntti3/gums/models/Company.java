package com.ntti3.gums.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.gums.GumsProtocolConstants;

import java.util.UUID;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Company {
    @JsonProperty(GumsProtocolConstants.COMPANY_GUID_PARAMETER)
    private UUID companyGuid;
    @JsonProperty(GumsProtocolConstants.OPCO_C_UID_PARAMETER)
    private String opcoCUid;
    @JsonProperty(GumsProtocolConstants.OPCO_C_NAME_PARAMETER)
    private String opcoCName;
    @JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER)
    private String opcoUid;

    public Company(@JsonProperty(GumsProtocolConstants.COMPANY_GUID_PARAMETER) UUID companyGuid,
                   @JsonProperty(GumsProtocolConstants.OPCO_C_UID_PARAMETER) String opcoCUid,
                   @JsonProperty(GumsProtocolConstants.OPCO_C_NAME_PARAMETER) String opcoCName,
                   @JsonProperty(GumsProtocolConstants.OPCO_UID_PARAMETER) String opcoUid) {
        this.companyGuid = companyGuid;
        this.opcoCUid = opcoCUid;
        this.opcoCName = opcoCName;
        this.opcoUid = opcoUid;
    }

    public UUID getCompanyGuid() {
        return companyGuid;
    }

    public String getOpcoCUid() {
        return opcoCUid;
    }

    public String getOpcoCName() {
        return opcoCName;
    }

    public void setOpcoCName(String opcoCName) {
        this.opcoCName = opcoCName;
    }

    @JsonIgnore
    public String getOpcoUid() {
        return opcoUid;
    }

    public void setOpcoCUid(String opcoCUid) {
        this.opcoCUid = opcoCUid;
    }

    @Override
    public String toString() {
        return "Company{" +
                "companyGuid=" + companyGuid +
                ", opcoCUid='" + opcoCUid + '\'' +
                ", opcoCName='" + opcoCName + '\'' +
                ", opcoUid='" + opcoUid + '\'' +
                '}';
    }
}
