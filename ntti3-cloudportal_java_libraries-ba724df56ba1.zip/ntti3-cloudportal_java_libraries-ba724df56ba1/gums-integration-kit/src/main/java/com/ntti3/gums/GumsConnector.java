package com.ntti3.gums;

import com.ntti3.gums.models.Company;
import com.ntti3.gums.models.Opco;
import com.ntti3.gums.models.PendingUser;
import com.ntti3.gums.models.RequestedPendingUser;
import com.ntti3.gums.models.User;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface GumsConnector {
    User getUser(UUID guid) throws IOException, GumsProtocolException;

    /**
     * Creates new user with given data in GUMS. If company and/or Opco do not exist they're also created.
     * If user exists, no new user is created. Depending on GUMS settings data of existing user my be updated to
     * given values.
     * <p>
     * <em>Please note that this API call is intended to be use only by AFP module of Cloud Portal</em>
     * </p>
     *
     * @param firstName
     * @param lastName
     * @param email
     * @param opcoUid
     * @param opcoName
     * @param opcoUUid
     * @param opcoCUid
     * @param opcoCName
     * @param flags
     * @return guid of existing/just created user
     * @throws java.io.IOException
     * @throws GumsProtocolException when connection problem occured of user data format is wrong
     */
    UUID getOrRegisterUser(String firstName, String lastName, String email, String opcoUid, String opcoName,
                           String opcoUUid, String opcoCUid, String opcoCName,
                           List<String> flags) throws IOException, GumsProtocolException;

    /**
     * Creates new user with given data in GUMS. If company and/or Opco do not exist they're also created.
     * If user exists, no new user is created. Depending on GUMS settings data of existing user my be updated to
     * given values.
     * <p>
     * <em>Please note that this API call is intended to be use only by AFP module of Cloud Portal</em>
     * </p>
     *
     * @param firstName
     * @param lastName
     * @param email
     * @param mobilePhone
     * @param opcoUid
     * @param opcoName
     * @param opcoUUid
     * @param opcoCUid
     * @param opcoCName
     * @param flags
     * @return guid of existing/just created user
     * @throws java.io.IOException
     * @throws GumsProtocolException when connection problem occured of user data format is wrong
     */
    UUID getOrRegisterUser(String firstName, String lastName, String email, String mobilePhone,
                           String opcoUid, String opcoName,
                           String opcoUUid, String opcoCUid, String opcoCName,
                           List<String> flags) throws IOException, GumsProtocolException;

    /**
     * Updates user's data in GUMS. The data are updated for user with guid
     * {@link com.ntti3.gums.models.User#getGuid()}. This call updates only fields
     * specified in GUMS Integration Guide:
     * <ul>
     * <li>first_name</li>
     * <li>last_name</li>
     * <li>email</li>
     * <li>opco_u_uid</li>
     * <li>active</li>
     * <li>company_guid</li>
     * <li>flags</li>
     * </ul>
     *
     * @param user User data to update. It <strong>should</strong> be an object obtained earlier by
     *             {@link #getUser(java.util.UUID)}.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    void updateUserData(User user) throws IOException, GumsProtocolException;

    List<String> getUserProductWhitelist(UUID guid) throws IOException, GumsProtocolException;

    void setUserProductWhitelist(UUID guid, List<String> Whitelist) throws IOException, GumsProtocolException;

    void addProductToUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException;

    boolean isProductInUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException;

    boolean removeProductFromUserWhitelist(UUID guid, String product) throws IOException, GumsProtocolException;

    UUID getUserGuid(String opcoUid, String opcoUUid) throws IOException, GumsProtocolException;

    /**
     * @param companyGuid
     * @return A company object if company with given company_guid exists, null otherwise
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    Company getCompany(UUID companyGuid) throws IOException, GumsProtocolException;

    UUID addCompany(String opcoCUid, String opcoCName, String opcoUid)
            throws IOException, GumsProtocolException;

    /**
     * Updates company data.
     * The data that can be updated are specified in Gums Integration Guide.
     * <ul>
     * <li>opco_c_name</li>
     * <li>opco_c_uid</li>
     * </ul>
     * <p/>
     * Company to update is selected by {@link com.ntti3.gums.models.Company#getCompanyGuid()}.
     *
     * @param company A company object. Is <strong>should</strong> be obtained by earlier request to GUMS.
     * @return true if given company exist, false otherwise
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    boolean updateCompany(Company company) throws IOException, GumsProtocolException;

    /**
     * @param opcoUid
     * @param opcoCUid
     * @return company_guid is company exists, null otherwise.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    UUID getCompanyGUID(String opcoUid, String opcoCUid) throws IOException, GumsProtocolException;

    /**
     * @param companyGuid
     * @param offset
     * @param limit
     * @return A page of users' guids. Returned {@link PagedResult#getResultPage()} <strong>must</strong>
     * be close after use.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    PagedResult<UUID> getCompanyUsers(UUID companyGuid, Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;

    /**
     * @param opcoUid
     * @return An object representing OpCo if such OpCo exists. null otherwise.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    Opco getOpco(String opcoUid) throws IOException, GumsProtocolException;

    void addOpco(String opcoUid, String opcoName) throws IOException, GumsProtocolException;

    /**
     * Updates given opco name to {@link com.ntti3.gums.models.Opco#getOpcoName()}
     *
     * @param opco Object representing an opco, which should be obtained with {@link #getOpco(String)}.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    void updateOpco(Opco opco) throws IOException, GumsProtocolException;

    /**
     * @param opcoUid
     * @param offset
     * @param limit
     * @return A page of users' GUIDs. Returned {@link PagedResult#getResultPage()} <strong>must</strong> be closed.
     * after use.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    PagedResult<UUID> getOpcoUsers(String opcoUid, Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;
    /**
     * @param opcoUid
     * @param offset
     * @param limit
     * @return A page of users' IDs. Returned {@link PagedResult#getResultPage()} <strong>must</strong> be closed.
     * after use.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    PagedResult<Integer> getOpcoPendingUsers(String opcoUid, Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;

    PagedResult<UUID> getUsers(Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;

    /**
     * @param opcoUid
     * @param offset
     * @param limit
     * @return A page of companies' GUIDs. Returned {@link PagedResult#getResultPage()} <strong>must</strong> be closed.
     * after use.
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    PagedResult<UUID> getOpcoCompanies(String opcoUid, Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;

    /**
     * @return All flags available in this GUMS instance
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    List<String> getFlags() throws IOException, GumsProtocolException;

    /**
     * @return All products available in this GUMS instance
     * @throws java.io.IOException
     * @throws GumsProtocolException
     */
    List<String> getProducts() throws IOException, GumsProtocolException;

    void unlock(UUID user) throws IOException, GumsProtocolException;

    boolean updatePassword(UUID user, String oldPassword, String newPassword) throws IOException, GumsProtocolException;

    void setPassword(UUID user, String newPassword) throws IOException, GumsProtocolException;

    boolean updateRecoveryQuestion(UUID user, String password, String question, String answer)
            throws IOException, GumsProtocolException;

    void setRecoveryQuestion(UUID user, String question, String answer)
            throws IOException, GumsProtocolException;

    String getUserProductRole(UUID user, String product) throws IOException, GumsProtocolException;

    void removeUserProductRole(UUID user, String product) throws IOException, GumsProtocolException;

    void setUserProductRole(UUID user, String product, String role) throws IOException, GumsProtocolException;

    Map<String, String> getUserRoles(UUID user) throws IOException, GumsProtocolException;

    int addPendingUser(RequestedPendingUser user) throws IOException, GumsProtocolException;
    
    UUID activateUser(Integer id, List<String> products, String opcoCUid, String opcoCName) 
            throws IOException, GumsProtocolException;
    
    UUID createUser(String firstName, String lastName, String email, String opcoUid, String opcoName, String opcoUUid, 
            String opcoCUid, String opcoCName, String password, String recoveryQuestion, String recoveryAnswer, 
            List<String> products) throws IOException, GumsProtocolException;

    PagedResult<Integer> getPendingUsers(Integer offset, Integer limit, OrderBy orderBy)
            throws IOException, GumsProtocolException;

    PendingUser getPendingUser(int id) throws IOException, GumsProtocolException;

    void removePendingUser(int id) throws IOException, GumsProtocolException;

    List<String> getUpdateableOpcos() throws IOException, GumsProtocolException;

    void rejectUser(Integer id) throws IOException, GumsProtocolException;

    boolean loginUsed(String opcoUid, String login) throws IOException, GumsProtocolException;
}
