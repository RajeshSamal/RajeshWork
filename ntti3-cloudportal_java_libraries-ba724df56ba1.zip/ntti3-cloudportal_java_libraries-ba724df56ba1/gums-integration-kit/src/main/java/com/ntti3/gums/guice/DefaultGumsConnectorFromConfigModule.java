package com.ntti3.gums.guice;

import com.google.common.base.Preconditions;
import com.google.inject.AbstractModule;
import com.ntti3.connectors.SSLSocketFactoryFactory;
import com.ntti3.gums.DefaultGumsConnector;
import com.ntti3.gums.GumsConnector;
import org.apache.http.params.HttpParams;

import javax.annotation.Nullable;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class DefaultGumsConnectorFromConfigModule extends AbstractModule {
    public static final String GUMS_BASE_URL_CONFIG_KEY = "baseUrl";
    private GumsConnector connector;

    public DefaultGumsConnectorFromConfigModule(Map<String, String> config) throws URISyntaxException,
            CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, IOException {
        this(config, null);
    }

    public DefaultGumsConnectorFromConfigModule(Map<String, String> config, @Nullable HttpParams httpParams)
            throws URISyntaxException,
            CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
            KeyManagementException, IOException {
        Preconditions.checkArgument(config.containsKey(GUMS_BASE_URL_CONFIG_KEY),
                "config must contain " + GUMS_BASE_URL_CONFIG_KEY + "key");
        URI gumsURI = new URI(config.get(GUMS_BASE_URL_CONFIG_KEY));

        connector = new DefaultGumsConnector(gumsURI, httpParams,
                SSLSocketFactoryFactory.getSSLSocketFactoryInstance(config));
    }

    @Override
    protected void configure() {
        bind(GumsConnector.class).toInstance(connector);
    }
}
