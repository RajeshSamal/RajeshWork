package com.ntti3.gums;

import com.google.common.collect.Lists;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.Collection;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OrderBy {
    private String column;
    private Order order;

    public OrderBy(String column, Order order) {
        this.column = column;
        this.order = order;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Collection<NameValuePair> buildQueryParams() {
        return Lists.<NameValuePair>newArrayList(new BasicNameValuePair(GumsProtocolConstants.ORDER_QUERY_PARAM,
                order.getProtocolName()),
                new BasicNameValuePair(GumsProtocolConstants.ORDER_BY_QUERY_PARAM, column));
    }
}
