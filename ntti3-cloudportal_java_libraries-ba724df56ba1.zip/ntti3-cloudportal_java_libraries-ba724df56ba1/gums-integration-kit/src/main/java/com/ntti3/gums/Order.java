package com.ntti3.gums;

/**
 * @author jan.karwowski@ntti3.com
 */
public enum  Order {
    ASC("ASC"), DESC("DESC");
    private String protocolName;

    private Order(String protocolName) {
        this.protocolName = protocolName;
    }

    public String getProtocolName() {
        return protocolName;
    }

    private static Order fromString(String protocolName){
        for(Order o: values()){
            if(o.getProtocolName().equals(protocolName)){
                return o;
            }
        }

        throw new IllegalArgumentException("Bad Order protocolName: "+protocolName);
    }
}
