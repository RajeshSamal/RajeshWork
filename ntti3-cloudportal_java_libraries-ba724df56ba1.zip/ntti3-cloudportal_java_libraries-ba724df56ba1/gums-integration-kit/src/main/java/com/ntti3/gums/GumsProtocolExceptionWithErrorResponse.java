package com.ntti3.gums;

import com.ntti3.protocol.ErrorResponse;

/**
 * @author jan.karwowski@ntti3.com
 */
public class GumsProtocolExceptionWithErrorResponse extends GumsProtocolException{
    private ErrorResponse response;

    public GumsProtocolExceptionWithErrorResponse(ErrorResponse response) {
        super(response.getMessage());
        this.response = response;
    }

    public ErrorResponse getResponse() {
        return response;
    }
}
