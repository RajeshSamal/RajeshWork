package com.ntti3.mailing.connector.exceptions;

import com.ntti3.mailing.connector.models.ErrorResponse;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class ApiException extends Exception {
    private final int httpCode;
    private final int errorCode;
    private final String details;

    public ApiException(int httpCode, int errorCode, String message, String details) {
        super(message);
        this.httpCode = httpCode;
        this.errorCode = errorCode;
        this.details = details;
    }

    public ApiException(int httpCode, ErrorResponse response) {
        super(response.getMessage());
        this.httpCode = httpCode;
        this.errorCode = response.hashCode();
        this.details = response.getDetails();
    }

    public int getHttpCode() {
        return httpCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getDetails() {
        return details;
    }
}
