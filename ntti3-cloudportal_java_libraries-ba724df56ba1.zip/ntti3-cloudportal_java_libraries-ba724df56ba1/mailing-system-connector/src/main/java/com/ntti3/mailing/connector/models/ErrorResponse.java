package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class ErrorResponse {
    private final int code;
    private final String message;
    private final String details;

    @JsonCreator
    public ErrorResponse(
            @JsonProperty(value = ApiConstants.CODE, required = true)
            int code,
            @JsonProperty(value = ApiConstants.MESSAGE, required = true)
            String message,
            @JsonProperty(value = ApiConstants.DETAILS, required = true)
            String details
    ) {
        this.code = code;
        this.message = message;
        this.details = details;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getDetails() {
        return details;
    }

    @Override
    public String toString() {
        return "ErrorResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", details='" + details + '\'' +
                '}';
    }
}
