package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class Recipient {
    public static enum RecipientType {
        TO,CC,BCC
    }

    @JsonProperty(ApiConstants.EMAIL)
    private final String email;

    @JsonProperty(ApiConstants.NAME)
    private final String name;

    @JsonProperty(ApiConstants.RECIPIENT_TYPE)
    private final RecipientType recipientType;

    @JsonProperty(ApiConstants.VARIABLES)
    private List<Variable> variableList = new ArrayList<>();

    public Recipient(String email, String name, RecipientType recipientType) {
        this.email = email;
        this.name = name;
        this.recipientType = recipientType;
    }

    public Recipient(String email, String name) {
        this.email = email;
        this.name = name;
        this.recipientType = RecipientType.TO;
    }

    public Recipient(String email) {
        this.email = email;
        this.name = null;
        this.recipientType = RecipientType.TO;
    }

    public void addVariable(Variable variable) {
        variableList.add(variable);
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public RecipientType getRecipientType() {
        return recipientType;
    }

    public List<Variable> getVariableList() {
        return Collections.unmodifiableList(variableList);
    }

    @Override
    public String toString() {
        return "Recipient{" +
                "email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", recipientType=" + recipientType +
                ", variableList=" + variableList +
                '}';
    }
}
