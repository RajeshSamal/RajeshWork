package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class MessageSearchResponse {
    private final UUID id;
    private final String sender;
    private final String recipient;
    private final String product;
    private final List<String> tags;
    private final String subject;
    private final long timestamp;

    @JsonCreator
    public MessageSearchResponse(
            @JsonProperty(value = ApiConstants.ID)
            UUID id,
            @JsonProperty(value = ApiConstants.SENDER)
            String sender,
            @JsonProperty(value = ApiConstants.RECIPIENT)
            String recipient,
            @JsonProperty(value = ApiConstants.PRODUCT)
            String product,
            @JsonProperty(value = ApiConstants.TAGS)
            List<String> tags,
            @JsonProperty(value = ApiConstants.SUBJECT)
            String subject,
            @JsonProperty(value = ApiConstants.TIMESTAMP)
            long timestamp) {
        this.id = id;
        this.sender = sender;
        this.recipient = recipient;
        this.product = product;
        if(tags==null) {
            tags = Collections.emptyList();
        }
        this.tags = Collections.unmodifiableList(tags);
        this.subject = subject;
        this.timestamp = timestamp;
    }

    public UUID getId() {
        return id;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getProduct() {
        return product;
    }

    public List<String> getTags() {
        return tags;
    }

    public String getSubject() {
        return subject;
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "MessageSearchResponse{" +
                "id=" + id +
                ", sender='" + sender + '\'' +
                ", recipient='" + recipient + '\'' +
                ", product='" + product + '\'' +
                ", tags=" + tags +
                ", subject='" + subject + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
