package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class SendResponse {
    private final String recipient;
    private final UUID id;
    private final String rejectReason;

    @JsonCreator
    public SendResponse(
            @JsonProperty(value = ApiConstants.EMAIL)
            String recipient,
            @JsonProperty(value = ApiConstants.ID)
            UUID id,
            @JsonProperty(value = ApiConstants.REJECT_REASON)
            String rejectReason) {
        this.recipient = recipient;
        this.id = id;
        this.rejectReason = rejectReason;
    }

    public String getRecipient() {
        return recipient;
    }

    public UUID getId() {
        return id;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    @Override
    public String toString() {
        return "SendResponse{" +
                "recipient='" + recipient + '\'' +
                ", id=" + id +
                ", rejectReason='" + rejectReason + '\'' +
                '}';
    }
}
