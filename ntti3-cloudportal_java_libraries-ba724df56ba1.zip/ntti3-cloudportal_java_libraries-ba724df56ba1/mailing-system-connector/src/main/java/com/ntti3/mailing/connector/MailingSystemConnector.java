package com.ntti3.mailing.connector;

import com.ntti3.mailing.connector.exceptions.ApiException;
import com.ntti3.mailing.connector.models.MessageSearchResponse;
import com.ntti3.mailing.connector.models.MessageSent;
import com.ntti3.mailing.connector.models.SearchParameters;
import com.ntti3.mailing.connector.models.SendResponse;
import com.ntti3.mailing.connector.models.SendingMessage;
import com.ntti3.mailing.connector.models.TagStatistics;
import com.ntti3.mailing.connector.models.Template;
import com.ntti3.mailing.connector.models.URLStatistics;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public interface MailingSystemConnector {

    public List<SendResponse> sendMessage(SendingMessage message) throws ApiException, IOException;
    public List<SendResponse> sendTemplateMessage(SendingMessage message) throws ApiException, IOException;
    public MessageSent getMessage(UUID id) throws ApiException, IOException;
    public List<MessageSearchResponse> searchMessages(SearchParameters parameters) throws ApiException, IOException;
    public List<Template> getAllTemplates() throws ApiException, IOException;
    public List<Template> searchTemplates(String label) throws ApiException, IOException;
    public Template getTemplate(String name) throws ApiException, IOException;
    public Template putTemplate(Template template) throws ApiException, IOException;
    public Template deleteTemplate(String name) throws ApiException, IOException;
    public TagStatistics getTagStatistics(String tag) throws ApiException, IOException;
    public URLStatistics getUrlStatistics(String url) throws ApiException, IOException;
}
