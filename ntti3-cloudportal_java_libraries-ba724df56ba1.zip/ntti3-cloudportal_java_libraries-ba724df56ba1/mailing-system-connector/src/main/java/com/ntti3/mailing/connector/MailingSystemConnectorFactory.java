package com.ntti3.mailing.connector;

import com.ntti3.connectors.SSLSocketFactoryFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class MailingSystemConnectorFactory {
    public static MailingSystemConnector getMailingSystemConnector(String url) throws URISyntaxException {
        return new DefaultMailingSystemConnector(url);
    }

    public static MailingSystemConnector getMailingSystemConnector(String url, KeyStore keyStore, String keyStorePass) throws URISyntaxException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        SSLSocketFactory sslSocketFactory = SSLSocketFactoryFactory.getSSLSocketFactoryInstance(keyStore, keyStorePass);
        return new DefaultMailingSystemConnector(url, sslSocketFactory);
    }

    public static MailingSystemConnector getMailingSystemConnector(String url, String keyStorePath, String keyStorePass) throws URISyntaxException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException, CertificateException {
        SSLSocketFactory sslSocketFactory = SSLSocketFactoryFactory.getSSLSocketFactoryInstance(keyStorePath, keyStorePass);
        return new DefaultMailingSystemConnector(url, sslSocketFactory);
    }
}
