package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class URLStatistics {
    private final int sent;
    private final int clicks;
    private final int uniqueClicks;

    @JsonCreator
    public URLStatistics(
            @JsonProperty(value = ApiConstants.SENT)
            int sent,
            @JsonProperty(value = ApiConstants.CLICKS)
            int clicks,
            @JsonProperty(value = ApiConstants.UNIQUE_CLICKS)
            int uniqueClicks) {
        this.sent = sent;
        this.clicks = clicks;
        this.uniqueClicks = uniqueClicks;
    }

    public int getSent() {
        return sent;
    }

    public int getClicks() {
        return clicks;
    }

    public int getUniqueClicks() {
        return uniqueClicks;
    }

    @Override
    public String toString() {
        return "URLStatistics{" +
                "sent=" + sent +
                ", clicks=" + clicks +
                ", uniqueClicks=" + uniqueClicks +
                '}';
    }
}
