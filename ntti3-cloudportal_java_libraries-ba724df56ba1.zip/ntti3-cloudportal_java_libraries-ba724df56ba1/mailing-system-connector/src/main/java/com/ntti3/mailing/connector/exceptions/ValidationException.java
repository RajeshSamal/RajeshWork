package com.ntti3.mailing.connector.exceptions;

import com.ntti3.mailing.connector.models.ErrorResponse;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class ValidationException extends ApiException {
    public ValidationException(int httpCode, int errorCode, String message, String details) {
        super(httpCode, errorCode, message, details);
    }

    public ValidationException(int httpCode, ErrorResponse response) {
        super(httpCode, response);
    }
}
