package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class Template {
    @JsonProperty(value = ApiConstants.TEMPLATE_NAME)
    private final String templateName;

    @JsonProperty(value = ApiConstants.SUBJECT)
    private final String subject;

    @JsonProperty(value = ApiConstants.HTML_CONTENT)
    private final String htmlContent;

    @JsonProperty(value = ApiConstants.TEXT_CONTENT)
    private final String textContent;

    @JsonProperty(value = ApiConstants.PRODUCT)
    private final String product;

    @JsonProperty(value = ApiConstants.LABELS)
    private final List<String> labels;

    @JsonCreator
    public Template(
            @JsonProperty(value = ApiConstants.TEMPLATE_NAME)
            String templateName,
            @JsonProperty(value = ApiConstants.SUBJECT)
            String subject,
            @JsonProperty(value = ApiConstants.HTML_CONTENT)
            String htmlContent,
            @JsonProperty(value = ApiConstants.TEXT_CONTENT)
            String textContent,
            @JsonProperty(value = ApiConstants.PRODUCT)
            String product,
            @JsonProperty(value = ApiConstants.LABELS)
            List<String> labels) {
        this.templateName = templateName;
        this.subject = subject;
        this.htmlContent = htmlContent;
        this.textContent = textContent;
        this.product = product;
        if(labels==null) {
            labels = Collections.emptyList();
        }
        this.labels = Collections.unmodifiableList(labels);
    }

    public String getTemplateName() {
        return templateName;
    }

    public String getSubject() {
        return subject;
    }

    public String getHtmlContent() {
        return htmlContent;
    }

    public String getTextContent() {
        return textContent;
    }

    public String getProduct() {
        return product;
    }

    public List<String> getLabels() {
        return labels;
    }

    public static class Builder {
        private String templateName;
        private String subject;
        private String htmlContent;
        private String textContent;
        private String product;
        private List<String> labels = new ArrayList<>();

        public Builder setTemplateName(String templateName) {
            this.templateName = templateName;
            return this;
        }

        public Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public Builder setHtmlContent(String htmlContent) {
            this.htmlContent = htmlContent;
            return this;
        }

        public Builder setTextContent(String textContent) {
            this.textContent = textContent;
            return this;
        }

        public Builder setProduct(String product) {
            this.product = product;
            return this;
        }

        public Builder addLabel(String label) {
            this.labels.add(label);
            return this;
        }

        public Template build() {
            return new Template(templateName, subject, htmlContent, textContent, product, labels);
        }

        @Override
        public String toString() {
            return "Builder{" +
                    "templateName='" + templateName + '\'' +
                    ", subject='" + subject + '\'' +
                    ", htmlContent='" + htmlContent + '\'' +
                    ", textContent='" + textContent + '\'' +
                    ", product='" + product + '\'' +
                    ", labels=" + labels +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "Template{" +
                "templateName='" + templateName + '\'' +
                ", subject='" + subject + '\'' +
                ", htmlContent='" + htmlContent + '\'' +
                ", textContent='" + textContent + '\'' +
                ", product='" + product + '\'' +
                ", labels=" + labels +
                '}';
    }
}
