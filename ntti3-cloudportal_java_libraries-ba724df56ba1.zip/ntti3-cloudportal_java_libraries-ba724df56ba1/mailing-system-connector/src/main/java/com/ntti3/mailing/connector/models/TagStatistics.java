package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class TagStatistics {
    private final int sent;
    private final int hardBounces;
    private final int softBounces;
    private final int rejects;
    private final int complaints;
    private final int opens;
    private final int clicks;

    @JsonCreator
    public TagStatistics(
            @JsonProperty(value = ApiConstants.SENT)
            int sent,
            @JsonProperty(value = ApiConstants.HARD_BOUNCES)
            int hardBounces,
            @JsonProperty(value = ApiConstants.SOFT_BOUNCES)
            int softBounces,
            @JsonProperty(value = ApiConstants.REJECTS)
            int rejects,
            @JsonProperty(value = ApiConstants.COMPLAINTS)
            int complaints,
            @JsonProperty(value = ApiConstants.OPENS)
            int opens,
            @JsonProperty(value = ApiConstants.CLICKS)
            int clicks) {
        this.sent = sent;
        this.hardBounces = hardBounces;
        this.softBounces = softBounces;
        this.rejects = rejects;
        this.complaints = complaints;
        this.opens = opens;
        this.clicks = clicks;
    }

    public int getSent() {
        return sent;
    }

    public int getHardBounces() {
        return hardBounces;
    }

    public int getSoftBounces() {
        return softBounces;
    }

    public int getRejects() {
        return rejects;
    }

    public int getComplaints() {
        return complaints;
    }

    public int getOpens() {
        return opens;
    }

    public int getClicks() {
        return clicks;
    }

    @Override
    public String toString() {
        return "TagStatistics{" +
                "sent=" + sent +
                ", hardBounces=" + hardBounces +
                ", softBounces=" + softBounces +
                ", rejects=" + rejects +
                ", complaints=" + complaints +
                ", opens=" + opens +
                ", clicks=" + clicks +
                '}';
    }
}
