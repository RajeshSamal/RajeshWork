package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class MessageSent {
    private final UUID id;
    private final String product;
    private final String sender;
    private final Date timestamp;
    private final String recipient;
    private final String subject;
    private final String template;
    private final List<String> tags;
    private final int opens;
    private final int clicks;

    @JsonCreator
    public MessageSent(
            @JsonProperty(value = ApiConstants.ID, required = true)
            UUID id,
            @JsonProperty(value = ApiConstants.PRODUCT, required = false)
            String product,
            @JsonProperty(value = ApiConstants.SENDER, required = true)
            String sender,
            @JsonProperty(value = ApiConstants.TIMESTAMP, required = true)
            long timestamp,
            @JsonProperty(value = ApiConstants.RECIPIENT, required = true)
            String recipient,
            @JsonProperty(value = ApiConstants.SUBJECT, required = true)
            String subject,
            @JsonProperty(value = ApiConstants.TEMPLATE_NAME, required = false)
            String template,
            @JsonProperty(value = ApiConstants.TAGS, required = false)
            List<String> tags,
            @JsonProperty(value = ApiConstants.OPENS, required = true)
            int opens,
            @JsonProperty(value = ApiConstants.CLICKS, required = true)
            int clicks
    ) {
        this.id = id;
        this.product = product;
        this.sender = sender;
        this.timestamp = new Date(timestamp);
        this.recipient = recipient;
        this.subject = subject;
        this.template = template;
        if(tags == null) {
            tags = Collections.emptyList();
        }
        this.tags = Collections.unmodifiableList(tags);
        this.opens = opens;
        this.clicks = clicks;
    }

    public UUID getId() {
        return id;
    }

    public String getProduct() {
        return product;
    }

    public String getSender() {
        return sender;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getSubject() {
        return subject;
    }

    public String getTemplate() {
        return template;
    }

    public List<String> getTags() {
        return tags;
    }

    public int getOpens() {
        return opens;
    }

    public int getClicks() {
        return clicks;
    }

    @Override
    public String toString() {
        return "MessageSent{" +
                "id=" + id +
                ", product='" + product + '\'' +
                ", sender='" + sender + '\'' +
                ", timestamp=" + timestamp +
                ", recipient='" + recipient + '\'' +
                ", subject='" + subject + '\'' +
                ", template='" + template + '\'' +
                ", tags=" + tags +
                ", opens=" + opens +
                ", clicks=" + clicks +
                '}';
    }
}
