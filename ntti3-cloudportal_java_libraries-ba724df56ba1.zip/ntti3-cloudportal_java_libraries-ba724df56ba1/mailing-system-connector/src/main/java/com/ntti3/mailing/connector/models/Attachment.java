package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ntti3.mailing.connector.ApiConstants;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class Attachment {
    @JsonProperty(ApiConstants.NAME)
    private final String name;

    @JsonProperty(ApiConstants.MIME_TYPE)
    private final String mimeType;

    @JsonProperty(ApiConstants.CONTENT)
    private final String content;

    public Attachment(String name, String mimeType, String content) {
        this.name = name;
        this.mimeType = mimeType;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getMimeType() {
        return mimeType;
    }

    public String getContent() {
        return content;
    }

    @Override
    public String toString() {
        return "Attachment{" +
                "name='" + name + '\'' +
                ", mimeType='" + mimeType + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
