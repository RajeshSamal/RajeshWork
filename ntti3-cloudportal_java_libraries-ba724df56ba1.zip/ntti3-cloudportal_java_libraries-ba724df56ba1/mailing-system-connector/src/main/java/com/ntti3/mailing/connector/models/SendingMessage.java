package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class SendingMessage {
    @JsonProperty(ApiConstants.TO)
    private final List<Recipient> to;

    @JsonProperty(value = ApiConstants.TEMPLATE_NAME)
    private final String templateName;

    @JsonProperty(ApiConstants.VARIABLES)
    private final List<Variable> variables;

    @JsonProperty(ApiConstants.FROM_EMAIL)
    private final String fromEmail;

    @JsonProperty(ApiConstants.FROM_NAME)
    private final String fromName;

    @JsonProperty(ApiConstants.SUBJECT)
    private final String subject;

    @JsonProperty(ApiConstants.HTML_CONTENT)
    private final String htmlContent;

    @JsonProperty(ApiConstants.TEXT_CONTENT)
    private final String textContent;

    @JsonProperty(ApiConstants.PRODUCT)
    private final String product;

    @JsonProperty(ApiConstants.TAGS)
    private final List<String> tags;

    @JsonProperty(ApiConstants.ATTACHMENTS)
    private final List<Attachment> attachments;

    @JsonProperty(ApiConstants.IMAGES)
    private final List<Attachment> images;

    @JsonProperty(ApiConstants.REPLY_TO)
    private String replyTo;

    private SendingMessage(Builder builder) {
        this.to = builder.to;
        this.templateName = builder.templateName;
        this.variables = builder.variables;
        this.fromEmail = builder.fromEmail;
        this.fromName = builder.fromName;
        this.subject = builder.subject;
        this.htmlContent = builder.htmlContent;
        this.textContent = builder.textContent;
        this.product = builder.product;
        this.tags = builder.tags;
        this.attachments = builder.attachments;
        this.images = builder.images;
        this.replyTo = builder.replyTo;
    }

    public List<Recipient> getTo() {
        return to;
    }

    public String getTemplateName() {
        return templateName;
    }

    public List<Variable> getVariables() {
        return variables;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public String getFromName() {
        return fromName;
    }

    public String getSubject() {
        return subject;
    }

    public String getHtmlContent() {
        return htmlContent;
    }

    public String getTextContent() {
        return textContent;
    }

    public String getProduct() {
        return product;
    }

    public List<String> getTags() {
        return tags;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public List<Attachment> getImages() {
        return images;
    }

    public String getReplyTo() {
        return replyTo;
    }

    public static class Builder {
        private List<Recipient> to = new ArrayList<>();
        private String templateName;
        private List<Variable> variables = new ArrayList<>();
        private String fromEmail;
        private String fromName;
        private String subject;
        private String htmlContent;
        private String textContent;
        private String product;
        private List<String> tags = new ArrayList<>();
        private List<Attachment> attachments = new ArrayList<>();
        private List<Attachment> images = new ArrayList<>();
        private String replyTo;

        public Builder templateName(String templateName) {
            this.templateName = templateName;
            return this;
        }

        public Builder fromEmail(String fromEmail) {
            this.fromEmail = fromEmail;
            return this;
        }

        public Builder fromName(String fromName) {
            this.fromName = fromName;
            return this;
        }

        public Builder subject(String subject) {
            this.subject = subject;
            return this;
        }

        public Builder htmlContent(String htmlContent) {
            this.htmlContent = htmlContent;
            return this;
        }

        public Builder textContent(String textContent) {
            this.textContent = textContent;
            return this;
        }

        public Builder product(String product) {
            this.product = product;
            return this;
        }

        public Builder addRecipient(String email, String name, Recipient.RecipientType recipientType) {
            to.add(new Recipient(email, name, recipientType));
            return this;
        }

        public Builder addRecipient(Recipient recipient) {
            to.add(recipient);
            return this;
        }

        public Builder addVariable(String name, String content) {
            variables.add(new Variable(name, content));
            return this;
        }

        public Builder addTag(String tag) {
            tags.add(tag);
            return this;
        }

        public Builder addAttachment(Attachment attachment) {
            attachments.add(attachment);
            return this;
        }

        public Builder addImage(Attachment image) {
            images.add(image);
            return this;
        }

        public Builder replyTo(String replyTo) {
            this.replyTo = replyTo;
            return this;
        }

        public SendingMessage build() {
            return new SendingMessage(this);
        }

        @Override
        public String toString() {
            return "Builder{" +
                    "to=" + to +
                    ", templateName='" + templateName + '\'' +
                    ", variables=" + variables +
                    ", fromEmail='" + fromEmail + '\'' +
                    ", fromName='" + fromName + '\'' +
                    ", subject='" + subject + '\'' +
                    ", htmlContent='" + htmlContent + '\'' +
                    ", textContent='" + textContent + '\'' +
                    ", product='" + product + '\'' +
                    ", tags=" + tags +
                    ", attachments=" + attachments +
                    ", images=" + images +
                    ", replyTo='" + replyTo + '\'' +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "SendingMessage{" +
                "to=" + to +
                ", templateName='" + templateName + '\'' +
                ", variables=" + variables +
                ", fromEmail='" + fromEmail + '\'' +
                ", fromName='" + fromName + '\'' +
                ", subject='" + subject + '\'' +
                ", htmlContent='" + htmlContent + '\'' +
                ", textContent='" + textContent + '\'' +
                ", product='" + product + '\'' +
                ", tags=" + tags +
                ", attachments=" + attachments +
                ", images=" + images +
                ", replyTo='" + replyTo + '\'' +
                '}';
    }
}
