package com.ntti3.mailing.connector;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public final class ApiConstants {
    public static final String CODE = "code";
    public static final String MESSAGE = "message";
    public static final String DETAILS = "details";
    public static final String ID = "id";
    public static final String PRODUCT = "product";
    public static final String SENDER = "sender";
    public static final String TIMESTAMP = "timestamp";
    public static final String RECIPIENT = "recipient";
    public static final String SUBJECT = "subject";
    public static final String TEMPLATE = "template";
    public static final String TAGS = "tags";
    public static final String OPENS = "opens";
    public static final String CLICKS = "clicks";
    public static final String TEMPLATE_NAME = "template_name";
    public static final String TO = "to";
    public static final String VARIABLES = "variables";
    public static final String FROM_EMAIL = "from_email";
    public static final String FROM_NAME = "from_name";
    public static final String HTML_CONTENT = "html_content";
    public static final String TEXT_CONTENT = "text_content";
    public static final String ATTACHMENTS = "attachments";
    public static final String IMAGES = "images";
    public static final String EMAIL = "email";
    public static final String NAME = "name";
    public static final String RECIPIENT_TYPE = "recipient_type";
    public static final String REJECT_REASON = "reject_reason";
    public static final String DATE_FROM = "date_from";
    public static final String DATE_TO = "date_to";
    public static final String LABELS = "labels";
    public static final String COMPLAINTS = "complaints";
    public static final String REJECTS = "rejects";
    public static final String SOFT_BOUNCES = "soft_bounces";
    public static final String HARD_BOUNCES = "hard_bounces";
    public static final String SENT = "sent";
    public static final String UNIQUE_CLICKS = "unique_clicks";
    public static final String MIME_TYPE = "mime_type";
    public static final String CONTENT = "content";
    public static final String REPLY_TO = "reply_to";
    public static final int VALIDATION_ERROR_STATUS = 555;
}
