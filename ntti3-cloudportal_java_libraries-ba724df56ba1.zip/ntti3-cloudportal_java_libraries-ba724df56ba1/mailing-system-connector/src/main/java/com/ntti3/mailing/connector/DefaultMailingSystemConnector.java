package com.ntti3.mailing.connector;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.ntti3.connectors.BaseConnector;
import com.ntti3.connectors.HttpParamsFromProperties;
import com.ntti3.mailing.connector.exceptions.ApiException;
import com.ntti3.mailing.connector.exceptions.NotFoundException;
import com.ntti3.mailing.connector.exceptions.ValidationException;
import com.ntti3.mailing.connector.models.ErrorResponse;
import com.ntti3.mailing.connector.models.MessageSearchResponse;
import com.ntti3.mailing.connector.models.MessageSent;
import com.ntti3.mailing.connector.models.SearchParameters;
import com.ntti3.mailing.connector.models.SendResponse;
import com.ntti3.mailing.connector.models.SendingMessage;
import com.ntti3.mailing.connector.models.TagStatistics;
import com.ntti3.mailing.connector.models.Template;
import com.ntti3.mailing.connector.models.URLStatistics;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.params.HttpParams;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
public class DefaultMailingSystemConnector extends BaseConnector implements MailingSystemConnector {
    public static final String MAILING_DEFAULTS_PROPERTIES_PATH = "/mailing_defaults.properties";
    public static final String MAILING_PROPERTIES_PATH = "mailing.properties";

    private final HttpClient httpClient;
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final ObjectWriter objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
    private final String url;

    private HttpResponse callPost(String action, String json) throws IOException, ApiException {
        HttpPost post = new HttpPost(url + action);
        post.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());
        post.setEntity(new StringEntity(json, ContentType.create("application/json","UTF-8")));
        return processRequest(post);
    }

    private HttpResponse callPut(String action, String json) throws IOException, ApiException {
        HttpPut put = new HttpPut(url + action);
        put.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());
        put.setEntity(new StringEntity(json));
        return processRequest(put);
    }

    private HttpResponse callGet(String action) throws IOException, ApiException {
        HttpGet get = new HttpGet(url + action);
        return processRequest(get);
    }

    private HttpResponse callDelete(String action) throws IOException, ApiException {
        HttpDelete delete = new HttpDelete(url + action);
        return processRequest(delete);
    }

    private HttpResponse processRequest(HttpRequestBase request) throws IOException, ApiException {
        HttpResponse response = httpClient.execute(request);
        int httpCode = response.getStatusLine().getStatusCode();
        if(BaseConnector.isStatusOk(httpCode)) { //OK Code
            return response;
        }
        String errorStringResponse = IOUtils.toString(response.getEntity().getContent());
        try {
            ErrorResponse errorResponse = objectMapper.readValue(errorStringResponse, ErrorResponse.class);
            if (httpCode == HttpStatus.SC_NOT_FOUND) {
                throw new NotFoundException(httpCode, errorResponse);
            }
            if (errorResponse.getCode() == ApiConstants.VALIDATION_ERROR_STATUS) {
                throw new ValidationException(httpCode, errorResponse);
            }
            throw new ApiException(httpCode, errorResponse);
        } catch (JsonMappingException | JsonParseException e) {
            throw new RuntimeException("Error parsing error response. Error content: " + errorStringResponse);
        }
    }

    public DefaultMailingSystemConnector(String url) throws URISyntaxException {
        this(url, null);
    }

    public DefaultMailingSystemConnector(String url, SSLSocketFactory httpsSocketFactory) throws URISyntaxException {
        super(new URI(url), null, httpsSocketFactory);
        Properties defaults;
        HttpClient client;
        try {
            defaults = new Properties();
            defaults.load(DefaultMailingSystemConnector.class.getResourceAsStream(MAILING_DEFAULTS_PROPERTIES_PATH));
        } catch (IOException e) {
            throw new RuntimeException("Problem with default properties file.", e);
        }
        try {
            HttpParams httpParams = HttpParamsFromProperties.getParams(MAILING_PROPERTIES_PATH, defaults);
            client = this.initHttpClient(httpParams);
        } catch (IOException e) {
            client = this.initHttpClient(HttpParamsFromProperties.getParams(defaults));
        }

        this.url = url;
        this.httpClient = client;
    }

    @Override
    public List<SendResponse> sendMessage(SendingMessage message) throws ApiException, IOException {
        String json = objectWriter.writeValueAsString(message);
        HttpResponse response = this.callPost("messages/send/", json);
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, SendResponse.class));
    }

    @Override
    public List<SendResponse> sendTemplateMessage(SendingMessage message) throws ApiException, IOException {
        String json = objectWriter.writeValueAsString(message);
        HttpResponse response = this.callPost("messages/send-template/", json);
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, SendResponse.class));
    }

    @Override
    public MessageSent getMessage(UUID id) throws ApiException, IOException {
        HttpResponse response = this.callGet("messages/" + id.toString());
        return objectMapper.readValue(response.getEntity().getContent(), MessageSent.class);
    }

    @Override
    public List<MessageSearchResponse> searchMessages(SearchParameters parameters) throws ApiException, IOException {
        String json = objectWriter.writeValueAsString(parameters);
        HttpResponse response = this.callPost("messages/search/", json);
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, MessageSearchResponse.class));
    }

    @Override
    public List<Template> getAllTemplates() throws ApiException, IOException {
        HttpResponse response = this.callGet("template/list/");
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, Template.class));
    }

    @Override
    public List<Template> searchTemplates(String label) throws ApiException, IOException {
        HttpResponse response = this.callGet("template/list/" + label);
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, Template.class));
    }

    @Override
    public Template getTemplate(String name) throws ApiException, IOException {
        HttpResponse response = this.callGet("template/" + name);
        return objectMapper.readValue(response.getEntity().getContent(), Template.class);
    }

    @Override
    public Template putTemplate(Template template) throws ApiException, IOException {
        String json = objectWriter.writeValueAsString(template);
        HttpResponse response = this.callPut("template/" + template.getTemplateName(), json);
        return objectMapper.readValue(response.getEntity().getContent(), Template.class);
    }

    @Override
    public Template deleteTemplate(String name) throws ApiException, IOException {
        HttpResponse response = this.callDelete("template/" + name);
        return objectMapper.readValue(response.getEntity().getContent(), Template.class);
    }

    @Override
    public TagStatistics getTagStatistics(String tag) throws ApiException, IOException {
        HttpResponse response = this.callGet("statistics/tag/" + tag);
        return objectMapper.readValue(response.getEntity().getContent(), TagStatistics.class);
    }

    @Override
    public URLStatistics getUrlStatistics(String url) throws ApiException, IOException {
        HttpResponse response = this.callGet("statistics/url/" + url);
        return objectMapper.readValue(response.getEntity().getContent(), URLStatistics.class);
    }
}
