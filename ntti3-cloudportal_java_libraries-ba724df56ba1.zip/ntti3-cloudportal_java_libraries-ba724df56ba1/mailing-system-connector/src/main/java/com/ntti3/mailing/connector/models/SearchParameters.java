package com.ntti3.mailing.connector.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ntti3.mailing.connector.ApiConstants;

import java.util.Date;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-18.
 */
@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class SearchParameters {
    @JsonProperty(ApiConstants.RECIPIENT)
    private final String recipient;

    @JsonProperty(ApiConstants.SENDER)
    private final String sender;

    @JsonProperty(ApiConstants.PRODUCT)
    private final String product;

    @JsonProperty(ApiConstants.TAGS)
    private final List<String> tags;

    @JsonProperty(ApiConstants.DATE_FROM)
    private final Date dateFrom;

    @JsonProperty(ApiConstants.DATE_TO)
    private final Date dateTo;

    private SearchParameters(Builder builder) {
        this.recipient = builder.recipient;
        this.sender = builder.sender;
        this.product = builder.product;
        this.tags = builder.tags;
        this.dateFrom = builder.dateFrom;
        this.dateTo = builder.dateTo;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getSender() {
        return sender;
    }

    public String getProduct() {
        return product;
    }

    public List<String> getTags() {
        return tags;
    }

    public Date getDateFrom() {
        return new Date(dateFrom.getTime());
    }

    public Date getDateTo() {
        return new Date(dateTo.getTime());
    }

    public static class Builder {
        private String recipient;
        private String sender;
        private String product;
        private List<String> tags;
        private Date dateFrom;
        private Date dateTo;

        public Builder recipient(String recipient) {
            this.recipient = recipient;
            return this;
        }

        public Builder sender(String sender) {
            this.sender = sender;
            return this;
        }

        public Builder product(String product) {
            this.product = product;
            return this;
        }

        public Builder dateFrom(Date dateFrom) {
            this.dateFrom = dateFrom;
            return this;
        }

        public Builder dteTo(Date dateTo) {
            this.dateTo = dateTo;
            return this;
        }

        public SearchParameters build() {
            return new SearchParameters(this);
        }

        @Override
        public String toString() {
            return "Builder{" +
                    "recipient='" + recipient + '\'' +
                    ", sender='" + sender + '\'' +
                    ", product='" + product + '\'' +
                    ", tags=" + tags +
                    ", dateFrom=" + dateFrom +
                    ", dateTo=" + dateTo +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "SearchParameters{" +
                "recipient='" + recipient + '\'' +
                ", sender='" + sender + '\'' +
                ", product='" + product + '\'' +
                ", tags=" + tags +
                ", dateFrom=" + dateFrom +
                ", dateTo=" + dateTo +
                '}';
    }
}
