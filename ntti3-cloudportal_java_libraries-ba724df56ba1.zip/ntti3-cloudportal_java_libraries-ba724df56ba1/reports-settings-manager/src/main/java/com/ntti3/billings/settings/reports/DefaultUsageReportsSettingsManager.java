package com.ntti3.billings.settings.reports;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Sets;
import com.google.common.collect.Table;
import com.google.inject.Inject;
import com.google.inject.assistedinject.Assisted;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import play.Configuration;
import play.Logger;

import java.util.List;
import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportsSettingsManager implements UsageReportsSettingsManager {

    private Set<RequestedUsageReportSetting> reportTypesForOpcos;
    private Table<OpcoUid, ReportType, Set<ServiceUid>> reportTypeSetTable;

    @Inject
    public DefaultUsageReportsSettingsManager(@Assisted Configuration configuration) {
        loadFromConfiguration(configuration);
    }

    protected void loadFromConfiguration(Configuration opcoReportsConfigurations) {
        reportTypesForOpcos = Sets.newHashSet();
        reportTypeSetTable = HashBasedTable.create();
        try {
            for (String opcoUidString : opcoReportsConfigurations.subKeys()) {
                OpcoUid opcoUid = OpcoUid.fromString(opcoUidString);
                Configuration opcoConfiguration = opcoReportsConfigurations.getConfig(opcoUidString);
                for (String reportTypeString : opcoConfiguration.keys()) {
                    ReportType reportType = ReportType.fromString(reportTypeString);
                    List<String> servicesList = opcoConfiguration.getStringList(reportTypeString);
                    for (String serviceString : servicesList) {
                        ServiceUid serviceUid  = ServiceUid.fromString(serviceString);
                        DefaultRequestedUsageReportSetting RequestedReportSetting =
                                new DefaultRequestedUsageReportSetting(opcoUid, serviceUid, reportType);
                        reportTypesForOpcos.add(RequestedReportSetting);
                        if (reportTypeSetTable.contains(opcoUid, reportType)) {
                            reportTypeSetTable.get(opcoUid, reportType).add(serviceUid);
                        } else {
                            reportTypeSetTable.put(opcoUid, reportType, Sets.newHashSet(serviceUid));
                        }
                    }
                }
            }
        } catch (IllegalArgumentException | ClassCastException e) {
            Logger.error("Could not load OpcoReportsSettings", e);
        }
    }

    @Override
    public Set<RequestedUsageReportSetting> getRequestedReports() {
        return Sets.newHashSet(reportTypesForOpcos);
    }

    @Override
    public Set<ServiceUid> getRequestedReports(OpcoUid opcoUid, ReportType reportType) {
        return reportTypeSetTable.get(opcoUid, reportType);
    }
}
