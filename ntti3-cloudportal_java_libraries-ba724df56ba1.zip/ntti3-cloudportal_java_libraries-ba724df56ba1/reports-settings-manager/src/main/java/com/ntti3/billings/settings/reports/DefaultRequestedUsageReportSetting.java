package com.ntti3.billings.settings.reports;

import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultRequestedUsageReportSetting implements RequestedUsageReportSetting {

    private OpcoUid opcoUid;
    private ServiceUid serviceUid;
    private ReportType reportType;

    public DefaultRequestedUsageReportSetting(OpcoUid opcoUid, ServiceUid serviceUid, ReportType reportType) {
        this.opcoUid = opcoUid;
        this.serviceUid = serviceUid;
        this.reportType = reportType;
    }

    @Override
    public OpcoUid getOpcoUid() {
        return opcoUid;
    }

    @Override
    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    @Override
    public ReportType getReportType() {
        return reportType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DefaultRequestedUsageReportSetting that = (DefaultRequestedUsageReportSetting) o;

        if (opcoUid != null ? !opcoUid.equals(that.opcoUid) : that.opcoUid != null) return false;

        return reportType == that.reportType && serviceUid == that.serviceUid;

    }

    @Override
    public int hashCode() {
        int result = opcoUid != null ? opcoUid.hashCode() : 0;
        result = 31 * result + (serviceUid != null ? serviceUid.hashCode() : 0);
        result = 31 * result + (reportType != null ? reportType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "DefaultRequestedUsageReportSetting{" +
                "opcoUid=" + opcoUid +
                ", serviceUid=" + serviceUid +
                ", reportType=" + reportType +
                '}';
    }
}
