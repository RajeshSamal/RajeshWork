package com.ntti3.billings.settings.reports;

import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportsSettingsManagerFactory {

    public UsageReportsSettingsManager create(Configuration configuration);
}
