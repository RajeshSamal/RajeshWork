package com.ntti3.billings.settings.reports;

import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
// TODO javadoc!
public interface RequestedUsageReportSetting {
    OpcoUid getOpcoUid();

    ServiceUid getServiceUid();

    ReportType getReportType();
}
