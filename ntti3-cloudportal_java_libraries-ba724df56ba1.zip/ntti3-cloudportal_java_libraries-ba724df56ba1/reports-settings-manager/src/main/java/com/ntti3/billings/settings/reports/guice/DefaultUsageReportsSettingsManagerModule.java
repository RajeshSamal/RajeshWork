package com.ntti3.billings.settings.reports.guice;

import com.google.inject.AbstractModule;
import com.google.inject.assistedinject.FactoryModuleBuilder;
import com.ntti3.billings.settings.reports.DefaultUsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManagerFactory;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportsSettingsManagerModule extends AbstractModule {

    @Override
    protected void configure() {
        install(new FactoryModuleBuilder()
                .implement(UsageReportsSettingsManager.class, DefaultUsageReportsSettingsManager.class)
                .build(UsageReportsSettingsManagerFactory.class));
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportsSettingsManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportsSettingsManagerModule.class.equals(obj.getClass());
    }
}
