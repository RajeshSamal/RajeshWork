package com.ntti3.spsso.session.fake;

import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSession;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;

import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class FakeSession implements UserSession {

    private final String uuidString;
    private final Role level;

    public FakeSession(String uuidString, Role level) {
        this.uuidString = uuidString;
        this.level = level;
    }

    @Override
    public void readToken(Multimap<String, String> stringStringMultimap) {

    }

    @Override
    public void clear() {

    }

    @Override
    public String getGuid() {
        return uuidString;
    }

    @Override
    public boolean isLoggedIn() {
        return true;
    }

    @Override
    public String getFirstName() {
        return "Coyote";
    }

    @Override
    public String getLastName() {
        return "Tester";
    }

    @Deprecated
    @Override
    public boolean isOpcoAdmin() {
        return level.coversRole(Role.OPCO_ADMIN);
    }

    @Deprecated
    @Override
    public boolean isCompanyAdmin() {
        return level.coversRole(Role.COMPANY_ADMIN);
    }

    @Deprecated
    @Override
    public boolean isSuperAdmin() {
        return level.coversRole(Role.SUPER_ADMIN);
    }

    @Override
    public boolean hasRole(Role role) {
        return level.coversRole(role);
    }

    @Override
    public Set<Role> getRoles() {
        return Sets.newHashSet(level);
    }

    @Override
    public OpcoUid getOpcoUid() {
        return OpcoUid.fromString("cl");
    }
}
