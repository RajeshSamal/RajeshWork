package com.ntti3.spsso.session.guava;

import com.ntti3.spsso.session.CookieUserSessionManager;
import com.ntti3.spsso.session.UserSessionManager;
import com.google.inject.AbstractModule;

/**
 * @author jan.karwowski@ntti3.com
 */
public class CookieUserSessionModule extends AbstractModule {
    @Override
    protected void configure() {
        bind(UserSessionManager.class).to(CookieUserSessionManager.class);
    }
}
