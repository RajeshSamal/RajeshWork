package com.ntti3.spsso.session.annotations;

import com.ntti3.spsso.session.annotations.actions.CheckUserAuthorized;
import play.mvc.With;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Deprecated
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE, ElementType.METHOD })
@With(CheckUserAuthorized.class)
public @interface UserAuthorized {
}
