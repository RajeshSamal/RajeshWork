package com.ntti3.play.annotations.auth;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ntti3.spsso.session.Role;

import play.mvc.With;
import com.ntti3.play.annotations.auth.actions.AuthorizedAction;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE, ElementType.METHOD })
@With(AuthorizedAction.class)
public @interface Authorized {
    Role role() default Role.USER;

    boolean exact() default false;
}
