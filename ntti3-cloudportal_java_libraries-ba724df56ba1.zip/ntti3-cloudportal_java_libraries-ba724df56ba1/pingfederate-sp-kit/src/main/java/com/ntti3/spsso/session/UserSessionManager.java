package com.ntti3.spsso.session;

import play.mvc.Http;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UserSessionManager {
    // TODO Javadoc
    public UserSession getSession(Http.Session session);
}
