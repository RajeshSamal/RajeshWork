package com.ntti3.play.annotations.auth.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * @author Mateusz Piękos (mateusz.piekos@codilime.com).
 */
@Aspect
public class LoggingAspect extends com.ntti3.connectors.aspects.LoggingAspect {
    @Pointcut("(execution(public * com.ntti3.play.annotations.auth..* (..)) || execution(public * com.ntti3.spsso..* (..))) && !execution(public * com.ntti3.play.annotations.auth.actions.* (..)) " )
    public void publicMethodPointcut() {
    }
}
