package com.ntti3.spsso.session;

import java.util.Arrays;
import java.util.Collection;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.base.Splitter;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;

public enum Role {
    // Role hierarchy is defined in RoleHierarchy class
    USER(null), COMPANY_ADMIN("company_admin"), OPCO_ADMIN("opco_admin"), SUPER_ADMIN(
            "super_admin");

    private final String flagName;

    private Role(String flagName) {
        this.flagName = flagName;
    }

    public boolean coversRole(Role role) {
        return this.equals(role)
                || RoleHierarchy.getInstance().getUnderRoles(this)
                        .contains(role);
    }

    public String getFlagName() {
        return flagName;
    }

    public static Role fromFlag(String flag) {
        for (Role role : values()) {
            if (role.getFlagName().equals(flag)) {
                return role;
            }
        }
        throw new IllegalArgumentException("No such flag: " + flag);
    }

    public static Role fromFlagOrNull(String flag) {
        for (Role role : values()) {
            if (role.getFlagName() == null)
                continue;
            if (role.getFlagName().equals(flag)) {
                return role;
            }
        }
        return null;
    }

    public static Iterable<Role> rolesFromFlags(Collection<String> flags) {
        return Iterables.concat(Collections2.filter(
                Collections2.transform(flags, new Function<String, Role>() {
                    @Override
                    public Role apply(String input) {
                        return fromFlagOrNull(input);
                    }
                }), new Predicate<Object>() {

                    @Override
                    public boolean apply(Object input) {
                        return input != null;
                    }
                }), Arrays.asList(USER));
    }

    public static String buildRolesString(Iterable<Role> roles) {
        return Joiner.on(",").join(
                Iterables.transform(roles, new Function<Role, String>() {
                    @Override
                    public String apply(Role input) {
                        return input.name();
                    }
                }));
    }

    public static Iterable<Role> parseRolesString(String rolesString) {
        return Iterables.transform(Splitter.on(",").split(rolesString),
                new Function<String, Role>() {
                    @Override
                    public Role apply(String input) {
                        return valueOf(input);
                    }
                });
    }

    public static Iterable<Role> underolesClosure(Iterable<Role> roles) {
        return Iterables.concat(roles, Iterables.concat(Iterables.transform(roles,
                new Function<Role, Iterable<Role>>() {
                    @Override
                    public Iterable<Role> apply(Role input) {
                        return RoleHierarchy.getInstance().getUnderRoles(input);
                    }
                })));
    }
}
