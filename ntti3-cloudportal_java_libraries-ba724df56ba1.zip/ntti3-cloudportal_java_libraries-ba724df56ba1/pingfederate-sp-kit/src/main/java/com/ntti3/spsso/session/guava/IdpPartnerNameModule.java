package com.ntti3.spsso.session.guava;

import com.ntti3.spsso.IdpPartnerName;
import com.google.inject.AbstractModule;

/**
 * @author jan.karwowski@ntti3.com
 */
public class IdpPartnerNameModule extends AbstractModule {
    private String idpPartnerName;

    public IdpPartnerNameModule(String idpPartnerName) {
        this.idpPartnerName = idpPartnerName;
    }

    @Override
    public boolean equals(Object obj) {
        return getClass().equals(obj.getClass());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    protected void configure() {
        bind(String.class).annotatedWith(IdpPartnerName.class).toInstance(
                idpPartnerName);
    }
}
