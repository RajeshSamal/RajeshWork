package com.ntti3.spsso.session;

import play.mvc.Http;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class CookieUserSessionManager implements UserSessionManager {

    @Override
    public UserSession getSession(Http.Session session) {
        return new CookieUserSession(session);
    }
}
