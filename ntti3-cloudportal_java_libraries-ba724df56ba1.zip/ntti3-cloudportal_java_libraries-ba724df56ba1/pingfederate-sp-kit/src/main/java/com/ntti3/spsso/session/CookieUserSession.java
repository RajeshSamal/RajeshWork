package com.ntti3.spsso.session;

import java.util.Collections;
import java.util.Set;

import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.gums.GumsProtocolConstants;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.pingidentity.opentoken.Agent;

import play.Logger;
import play.mvc.Http;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class CookieUserSession implements UserSession {

    private static final String GUID = "guid";
    private static final String EMAIL = "email";
    private static final String OPCO_UID = "opco_uid";
    private static final String FIRST_NAME = "first_name";
    private static final String LAST_NAME = "last_name";
    private static final String ROLES = "roles";
    private final Http.Session session;

    public final Set<Role> roles;

    CookieUserSession(Http.Session session) {
        this.session = session;
        if (this.session.get(ROLES) == null)
            roles = Collections.emptySet();
        else
            roles = Collections.unmodifiableSet(Sets.newHashSet(Role
                    .underolesClosure(Role.parseRolesString(session(ROLES)))));
        
        Logger.debug("User logged. Roles: " + roles);
    }

    @Override
    public void readToken(Multimap<String, String> token) {
        session(GUID, token.get(Agent.TOKEN_SUBJECT).iterator().next());
        session(EMAIL, token.get(EMAIL).iterator().next());
        session(ROLES, Role.buildRolesString(Role.rolesFromFlags(token
                .get(GumsProtocolConstants.FLAGS_PARAMETER))));
        session(OPCO_UID, token.get(GumsProtocolConstants.OPCO_UID_PARAMETER)
                .iterator().next());
        session(FIRST_NAME,
                token.get(GumsProtocolConstants.FIRST_NAME_PARAMETER)
                        .iterator().next());
        session(LAST_NAME, token.get(GumsProtocolConstants.LAST_NAME_PARAMETER)
                .iterator().next());
    }

    @Override
    public String getGuid() {
        return session(GUID);
    }

    @Override
    public void clear() {
        session.clear();
    }

    @Override
    public boolean isLoggedIn() {
        return roles.contains(Role.USER);
    }

    @Override
    public String getFirstName() {
        if (isLoggedIn()) {
            return session(FIRST_NAME);
        } else {
            return null;
        }
    }

    @Override
    public String getLastName() {
        if (isLoggedIn()) {
            return session(LAST_NAME);
        } else {
            return null;
        }
    }

    @Override
    public Set<Role> getRoles() {
        return roles;
    }

    @Override
    public boolean isOpcoAdmin() {
        return roles.contains(Role.OPCO_ADMIN);
    }

    @Override
    public boolean isCompanyAdmin() {
        return roles.contains(Role.COMPANY_ADMIN);
    }

    @Override
    public boolean isSuperAdmin() {
        return roles.contains(Role.SUPER_ADMIN);
    }

    @Override
    public OpcoUid getOpcoUid() {
        if (isLoggedIn()) {
            return OpcoUid.fromString(session(OPCO_UID));
        } else {
            return null;
        }
    }

    private void session(String key, String value) {
        this.session.put(key, value);
    }

    private String session(String key) {
        return this.session.get(key);
    }

    @Override
    public boolean hasRole(final Role role) {
        return Iterables.any(roles, new Predicate<Role>() {

            @Override
            public boolean apply(Role input) {
                return input.coversRole(role);
            }

        });
    }
}
