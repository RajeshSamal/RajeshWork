package com.ntti3.spsso;

import com.ntti3.pingfederate.connector.ProtocolHelper;
import com.ntti3.pingfederate.connector.ProtocolParametersException;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.TokenNotFoundException;
import com.ntti3.pingfederate.connector.RequestHandlerException;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;
import com.ntti3.urlhelper.UrlHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Preconditions;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;
import com.pingidentity.opentoken.TokenException;
import play.mvc.Call;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class SsoController extends Controller {

    private final VhostInstanceSelector<String> idpParameterSelector;
    private final VhostInstanceSelector<SPProtocolHelper> vhostSpProtocolHelperSelector;
    private final VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector;
    private UserSessionManager userSessionManager;
    private ObjectMapper objectMapper = new ObjectMapper();

    protected abstract Result ssoSuccessResult();

    protected abstract Result sloSuccessResult();

    protected abstract Call actionHandlerRoute(String type);

    protected abstract Call sloSuccessRoute();

    protected abstract Call sloFailureRoute();

    @Inject
    public SsoController(VhostInstanceSelector<SPProtocolHelper> vhostSpProtocolHelperSelector,
                         VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector,
                         UserSessionManager userSessionManager,
                         VhostInstanceSelector<String> idpParameterSelector) {
        Preconditions.checkNotNull(vhostSpProtocolHelperSelector);
        Preconditions.checkNotNull(vhostUrlHelperSelector);
        Preconditions.checkNotNull(userSessionManager);
        Preconditions.checkNotNull(idpParameterSelector);
        this.vhostSpProtocolHelperSelector = vhostSpProtocolHelperSelector;
        this.vhostUrlHelperSelector = vhostUrlHelperSelector;
        this.userSessionManager = userSessionManager;
        this.idpParameterSelector = idpParameterSelector;
    }

    public Result actionHandler(String action)
            throws ProtocolParametersException, TokenNotFoundException,
            TokenException, UnknownVhostException, RequestHandlerException {
        return getSpProtocolHelper(request()).handleRequest(action, request(),
                new SPProtocolHelper.RequestHandler() {
                    @Override
                    public Result sloRequest(
                            ProtocolHelper.ResumePath resumePath)
                            throws RequestHandlerException {
                        // Logout
                        try {
                            userSessionManager.getSession(session()).clear();
                            response().setHeader(Http.HeaderNames.CACHE_CONTROL,
                                    "NO-CACHE");
                            return seeOther(resumePath.getUrl());
                        }
                        catch (MalformedURLException e) {
                            throw new RequestHandlerException(e);
                        }

                    }

                    @Override
                    public Result ssoSuccess(String resumeUrl,
                                             Multimap<String, String> token) throws RequestHandlerException {
                        userSessionManager.getSession(session()).readToken(
                                token);
                        response().setHeader(Http.HeaderNames.CACHE_CONTROL,
                                "NO-CACHE");
                        if (resumeUrl != null) {
                            return seeOther(resumeUrl);
                        }
                        return ssoSuccessResult();
                    }

                    @Override
                    public Result ssoSuccess(Multimap<String, String> token)
                            throws RequestHandlerException {
                        return ssoSuccess(null, token);
                    }

                    @Override
                    public Result ssoFailure(String error, String details)
                            throws RequestHandlerException {
                        return ok("Sso failed");
                    }
                });
    }

    public Result sloSuccess() {
        return sloSuccessResult();
    }

    public Result startSso() throws MalformedURLException, UnknownVhostException {
        return temporaryRedirect(getSpProtocolHelper(request())
                .buildSsoUrl(this.getIdpParameter(request()), getSsoSuccessTarget(),
                        getSsoFailureTarget()).toString());
    }

    protected String getSsoFailureTarget() throws MalformedURLException, UnknownVhostException {
        return getUrlHelper(request())
                .absoluteAddress(actionHandlerRoute(SPProtocolHelper.RequestType.SSO_ERROR_HANDLER
                        .getUrlName()));
    }

    protected String getSsoSuccessTarget() throws MalformedURLException, UnknownVhostException {
        return getUrlHelper(request())
                .absoluteAddress(actionHandlerRoute(SPProtocolHelper.RequestType.SSO_SUCCESS_HANDLER
                        .getUrlName()));
    }

    public Result startSlo() throws MalformedURLException, TokenException,
            URISyntaxException, UnknownVhostException {
        UserSession userSession = userSessionManager.getSession(session());

        final UrlHelper urlHelper = getUrlHelper(request());
        String redirectUrl = getSpProtocolHelper(request()).buildSloUrl(
                userSession.getGuid(),
                urlHelper.absoluteAddress(sloSuccessRoute()),
                urlHelper.absoluteAddress(sloFailureRoute())).toString();
        userSession.clear();
        return temporaryRedirect(redirectUrl);
    }

    public Result getUserInfo() throws JsonProcessingException {
        UserSession session = userSessionManager.getSession(session());

        response().setContentType("application/json");
        return ok(objectMapper.writerWithType(UserSession.class)
                .writeValueAsString(session));
    }

    protected UrlHelper getUrlHelper(Http.Request request) throws UnknownVhostException {
        return vhostUrlHelperSelector.getInstanceForVhost(request);
    }

    protected SPProtocolHelper getSpProtocolHelper(Http.Request request) throws UnknownVhostException {
        return vhostSpProtocolHelperSelector.getInstanceForVhost(request);
    }

    protected String getIdpParameter(Http.Request request) throws UnknownVhostException {
        return idpParameterSelector.getInstanceForVhost(request);
    }
}
