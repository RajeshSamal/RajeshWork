package com.ntti3.spsso.session;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

public final class RoleHierarchy {
    private static volatile RoleHierarchy singleton;

    private final Map<Role, Set<Role>> underRoles;

    static RoleHierarchy getInstance() {
        if (singleton == null) {
            synchronized (RoleHierarchy.class) {
                if (singleton == null) {
                    return singleton = new RoleHierarchy();
                }
            }
        }
            
        return singleton;
    }

    private static void putWithAncestors(final EnumMap<Role, Set<Role>> map,
            final Role role, final Role... ancestors) {
        ImmutableSet<Role> set = Sets.immutableEnumSet(Iterables.concat(Arrays
                .asList(ancestors), Iterables.concat(Lists.transform(
                Arrays.asList(ancestors), new Function<Role, Set<Role>>() {
                    @Override
                    public Set<Role> apply(Role input) {
                        return map.get(input);
                    }
                }))));
        map.put(role, set);
    }

    private RoleHierarchy() {
        EnumMap<Role, Set<Role>> map = new EnumMap<>(Role.class);
        map.put(Role.USER, Collections.<Role> emptySet());
        putWithAncestors(map, Role.COMPANY_ADMIN, Role.USER);
        putWithAncestors(map, Role.OPCO_ADMIN, Role.COMPANY_ADMIN);
        putWithAncestors(map, Role.SUPER_ADMIN, Role.OPCO_ADMIN);

        for (Role role : Role.values()) {
            Preconditions.checkNotNull(map.get(role), "Role " + role.name()
                    + " not defined!");
        }

        underRoles = Collections.unmodifiableMap(map);
    }

    Set<Role> getUnderRoles(Role role) {
        Preconditions.checkNotNull(role);
        return underRoles.get(role);
    }

}
