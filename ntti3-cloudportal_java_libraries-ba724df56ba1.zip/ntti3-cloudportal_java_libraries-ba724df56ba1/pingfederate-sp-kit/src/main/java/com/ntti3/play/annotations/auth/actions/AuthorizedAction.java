package com.ntti3.play.annotations.auth.actions;

import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;
import play.libs.F;
import play.libs.F.Promise;
import play.mvc.Action;
import play.mvc.Http.Context;
import play.mvc.SimpleResult;

import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.inject.Inject;

public class AuthorizedAction extends Action<Authorized> {

    private final UserSessionManager sessionManager;

    @Inject
    public AuthorizedAction(UserSessionManager sessionManager) {
        this.sessionManager = Preconditions.checkNotNull(sessionManager);
    }

    @Override
    public Promise<SimpleResult> call(Context ctx) throws Throwable {
        UserSession session = sessionManager.getSession(ctx.session());

        if (configuration.exact()
                && session.getRoles().contains(configuration.role()))
            return F.Promise.<SimpleResult> pure(unauthorized());
        if (!configuration.exact()
                && !Iterables.any(session.getRoles(), new Predicate<Role>() {
                    @Override
                    public boolean apply(Role input) {
                        return input.coversRole(configuration.role());
                    }
                })) {
            return F.Promise.<SimpleResult> pure(unauthorized());
        }

        return delegate.call(ctx);
    }

}
