package com.ntti3.spsso.session.annotations.actions;

import com.ntti3.play.frontend.ErrorCode;
import com.ntti3.play.frontend.JsonResponseBuilder;
import com.ntti3.spsso.session.UserSessionManager;
import com.ntti3.spsso.session.annotations.UserAuthorized;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.SimpleResult;

/**
 * @author jan.karwowski@ntti3.com
 */
@Deprecated
public class CheckUserAuthorized extends Action<UserAuthorized> {
    private final UserSessionManager sessionManager;

    @Inject
    public CheckUserAuthorized(UserSessionManager sessionManager) {
        Preconditions.checkNotNull(sessionManager, "sessionManager");
        this.sessionManager = sessionManager;
    }

    @Override
    public F.Promise<SimpleResult> call(Http.Context ctx) throws Throwable {
        if (!sessionManager.getSession(ctx.session()).isLoggedIn())
            return F.Promise
                    .<SimpleResult> pure(unauthorized(JsonResponseBuilder
                            .prepareErrorMessage(ErrorCode.UNAUTHORIZED)));

        return this.delegate.call(ctx);
    }
}
