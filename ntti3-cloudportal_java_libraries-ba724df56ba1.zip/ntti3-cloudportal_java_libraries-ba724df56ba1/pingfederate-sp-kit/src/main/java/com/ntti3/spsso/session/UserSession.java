package com.ntti3.spsso.session;

import java.util.Set;

import com.ntti3.billings.types.base.OpcoUid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Multimap;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UserSession {
    // TODO Javadoc
    void readToken(Multimap<String, String> token);

    void clear();

    @JsonInclude(JsonInclude.Include.NON_NULL)
    String getGuid();

    boolean isLoggedIn();

    @JsonInclude(JsonInclude.Include.NON_NULL)
    String getFirstName();

    @JsonInclude(JsonInclude.Include.NON_NULL)
    String getLastName();

    @Deprecated
    boolean isOpcoAdmin();

    @Deprecated
    boolean isCompanyAdmin();

    @Deprecated
    boolean isSuperAdmin();

    boolean hasRole(Role role);

    Set<Role> getRoles();

    @JsonInclude(JsonInclude.Include.NON_NULL)
    OpcoUid getOpcoUid();
}
