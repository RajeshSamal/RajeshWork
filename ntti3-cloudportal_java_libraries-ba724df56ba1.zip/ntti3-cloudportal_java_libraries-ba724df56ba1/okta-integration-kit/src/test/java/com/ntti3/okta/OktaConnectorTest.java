package com.ntti3.okta;

import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.models.User;

import junit.framework.TestCase;

import org.junit.Ignore;
import org.junit.Test;

import java.net.URI;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.*;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaConnectorTest {
    private static final String PASSWORD = "ILikeGreen1";
    private static final String OTHER_NEW_PASSWORD = "Kaboooooom1";
    private static final String NEW_PASSWORD = "iIiIiIiI1";
    //private static final String APP_ID = "0oaslihh3sZFFLJZWGKJ";
    private static final String APP_ID = "0oa283yl0eSMDQOYGJRM"; // oktapreview
    //private static final String APP_ID = "0oarfuidx1XUGCDMOECZ";
    private OktaConnector oktaConnector;

    @org.junit.Before
    public void setUp() throws Exception {
        //oktaConnector = new OktaConnector("00vilImkzaw9413JNFGO_jpPUSA-SZOahsQ2EA5eaW", "ntti34.okta.com");
        //oktaConnector = new OktaConnector("00XFyxE9HnLiZpn21tWXPwChy4AdlxKzdBtMdcYF6h", "ntti32.okta.com");
        oktaConnector = new OktaConnector(new URI("https://ntti32.oktapreview.com/"), null,
                "00gFcboVjR5fPXJD_ST-Kgv1c_AkCMkk1WAYReXpaM");
    }

    @org.junit.After
    public void tearDown() throws Exception {

    }

    @Test
    public void test1() throws Exception {
        User user = new User();
        user.setFirstName("Kermit");
        user.setLastName("Fróg");
        String email1 = "kermit.the.frog." + System.currentTimeMillis() + "@mailinator.com";
        String email2 = "kermit.frog." + System.currentTimeMillis() + "@mailinator.com";

        user.setEmail(email1);
        user.setLogin(email1);
        user.setMobilePhone("555-000-000-0000");
        user.setPassword(PASSWORD);
        user.setRecoveryQuestion("AAAA");
        user.setRecoveryAnswer("BBBB");

        oktaConnector.registerUser(user);
        oktaConnector.activateUser(user.getLogin());

        oktaConnector.unlockUser(email1);

        oktaConnector.updatePassword(email1, OTHER_NEW_PASSWORD);
        oktaConnector.updateRecoveryQuestion(email1, "UbaUba", "XXXX");

        TestCase.assertFalse(oktaConnector.updatePassword(email1, "UbaUba", "XXXXxxxx"));
        TestCase.assertTrue(oktaConnector.updatePassword(email1, OTHER_NEW_PASSWORD, NEW_PASSWORD));

        TestCase.assertFalse(oktaConnector.updateRecoveryQuestion(email1, "UbaUba",
                "XXXXxxxx", NEW_PASSWORD));

        TestCase.assertTrue(oktaConnector.updateRecoveryQuestion(email1, NEW_PASSWORD,
                "XXXXxxxx", "A_a_A-C"));

        List<String> strings = oktaConnector.listUserApps(email1);
        assertEquals(0, strings.size());
        oktaConnector.assignUserToApp(email1, APP_ID);
        strings = oktaConnector.listUserApps(email1);
        assertThat(oktaConnector.listUserApps(email1))
                .containsExactly(APP_ID);

        oktaConnector.revokeUserApp(email1, APP_ID);
        strings = oktaConnector.listUserApps(email1);
        System.err.println("I am butterfly!!!!!!!!!!!!!");
        System.err.println(strings);
        //TimeUnit.MINUTES.sleep(1);

        assertEquals(0, strings.size());

        User user2 = new User();
        user2.setLogin(email1);
        user2.setEmail(email2);
        user2.setFirstName("timreK");
        user2.setLastName("gorF");
        user2.setMobilePhone("555-123-123-1234");

        oktaConnector.editUser(user);
    }
    
    @Test
    public void passwordValidationTest() throws RegistrationProtocolException {
    	User user = new User();
        user.setFirstName("Kermit");
        user.setLastName("Fróg");
        String email1 = "kermit.the.frog." + System.currentTimeMillis() + "@mailinator.com";
        String email2 = "kermit.frog." + System.currentTimeMillis() + "@mailinator.com";

        user.setEmail(email1);
        user.setLogin(email1);
        user.setMobilePhone("555-000-000-0000");
        user.setPassword("123");
        user.setRecoveryQuestion("AAAA");
        user.setRecoveryAnswer("BBBB");

        try {
        	oktaConnector.registerUser(user);
        } catch (OktaValidationException ex) {
        	assertThat(ex.getValidationMessages())
        	.containsOnly("Passwords must have at least 8 characters, a lowercase letter, an "
        			+ "uppercase letter, a number, no parts of your username");
        	return;
        }
        fail();
    }

    @Test
    @Ignore
    public void test2() throws Exception {
        User user = new User();
        user.setFirstName("Kermit");
        user.setLastName("Fróg");
        String email1 = "kermit.the.frog@mailinator.com";
        String email2 = "kermit.frog@mailinator.com";

        user.setEmail(email1);
        user.setLogin(email1);
        user.setMobilePhone("555-000-000-0000");
        user.setPassword(PASSWORD);
        user.setRecoveryQuestion("AAAA");
        user.setRecoveryAnswer("BBBB");
        user.setRecoveryAnswer("BBBB");

        OktaConnector oktaConnector = new OktaConnector(new URI("https://ntti32.okta.com/"), null,
                "00XFyxE9HnLiZpn21tWXPwChy4AdlxKzdBtMdcYF6h");
        oktaConnector.registerUser(user);
    }

//    @Test
//    public void test3() throws Exception {
//        User user = new User();
//        user.setFirstName("Kermit");
//        user.setLastName("Fróg");
//        String email1 = "kermit.the.frog.1396605059058@mailinator.com";
//        String email2 = "kermit.frog@mailinator.com";
//
//        user.setEmail(email1);
//        user.setLogin(email1);
//        user.setMobilePhone("555-000-000-0000");
//        user.setPassword(PASSWORD);
//        user.setRecoveryQuestion("AAAA");
//        user.setRecoveryAnswer("BBBB");
//
//
//        OktaConnector oktaConnector = new OktaConnector("00vilImkzaw9413JNFGO_jpPUSA-SZOahsQ2EA5eaW", "ntti32.oktapreview.com");
//        List<String> strings = oktaConnector.listUserApps(email1);
//        System.err.println("I am butterfly!!!!!!!!!!!!!");
//        System.err.println(strings);
//
//        assertEquals(0, strings.size());
//    }
}

