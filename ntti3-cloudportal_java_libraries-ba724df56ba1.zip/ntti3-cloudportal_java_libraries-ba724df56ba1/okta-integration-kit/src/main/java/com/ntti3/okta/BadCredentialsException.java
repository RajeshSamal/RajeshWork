package com.ntti3.okta;

import com.ntti3.okta.models.ErrorResponse;

/**
 * @author jan.karwowski@ntti3.com
 */
public class BadCredentialsException extends OktaProtocolErrorResponse {
    public BadCredentialsException(ErrorResponse val) {
        super(val);
    }
}
