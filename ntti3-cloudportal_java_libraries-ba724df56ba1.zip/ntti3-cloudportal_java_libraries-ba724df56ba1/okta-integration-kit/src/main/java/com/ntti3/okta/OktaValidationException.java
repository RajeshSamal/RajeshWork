package com.ntti3.okta;

import com.ntti3.gums.register.exceptions.ValidationFailedException;
import com.ntti3.okta.models.ErrorCause;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nullable;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaValidationException extends ValidationFailedException {
	private static final long serialVersionUID = 2L;
	private final List<String> errorList;
    
    public OktaValidationException(List<ErrorCause> errorList) {
    	this.errorList = Lists.transform(errorList,
                                new Function<ErrorCause, String>() {
                                    @Override
                                    public String apply(@Nullable ErrorCause cause) {
                                        return String.valueOf(cause);
                                    }
                                });
    }

    public OktaValidationException(String message, List<String> errorList) {
        super(message);
        this.errorList = errorList;
    }

    public OktaValidationException(String message, Throwable cause, List<String> errorList) {
        super(message, cause);
        this.errorList = errorList;
    }

    public OktaValidationException(Throwable cause, List<String> errorList) {
        super(cause);
        this.errorList = errorList;
    }

    public OktaValidationException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace, List<String> errorList) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.errorList = errorList;
    }

    @Override
    public Collection<?> getValidationMessages() {
        return errorList;
    }
}
