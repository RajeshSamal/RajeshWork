package com.ntti3.okta.models;

/**
 * @author jan.karwowski@ntti3.com
 */
public enum Status {
    ACTIVE
}
