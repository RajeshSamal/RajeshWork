package com.ntti3.okta;

import com.ntti3.okta.models.ErrorResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;

import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ErrorHelpers {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    static void parseErrorResponse(HttpResponse response)
            throws IOException, OktaProtocolException,
            OktaUserNotFoundException, OktaValidationException {
        try {
            if (response.getStatusLine() == null) {
                throw new OktaProtocolException("Critical error, no status line in response");
            }
            if (response.getEntity() != null) {
                ErrorResponse val = objectMapper.reader(ErrorResponse.class).readValue(response.getEntity().getContent());
                if (val != null) {
                    switch (val.getErrorCode()) {
                        case ProtocolConstants.E0000007:
                            throw new OktaUserNotFoundException(val);
                        case ProtocolConstants.E0000001:
                            throw new OktaValidationException(val.getErrorCauses());
                        case ProtocolConstants.E0000016:
                            throw new UserAlreadyActivatedException(val);
                        case ProtocolConstants.E0000014:
                            throw new BadCredentialsException(val);
                    }

                    throw new OktaProtocolErrorResponse(val);
                }
            }
        } catch (JsonParseException ex) {
            // we can't rely on content type to detect if okta sent error description to us
            // cause they do not set content type in error responses. So we detect nonparseable responses
        }
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_NOT_FOUND)
            throw new OktaUserNotFoundException();
        throw new OktaProtocolException("Status code " + response.getStatusLine().getStatusCode());
    }
}
