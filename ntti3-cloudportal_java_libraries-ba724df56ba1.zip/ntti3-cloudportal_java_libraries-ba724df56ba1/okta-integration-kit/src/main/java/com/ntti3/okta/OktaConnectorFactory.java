package com.ntti3.okta;

import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.UserRegistrationConnectorFactory;
import com.google.common.base.Preconditions;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaConnectorFactory implements UserRegistrationConnectorFactory {

    private static final String OKTA_TOKEN_KEY = "okta.token";
    private static final String OKTA_URL_KEY = "okta.url";
    private static final String OKTA_DEFAULT_APP_KEY = "okta.app";

    @Override
    public UserRegistrationConnector getInstance(Properties connectorProperties) {
        Preconditions.checkNotNull(connectorProperties.get(OKTA_URL_KEY), "Required key " + OKTA_URL_KEY
                + " not found in properties");
        Preconditions.checkNotNull(connectorProperties.get(OKTA_TOKEN_KEY), "Required key " + OKTA_TOKEN_KEY
                + " not found in properties");
        Preconditions.checkNotNull(connectorProperties.get(OKTA_DEFAULT_APP_KEY), "Required key " + OKTA_DEFAULT_APP_KEY
                + " not found in properties");

        try {
            return new OktaConnectorWithDefaultApplication(new OktaConnector(
                    new URI("https://"+connectorProperties.getProperty(OKTA_URL_KEY)+"/"), null,
                    connectorProperties.getProperty(OKTA_TOKEN_KEY)),
                    connectorProperties.getProperty(OKTA_DEFAULT_APP_KEY));
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
