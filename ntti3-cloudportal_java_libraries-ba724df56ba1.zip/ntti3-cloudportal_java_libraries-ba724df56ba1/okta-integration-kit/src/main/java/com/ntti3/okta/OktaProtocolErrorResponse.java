package com.ntti3.okta;

import com.ntti3.okta.models.ErrorResponse;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaProtocolErrorResponse extends OktaProtocolException {
    private final ErrorResponse val;

    public OktaProtocolErrorResponse(ErrorResponse val) {
        super(val.getErrorCode()+" "+val.getErrorSummary()+val.getErrorCauses());
        this.val=val;
    }

    public ErrorResponse getVal() {
        return val;
    }
}
