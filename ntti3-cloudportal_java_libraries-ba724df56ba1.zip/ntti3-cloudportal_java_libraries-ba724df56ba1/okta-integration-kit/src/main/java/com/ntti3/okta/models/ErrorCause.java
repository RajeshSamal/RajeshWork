package com.ntti3.okta.models;

import com.ntti3.okta.ProtocolConstants;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ErrorCause {
	@JsonProperty(ProtocolConstants.ERROR_SUMMARY_FIELD)
	private String errorSummary;

	public String getErrorSummary() {
		return errorSummary;
	}

	public void setErrorSummary(String errorSummary) {
		this.errorSummary = errorSummary;
	}

	public ErrorCause(@JsonProperty(ProtocolConstants.ERROR_SUMMARY_FIELD) String errorSummary) {
		this.errorSummary = errorSummary;
	}

	@Override
	public String toString() {
		return errorSummary;
	}
}
