package com.ntti3.okta;

/**
 * @author jan.karwowski@ntti3.com
 */
public class ProtocolConstants {
    public static final String OKTA_DOMAIN_SUFFIX = ".okta.com/";
    public static final String API_PATH_PREFIX = "/api/";
    public static final String VERSION_PATH_PREFIX = "v1/";
    public static final String USERS_PATH_COMPONENT = "users/";
    public static final String APPS_PATH_COMPONENT = "apps/";

    public static final String ACTIVATE_USER_PARAM = "activate";

    public static final String ERROR_SUMMARY_FIELD = "errorSummary";
    
    public static final String CHANGE_PASSWORD_SUFFIX = "/credentials/change_password";
    public static final String CHANGE_QUESTION_SUFFIX = "/credentials/change_recovery_question";

    public static final String NEW_PASSWORD_FIELD = "newPassword";
    public static final String OLD_PASSWORD_FILED = "oldPassword";
    public static final String E0000007 = "E0000007";
    public static final String E0000001 = "E0000001";
    public static final String E0000014 = "E0000014";
    public static final String LIFECYCLE_UNLOCK_PATH_SEGMENT = "/lifecycle/unlock";
    public static final String FILTER_QUERY_PARAM = "filter";
    public static final String USER_ID_FILTER_STRING = "user.id eq ";
    public static final String LIFECYCLE_ACTIVATE_PATH_SEGMENT = "/lifecycle/activate";
    public static final String E0000032 = "E0000032";
    public static final String PROFILE_FIELD = "profile";
    public static final String E0000016 = "E0000016";
    public static final String ID_FIELD = "id";
}
