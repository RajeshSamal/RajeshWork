package com.ntti3.okta;

import com.ntti3.okta.models.ErrorResponse;

/**
 * @author jan.karwowski@ntti3.com
 */
public class UserAlreadyActivatedException extends OktaProtocolErrorResponse {
    public UserAlreadyActivatedException(ErrorResponse val) {
        super(val);
    }
}
