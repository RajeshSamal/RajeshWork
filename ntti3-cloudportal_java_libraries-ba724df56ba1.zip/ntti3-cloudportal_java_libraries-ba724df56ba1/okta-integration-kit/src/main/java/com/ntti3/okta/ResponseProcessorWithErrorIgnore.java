package com.ntti3.okta;

import org.apache.http.HttpResponse;

import java.io.IOException;
import java.util.Set;

import static com.ntti3.connectors.BaseConnector.isStatusOk;

/**
 * @author jan.karwowski@ntti3.com
 */
public abstract class ResponseProcessorWithErrorIgnore<T> implements ResponseProcessor<T> {
    private final Set<String> ignoredErrorCodes;

    protected ResponseProcessorWithErrorIgnore(Set<String> ignoredErrorCodes) {
        this.ignoredErrorCodes = ignoredErrorCodes;
    }

    public abstract T onSuccessResponse(HttpResponse response) throws IOException;

    public abstract T onErrorIgnoreResponse(String errorCode);

    @Override
    public T process(HttpResponse response) throws OktaProtocolException,
            OktaUserNotFoundException, OktaValidationException {
        if (isStatusOk(response)) {
            try {
                return onSuccessResponse(response);
            } catch (IOException e) {
                throw new OktaProtocolException(e);
            }
        } else {
            try {
                ErrorHelpers.parseErrorResponse(response);
            } catch (IOException e) {
                throw new OktaProtocolException(e);
            } catch (OktaProtocolErrorResponse e) {
                if (e.getVal() != null && ignoredErrorCodes.contains(e.getVal().getErrorCode()))
                    return onErrorIgnoreResponse(e.getVal().getErrorCode());
                throw e;
            }
        }
        throw new OktaProtocolException(OktaConnector.UNKNOWN_ERROR_CONDITION);
    }
}
