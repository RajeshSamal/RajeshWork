package com.ntti3.okta;

import org.apache.http.HttpResponse;

import java.io.IOException;

/**
* @author jan.karwowski@ntti3.com
*/
interface ResponseProcessor<T> {
    public T process(HttpResponse response) throws IOException, OktaProtocolException, OktaUserNotFoundException,
            OktaValidationException;
}
