package com.ntti3.okta;

import com.ntti3.connectors.BaseConnector;
import org.apache.http.HttpResponse;

import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
abstract class StandardResponseProcessor<T> implements ResponseProcessor<T> {
    public abstract T process200Code(HttpResponse response) throws
            IOException, OktaProtocolException, OktaUserNotFoundException;

    @Override
    public T process(HttpResponse response) throws OktaProtocolException, OktaUserNotFoundException,
            OktaValidationException {
        try {
            if (BaseConnector.isStatusOk(response))
                return process200Code(response);
            ErrorHelpers.parseErrorResponse(response);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
        throw new OktaProtocolException(OktaConnector.UNKNOWN_ERROR_CONDITION);
    }
}
