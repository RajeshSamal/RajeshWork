package com.ntti3.okta;

import com.ntti3.gums.register.exceptions.RegistrationProtocolException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaProtocolException extends RegistrationProtocolException {
    public OktaProtocolException() {
    }

    public OktaProtocolException(String message) {
        super(message);
    }

    public OktaProtocolException(String message, Throwable cause) {
        super(message, cause);
    }

    public OktaProtocolException(Throwable cause) {
        super(cause);
    }

    public OktaProtocolException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
