package com.ntti3.okta;

import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.UserNotFoundException;
import com.ntti3.gums.register.models.User;

import javax.annotation.Nonnull;
import java.io.IOException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaConnectorWithDefaultApplication implements UserRegistrationConnector {
    private final OktaConnector oktaConnector;
    private final String appId;

    public OktaConnectorWithDefaultApplication(OktaConnector oktaConnector, String appId) {
        this.oktaConnector = oktaConnector;
        this.appId = appId;
    }

    @Override
    public void activateUser(@Nonnull String opcoUUid) throws RegistrationProtocolException, IOException, UserNotFoundException {
        oktaConnector.activateUser(opcoUUid);
    }

    @Override
    public void unlockUser(@Nonnull String opcoUUid) throws RegistrationProtocolException,
            UserNotFoundException {
        oktaConnector.unlockUser(opcoUUid);
    }

    @Override
    public boolean updateRecoveryQuestion(@Nonnull String opcoUUid, @Nonnull String oldPassword,
                                          @Nonnull String question, @Nonnull String answer)
            throws RegistrationProtocolException, UserNotFoundException {
        return oktaConnector.updateRecoveryQuestion(opcoUUid, oldPassword, question, answer);
    }

    @Override
    public void updateRecoveryQuestion(String opcoUUid, String question, String answer) throws
    RegistrationProtocolException, UserNotFoundException {
        oktaConnector.updateRecoveryQuestion(opcoUUid, question, answer);
    }

    @Override
    public boolean updatePassword(@Nonnull String opcoUUid, @Nonnull String oldPassword,
                                  @Nonnull String newPassword)
            throws RegistrationProtocolException, UserNotFoundException {
        return oktaConnector.updatePassword(opcoUUid, oldPassword, newPassword);
    }

    @Override
    public void updatePassword(String opcoUUid, String newPassword)
            throws OktaProtocolException, IOException, OktaUserNotFoundException, OktaValidationException {
        oktaConnector.updatePassword(opcoUUid, newPassword);
    }

    @Override
    public String registerUser(@Nonnull User user) throws RegistrationProtocolException {
        String id = oktaConnector.registerUser(user);
        try {
            oktaConnector.assignUserToApp(id, appId);
        } catch (OktaUserNotFoundException e) {
            //We should not have such exception
            throw new RuntimeException(e);
        }
        return id;
    }

    @Override
    public void editUser(@Nonnull User user) throws OktaProtocolException, OktaUserNotFoundException,
            OktaValidationException {
        oktaConnector.editUser(user);
    }

    @Override
    public boolean userExists(@Nonnull String login) throws RegistrationProtocolException {
        return oktaConnector.userExists(login);
    }
}
