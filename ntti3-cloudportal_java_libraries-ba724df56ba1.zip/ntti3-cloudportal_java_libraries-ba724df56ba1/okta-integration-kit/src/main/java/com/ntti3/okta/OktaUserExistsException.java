package com.ntti3.okta;

import com.ntti3.gums.register.exceptions.UserExistsException;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaUserExistsException extends UserExistsException {
    public OktaUserExistsException() {
    }

    public OktaUserExistsException(String message) {
        super(message);
    }

    public OktaUserExistsException(String message, Throwable cause) {
        super(message, cause);
    }

    public OktaUserExistsException(Throwable cause) {
        super(cause);
    }
}
