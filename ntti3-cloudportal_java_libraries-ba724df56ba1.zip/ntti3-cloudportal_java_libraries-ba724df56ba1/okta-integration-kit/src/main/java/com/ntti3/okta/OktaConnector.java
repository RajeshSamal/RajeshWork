package com.ntti3.okta;

import com.ntti3.connectors.BaseConnector;
import com.ntti3.gums.register.UserRegistrationConnector;
import com.ntti3.gums.register.exceptions.RegistrationProtocolException;
import com.ntti3.gums.register.exceptions.UserNotFoundException;
import com.ntti3.okta.models.Credentials;
import com.ntti3.okta.models.Password;
import com.ntti3.okta.models.Profile;
import com.ntti3.okta.models.RecoveryQuestion;
import com.ntti3.okta.models.User;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.params.HttpParams;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.List;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaConnector extends BaseConnector implements UserRegistrationConnector {
    public static final String UNKNOWN_ERROR_CONDITION = "Unknown error condition";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private final String authToken;

    public OktaConnector(@Nonnull URI baseAddress, @Nullable HttpParams params, String authToken) {
        super(baseAddress, params);
        this.authToken = authToken;
    }

    public OktaConnector(@Nonnull URI baseAddress, @Nullable HttpParams params,
                         Collection<Scheme> schemes, String authToken) {
        super(baseAddress, params, schemes);
        this.authToken = authToken;
    }

    public OktaConnector(@Nonnull URI baseAddress, @Nullable HttpParams params,
                         @Nullable SSLSocketFactory httpsSocketFactory, String authToken) {
        super(baseAddress, params, httpsSocketFactory);
        this.authToken = authToken;
    }

    @Override
    public void editUser(@Nonnull com.ntti3.gums.register.models.User user)
            throws OktaProtocolException, OktaUserNotFoundException, OktaValidationException {
        String oktaId = getOktaId(user.getLogin());
        Profile profile = new Profile();

        profile.setEmail(user.getEmail());
        profile.setFirstName(user.getFirstName());
        profile.setLastName(user.getLastName());
        profile.setMobilePhone(user.getMobilePhone());
        profile.setLogin(user.getLogin());

        ObjectNode node = objectMapper.createObjectNode();
        node.put(ProtocolConstants.PROFILE_FIELD, objectMapper.valueToTree(profile));

        try {
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + oktaId).build();
            HttpPut request = new HttpPut(uri);
            request.setEntity(new StringEntity(objectMapper.writeValueAsString(node), ContentType.APPLICATION_JSON));
            performRequest(request, new StandardResponseProcessor<Void>() {
                @Override
                public Void process200Code(HttpResponse response) throws IOException, OktaProtocolException,
                        OktaUserNotFoundException {
                    return null;
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
    }

    @Override
    public String registerUser(@Nonnull final com.ntti3.gums.register.models.User user)
            throws RegistrationProtocolException {
        if (checkIfUserExists(user.getLogin()))
            throw new OktaUserExistsException();

        User oktaUser = new User();
        oktaUser.copyGenericUserData(user);

        try {
            HttpPost post = new HttpPost();
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT)
                    .setParameter(ProtocolConstants.ACTIVATE_USER_PARAM, "false")
                    .build();
            post.setURI(uri);
            String string = objectMapper.writeValueAsString(oktaUser);
            post.setEntity(new StringEntity(string, ContentType.APPLICATION_JSON));
            return performRequest(post, new StandardResponseProcessor<String>() {
                @Override
                public String process200Code(HttpResponse response) {
                    return user.getLogin();
                }
            });
        } catch (URISyntaxException | OktaUserNotFoundException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
    }

    @Override
    public void activateUser(@Nonnull String opcoUUid) throws OktaProtocolException,
            IOException, OktaUserNotFoundException, OktaValidationException {
        try {
            String oktaId = getOktaId(opcoUUid);
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + oktaId
                    + ProtocolConstants.LIFECYCLE_ACTIVATE_PATH_SEGMENT)
                    .setParameter("sendEmail", "false")
                    .build();
            HttpPost post = new HttpPost(uri);

            String string = objectMapper.writeValueAsString(new Object() {
                public boolean sendEmail = false;
            });

            post.setEntity(new StringEntity(string, ContentType.APPLICATION_JSON));

            try {
                performRequest(post, new StandardResponseProcessor<Void>() {
                    @Override
                    public Void process200Code(HttpResponse response) throws IOException, OktaProtocolException,
                            OktaUserNotFoundException {
                        return null;
                    }
                });
            } catch (UserAlreadyActivatedException ex) {
                // Ignore
            }

        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void updatePassword(String opcoUUid, String newPassword) throws OktaProtocolException, IOException,
            OktaUserNotFoundException, OktaValidationException {
        Credentials credentials = new Credentials();
        credentials.setPassword(new Password());
        credentials.getPassword().setValue(newPassword);
        updateCredentails(opcoUUid, credentials);
    }

    @Override
    public boolean updatePassword(@Nonnull String opcoUUid, @Nonnull String oldPassword, @Nonnull String newPassword)
            throws RegistrationProtocolException, UserNotFoundException {
        String oktaId = getOktaId(opcoUUid);

        Password oldPasswordP = new Password();
        oldPasswordP.setValue(oldPassword);
        Password newPasswordP = new Password();
        newPasswordP.setValue(newPassword);

        try {
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + oktaId + ProtocolConstants
                    .CHANGE_PASSWORD_SUFFIX).build();
            HttpPost post = new HttpPost(uri);
            ObjectNode node = objectMapper.createObjectNode();
            node.put(ProtocolConstants.OLD_PASSWORD_FILED, objectMapper.valueToTree(oldPasswordP));
            node.put(ProtocolConstants.NEW_PASSWORD_FIELD, objectMapper.valueToTree(newPasswordP));
            post.setEntity(new StringEntity(objectMapper.writeValueAsString(node), ContentType.APPLICATION_JSON));
            return performRequest(post, new StandardResponseProcessor<Boolean>() {
                @Override
                public Boolean process200Code(HttpResponse response) {
                    return true;
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        } catch (BadCredentialsException ex) {
            return false;
        }
    }

    @Override
    public void updateRecoveryQuestion(String opcoUUid, String question, String answer)
            throws RegistrationProtocolException, UserNotFoundException {
        Credentials credentials = new Credentials();
        credentials.setRecoveryQuestion(new RecoveryQuestion());
        credentials.getRecoveryQuestion().setQuestion(question);
        credentials.getRecoveryQuestion().setAnswer(answer);
        updateCredentails(opcoUUid, credentials);
    }

    @Override
    public boolean updateRecoveryQuestion(@Nonnull String opcoUUid, @Nonnull String oldPassword,
                                          @Nonnull String question, @Nonnull String answer)
            throws RegistrationProtocolException, UserNotFoundException {
        String oktaId = getOktaId(opcoUUid);

        Password oldPasswordP = new Password();
        oldPasswordP.setValue(oldPassword);
        RecoveryQuestion recoveryQuestion = new RecoveryQuestion();
        recoveryQuestion.setQuestion(question);
        recoveryQuestion.setAnswer(answer);

        try {
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + oktaId + ProtocolConstants
                    .CHANGE_QUESTION_SUFFIX).build();
            HttpPost post = new HttpPost(uri);
            ObjectNode node = objectMapper.createObjectNode();
            node.put("password", oldPassword);
            node.put("recovery_question", objectMapper.valueToTree(recoveryQuestion));
            //         recovery_question
            post.setEntity(new StringEntity(objectMapper.writeValueAsString(node), ContentType.APPLICATION_JSON));
            return performRequest(post, new StandardResponseProcessor<Boolean>() {
                @Override
                public Boolean process200Code(HttpResponse response) {
                    return true;
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        } catch (BadCredentialsException ex) {
            return false;
        }
    }

    @Override
    public void unlockUser(@Nonnull String opcoUUid) throws RegistrationProtocolException,
            UserNotFoundException {
        String oktaId = getOktaId(opcoUUid);
        try {
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + oktaId + ProtocolConstants.LIFECYCLE_UNLOCK_PATH_SEGMENT)
                    .build();
            HttpPost post = new HttpPost(uri);
            performRequest(post, new ResponseProcessorWithErrorIgnore<Object>(
                    Sets.newHashSet(ProtocolConstants.E0000032)) {
                @Override
                public Object onSuccessResponse(HttpResponse response) throws IOException {
                    return null;
                }

                @Override
                public Object onErrorIgnoreResponse(String errorCode) {
                    return null;
                }
            });

        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void assignUserToApp(String opcoUUid, String appId) throws OktaProtocolException,
            OktaUserNotFoundException, OktaValidationException {
        try {
            userAssigningCall(opcoUUid, appId, new HttpPut());
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
    }

    public void revokeUserApp(String opcoUUid, String appId) throws OktaProtocolException, IOException,
            OktaUserNotFoundException, OktaValidationException {
        userAssigningCall(opcoUUid, appId, new HttpEntityEnclosingRequestBase() {
            @Override
            public String getMethod() {
                return "DELETE";
            }
        });
    }

    public List<String> listUserApps(String opcoUUid)
            throws OktaProtocolException, IOException, OktaUserNotFoundException, OktaValidationException {
        String oktaId = getOktaId(opcoUUid);
        try {
            HttpGet get = new HttpGet(getBaseBuilder(ProtocolConstants.APPS_PATH_COMPONENT)
                    .setParameter(ProtocolConstants.FILTER_QUERY_PARAM, ProtocolConstants.USER_ID_FILTER_STRING + "\"" + oktaId + "\"")
                    .build());
            return performRequest(get, new StandardResponseProcessor<List<String>>() {
                @Override
                public List<String> process200Code(HttpResponse response)
                        throws IOException, OktaProtocolException, OktaUserNotFoundException {
                    List<String> ret = Lists.newArrayList();
                    ArrayNode node = (ArrayNode) objectMapper.readTree(response.getEntity().getContent());
                    for (JsonNode nn : node) {
                        ret.add(nn.get("id").asText());
                    }

                    return ret;
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean userExists(@Nonnull String login) throws RegistrationProtocolException {
        return checkIfUserExists(login);
    }

    private boolean checkIfUserExists(String login) throws OktaValidationException, OktaProtocolException {
        try {
            getOktaId(login);
            return true;
        } catch (OktaUserNotFoundException ex) {
            return false;
        }
    }

    String getOktaId(String login) throws OktaProtocolException, OktaUserNotFoundException,
            OktaValidationException {
        try {
            URI uri = getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + login).build();
            HttpGet get = new HttpGet(uri);
            return performRequest(get, new StandardResponseProcessor<String>() {
                @Override
                public String process200Code(HttpResponse response) throws IOException, OktaProtocolException, OktaUserNotFoundException {
                    JsonNode jsonNode = objectMapper.readTree(response.getEntity().getContent());
                    return jsonNode.get(ProtocolConstants.ID_FIELD).asText();
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private void userAssigningCall(String opcoUUid, String appId, HttpEntityEnclosingRequestBase method) throws IOException, OktaProtocolException, OktaUserNotFoundException, OktaValidationException {
        String oktaId = getOktaId(opcoUUid);
        try {
            URI uri = getBaseBuilder(ProtocolConstants.APPS_PATH_COMPONENT + appId
                    + "/" + ProtocolConstants.USERS_PATH_COMPONENT + oktaId).build();
            method.setURI(uri);
            method.setEntity(new StringEntity("{}", ContentType.APPLICATION_JSON));
            performRequest(method, new StandardResponseProcessor<Void>() {
                @Override
                public Void process200Code(HttpResponse response) throws IOException, OktaProtocolException,
                        OktaUserNotFoundException {
                    return null;
                }
            });
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void updateCredentails(String opcoUUid, Credentials credentials) throws OktaProtocolException, OktaUserNotFoundException, OktaValidationException {
        String oktaId = getOktaId(opcoUUid);
        ObjectNode node = objectMapper.createObjectNode();
        node.put("credentials", objectMapper.valueToTree(credentials));
        try {
            HttpPut put = new HttpPut(getBaseBuilder(ProtocolConstants.USERS_PATH_COMPONENT + "/" + oktaId).build());
            put.setEntity(new StringEntity(objectMapper.writeValueAsString(node), ContentType.APPLICATION_JSON));
            performRequest(put, new StandardResponseProcessor<Void>() {
                @Override
                public Void process200Code(HttpResponse response) throws IOException,
                        OktaProtocolException, OktaUserNotFoundException {
                    return null;
                }
            });
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
    }

    private <T extends HttpRequestBase> T setBasicOktaHeaders(T request) {
        request.addHeader(HttpHeaders.AUTHORIZATION, "SSWS " + authToken);
        request.addHeader(HttpHeaders.ACCEPT, ContentType.APPLICATION_JSON.getMimeType());
        request.addHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());

        return request;
    }

    private URIBuilder getBaseBuilder(String pathSuffix) {
        return getBaseBuilder()
                .setPath(ProtocolConstants.API_PATH_PREFIX + ProtocolConstants.VERSION_PATH_PREFIX + pathSuffix);
    }

    private <T> T performRequest(HttpRequestBase request, ResponseProcessor<T> processor)
            throws OktaProtocolException, OktaUserNotFoundException, OktaValidationException {
        try {
            setBasicOktaHeaders(request);
            HttpResponse response = getHttpClient().execute(request);
            try {
                return processor.process(response);
            } finally {
                request.releaseConnection();
            }
        } catch (IOException ex) {
            throw new OktaProtocolException(ex);
        }
    }

}
