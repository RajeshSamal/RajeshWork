package com.ntti3.okta.models;

/**
 * @author jan.karwowski@ntti3.com
 */
public class User {
    private Profile profile = new Profile();
    private Credentials credentials = new Credentials();

    public void copyGenericUserData(com.ntti3.gums.register.models.User user) {
        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setEmail(user.getEmail());
        setLogin(user.getLogin());
        setMobilePhone(user.getMobilePhone());
        if (user.getPassword() != null)
            setPassword(user.getPassword());
        if (user.getRecoveryQuestion() != null)
            setRecoveryQuestion(user.getRecoveryQuestion());
        if (user.getRecoveryAnswer() != null)
            setRecoveryAnswer(user.getRecoveryAnswer());
    }

    public void setFirstName(String firstName) {
        profile.setFirstName(firstName);
    }

    public void setLastName(String lastName) {
        profile.setLastName(lastName);
    }

    public void setEmail(String email) {
        profile.setEmail(email);
    }

    public void setLogin(String login) {
        profile.setLogin(login);
    }

    public void setMobilePhone(String mobilePhone) {
        profile.setMobilePhone(mobilePhone);
    }

    public void setPassword(String password) {
        if (credentials.getPassword() == null)
            credentials.setPassword(new Password());
        credentials.getPassword().setValue(password);
    }

    public void setRecoveryQuestion(String question) {
        if (credentials.getRecoveryQuestion() == null)
            credentials.setRecoveryQuestion(new RecoveryQuestion());
        credentials.getRecoveryQuestion().setQuestion(question);
    }

    public void setRecoveryAnswer(String answer) {
        if (credentials.getRecoveryQuestion() == null)
            credentials.setRecoveryQuestion(new RecoveryQuestion());
        credentials.getRecoveryQuestion().setAnswer(answer);
    }

    public Profile getProfile() {
        return profile;
    }

    public Credentials getCredentials() {
        return credentials;
    }
}
