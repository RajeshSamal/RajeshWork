package com.ntti3.okta.models;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Credentials {
    private Password password;
    @JsonProperty("recovery_question")
    private RecoveryQuestion recoveryQuestion;

    public Password getPassword() {
        return password;
    }

    public void setPassword(Password password) {
        this.password = password;
    }

    public RecoveryQuestion getRecoveryQuestion() {
        return recoveryQuestion;
    }

    public void setRecoveryQuestion(RecoveryQuestion recoveryQuestion) {
        this.recoveryQuestion = recoveryQuestion;
    }
}
