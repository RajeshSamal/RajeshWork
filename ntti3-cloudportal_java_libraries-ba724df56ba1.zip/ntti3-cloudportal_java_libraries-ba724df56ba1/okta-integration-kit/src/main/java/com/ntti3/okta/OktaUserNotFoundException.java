package com.ntti3.okta;

import com.ntti3.gums.register.exceptions.UserNotFoundException;
import com.ntti3.okta.models.ErrorResponse;

/**
 * @author jan.karwowski@ntti3.com
 */
public class OktaUserNotFoundException extends UserNotFoundException {
    private final ErrorResponse val;

    public OktaUserNotFoundException() {
        val=null;
    }

    public OktaUserNotFoundException(ErrorResponse val) {
        super(val.getErrorCode()+" "+val.getErrorSummary()+val.getErrorCauses());
        this.val=val;
    }
}
