package com.ntti3.billings.api.client;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Aspect
public class LoggingAspect extends com.ntti3.connectors.aspects.LoggingAspect {

    @Pointcut("execution(public * com.ntti3.billings.api.client.ApiClient+.*(..))")
    public void publicMethodPointcut() {

    }
}
