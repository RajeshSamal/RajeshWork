package com.ntti3.billings.api.client.guice;

import com.ntti3.billings.api.client.ApiClient;
import com.ntti3.billings.api.client.DefaultApiClient;
import com.ntti3.billings.api.client.guice.annotations.ApiVersion;
import com.ntti3.billings.api.client.guice.annotations.BillingsAddress;
import com.ntti3.billings.api.client.guice.annotations.BillingsXAccelRedirectUri;
import com.google.inject.PrivateModule;

import java.net.URI;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultApiClientModule extends PrivateModule {

    private final URI billingsAddress;
    private final String billingsXAccelRedirectUri;
    private final int apiVersion;

    public DefaultApiClientModule(URI billingsAddress, String billingsXAccelRedirectUri, int apiVersion) {
        this.billingsAddress = billingsAddress;
        this.billingsXAccelRedirectUri = billingsXAccelRedirectUri;
        this.apiVersion = apiVersion;
    }

    @Override
    protected void configure() {
        bind(URI.class).annotatedWith(BillingsAddress.class).toInstance(billingsAddress);
        bindConstant().annotatedWith(BillingsXAccelRedirectUri.class).to(billingsXAccelRedirectUri);
        bindConstant().annotatedWith(ApiVersion.class).to(apiVersion);
        bind(ApiClient.class).to(DefaultApiClient.class);
        expose(ApiClient.class);
    }

    @Override
    public int hashCode() {
        return DefaultApiClientModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultApiClientModule.class.equals(obj.getClass());
    }
}
