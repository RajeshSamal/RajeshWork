package com.ntti3.billings.api.client.guice.annotations;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

import com.google.inject.BindingAnnotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@BindingAnnotation
public @interface BillingsAddress {
}
