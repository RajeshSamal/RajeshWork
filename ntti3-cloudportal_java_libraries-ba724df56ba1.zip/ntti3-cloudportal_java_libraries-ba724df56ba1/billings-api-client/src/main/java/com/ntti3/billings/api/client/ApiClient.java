package com.ntti3.billings.api.client;

import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;

import java.util.Collection;

/**
 * Billing And Metering Module API Client
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface ApiClient {
    /**
     * Returns Uri to be used in x-accel-redirect for Customer Summary for Operating Company,
     * Service, year and month.
     * @param customerOpcoUid Unique identifier of Operating Company.
     * @param serviceUid Unique identifier of Service.
     * @param yearAndMonth Year and month of the summary.
     * @return Uri to be used in x-accel-redirect.
     */
    String getCustomerSummaryXAccelRedirectUri(OpcoUid customerOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth);

    /**
     * Returns Uri to be used in x-accel-redirect for Service Provider Summary for Operating Company,
     * Service, year and month.
     * @param serviceOpcoUid Unique identifier of Operating Company.
     * @param serviceUid Unique identifier of Service.
     * @param yearAndMonth Year and month of the summary.
     * @return Uri to be used in x-accel-redirect.
     */
    String getServiceProviderSummaryXAccelRedirectUri(OpcoUid serviceOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth);

    /**
     * Returns Uri to be used in x-accel-redirect for Overall Summary for Service, year and month.
     * @param serviceUid Unique identifier of Service.
     * @param yearAndMonth Year and month of the summary.
     * @return Uri to be used in x-accel-redirect.
     */
    String getOverallSummaryXAccelRedirectUri(ServiceUid serviceUid, YearAndMonth yearAndMonth);

    /**
     * Returns download statuses of Usage Reports.
     * @param yearAndMonth Year and month of to get statuses for.
     * @return UsageReportDownloadStatuses for the specified year and month.
     * @throws ApiClientException if could not connect to Billing And Metering Module or could not parse
     * the answer.
     */
    Collection<UsageReportDownloadStatus> getDownloadStatuses(YearAndMonth yearAndMonth) throws ApiClientException;
}
