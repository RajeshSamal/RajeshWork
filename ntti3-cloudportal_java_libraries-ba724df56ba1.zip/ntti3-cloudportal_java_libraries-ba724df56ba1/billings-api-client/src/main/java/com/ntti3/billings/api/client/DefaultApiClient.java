package com.ntti3.billings.api.client;

import com.ntti3.billings.api.client.guice.annotations.ApiVersion;
import com.ntti3.billings.api.client.guice.annotations.BillingsAddress;
import com.ntti3.billings.api.client.guice.annotations.BillingsXAccelRedirectUri;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.DownloadStatusesResponse;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import com.ntti3.connectors.BaseConnector;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.inject.Inject;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultApiClient extends BaseConnector implements ApiClient {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static final String API_VERSION_STRING = "api_version";
    public static final String CUSTOMER_SUMMARY = "customer_summary";
    public static final String SERVICE_PROVIDER_SUMMARY = "service_provider_summary";
    public static final String OVERALL_SUMMARY = "overall_summary";
    public static final String DOWNLOAD_STATUSES = "download_statuses";
    private static final Logger logger = LoggerFactory.getLogger(DefaultApiClient.class);

    private final String billingsXAccelRedirectUri;
    private final String apiVersion;

    @Inject
    public DefaultApiClient(@BillingsAddress URI billingsAddress,
                            @BillingsXAccelRedirectUri String billingsXAccelRedirectUri,
                            @ApiVersion int apiVersion) {
        super(billingsAddress, null);
        this.billingsXAccelRedirectUri = billingsXAccelRedirectUri;
        this.apiVersion = Integer.toString(apiVersion);
    }

    @Override
    public String getCustomerSummaryXAccelRedirectUri(OpcoUid customerOpcoUid,
                                                      ServiceUid serviceUid,
                                                      YearAndMonth yearAndMonth) {
        String path = String.format("%s/%s/%s/%s/%d/%d",
                billingsXAccelRedirectUri, CUSTOMER_SUMMARY,
                customerOpcoUid.toString(), serviceUid.getTextRepresentation(),
                yearAndMonth.getYear(), yearAndMonth.getMonth());
        return getUriFromPath(path);
    }

    @Override
    public String getServiceProviderSummaryXAccelRedirectUri(OpcoUid serviceOpcoUid,
                                                             ServiceUid serviceUid,
                                                             YearAndMonth yearAndMonth) {
        String path = String.format("%s/%s/%s/%s/%d/%d",
                billingsXAccelRedirectUri, SERVICE_PROVIDER_SUMMARY,
                serviceOpcoUid.toString(), serviceUid.getTextRepresentation(),
                yearAndMonth.getYear(), yearAndMonth.getMonth());
        return getUriFromPath(path);
    }

    @Override
    public String getOverallSummaryXAccelRedirectUri(ServiceUid serviceUid,
                                                     YearAndMonth yearAndMonth) {
        String path = String.format("%s/%s/%s/%d/%d",
                billingsXAccelRedirectUri, OVERALL_SUMMARY,
                serviceUid.getTextRepresentation(),yearAndMonth.getYear(),
                yearAndMonth.getMonth());
        return getUriFromPath(path);
    }

    @Override
    public Collection<UsageReportDownloadStatus> getDownloadStatuses(YearAndMonth yearAndMonth) throws ApiClientException {
        String statusesPath = String.format("/%s/%d/%d", DOWNLOAD_STATUSES, yearAndMonth.getYear(), yearAndMonth.getMonth());
        return performRequest(statusesPath, new HttpGet(), new ResponseProcessor<Collection<UsageReportDownloadStatus>>() {
            @Override
            public Collection<UsageReportDownloadStatus> process(HttpResponse response) throws ApiClientException, IOException {
                checkNotNull("Malformed HTTP response (empty status line)", response.getStatusLine());
                switch (response.getStatusLine().getStatusCode()) {
                    case 200:
                        checkNotNull("Malformed HTTP response (no entity)", response.getEntity());
                        checkNotNull("Malformed HTTP response (no content)", response.getEntity().getContent());
                        return parseDownloadStatusesResponse(response.getEntity().getContent());
                    default:
                        throw new ApiClientException("Request returned status: " + response.getStatusLine().getStatusCode());
                }
            }
        });
    }

    private <T> T performRequest(String path, HttpRequestBase request, ResponseProcessor<T> processor)
            throws ApiClientException {
        try {
            request.setURI(getBaseBuilder().setPath(path).build());

            return performRequest(request, processor);
        } catch (URISyntaxException ex) {
            throw new RuntimeException(ex);
        } catch (IOException e) {
            throw new ApiClientException("IOException during API call", e);
        }
    }

    private void checkNotNull(String messageOnNull, Object object) throws ApiClientException {
        if (object == null) {
            throw new ApiClientException(messageOnNull);
        }
    }

    private <T> T performRequest(HttpRequestBase request, ResponseProcessor<T> processor)
            throws IOException, ApiClientException {
        HttpResponse response = getHttpClient().execute(request);
        try {
            return processor.process(response);
        } finally {
            request.releaseConnection();
        }
    }

    protected static interface ResponseProcessor<T> {
        public T process(HttpResponse response) throws ApiClientException, IOException;
    }

    private String getUriFromPath(String path) {
        URIBuilder uriBuilder = new URIBuilder();
        try {
            return uriBuilder.setPath(path)
                    .addParameter(API_VERSION_STRING, apiVersion)
                    .build().toString();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private static Collection<UsageReportDownloadStatus> parseDownloadStatusesResponse(InputStream inputStream) throws ApiClientException {
        final DownloadStatusesResponse downloadStatusesResponse;
        try {
            downloadStatusesResponse = objectMapper.readValue(inputStream, DownloadStatusesResponse.class);
            return downloadStatusesResponse.getDownloadStatuses();
        } catch (JsonMappingException | JsonParseException e) {
            throw new ApiClientException("Could not parse answer from Billings Module", e);
        } catch (IOException e) {
            throw new ApiClientException("IO exception during reading Billings Module response", e);
        } finally {
            safeClose(inputStream);
        }
    }

    private static void safeClose(Closeable closeable) {
        try {
            closeable.close();
        } catch (IOException e) {
            logger.warn("IO exception during close", e);
        }
    }
}
