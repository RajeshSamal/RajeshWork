package com.ntti3.billings.api.client;

import com.ntti3.billings.api.client.guice.DefaultApiClientModule;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.google.common.collect.Sets;
import com.google.inject.Guice;
import com.google.inject.Injector;
import org.joda.time.DateTime;
import org.junit.Rule;
import org.junit.Test;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Set;

import static org.junit.Assert.assertEquals;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultApiClientTest {


    public static final OpcoUid NTTI_3 = OpcoUid.fromString("ntti3");
    public static final OpcoUid CL = OpcoUid.fromString("cl");
    public static final int YEAR = 2014;
    public static final int MONTH = 12;
    public static final String DOMAIN = "localhost";
    public static final Integer PORT = 9000;
    public static final String BILLING_AND_METERING_MODULE_ADDRESS = "http://" + DOMAIN + ":" + PORT.toString() + "/";
    public static final String BILLING_AND_METERING_MODULE_XACCEL = DOMAIN + ":" + PORT.toString();
    public static final int API_VERSION = 1;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(PORT);

    private final Injector injector;
    public DefaultApiClientTest() throws URISyntaxException {
        URI uri = new URI(BILLING_AND_METERING_MODULE_ADDRESS);
        injector = Guice.createInjector(new DefaultApiClientModule(uri,
                BILLING_AND_METERING_MODULE_XACCEL, 1));
    }

    @Test
    public void testGetCustomerSummaryXAccelRedirectUri() throws Exception {
        ApiClient apiClient = injector.getInstance(ApiClient.class);

        String uri = apiClient.getCustomerSummaryXAccelRedirectUri(
                OpcoUid.fromString("opcouid"),
                ServiceUid.MGR,
                YearAndMonth.fromInts(2012, MONTH));

        String expectedUri = String.format("%s/customer_summary/opcouid/MGR/2012/12?api_version=%d",
                BILLING_AND_METERING_MODULE_XACCEL,
                API_VERSION);

        assertEquals(expectedUri, uri);
    }

    @Test
    public void testGetServiceProviderSummaryXAccelRedirectUri() throws Exception {
        ApiClient apiClient = injector.getInstance(ApiClient.class);

        String uri = apiClient.getServiceProviderSummaryXAccelRedirectUri(
                OpcoUid.fromString("opcouid"),
                ServiceUid.MGR,
                YearAndMonth.fromInts(2012, MONTH));

        String expectedUri = String.format("%s/service_provider_summary/opcouid/MGR/2012/12?api_version=%d",
                BILLING_AND_METERING_MODULE_XACCEL,
                API_VERSION);

        assertEquals(expectedUri, uri);
    }

    @Test
    public void testGetOverallSummaryXAccelRedirectUri() throws Exception {
        ApiClient apiClient = injector.getInstance(ApiClient.class);

        String uri = apiClient.getOverallSummaryXAccelRedirectUri(
                ServiceUid.MGR,
                YearAndMonth.fromInts(2012, MONTH));

        String expectedUri = String.format("%s/overall_summary/MGR/2012/12?api_version=%d",
                BILLING_AND_METERING_MODULE_XACCEL,
                API_VERSION);

        assertEquals(expectedUri, uri);
    }

    @Test
    public void testGetDownloadStatuses() throws IOException, ApiClientException, URISyntaxException {
        DateTime downloadTime = DateTime.parse("2014-02-18T13:07:56.000+01:00");

        String bmmResponse = "{\"download_statuses\":[" +
                "{\"opco_uid\":\"ntti3\",\"service_uid\":\"DVP\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"service_provider_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"cl\",\"service_uid\":\"MGR\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"service_provider_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"cl\",\"service_uid\":\"MGR\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"customer_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"ntti3\",\"service_uid\":\"MGR\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"customer_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"cl\",\"service_uid\":\"DVP\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"customer_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"ntti3\",\"service_uid\":\"PLN\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"customer_summary\",\"status\":\"pending\"}," +

                " {\"opco_uid\":\"cl\",\"service_uid\":\"PLN\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"download_time\":\"" + downloadTime.toString() + "\"," +
                "\"report_type\":\"service_provider_summary\",\"status\":\"ok\"}," +

                " {\"opco_uid\":\"ntti3\",\"service_uid\":\"PLN\",\"year\":" + YEAR + ",\"month\":" + MONTH + "," +
                "\"report_type\":\"service_provider_summary\",\"status\":\"pending\"}]}";


        final String format = String.format("/%s/%d/%d", DefaultApiClient.DOWNLOAD_STATUSES, YEAR, MONTH);
        stubFor(get(urlEqualTo(format))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(bmmResponse)));

        ApiClient apiClient = injector.getInstance(ApiClient.class);

        Collection<UsageReportDownloadStatus> usageReportDownloadStatusCollection
                = apiClient.getDownloadStatuses(YearAndMonth.fromInts(YEAR, MONTH));

        Set<UsageReportDownloadStatus> expectedUsageReportDownloadStatuses = Sets.newHashSet(
                UsageReportDownloadStatus.pending(NTTI_3, ServiceUid.MGR, YEAR, MONTH, ReportType.CS),
                UsageReportDownloadStatus.pending(NTTI_3, ServiceUid.PLN, YEAR, MONTH, ReportType.CS),
                UsageReportDownloadStatus.pending(NTTI_3, ServiceUid.PLN, YEAR, MONTH, ReportType.SPS),
                UsageReportDownloadStatus.pending(NTTI_3, ServiceUid.DVP, YEAR, MONTH, ReportType.SPS),

                UsageReportDownloadStatus.pending(CL, ServiceUid.DVP, YEAR, MONTH, ReportType.CS),
                UsageReportDownloadStatus.pending(CL, ServiceUid.MGR, YEAR, MONTH, ReportType.CS),
                UsageReportDownloadStatus.downloaded(CL, ServiceUid.PLN, YEAR, MONTH, downloadTime, ReportType.SPS),
                UsageReportDownloadStatus.pending(CL, ServiceUid.MGR, YEAR, MONTH, ReportType.SPS)
        );

        assertEquals(Sets.newHashSet(usageReportDownloadStatusCollection), expectedUsageReportDownloadStatuses);
    }

    @Test(expected = ApiClientException.class)
    public void testGetDownloadStatusesIncorrectData() throws ApiClientException, IOException, URISyntaxException {

        String bmmResponse = "{\"download_statuses\":[" +
                "{\"opco_uid\":\"ntti3\",\"service_uid\":\"ML\",\"year\":2014,\"month\":2," +
                "\"repown\"},\"}]}";

        stubFor(get(urlEqualTo(String.format("/%s/%d/%d", DefaultApiClient.DOWNLOAD_STATUSES, YEAR, MONTH)))
                .withHeader("Accept", equalTo("text/xml"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "text/xml")
                        .withBody(bmmResponse)));

        ApiClient apiClient = injector.getInstance(ApiClient.class);
        apiClient.getDownloadStatuses(YearAndMonth.fromInts(YEAR, MONTH));
    }
}
