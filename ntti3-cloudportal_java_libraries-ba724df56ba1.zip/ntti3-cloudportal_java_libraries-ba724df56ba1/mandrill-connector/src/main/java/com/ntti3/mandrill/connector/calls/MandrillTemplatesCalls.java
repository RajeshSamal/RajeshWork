package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.RenderResponse;
import com.ntti3.mandrill.connector.responses.TemplateResponse;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public interface MandrillTemplatesCalls {
    public TemplateResponse add(Template template) throws IOException, ErrorResponseException;
    public TemplateResponse update(Template template) throws IOException, ErrorResponseException;
    public TemplateResponse info(String name) throws IOException, ErrorResponseException;
    public TemplateResponse publish(String name) throws IOException, ErrorResponseException;
    public TemplateResponse delete(String name) throws IOException, ErrorResponseException;
    public List<TemplateResponse> list(String label) throws IOException, ErrorResponseException;
    public RenderResponse render(String name, List<NameContentElement> templateContent, List<NameContentElement> mergeVariables) throws IOException, ErrorResponseException;
}
