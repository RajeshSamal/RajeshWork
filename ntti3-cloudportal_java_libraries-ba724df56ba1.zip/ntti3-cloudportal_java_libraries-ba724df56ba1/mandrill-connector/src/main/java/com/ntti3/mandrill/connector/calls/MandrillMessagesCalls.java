package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.models.Message;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.responses.MessageContentResponse;
import com.ntti3.mandrill.connector.responses.MessageInfoResponse;
import com.ntti3.mandrill.connector.responses.SendResponse;

import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public interface MandrillMessagesCalls {
    List<SendResponse> send(Message message, Boolean async, String ipPool, Date sendAt) throws ErrorResponseException, IOException;

    List<SendResponse> send(Message message, Boolean async) throws ErrorResponseException, IOException;

    List<SendResponse> send_template(String templateName, List<NameContentElement> templateContent, Message message, Boolean async, String ipPool, Date sendAt)  throws ErrorResponseException, IOException;

    List<SendResponse> send_template(String templateName, List<NameContentElement> templateContent, Message message, Boolean async) throws ErrorResponseException, IOException;

    List<MessageInfoResponse> search(String query, Date from, Date to, List<String> tags, List<String> senders, List<String> apiKeys, int limit) throws IOException, ErrorResponseException;

    MessageInfoResponse info(String id) throws IOException, ErrorResponseException;

    MessageContentResponse content(String id) throws IOException, ErrorResponseException;
}
