package com.ntti3.mandrill.connector.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class Attachment {

    private String type;
    private String name;
    private String content;

    @JsonCreator
    public Attachment(
            @JsonProperty(value = ApiConstants.TYPE) String type,
            @JsonProperty(value = ApiConstants.NAME) String name,
            @JsonProperty(value = ApiConstants.CONTENT) String content
    ) {
        this.type = type;
        this.name = name;
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }
}
