package com.ntti3.mandrill.connector.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class Message {
    @JsonProperty(value = ApiConstants.HTML, required = true)
    private String html;
    @JsonProperty(value = ApiConstants.TEXT, required = true)
    private String text;
    @JsonProperty(value = ApiConstants.SUBJECT, required = true)
    private String subject;
    @JsonProperty(value = ApiConstants.FROM_EMAIL, required = true)
    private String fromEmail;
    @JsonProperty(value = ApiConstants.FROM_NAME, required = true)
    private String fromName;
    @JsonProperty(value = ApiConstants.TO, required = true)
    private List<Recipient> to;
    @JsonProperty(value = ApiConstants.HEADERS, required = true)
    private Map<String,String> headers;
    @JsonProperty(value = ApiConstants.IMPORTANT, required = true)
    private boolean important;
    @JsonProperty(value = ApiConstants.TRACK_OPENS, required = true)
    private Boolean trackOpens;
    @JsonProperty(value = ApiConstants.TRACK_CLICKS, required = true)
    private Boolean trackClicks;
    @JsonProperty(value = ApiConstants.AUTO_TEXT, required = true)
    private Boolean autoText;
    @JsonProperty(value = ApiConstants.AUTO_HTML, required = true)
    private Boolean autoHtml;
    @JsonProperty(value = ApiConstants.INLINE_CSS, required = true)
    private Boolean inlineCss;
    @JsonProperty(value = ApiConstants.USE_STRIP_QS, required = true)
    private Boolean urlStripQs;
    @JsonProperty(value = ApiConstants.PRESERVE_RECIPIENTS, required = true)
    private Boolean preserveRecipients;
    @JsonProperty(value = ApiConstants.VIEW_CONTENT_LINK, required = true)
    private Boolean viewContentLink;
    @JsonProperty(value = ApiConstants.BCC_ADDRESS, required = true)
    private String bccAddress;
    @JsonProperty(value = ApiConstants.SIGNING_DOMAIN, required = true)
    private String signingDomain;
    @JsonProperty(value = ApiConstants.RETURN_PATH_DOMAIN, required = true)
    private String returnPathDomain;
    @JsonProperty(value = ApiConstants.MERGE, required = true)
    private boolean merge;
    @JsonProperty(value = ApiConstants.GLOBAL_MERGE_VARS, required = true)
    private List<NameContentElement> globalMergeVars;
    @JsonProperty(value = ApiConstants.MERGE_VARS, required = true)
    private List<RecipientMergeVariables> mergeVars;
    @JsonProperty(value = ApiConstants.TAGS, required = true)
    private List<String> tags;
    @JsonProperty(value = ApiConstants.SUBACCOUNT, required = true)
    private String subaccount;
    @JsonProperty(value = ApiConstants.GOOGLE_ANALYTICS_DOMAIN, required = true)
    private List<String> googleAnalyticsDomains;
    @JsonProperty(value = ApiConstants.GOOGLE_ANALYTICS_CAMPAIGN, required = true)
    private List<String> googleAnalyticsCampaign;
    @JsonProperty(value = ApiConstants.METADATA, required = true)
    private Map<String, String> metadata;
    @JsonProperty(value = ApiConstants.RECIPIENT_METADATA, required = true)
    private List<RecipientMetadata> recipientMetadata;
    @JsonProperty(value = ApiConstants.ATTACHMENTS, required = true)
    private List<Attachment> attachments;
    @JsonProperty(value = ApiConstants.IMAGES, required = true)
    private List<Attachment> images;

    public Message() {
        to = new ArrayList<>();
        headers = new HashMap<>();
        globalMergeVars = new ArrayList<>();
        mergeVars = new ArrayList<>();
        tags = new ArrayList<>();
        googleAnalyticsDomains = new ArrayList<>();
        googleAnalyticsCampaign = new ArrayList<>();
        metadata = new HashMap<>();
        recipientMetadata = new ArrayList<>();
        attachments = new ArrayList<>();
        images = new ArrayList<>();
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    public void addTo(Recipient recipient) {
       to.add(recipient);
    }

    public List<Recipient> getTo() {
        return Collections.unmodifiableList(to);
    }

    public boolean isImportant() {
        return important;
    }

    public void setImportant(boolean important) {
        this.important = important;
    }

    public Boolean isTrackOpens() {
        return trackOpens;
    }

    public void setTrackOpens(Boolean trackOpens) {
        this.trackOpens = trackOpens;
    }

    public Boolean isTrackClicks() {
        return trackClicks;
    }

    public void setTrackClicks(Boolean trackClicks) {
        this.trackClicks = trackClicks;
    }

    public Boolean isAutoText() {
        return autoText;
    }

    public void setAutoText(Boolean autoText) {
        this.autoText = autoText;
    }

    public Boolean isAutoHtml() {
        return autoHtml;
    }

    public void setAutoHtml(Boolean autoHtml) {
        this.autoHtml = autoHtml;
    }

    public Boolean isInlineCss() {
        return inlineCss;
    }

    public void setInlineCss(Boolean inlineCss) {
        this.inlineCss = inlineCss;
    }

    public Boolean isUrlStripQs() {
        return urlStripQs;
    }

    public void setUrlStripQs(Boolean urlStripQs) {
        this.urlStripQs = urlStripQs;
    }

    public Boolean isPreserveRecipients() {
        return preserveRecipients;
    }

    public void setPreserveRecipients(Boolean preserveRecipients) {
        this.preserveRecipients = preserveRecipients;
    }

    public String getBccAddress() {
        return bccAddress;
    }

    public void setBccAddress(String bccAddress) {
        this.bccAddress = bccAddress;
    }

    public Boolean isViewContentLink() {
        return viewContentLink;
    }

    public void setViewContentLink(Boolean viewContentLink) {
        this.viewContentLink = viewContentLink;
    }

    public String getSigningDomain() {
        return signingDomain;
    }

    public void setSigningDomain(String signingDomain) {
        this.signingDomain = signingDomain;
    }

    public String getReturnPathDomain() {
        return returnPathDomain;
    }

    public void setReturnPathDomain(String returnPathDomain) {
        this.returnPathDomain = returnPathDomain;
    }

    public boolean isMerge() {
        return merge;
    }

    public void setMerge(boolean merge) {
        this.merge = merge;
    }

    public String getSubaccount() {
        return subaccount;
    }

    public void setSubaccount(String subaccount) {
        this.subaccount = subaccount;
    }

    public Map<String, String> getHeaders() {
        return Collections.unmodifiableMap(headers);
    }

    public void addHeader(String name, String content) {
        headers.put(name, content);
    }

    public List<NameContentElement> getGlobalMergeVars() {
        return Collections.unmodifiableList(globalMergeVars);
    }

    public void addGlobalMergeVar(NameContentElement var) {
        globalMergeVars.add(var);
    }

    public List<RecipientMergeVariables> getMergeVars() {
        return Collections.unmodifiableList(mergeVars);
    }

    public void addRecipientMergeVar(RecipientMergeVariables var) {
        mergeVars.add(var);
    }

    public List<String> getTags() {
        return Collections.unmodifiableList(tags);
    }

    public void addTag(String tag) {
        tags.add(tag);
    }

    public List<String> getGoogleAnalyticsDomains() {
        return Collections.unmodifiableList(googleAnalyticsDomains);
    }

    public void addGoogleAnalyticsDomain(String domain) {
        googleAnalyticsDomains.add(domain);
    }

    public List<String> getGoogleAnalyticsCampaign() {
        return Collections.unmodifiableList(googleAnalyticsCampaign);
    }

    public void addGoogleAnalyticsCampaign(String campaign) {
        googleAnalyticsCampaign.add(campaign);
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void addMetaData(String key, String value) {
        metadata.put(key, value);
    }

    public List<RecipientMetadata> getRecipientMetadata() {
        return Collections.unmodifiableList(recipientMetadata);
    }

    public void addRecipientMetadata(RecipientMetadata metadata) {
        recipientMetadata.add(metadata);
    }

    public List<Attachment> getAttachments() {
        return Collections.unmodifiableList(attachments);
    }

    public void addAttachment(Attachment attachment) {
        attachments.add(attachment);
    }

    public List<Attachment> getImages() {
        return Collections.unmodifiableList(images);
    }

    public void addImage(Attachment image) {
        if(!image.getType().startsWith(ApiConstants.IMAGE_MIME_PREFIX)) {
            throw new IllegalArgumentException("Image mime type must start with \"" + ApiConstants.IMAGE_MIME_PREFIX + "\"");
        }
        images.add(image);
    }
}
