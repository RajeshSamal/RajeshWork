package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.calls.DefaultMandrillMessagesCalls;
import com.ntti3.mandrill.connector.calls.DefaultMandrillTagsCalls;
import com.ntti3.mandrill.connector.calls.DefaultMandrillTemplatesCalls;
import com.ntti3.mandrill.connector.calls.DefaultMandrillUsersCalls;
import com.ntti3.mandrill.connector.calls.DefaultUrlsCalls;
import com.ntti3.mandrill.connector.calls.MandrillMessagesCalls;
import com.ntti3.mandrill.connector.calls.MandrillTagsCalls;
import com.ntti3.mandrill.connector.calls.MandrillTemplatesCalls;
import com.ntti3.mandrill.connector.calls.MandrillUrlsCalls;
import com.ntti3.mandrill.connector.calls.MandrillUsersCalls;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class DefaultMandrillConnector implements MandrillConnector {
    private static final String URL = "https://mandrillapp.com/api/1.0/";

    private final String apiKey;
    private final MandrillMessagesCalls messages;
    private final MandrillTemplatesCalls templates;
    private final MandrillUsersCalls users;
    private final MandrillUrlsCalls urls;
    private final MandrillTagsCalls tags;

    public DefaultMandrillConnector(String apiKey) {
        this.apiKey = apiKey;
        messages = new DefaultMandrillMessagesCalls(URL, this.apiKey);
        templates = new DefaultMandrillTemplatesCalls(URL, this.apiKey);
        users = new DefaultMandrillUsersCalls(URL, this.apiKey);
        urls = new DefaultUrlsCalls(URL, this.apiKey);
        tags = new DefaultMandrillTagsCalls(URL, this.apiKey);
    }

    public String getApiKey() {
        return apiKey;
    }

    @Override
    public MandrillMessagesCalls getMessagesCalls() {
        return messages;
    }

    @Override
    public MandrillTemplatesCalls getTemplatesCalls() {
        return templates;
    }

    @Override
    public MandrillUsersCalls getUsersCalls() {
        return users;
    }

    @Override
    public MandrillUrlsCalls getUrlsCalls() {
        return urls;
    }

    @Override
    public MandrillTagsCalls getTagsCalls() {
        return tags;
    }
}