package com.ntti3.mandrill.connector.exceptions;

import com.ntti3.mandrill.connector.responses.ErrorResponse;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class ErrorResponseException extends Exception {

    private String status;
    private int code;
    private String name;

    public ErrorResponseException(int code, String status, String name, String message) {
        super(message);
        this.status = status;
        this.code = code;
        this.name = name;
    }

    public ErrorResponseException(ErrorResponse response) {
        super(response.getMessage());
        this.status = response.getStatus();
        this.code = response.getCode();
        this.name = response.getName();
    }

    public String getStatus() {
        return status;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
