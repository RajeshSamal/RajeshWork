package com.ntti3.mandrill.connector.responses.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class OpensDetail {
    private long timestamp;
    private String ip;
    private String location;
    private String userAgent;

    @JsonCreator
    public OpensDetail(
            @JsonProperty(value = ApiConstants.TS) long timestamp,
            @JsonProperty(value = ApiConstants.IP) String ip,
            @JsonProperty(value = ApiConstants.LOCATION) String location,
            @JsonProperty(value = ApiConstants.UA) String userAgent) {
        this.timestamp = timestamp;
        this.ip = ip;
        this.location = location;
        this.userAgent = userAgent;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getIp() {
        return ip;
    }

    public String getLocation() {
        return location;
    }

    public String getUserAgent() {
        return userAgent;
    }
}
