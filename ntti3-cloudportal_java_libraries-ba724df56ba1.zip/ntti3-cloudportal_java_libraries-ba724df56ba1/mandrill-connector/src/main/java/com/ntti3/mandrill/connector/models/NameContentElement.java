package com.ntti3.mandrill.connector.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class NameContentElement {
    @JsonProperty(value = ApiConstants.NAME, required = true)
    private String name;
    @JsonProperty(value = ApiConstants.CONTENT, required = true)
    private String content;

    public NameContentElement(String name, String content) {
        this.name = name;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }
}
