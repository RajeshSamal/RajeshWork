package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.responses.models.Statistics;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.Date;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class UserInfoResponse {
    private String username;
    private Date createdAt;
    private String publicId;
    private int reputation;
    private int hourlyQuota;
    private int backlog;
    private Map<String,Statistics> statistics;

    @JsonCreator
    public UserInfoResponse(
            @JsonProperty(value = ApiConstants.USERNAME) String username,
            @JsonProperty(value = ApiConstants.CREATED_AT) Date createdAt,
            @JsonProperty(value = ApiConstants.PUBLIC_ID) String publicId,
            @JsonProperty(value = ApiConstants.REPUTATION) int reputation,
            @JsonProperty(value = ApiConstants.HOURLY_QUOTA) int hourlyQuota,
            @JsonProperty(value = ApiConstants.BACKLOG) int backlog,
            @JsonProperty(value = ApiConstants.STATS) Map<String, Statistics> statistics
    ) {
        this.username = username;
        this.createdAt = createdAt;
        this.publicId = publicId;
        this.reputation = reputation;
        this.hourlyQuota = hourlyQuota;
        this.backlog = backlog;
        if(statistics==null) {
            statistics = Collections.emptyMap();
        }
        this.statistics = Collections.unmodifiableMap(statistics);
    }

    public String getUsername() {
        return username;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public String getPublicId() {
        return publicId;
    }

    public int getReputation() {
        return reputation;
    }

    public int getHourlyQuota() {
        return hourlyQuota;
    }

    public int getBacklog() {
        return backlog;
    }

    public Map<String, Statistics> getStatistics() {
        return statistics;
    }
}
