package com.ntti3.mandrill.connector;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class MandrillConnectorFactory {
    public MandrillConnector makeMandrillConnector(String apiKey) {
        return new DefaultMandrillConnector(apiKey);
    }
}
