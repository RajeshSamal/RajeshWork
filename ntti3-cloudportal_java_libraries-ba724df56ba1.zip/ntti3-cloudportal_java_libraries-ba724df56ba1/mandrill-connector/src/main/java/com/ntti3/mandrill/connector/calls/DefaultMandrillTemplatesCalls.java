package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.RenderResponse;
import com.ntti3.mandrill.connector.responses.TemplateResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class DefaultMandrillTemplatesCalls extends AbstractCall implements MandrillTemplatesCalls {
    private static final String TEMPLATES = "templates";

    private static final String METHOD_ADD = "add";
    private static final String METHOD_INFO = "info";
    private static final String METHOD_UPDATE = "update";
    private static final String METHOD_PUBLISH = "publish";
    private static final String METHOD_DELETE = "delete";
    private static final String METHOD_LIST = "list";
    private static final String METHOD_RENDER = "render";

    private Map<String,Object> prepareNameParam(String name) {
        Map<String, Object> params = new HashMap<>();
        params.put(ApiConstants.NAME, name);
        return params;
    }

    private Map<String,Object> templateToMap(Template template) {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.NAME, template.getName());
        params.put(ApiConstants.FROM_EMAIL, template.getFromEmail());
        params.put(ApiConstants.FROM_NAME, template.getFromEmail());
        params.put(ApiConstants.SUBJECT, template.getSubject());
        params.put(ApiConstants.CODE, template.getCode());
        params.put(ApiConstants.TEXT, template.getText());
        params.put(ApiConstants.PUBLISH, template.isPublish());
        params.put(ApiConstants.LABELS, template.getLabels());
        return params;
    }

    public DefaultMandrillTemplatesCalls(String url, String apiKey) {
        super(url, apiKey);
    }

    @Override
    protected String getPrefix() {
        return TEMPLATES;
    }

    @Override
    public TemplateResponse add(Template template) throws IOException, ErrorResponseException {
        return this.query(METHOD_ADD, templateToMap(template), TemplateResponse.class);
    }

    @Override
    public TemplateResponse update(Template template) throws IOException, ErrorResponseException {
        return this.query(METHOD_UPDATE, templateToMap(template), TemplateResponse.class);
    }

    @Override
    public TemplateResponse info(String name) throws IOException, ErrorResponseException {
        return this.query(METHOD_INFO, prepareNameParam(name), TemplateResponse.class);
    }

    @Override
    public TemplateResponse publish(String name) throws IOException, ErrorResponseException {

        return this.query(METHOD_PUBLISH, prepareNameParam(name), TemplateResponse.class);
    }

    @Override
    public TemplateResponse delete(String name) throws IOException, ErrorResponseException {
        return this.query(METHOD_DELETE, prepareNameParam(name), TemplateResponse.class);
    }

    @Override
    public List<TemplateResponse> list(String label) throws IOException, ErrorResponseException {
        Map<String, Object> params = new HashMap<>();
        params.put(ApiConstants.LABEL, label);
        return this.queryList(METHOD_LIST, params, TemplateResponse.class);
    }

    @Override
    public RenderResponse render(String name, List<NameContentElement> templateContent, List<NameContentElement> mergeVariables) throws IOException, ErrorResponseException {
        Map<String, Object> params = new HashMap<>();
        params.put(ApiConstants.TEMPLATE_NAME, name);
        params.put(ApiConstants.TEMPLATE_CONTENT, templateContent);
        params.put(ApiConstants.MERGE_VARS, mergeVariables);
        return this.query(METHOD_RENDER, params, RenderResponse.class);
    }
}
