package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.UrlResponse;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public interface MandrillUrlsCalls {
    public List<UrlResponse> list() throws IOException, ErrorResponseException;
    public List<UrlResponse> search(String query) throws IOException, ErrorResponseException;
}
