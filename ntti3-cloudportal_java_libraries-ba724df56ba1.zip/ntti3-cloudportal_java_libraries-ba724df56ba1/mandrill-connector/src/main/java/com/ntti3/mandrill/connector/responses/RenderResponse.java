package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class RenderResponse {
    private String html;

    @JsonCreator
    public RenderResponse(@JsonProperty(value = ApiConstants.HTML) String html) {
        this.html = html;
    }

    public String getHtml() {
        return html;
    }
}
