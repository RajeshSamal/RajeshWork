package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.TagInfoResponse;
import com.ntti3.mandrill.connector.responses.TagResponse;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public interface MandrillTagsCalls {
    public List<TagResponse> list() throws IOException, ErrorResponseException;
    public TagResponse delete(String tag) throws IOException, ErrorResponseException;
    public TagInfoResponse info(String tag) throws IOException, ErrorResponseException;
}
