package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.SenderResponse;
import com.ntti3.mandrill.connector.responses.UserInfoResponse;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class DefaultMandrillUsersCalls extends AbstractCall implements MandrillUsersCalls {
    private static final String PREFIX = "users";

    private static final String METHOD_INFO = "info";
    private static final String METHOD_PING = "ping";
    private static final String METHOD_SENDERS = "senders";

    public DefaultMandrillUsersCalls(String url, String apikey) {
        super(url, apikey);
    }

    @Override
    protected String getPrefix() {
        return PREFIX;
    }

    @Override
    public UserInfoResponse info() throws IOException, ErrorResponseException {
        return this.query(METHOD_INFO, null, UserInfoResponse.class);
    }

    @Override
    public String ping() throws IOException, ErrorResponseException {
        return this.query(METHOD_PING, null, String.class);
    }

    @Override
    public List<SenderResponse> senders() throws IOException, ErrorResponseException {
        return this.queryList(METHOD_SENDERS, null, SenderResponse.class);
    }
}
