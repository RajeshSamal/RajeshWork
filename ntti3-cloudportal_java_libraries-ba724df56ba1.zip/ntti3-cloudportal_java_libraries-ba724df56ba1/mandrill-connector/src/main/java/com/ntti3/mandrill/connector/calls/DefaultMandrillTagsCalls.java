package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.TagInfoResponse;
import com.ntti3.mandrill.connector.responses.TagResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class DefaultMandrillTagsCalls extends AbstractCall implements MandrillTagsCalls {
    private static final String PREFIX = "tags";

    private static final String METHOD_LIST = "list";
    private static final String METHOD_DELETE = "delete";
    private static final String METHOD_INFO = "info";

    private Map<String,Object> getTagParams(String tag) {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.TAG, tag);
        return params;
    }

    public DefaultMandrillTagsCalls(String url, String apiKey) {
        super(url, apiKey);
    }

    @Override
    protected String getPrefix() {
        return PREFIX;
    }

    @Override
    public List<TagResponse> list() throws IOException, ErrorResponseException {
        return this.queryList(METHOD_LIST, null, TagResponse.class);
    }

    @Override
    public TagResponse delete(String tag) throws IOException, ErrorResponseException {
        return this.query(METHOD_DELETE, getTagParams(tag), TagResponse.class);
    }

    @Override
    public TagInfoResponse info(String tag) throws IOException, ErrorResponseException {
        return this.query(METHOD_INFO, getTagParams(tag), TagInfoResponse.class);
    }
}
