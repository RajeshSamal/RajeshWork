package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.models.Attachment;
import com.ntti3.mandrill.connector.models.Recipient;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class MessageContentResponse {
    private long ts;
    private String id;
    private String fromEmail;
    private String fromName;
    private String subject;
    private Recipient to;
    private List<String> tags;
    //if headers are empty API returns array instead of object, for now ignore parsing headers...
    @JsonIgnore
    private Map<String,String> headers;
    private String text;
    private String html;
    private List<Attachment> attachments;

    @JsonCreator
    public MessageContentResponse(
            @JsonProperty(value = ApiConstants.TIMESTAMP) long ts,
            @JsonProperty(value = ApiConstants.PRIVATE_ID) String id,
            @JsonProperty(value = ApiConstants.FROM_EMAIL) String fromEmail,
            @JsonProperty(value = ApiConstants.FROM_NAME) String fromName,
            @JsonProperty(value = ApiConstants.SUBJECT) String subject,
            @JsonProperty(value = ApiConstants.TO) Recipient to,
            @JsonProperty(value = ApiConstants.TAGS) List<String> tags,
            //if headers are empty API returns array instead of object, for now ignore parsing headers...
            //@JsonProperty(value = HEADERS) Map<String,String> headers,
            @JsonProperty(value = ApiConstants.TEXT) String text,
            @JsonProperty(value = ApiConstants.HTML) String html,
            @JsonProperty(value = ApiConstants.ATTACHMENTS) List<Attachment> attachments
    ) {
        this.ts = ts;
        this.id = id;
        this.fromEmail = fromEmail;
        this.fromName = fromName;
        this.subject = subject;
        this.to = to;
        if(tags == null) {
            tags = Collections.emptyList();
        }
        this.tags = Collections.unmodifiableList(tags);
        this.headers = headers;
        this.text = text;
        this.html = html;
        if(attachments == null) {
            attachments = Collections.emptyList();
        }
        this.attachments = Collections.unmodifiableList(attachments);
    }

    public long getTimestamp() {
        return ts;
    }

    public String getId() {
        return id;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public String getFromName() {
        return fromName;
    }

    public String getSubject() {
        return subject;
    }

    public Recipient getTo() {
        return to;
    }

    public List<String> getTags() {
        return tags;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public String getText() {
        return text;
    }

    public String getHtml() {
        return html;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }
}
