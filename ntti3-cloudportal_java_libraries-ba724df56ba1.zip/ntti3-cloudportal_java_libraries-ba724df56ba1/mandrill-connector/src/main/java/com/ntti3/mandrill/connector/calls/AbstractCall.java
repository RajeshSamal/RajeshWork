package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.exceptions.InvalidKeyException;
import com.ntti3.mandrill.connector.exceptions.MessageNotFoundException;
import com.ntti3.mandrill.connector.exceptions.TagNotFoundException;
import com.ntti3.mandrill.connector.exceptions.TemplateNotFoundException;
import com.ntti3.mandrill.connector.responses.ErrorResponse;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public abstract class AbstractCall {
    private final String apiKey;
    private final String url;
    private final HttpClient httpClient;
    private final static ObjectMapper objectMapper = new ObjectMapper();
    private final static ObjectWriter objectWriter;

    static {
        //There are undocumented fields in API, ignore them
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
    }

    public AbstractCall(String url, String apiKey) {
        this.url = url;
        this.apiKey = apiKey;
        httpClient = new DefaultHttpClient();
    }

    private HttpResponse call(String method, Map<String, Object> params) throws IOException, ErrorResponseException {
        HttpPost post = new HttpPost(url + method);
        if(params==null) {
            params = new HashMap<>();
        }
        params.put(ApiConstants.KEY, apiKey);
        String json = objectWriter.writeValueAsString(params);
        post.setEntity(new StringEntity(json, ContentType.create("application/json","UTF-8")));

        HttpResponse response = httpClient.execute(post);
        if(response.getStatusLine() == null || response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            ErrorResponse errorResponse = objectMapper.readValue(response.getEntity().getContent(), ErrorResponse.class);
            switch (errorResponse.getName()) {
                case ApiConstants.MESSAGE_NOT_FOUND_ERROR:
                    throw new MessageNotFoundException(errorResponse);
                case ApiConstants.TEMPLATE_NOT_FOUND_ERROR:
                    throw new TemplateNotFoundException(errorResponse);
                case ApiConstants.TAG_NOT_FOUND_ERROR:
                    throw new TagNotFoundException(errorResponse);
                case ApiConstants.INVALID_KEY_ERROR:
                    throw new InvalidKeyException(errorResponse);
                default:
                    throw new ErrorResponseException(errorResponse);
            }
        }
        return response;
    }

    protected abstract String getPrefix();

    protected <T> T query(String method, Map<String, Object> params, Class<T> valueType) throws IOException, ErrorResponseException {
        method = getPrefix()+"/"+method;
        HttpResponse response = this.call(method, params);
        return objectMapper.readValue(response.getEntity().getContent(), valueType);
    }

    protected <T> List<T> queryList(String method, Map<String, Object> params, Class<T> valueType) throws IOException, ErrorResponseException {
        method = getPrefix()+"/"+method;
        HttpResponse response = this.call(method, params);
        return objectMapper.readValue(response.getEntity().getContent(), objectMapper.getTypeFactory().constructCollectionType(List.class, valueType));
    }
}
