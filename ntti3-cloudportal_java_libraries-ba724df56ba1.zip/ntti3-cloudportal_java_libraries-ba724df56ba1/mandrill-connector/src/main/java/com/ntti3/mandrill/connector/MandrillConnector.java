package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.calls.MandrillMessagesCalls;
import com.ntti3.mandrill.connector.calls.MandrillTagsCalls;
import com.ntti3.mandrill.connector.calls.MandrillTemplatesCalls;
import com.ntti3.mandrill.connector.calls.MandrillUrlsCalls;
import com.ntti3.mandrill.connector.calls.MandrillUsersCalls;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public interface MandrillConnector {
    MandrillMessagesCalls getMessagesCalls();

    MandrillTemplatesCalls getTemplatesCalls();

    MandrillUsersCalls getUsersCalls();

    MandrillUrlsCalls getUrlsCalls();

    MandrillTagsCalls getTagsCalls();
}
