package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.utils.MandrillDateTimeDeserializer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class TemplateResponse {
    private String slug;
    private String name;
    private List<String> labels;
    private String code;
    private String subject;
    private String fromEmail;
    private String fromName;
    private String text;
    private String publishName;
    private String publishCode;
    private String publishFromEmail;
    private String publishFromName;
    private String publishText;
    private Date publishedAt;
    private Date createdAt;
    private Date updatedAt;

    @JsonCreator
    public TemplateResponse(
            @JsonProperty(value = ApiConstants.SLUG) String slug,
            @JsonProperty(value = ApiConstants.NAME) String name,
            @JsonProperty(value = ApiConstants.LABELS) List<String> labels,
            @JsonProperty(value = ApiConstants.CODE)  String code,
            @JsonProperty(value = ApiConstants.SUBJECT) String subject,
            @JsonProperty(value = ApiConstants.FROM_EMAIL) String fromEmail,
            @JsonProperty(value = ApiConstants.FROM_NAME) String fromName,
            @JsonProperty(value = ApiConstants.TEXT) String text,
            @JsonProperty(value = ApiConstants.PUBLISH_NAME) String publishName,
            @JsonProperty(value = ApiConstants.PUBLISH_CODE) String publishCode,
            @JsonProperty(value = ApiConstants.PUBLISH_FROM_EMAIL) String publishFromEmail,
            @JsonProperty(value = ApiConstants.PUBLISH_FROM_NAME) String publishFromName,
            @JsonProperty(value = ApiConstants.PUBLISH_TEXT) String publishText,
            @JsonProperty(value = ApiConstants.PUBLISHED_AT)
            @JsonDeserialize(using = MandrillDateTimeDeserializer.class)
            Date publishedAt,
            @JsonProperty(value = ApiConstants.CREATED_AT)
            @JsonDeserialize(using = MandrillDateTimeDeserializer.class)
            Date createdAt,
            @JsonProperty(value = ApiConstants.UPDATED_AT)
            @JsonDeserialize(using = MandrillDateTimeDeserializer.class)
            Date updatedAt
    ) {
        this.slug = slug;
        this.name = name;
        if(labels==null) {
            labels = Collections.emptyList();
        }
        this.labels = Collections.unmodifiableList(labels);
        this.code = code;
        this.subject = subject;
        this.fromEmail = fromEmail;
        this.fromName = fromName;
        this.text = text;
        this.publishName = publishName;
        this.publishCode = publishCode;
        this.publishFromEmail = publishFromEmail;
        this.publishFromName = publishFromName;
        this.publishText = publishText;
        this.publishedAt = publishedAt;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public String getSlug() {
        return slug;
    }

    public String getName() {
        return name;
    }

    public List<String> getLabels() {
        return labels;
    }

    public String getCode() {
        return code;
    }

    public String getSubject() {
        return subject;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public String getFromName() {
        return fromName;
    }

    public String getText() {
        return text;
    }

    public String getPublishName() {
        return publishName;
    }

    public String getPublishCode() {
        return publishCode;
    }

    public String getPublishFromEmail() {
        return publishFromEmail;
    }

    public String getPublishFromName() {
        return publishFromName;
    }

    public String getPublishText() {
        return publishText;
    }

    public Date getPublishedAt() {
        return publishedAt;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }
}
