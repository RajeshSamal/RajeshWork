package com.ntti3.mandrill.connector.models;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class Recipient {
    public static enum Type {
        to,cc,bcc
    }

    private String email;
    private String name;
    private Type type;

    public Recipient() {
        this.type = Type.to;
    }

    public Recipient(String email, String name, Type type) {
        this.email = email;
        this.name = name;
        this.type = type;
    }

    public Recipient(String email, String name) {
        this.email = email;
        this.name = name;
        this.type = Type.to;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
