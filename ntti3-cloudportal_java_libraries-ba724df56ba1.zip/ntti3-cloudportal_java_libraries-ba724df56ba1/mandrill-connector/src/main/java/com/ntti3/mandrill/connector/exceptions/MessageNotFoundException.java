package com.ntti3.mandrill.connector.exceptions;

import com.ntti3.mandrill.connector.responses.ErrorResponse;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-16.
 */
public class MessageNotFoundException extends NotFoundException {
    public MessageNotFoundException(int code, String status, String name, String message) {
        super(code, status, name, message);
    }

    public MessageNotFoundException(ErrorResponse response) {
        super(response);
    }
}
