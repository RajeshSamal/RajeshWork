package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class UrlResponse {
    private String url;
    private int sent;
    private int clicks;
    private int uniqueClicks;

    @JsonCreator
    public UrlResponse(
            @JsonProperty(value = ApiConstants.URL) String url,
            @JsonProperty(value = ApiConstants.SENT) int sent,
            @JsonProperty(value = ApiConstants.CLICKS) int clicks,
            @JsonProperty(value = ApiConstants.UNIQUE_CLICKS) int uniqueClicks
    ) {
        this.url = url;
        this.sent = sent;
        this.clicks = clicks;
        this.uniqueClicks = uniqueClicks;
    }

    public String getUrl() {
        return url;
    }

    public int getSent() {
        return sent;
    }

    public int getClicks() {
        return clicks;
    }

    public int getUniqueClicks() {
        return uniqueClicks;
    }
}
