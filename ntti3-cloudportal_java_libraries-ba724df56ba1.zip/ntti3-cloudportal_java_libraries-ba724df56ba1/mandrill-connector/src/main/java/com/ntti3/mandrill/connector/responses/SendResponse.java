package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class SendResponse {
    private String email;
    private String status;
    private String rejectReason;
    private String id;

    @JsonCreator
    public SendResponse(
            @JsonProperty(value = ApiConstants.EMAIL) String email,
            @JsonProperty(value = ApiConstants.STATUS) String status,
            @JsonProperty(value = ApiConstants.REJECT_REASON) String rejectReason,
            @JsonProperty(value = ApiConstants.PRIVATE_ID) String id
    ) {
        this.email = email;
        this.status = status;
        this.rejectReason = rejectReason;
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public String getStatus() {
        return status;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public String getId() {
        return id;
    }
}
