package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.SenderResponse;
import com.ntti3.mandrill.connector.responses.UserInfoResponse;

import java.io.IOException;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public interface MandrillUsersCalls {
    UserInfoResponse info() throws IOException, ErrorResponseException;
    String ping() throws IOException, ErrorResponseException;
    List<SenderResponse> senders() throws IOException, ErrorResponseException;
}
