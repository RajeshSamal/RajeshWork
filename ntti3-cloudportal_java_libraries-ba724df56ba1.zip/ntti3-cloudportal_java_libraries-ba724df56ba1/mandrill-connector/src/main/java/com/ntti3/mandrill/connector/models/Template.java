package com.ntti3.mandrill.connector.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class Template {
    private String key;
    private String name;
    private String from_email;
    private String from_name;
    private String subject;
    private String code;
    private String text;
    private boolean publish;
    private List<String> labels = new ArrayList<>();

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFromEmail() {
        return from_email;
    }

    public void setFromEmail(String from_email) {
        this.from_email = from_email;
    }

    public String getFromName() {
        return from_name;
    }

    public void setFromName(String from_name) {
        this.from_name = from_name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isPublish() {
        return publish;
    }

    public void setPublish(boolean publish) {
        this.publish = publish;
    }

    public List<String> getLabels() {
        return Collections.unmodifiableList(labels);
    }

    public void addLabel(String label) {
        labels.add(label);
    }
}
