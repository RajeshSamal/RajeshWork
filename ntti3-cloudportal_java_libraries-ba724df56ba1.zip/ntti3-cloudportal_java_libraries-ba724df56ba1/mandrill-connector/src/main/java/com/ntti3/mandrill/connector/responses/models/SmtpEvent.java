package com.ntti3.mandrill.connector.responses.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class SmtpEvent {
    private long timestamp;
    private String type;
    //diag
    private String response;
    private String sourceIp;
    private String destinationIp;

    @JsonCreator
    public SmtpEvent(
            @JsonProperty(value = ApiConstants.TS) long timestamp,
            @JsonProperty(value = ApiConstants.TYPE) String type,
            @JsonProperty(value = ApiConstants.DIAG) String response,
            @JsonProperty(value = ApiConstants.SOURCE_IP) String sourceIp,
            @JsonProperty(value = ApiConstants.DESTINATION_IP) String destinationIp
    ) {
        this.timestamp = timestamp;
        this.type = type;
        this.response = response;
        this.sourceIp = sourceIp;
        this.destinationIp = destinationIp;
    }
}
