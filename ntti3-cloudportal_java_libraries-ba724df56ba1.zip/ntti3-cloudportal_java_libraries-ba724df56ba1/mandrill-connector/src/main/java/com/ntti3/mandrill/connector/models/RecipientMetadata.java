package com.ntti3.mandrill.connector.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class RecipientMetadata {
    @JsonProperty(value = ApiConstants.RCPT, required = true)
    private String recipient;
    @JsonProperty(value = ApiConstants.VALUES, required = true)
    private Map<String,String> values;

    public RecipientMetadata(String recipient) {
        this.recipient = recipient;
        values = new HashMap<>();
    }

    public void addValue(String key, String value) {
        values.put(key, value);
    }

    public String getRecipient() {
        return recipient;
    }

    public Map<String, String> getValues() {
        return Collections.unmodifiableMap(values);
    }
}
