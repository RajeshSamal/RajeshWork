package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.responses.models.ClicksDetail;
import com.ntti3.mandrill.connector.responses.models.OpensDetail;
import com.ntti3.mandrill.connector.responses.models.SmtpEvent;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class MessageInfoResponse {
    private long ts;
    private String id;
    private String sender;
    private String template;
    private String subject;
    private String email;
    private List<String> tags;
    private int opens;
    private List<OpensDetail> opensDetail;
    private int clicks;
    private List<ClicksDetail> clicksDetail;
    private String state;
    private Map<String,String> metadata;
    private List<SmtpEvent> smtpEvents;

    @JsonCreator
    public MessageInfoResponse(
            @JsonProperty(value = ApiConstants.TIMESTAMP) long ts,
            @JsonProperty(value = ApiConstants.PRIVATE_ID) String id,
            @JsonProperty(value = ApiConstants.SENDER) String sender,
            @JsonProperty(value = ApiConstants.TEMPLATE) String template,
            @JsonProperty(value = ApiConstants.SUBJECT) String subject,
            @JsonProperty(value = ApiConstants.EMAIL) String email,
            @JsonProperty(value = ApiConstants.TAGS) List<String> tags,
            @JsonProperty(value = ApiConstants.OPENS) int opens,
            @JsonProperty(value = ApiConstants.OPENS_DETAIL) List<OpensDetail> opensDetail,
            @JsonProperty(value = ApiConstants.CLICKS) int clicks,
            @JsonProperty(value = ApiConstants.CLICKS_DETAIL) List<ClicksDetail> clicksDetail,
            @JsonProperty(value = ApiConstants.STATE) String state,
            @JsonProperty(value = ApiConstants.METADATA) Map<String, String> metadata,
            @JsonProperty(value = ApiConstants.SMTP_EVENTS) List<SmtpEvent> smtpEvents
    ) {
        this.ts = ts;
        this.id = id;
        this.sender = sender;
        this.template = template;
        this.subject = subject;
        this.email = email;
        if(tags == null) {
            tags = Collections.emptyList();
        }
        this.tags = Collections.unmodifiableList(tags);
        this.opens = opens;
        if(opensDetail == null) {
            opensDetail = Collections.emptyList();
        }
        this.opensDetail = Collections.unmodifiableList(opensDetail);
        this.clicks = clicks;
        if(clicksDetail == null) {
            clicksDetail = Collections.emptyList();
        }
        this.clicksDetail = Collections.unmodifiableList(clicksDetail);
        this.state = state;
        if(metadata==null) {
            metadata = Collections.emptyMap();
        }
        this.metadata = Collections.unmodifiableMap(metadata);
        if(smtpEvents == null) {
            smtpEvents = Collections.emptyList();
        }
        this.smtpEvents = Collections.unmodifiableList(smtpEvents);
    }

    public long getTimestamp() {
        return ts;
    }

    public String getId() {
        return id;
    }

    public String getSender() {
        return sender;
    }

    public String getTemplate() {
        return template;
    }

    public String getSubject() {
        return subject;
    }

    public String getEmail() {
        return email;
    }

    public List<String> getTags() {
        return tags;
    }

    public int getOpens() {
        return opens;
    }

    public List<OpensDetail> getOpensDetail() {
        return opensDetail;
    }

    public int getClicks() {
        return clicks;
    }

    public List<ClicksDetail> getClicksDetail() {
        return clicksDetail;
    }

    public String getState() {
        return state;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public List<SmtpEvent> getSmtpEvents() {
        return smtpEvents;
    }
}
