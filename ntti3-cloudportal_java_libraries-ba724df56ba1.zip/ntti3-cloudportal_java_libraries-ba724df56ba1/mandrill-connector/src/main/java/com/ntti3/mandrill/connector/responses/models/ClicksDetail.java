package com.ntti3.mandrill.connector.responses.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class ClicksDetail extends OpensDetail {
    private String url;

    @JsonCreator
    public ClicksDetail(
            @JsonProperty(value = ApiConstants.TS) long timestamp,
            @JsonProperty(value = ApiConstants.IP) String ip,
            @JsonProperty(value = ApiConstants.LOCATION) String location,
            @JsonProperty(value = ApiConstants.UA) String userAgent,
            @JsonProperty(value = ApiConstants.URL) String url) {
        super(timestamp, ip, location, userAgent);
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
