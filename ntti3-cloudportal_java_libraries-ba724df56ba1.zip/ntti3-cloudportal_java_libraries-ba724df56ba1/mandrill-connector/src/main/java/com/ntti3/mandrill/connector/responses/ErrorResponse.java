package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class ErrorResponse {

    private String status;
    private int code;
    private String name;
    private String message;

    @JsonCreator
    public ErrorResponse(
            @JsonProperty(value = ApiConstants.STATUS) String status,
            @JsonProperty(value = ApiConstants.CODE) int code,
            @JsonProperty(value = ApiConstants.NAME) String name,
            @JsonProperty(value = ApiConstants.MESSAGE) String message
    ) {
        this.message = message;
        this.status = status;
        this.code = code;
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getMessage() {
        return message;
    }
}
