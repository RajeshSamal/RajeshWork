package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.models.Message;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.responses.MessageContentResponse;
import com.ntti3.mandrill.connector.responses.MessageInfoResponse;
import com.ntti3.mandrill.connector.responses.SendResponse;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-07.
 */
public class DefaultMandrillMessagesCalls extends AbstractCall implements MandrillMessagesCalls {
    private static final String PREFIX = "messages";

    private static final String METHOD_SEND = "send";
    private static final String METHOD_SEND_TEMPLATE = "send-template";
    private static final String METHOD_SEARCH = "search";
    private static final String METHOD_INFO = "info";
    private static final String METHOD_CONTENT = "content";

    private static final String dateformat = "yyyy/MM/dd";
    private static final String datetimeformat = "yyyy-MM-dd hh:mm:ss";

    private Map<String, Object> buildParams(Message message, Boolean async, String ip_pool, Date send_at) {
        HashMap<String, Object> params = new HashMap<>();
        params.put(ApiConstants.MESSAGE, message);
        params.put(ApiConstants.ASYNC, async);
        params.put(ApiConstants.IP_POOL, ip_pool);
        if(send_at != null) {
            DateFormat dtf = new SimpleDateFormat(datetimeformat);
            params.put(ApiConstants.SEND_AT, dtf.format(send_at));
        }
        return params;
    }

    public DefaultMandrillMessagesCalls(String url, String apikey) {
        super(url, apikey);
    }

    @Override
    protected String getPrefix() {
        return PREFIX;
    }

    @Override
    public List<SendResponse> send(Message message, Boolean async, String ipPool, Date sendAt) throws ErrorResponseException, IOException {
        Map<String,Object> params = buildParams(message, async, ipPool, sendAt);
        return queryList(METHOD_SEND, params, SendResponse.class);
    }

    @Override
    public List<SendResponse> send(Message message, Boolean async) throws ErrorResponseException, IOException {
        return send(message, async, null, null);
    }

    @Override
    public List<SendResponse> send_template(String templateName, List<NameContentElement> templateContent, Message message, Boolean async, String ipPool, Date sendAt)  throws ErrorResponseException, IOException{
        Map<String,Object> params = buildParams(message ,async, ipPool, sendAt);
        params.put(ApiConstants.TEMPLATE_NAME, templateName);
        params.put(ApiConstants.TEMPLATE_CONTENT, templateContent);
        return queryList(METHOD_SEND_TEMPLATE, params, SendResponse.class);
    }

    @Override
    public List<SendResponse> send_template(String templateName, List<NameContentElement> templateContent, Message message, Boolean async) throws ErrorResponseException, IOException {
        return send_template(templateName, templateContent, message, async, null, null);
    }

    @Override
    public List<MessageInfoResponse> search(String query, Date from, Date to, List<String> tags, List<String> senders, List<String> apiKeys, int limit) throws IOException, ErrorResponseException {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.QUERY, query);
        DateFormat df = new SimpleDateFormat(dateformat);
        if(from != null) {
            params.put(ApiConstants.DATE_FROM, df.format(from));
        }
        if(to != null) {
            params.put(ApiConstants.DATE_TO, df.format(to));
        }
        params.put(ApiConstants.TAGS, tags);
        params.put(ApiConstants.SENDERS, senders);
        params.put(ApiConstants.API_KEYS, apiKeys);
        params.put(ApiConstants.LIMIT, limit);
        return this.queryList(METHOD_SEARCH, params, MessageInfoResponse.class);
    }

    @Override
    public MessageInfoResponse info(String id) throws IOException, ErrorResponseException {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.ID, id);
        return this.query(METHOD_INFO, params, MessageInfoResponse.class);
    }

    @Override
    public MessageContentResponse content(String id) throws IOException, ErrorResponseException {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.ID, id);
        return this.query(METHOD_CONTENT, params, MessageContentResponse.class);
    }
}
