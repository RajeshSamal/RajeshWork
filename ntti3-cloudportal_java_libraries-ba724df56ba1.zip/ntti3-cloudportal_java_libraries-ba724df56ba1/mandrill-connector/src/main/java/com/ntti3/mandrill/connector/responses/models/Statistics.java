package com.ntti3.mandrill.connector.responses.models;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class Statistics {
    private int sent;
    private int hardBounces;
    private int softBounces;
    private int rejects;
    private int complaints;
    private int unsubs;
    private int opens;
    private int uniqueOpens;
    private int clicks;
    private int uniqueClicks;

    @JsonCreator
    public Statistics(
            @JsonProperty(value = ApiConstants.SENT) int sent,
            @JsonProperty(value = ApiConstants.HARD_BOUNCES) int hardBounces,
            @JsonProperty(value = ApiConstants.SOFT_BOUNCES) int softBounces,
            @JsonProperty(value = ApiConstants.REJECTS) int rejects,
            @JsonProperty(value = ApiConstants.COMPLAINTS) int complaints,
            @JsonProperty(value = ApiConstants.UNSUBS) int unsubs,
            @JsonProperty(value = ApiConstants.OPENS) int opens,
            @JsonProperty(value = ApiConstants.UNIQUE_OPENS) int uniqueOpens,
            @JsonProperty(value = ApiConstants.CLICKS) int clicks,
            @JsonProperty(value = ApiConstants.UNIQUE_CLICKS) int uniqueClicks) {
        this.sent = sent;
        this.hardBounces = hardBounces;
        this.softBounces = softBounces;
        this.rejects = rejects;
        this.complaints = complaints;
        this.unsubs = unsubs;
        this.opens = opens;
        this.uniqueOpens = uniqueOpens;
        this.clicks = clicks;
        this.uniqueClicks = uniqueClicks;
    }

    public int getSent() {
        return sent;
    }

    public int getHardBounces() {
        return hardBounces;
    }

    public int getSoftBounces() {
        return softBounces;
    }

    public int getRejects() {
        return rejects;
    }

    public int getComplaints() {
        return complaints;
    }

    public int getUnsubs() {
        return unsubs;
    }

    public int getOpens() {
        return opens;
    }

    public int getUniqueOpens() {
        return uniqueOpens;
    }

    public int getClicks() {
        return clicks;
    }

    public int getUniqueClicks() {
        return uniqueClicks;
    }
}
