package com.ntti3.mandrill.connector.calls;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.UrlResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class DefaultUrlsCalls extends AbstractCall implements MandrillUrlsCalls {
    private static final String PREFIX = "urls";

    private static final String METHOD_LIST = "list";
    private static final String METHOD_SEARCH = "search";

    public DefaultUrlsCalls(String url, String apiKey) {
        super(url, apiKey);
    }

    @Override
    public List<UrlResponse> list() throws IOException, ErrorResponseException {
        return this.queryList(METHOD_LIST, null, UrlResponse.class);
    }

    @Override
    public List<UrlResponse> search(String query) throws IOException, ErrorResponseException {
        Map<String,Object> params = new HashMap<>();
        params.put(ApiConstants.Q, query);
        return this.queryList(METHOD_SEARCH, params, UrlResponse.class);
    }

    @Override
    protected String getPrefix() {
        return PREFIX;
    }
}
