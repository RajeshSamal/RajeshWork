package com.ntti3.mandrill.connector.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.DateDeserializers;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class MandrillDateTimeDeserializer extends DateDeserializers.DateDeserializer {
    private final List<String> formats = new ArrayList<>();

    public MandrillDateTimeDeserializer() {
        super();
        formats.add("yyyy-MM-dd HH:mm:ss.SSSSS");
        formats.add("yyyy-MM-dd HH:mm:ss");
    }

    @Override
    public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        String text = jp.getValueAsString();
        DateFormat dt;
        for(String format : formats) {
            dt = new SimpleDateFormat(format);
            try{
                return dt.parse(text);
            } catch (ParseException ignored) { }
        }
        return super.deserialize(jp, ctxt);
    }
}
