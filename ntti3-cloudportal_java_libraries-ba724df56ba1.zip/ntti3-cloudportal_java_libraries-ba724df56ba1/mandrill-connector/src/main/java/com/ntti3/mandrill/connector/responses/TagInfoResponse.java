package com.ntti3.mandrill.connector.responses;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.responses.models.Statistics;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.Map;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class TagInfoResponse {
    private String tag;
    private int sent;
    private int hardBounces;
    private int softBounces;
    private int rejects;
    private int complaints;
    private int unsubs;
    private int opens;
    private int clicks;
    private Map<String, Statistics> statistics;

    public TagInfoResponse(
            @JsonProperty(value = ApiConstants.TAG) String tag,
            @JsonProperty(value = ApiConstants.SENT) int sent,
            @JsonProperty(value = ApiConstants.HARD_BOUNCES) int hardBounces,
            @JsonProperty(value = ApiConstants.SOFT_BOUNCES) int softBounces,
            @JsonProperty(value = ApiConstants.REJECTS) int rejects,
            @JsonProperty(value = ApiConstants.COMPLAINTS) int complaints,
            @JsonProperty(value = ApiConstants.UNSUBS) int unsubs,
            @JsonProperty(value = ApiConstants.OPENS) int opens,
            @JsonProperty(value = ApiConstants.CLICKS) int clicks,
            @JsonProperty(value = ApiConstants.STATS) Map<String, Statistics> statistics
    ) {
        this.tag = tag;
        this.sent = sent;
        this.hardBounces = hardBounces;
        this.softBounces = softBounces;
        this.rejects = rejects;
        this.complaints = complaints;
        this.unsubs = unsubs;
        this.opens = opens;
        this.clicks = clicks;
        if(statistics==null) {
            statistics = Collections.emptyMap();
        }
        this.statistics = Collections.unmodifiableMap(statistics);
    }

    public String getTag() {
        return tag;
    }

    public int getSent() {
        return sent;
    }

    public int getHardBounces() {
        return hardBounces;
    }

    public int getSoftBounces() {
        return softBounces;
    }

    public int getRejects() {
        return rejects;
    }

    public int getComplaints() {
        return complaints;
    }

    public int getUnsubs() {
        return unsubs;
    }

    public int getOpens() {
        return opens;
    }

    public int getClicks() {
        return clicks;
    }

    public Map<String, Statistics> getStatistics() {
        return statistics;
    }
}
