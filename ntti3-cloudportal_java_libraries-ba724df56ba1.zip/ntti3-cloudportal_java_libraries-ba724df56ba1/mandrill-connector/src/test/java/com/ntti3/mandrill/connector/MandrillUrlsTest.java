package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.responses.UrlResponse;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 * This tests depends on data on server, that is why they are ignored
 */
public class MandrillUrlsTest extends MandrillTest{

    @Test
    //@Ignore
    public void testList() throws Exception {
        List<UrlResponse> responseList = getConnector().getUrlsCalls().list();
        TestCase.assertTrue(responseList.size() > 0);
    }

    @Test
    //@Ignore
    public void testQuery() throws Exception {
        List<UrlResponse> responseList = getConnector().getUrlsCalls().search("codilime");
        TestCase.assertTrue(responseList.size() > 0);
    }
}
