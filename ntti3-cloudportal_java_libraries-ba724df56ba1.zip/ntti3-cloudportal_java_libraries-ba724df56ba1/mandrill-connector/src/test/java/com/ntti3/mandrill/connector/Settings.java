package com.ntti3.mandrill.connector;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public final class Settings {
    //Test key for rejected test to work (not sending emails)
    static final String test_api_key = "HDGq8GCohFWZHnXF6muw_A";
    //Non-test key to test search and info (test key returns no messages)
    static final String api_key = "5QBt04_TNFK7Wocankbjvg";
    static final String recipient = "bartlomiej.biernacki@codilime.com";
    //Must be one allowed to send via api
    static final String sender = "bartlomiej.biernacki@codilime.com";
    //For query string in testSearch
    static final String domain = "codilime.com";
}
