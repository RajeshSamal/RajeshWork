package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.models.Message;
import com.ntti3.mandrill.connector.models.Recipient;
import com.ntti3.mandrill.connector.responses.SendResponse;
import junit.framework.TestCase;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class MandrillMessagesSendTest extends MandrillTest {
    private Message buildTestMsg(String recipient) {
        Message message = new Message();
        message.setHtml("<b>test</b>");
        message.addTo(new Recipient(recipient, "Jan Testowy"));
        message.setFromEmail(Settings.sender);
        return message;
    }

    private Message buildTestMsg() {
        return buildTestMsg(Settings.recipient);
    }

    @org.junit.Test
    public void testSend() throws Exception {
        Message message = buildTestMsg();
        List<SendResponse> responses = getTestConnector().getMessagesCalls().send(message, false);
        TestCase.assertEquals(1, responses.size());
        SendResponse response = responses.get(0);
        TestCase.assertEquals(null, response.getRejectReason());
        TestCase.assertEquals("sent", response.getStatus());
    }

    @org.junit.Test
    public void testReject() throws Exception {
        Message message = buildTestMsg("reject@test.mandrillapp.com");
        List<SendResponse> responses = getTestConnector().getMessagesCalls().send(message, false);
        SendResponse response = responses.get(0);
        TestCase.assertEquals("rejected", response.getStatus());
    }

    @org.junit.Test
    public void testSendTemplate() throws Exception {
        Message message = buildTestMsg();
        List<SendResponse> responses = getTestConnector().getMessagesCalls().send_template("test", null, message, false);
        TestCase.assertEquals(responses.size(), 1);
        SendResponse response = responses.get(0);
        TestCase.assertEquals(response.getRejectReason(), null);
        TestCase.assertEquals(response.getStatus(), "sent");

    }
}
