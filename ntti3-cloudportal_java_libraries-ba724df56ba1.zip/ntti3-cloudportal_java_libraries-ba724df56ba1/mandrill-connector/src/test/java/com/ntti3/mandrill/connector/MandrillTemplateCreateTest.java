package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public class MandrillTemplateCreateTest extends MandrillTest {
    private static final String TEST_TEMPLATE_NAME = "test-template";
    private static final String TEST_TEMPLATE_CODE = "<h1>test-template</h1> *|TESTMERGEVAR|*";

    @Test
    public void createDeleteTemplate() throws Exception {
        Template t = new Template();
        t.setName(TEST_TEMPLATE_NAME);
        t.setCode(TEST_TEMPLATE_CODE);
        t.setPublish(false);
        TemplateResponse resp = getConnector().getTemplatesCalls().add(t);
        TestCase.assertEquals(TEST_TEMPLATE_NAME, resp.getName());
        TestCase.assertEquals(TEST_TEMPLATE_CODE, resp.getCode());
        Thread.sleep(1000);
        resp = getConnector().getTemplatesCalls().delete(TEST_TEMPLATE_NAME);
        TestCase.assertEquals(TEST_TEMPLATE_NAME, resp.getName());
        TestCase.assertEquals(TEST_TEMPLATE_CODE, resp.getCode());
    }

}
