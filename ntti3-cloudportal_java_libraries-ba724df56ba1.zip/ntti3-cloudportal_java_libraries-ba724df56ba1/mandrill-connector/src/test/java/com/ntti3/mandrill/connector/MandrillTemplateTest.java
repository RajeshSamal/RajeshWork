package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.models.NameContentElement;
import com.ntti3.mandrill.connector.models.Template;
import com.ntti3.mandrill.connector.responses.RenderResponse;
import com.ntti3.mandrill.connector.responses.TemplateResponse;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class MandrillTemplateTest extends MandrillTest {
    private static final String TEST_TEMPLATE_NAME = "test-template";
    private static final String TEST_TEMPLATE_CODE = "<h1>test-template</h1> *|TESTMERGEVAR|*";


    @Before
    public void addTestTemplate() throws IOException, ErrorResponseException {
        Template t = new Template();
        t.setName(TEST_TEMPLATE_NAME);
        t.setCode(TEST_TEMPLATE_CODE);
        t.setPublish(false);
        getConnector().getTemplatesCalls().add(t);
    }

    @After
    public void removeTestTemplate() throws IOException, ErrorResponseException {
        getConnector().getTemplatesCalls().delete(TEST_TEMPLATE_NAME);
    }

    @Test
    public void infoTest() throws Exception {
        TemplateResponse resp = getConnector().getTemplatesCalls().info(TEST_TEMPLATE_NAME);
        TestCase.assertEquals(TEST_TEMPLATE_NAME, resp.getName());
        TestCase.assertEquals(TEST_TEMPLATE_CODE, resp.getCode());
    }

    @Test
    public void updateTest() throws Exception {
        String new_code = "<b>Some diffrent code<b>";
        Template t = new Template();
        t.setName(TEST_TEMPLATE_NAME);
        t.setCode(new_code);
        getConnector().getTemplatesCalls().update(t);
        TemplateResponse resp = getConnector().getTemplatesCalls().info(TEST_TEMPLATE_NAME);
        TestCase.assertEquals(new_code, resp.getCode());
    }

    @Test
    public void publishTest() throws Exception {
        TemplateResponse resp = getConnector().getTemplatesCalls().info(TEST_TEMPLATE_NAME);
        TestCase.assertNull(resp.getPublishedAt());
        resp = getConnector().getTemplatesCalls().publish(TEST_TEMPLATE_NAME);
        TestCase.assertNotNull(resp.getPublishedAt());
    }

    @Test
    public void listTest() throws Exception {
        List<TemplateResponse> respList = getConnector().getTemplatesCalls().list(null);
        TestCase.assertTrue(respList.size() > 0);
        respList = getConnector().getTemplatesCalls().list("no-such-label-"+Math.random());
        TestCase.assertEquals(0, respList.size());
    }

    @Test
    public void testRender() throws Exception {
        List<NameContentElement> mergeVars = new ArrayList<>();
        mergeVars.add(new NameContentElement("TESTMERGEVAR", "test of rendering"));
        RenderResponse resp = getConnector().getTemplatesCalls().render(TEST_TEMPLATE_NAME, null, mergeVars);
        TestCase.assertTrue(resp.getHtml().contains("test of rendering"));
        TestCase.assertTrue(resp.getHtml().contains("<h1>test-template</h1>"));
    }
}
