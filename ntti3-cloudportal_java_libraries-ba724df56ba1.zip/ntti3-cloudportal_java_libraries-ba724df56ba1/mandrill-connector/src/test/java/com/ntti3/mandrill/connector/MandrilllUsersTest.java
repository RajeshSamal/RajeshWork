package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.exceptions.ErrorResponseException;
import com.ntti3.mandrill.connector.responses.SenderResponse;
import junit.framework.TestCase;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 */
public class MandrilllUsersTest extends MandrillTest {

    @Test
    public void pingTest() throws Exception {
        TestCase.assertEquals("PONG!", getTestConnector().getUsersCalls().ping());
    }

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Test
    public void wrongKeyTest() throws Exception {
        MandrillConnector connector = (new MandrillConnectorFactory()).makeMandrillConnector(Settings.api_key + Math.random());

        exception.expect(ErrorResponseException.class);
        exception.expectMessage("Invalid API key");
        connector.getUsersCalls().ping();
    }

    @Test
    public void sendersTest() throws Exception {
        List<SenderResponse> responseList = getConnector().getUsersCalls().senders();
        TestCase.assertTrue(responseList.size() > 0);
    }
}
