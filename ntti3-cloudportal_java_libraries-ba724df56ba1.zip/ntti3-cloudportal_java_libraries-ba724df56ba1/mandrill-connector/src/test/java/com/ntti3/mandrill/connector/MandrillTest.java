package com.ntti3.mandrill.connector;

import org.junit.BeforeClass;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-09.
 */
public abstract class MandrillTest {
    private static MandrillConnector connector;
    private static MandrillConnector testConnector;

    @BeforeClass
    public static void setUp() {
        connector = (new MandrillConnectorFactory()).makeMandrillConnector(Settings.api_key);
        testConnector = (new MandrillConnectorFactory()).makeMandrillConnector(Settings.test_api_key);
    }

    protected static MandrillConnector getConnector() {
        return connector;
    }

    protected static MandrillConnector getTestConnector() {
        return testConnector;
    }
}
