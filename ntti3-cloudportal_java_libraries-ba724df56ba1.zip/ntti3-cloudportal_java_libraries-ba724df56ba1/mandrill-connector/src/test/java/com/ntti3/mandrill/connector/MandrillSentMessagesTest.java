package com.ntti3.mandrill.connector;

import com.ntti3.mandrill.connector.calls.ApiConstants;
import com.ntti3.mandrill.connector.models.Message;
import com.ntti3.mandrill.connector.models.Recipient;
import com.ntti3.mandrill.connector.responses.MessageContentResponse;
import com.ntti3.mandrill.connector.responses.MessageInfoResponse;
import com.ntti3.mandrill.connector.responses.SendResponse;
import com.ntti3.mandrill.connector.responses.TagInfoResponse;
import com.ntti3.mandrill.connector.responses.TagResponse;
import junit.framework.TestCase;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-08.
 * WARNING: this test need to wait for few minutes before data about sent email are avaible. Also it sends real mails
 */
@Ignore
public class MandrillSentMessagesTest extends MandrillTest {
    static final String testText = "test";
    static final String testHTML = "<b>test</b>";
    static String testTag;

    static String id;

    @BeforeClass
    public static void sendTestMail() throws Exception {
        testTag = "TestowyTag" + Math.random();
        Message message = new Message();
        message.setHtml(testHTML);
        message.setText(testText);
        message.addTo(new Recipient(Settings.recipient, "Jan Testowy"));
        message.setFromEmail(Settings.sender);
        message.addTag(testTag);
        List<SendResponse> responses = getConnector().getMessagesCalls().send(message, false);
        SendResponse response = responses.get(0);
        id = response.getId();
        //Server will not get info about just send msg, wait a moment
        Thread.sleep(5*60000);
    }

    @Test
    public void testSearch() throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.set(2010,Calendar.JANUARY,1);
        Date from = cal.getTime();
        cal.set(2016,Calendar.DECEMBER, 31);
        Date to = cal.getTime();
        List<MessageInfoResponse> responses = getConnector().getMessagesCalls().search("email:" + Settings.domain, from, to, null, null, null, 1);

        TestCase.assertEquals(1, responses.size());
        MessageInfoResponse resp = responses.get(0);
        TestCase.assertEquals(Settings.recipient, resp.getEmail());
        TestCase.assertEquals(ApiConstants.SENT, resp.getState());
        TestCase.assertEquals(id, resp.getId());
    }

    @Test
    public void testInfo() throws Exception {
        MessageInfoResponse resp = getConnector().getMessagesCalls().info(id);

        TestCase.assertEquals(Settings.recipient, resp.getEmail());
        TestCase.assertEquals(ApiConstants.SENT, resp.getState());
        TestCase.assertEquals(id, resp.getId());

    }

    @Test
    public void testContent() throws Exception {
        MessageContentResponse resp = getConnector().getMessagesCalls().content(id);

        TestCase.assertEquals(testText, resp.getText());
        TestCase.assertTrue(resp.getHtml().contains(testHTML));
        TestCase.assertEquals(id, resp.getId());
    }

    @Test
    public void testTagInfo() throws Exception {
        TagInfoResponse tr = getConnector().getTagsCalls().info(testTag);
        TestCase.assertEquals(testTag, tr.getTag());
        TestCase.assertEquals(1, tr.getSent());
    }

    @Test
    public void testTagList() throws Exception {
        //ok, just test if there arent any exceptions
        List<TagResponse> tr = getConnector().getTagsCalls().list();
    }
}
