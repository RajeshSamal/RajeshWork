package models;

import com.ntti3.tokengenerator.models.Token;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenTest {

    private static final String VALID_VALUE = "emilidocemilidocemilidocemilidocemilidocemilidoc";
    private static final String OK_LONG_VALUE = "aasdsfsdfsdfsffdsemilidocemilidocemilidocemilidocemilidocemilido";
    private static final String TOO_LONG_VALUE= "aasdsfsdfsdfsffdsemilidocemilidocemilidocemilidocemilidocemilidoa";
    private static final String OK_SHORT_VALUE = "codili";
    private static final String TOO_SHORT_VALUE = "codil";

    @Test(expected = NullPointerException.class)
    public void nullValue() {
        Token token = new Token(null, "", DateTime.now());
    }

    @Test(expected = NullPointerException.class)
    public void nullTarget() {
        Token token = new Token(VALID_VALUE, null, DateTime.now());
    }

    @Test(expected = NullPointerException.class)
    public void nullValidUntil() {
        Token token = new Token(VALID_VALUE, "", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void tooLongValue() {
        Token token = new Token(TOO_LONG_VALUE, "", DateTime.now());
    }

    @Test
    public void okLongValue() {
        Token token = new Token(OK_LONG_VALUE, "", DateTime.now());
    }

    @Test(expected = IllegalArgumentException.class)
    public void tooShortValue() {
        Token token = new Token(TOO_SHORT_VALUE, "", DateTime.now());
    }

    @Test
    public void okShortValue() {
        Token token = new Token(OK_SHORT_VALUE, "", DateTime.now());
    }

    @Test
    public void validTokenEqual() {
        DateTime date = DateTime.now();
        System.err.println(date.isBefore(date.plusDays(1)));
        Token token = new Token(VALID_VALUE, "", date);
        Assert.assertEquals("Token isValid", token.isValid(date), true);
    }

    @Test
    public void longValidToken() {
        DateTime date = DateTime.now();
        Token token = new Token(VALID_VALUE, "", date.plusDays(5));
        Assert.assertEquals("Token isValid", token.isValid(date), true);
    }

    @Test
    public void invalidToken() {
        DateTime date = DateTime.now();
        Token token = new Token(VALID_VALUE, "", date.minusMillis(1));
        Assert.assertEquals("Token isValid", token.isValid(date), false);
    }
}
