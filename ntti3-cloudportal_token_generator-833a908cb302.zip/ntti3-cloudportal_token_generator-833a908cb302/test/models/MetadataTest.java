package models;

import com.ntti3.tokengenerator.models.Metadata;
import org.junit.Test;

/**
 * @author Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class MetadataTest {

    private static final String VALID_VALUE = "emilidocemilidocemilidocemilidocemilidocemilidoc";
    private static final String OK_LONG_VALUE = "aasdsfsdfsdfsffdsemilidocemilidocemilidocemilidocemilidocemilido";
    private static final String TOO_LONG_VALUE= "aasdsfsdfsdfsffdsemilidocemilidocemilidocemilidocemilidocemilidoa";

    @Test(expected = IllegalArgumentException.class)
    public void tooLongKey() {
        Metadata metadata = new Metadata(TOO_LONG_VALUE, VALID_VALUE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void tooLongValue() {
        Metadata metadata = new Metadata(VALID_VALUE, TOO_LONG_VALUE);
    }

    @Test
    public void okLongValue() {
        Metadata metadata = new Metadata(OK_LONG_VALUE, OK_LONG_VALUE);
    }


}
