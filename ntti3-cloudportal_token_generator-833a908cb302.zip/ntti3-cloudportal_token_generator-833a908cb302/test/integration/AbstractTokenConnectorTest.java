package integration;

import com.google.common.base.Optional;
import com.google.common.collect.Maps;
import com.ntti3.tokens.Token;
import com.ntti3.tokens.TokenServiceConnector;
import com.ntti3.tokens.exceptions.TokenServiceException;
import com.ntti3.tokens.exceptions.TokenServiceInvalidApiCallException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.net.URI;
import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

public abstract class AbstractTokenConnectorTest {

    public static final String LABEL = "foobar";
    public static final Integer DEFAULT_LENGTH = 6;
    public static final String TESTKEY_A = "testkey";
    public static final String TESTKEY_B = "testkey1";
    public static final String TESTVALUE_A = "testvalue";
    public static final String TESTVALUE_B = "testvalue1";

    public abstract String getTokenServiceAddress();

    @Test
    public void createDefault() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Token t = connector.createToken(LABEL);
        Assert.assertEquals(t.getLabel(), LABEL);
        Assert.assertEquals(t.getValue().length(), (int) DEFAULT_LENGTH);
    }

    @Test
    public void createSeconds() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        int seconds = 10;
        Token t = connector.createToken(LABEL, (long)seconds, null);
        Assert.assertEquals(t.getLabel(), LABEL);
        Assert.assertEquals(t.getValue().length(), (int) DEFAULT_LENGTH);
    }

    @Test
    public void createLength() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        int length = 10;
        Token t = connector.createToken(LABEL, null, length);
        Assert.assertEquals(t.getLabel(), LABEL);
        Assert.assertEquals(t.getValue().length(), length);
    }

    @Test
    public void useOk() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Token t = connector.createToken(LABEL);
        Assert.assertTrue(connector.useToken(t.getLabel(), t.getValue()));
        Assert.assertFalse(connector.useToken(t.getLabel(), t.getValue()));
    }

    @Test
    public void useFail() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Assert.assertFalse(connector.useToken("value", "token"));
    }

    @Test
    public void checkTrue() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Token t = connector.createToken(LABEL);
        Assert.assertTrue("token present", connector.checkToken(t.getLabel(), t.getValue()).isPresent());
        Token tokenFromCheck = connector.checkToken(t.getLabel(), t.getValue()).get();
        Assert.assertEquals("tokens equals", t, tokenFromCheck);
    }

    @Test
    public void checkFalse() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Assert.assertFalse(connector.checkToken("foobar", "5kldfgl").isPresent());
    }

    @Test
    public void createWithMetadata() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        int seconds = 10;
        Map<String, String> map = Maps.newHashMap();
        map.put(TESTKEY_A, TESTVALUE_A);
        map.put(TESTKEY_B, TESTVALUE_B);
        Token t = connector.createToken(LABEL, (long)seconds, null, map);
        Assert.assertEquals(t.getLabel(), LABEL);
        Assert.assertEquals(t.getValue().length(), (int) DEFAULT_LENGTH);
        Assert.assertEquals(t.getMetadata(TESTKEY_A), Optional.of(TESTVALUE_A));
        Assert.assertEquals(t.getMetadata(TESTKEY_B), Optional.of(TESTVALUE_B));
    }

    @Test()
    public void checkTrueWithMetadata() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        Map<String, String> map = Maps.newHashMap();
        map.put(TESTKEY_A, TESTVALUE_A);
        map.put(TESTKEY_B, TESTVALUE_B);
        Token t = connector.createToken(LABEL, null, null, map);
        Assert.assertTrue("token present", connector.checkToken(t.getLabel(), t.getValue()).isPresent());
        Token tokenFromCheck = connector.checkToken(t.getLabel(), t.getValue()).get();
        Assert.assertEquals("tokens equals", t, tokenFromCheck);
    }

    @Test(expected = TokenServiceInvalidApiCallException.class)
    public void checkNullLabel() throws IOException, TokenServiceException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        connector.createToken(null);
    }

    @Test
    public void wrongValueLength() throws IOException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        try {
            Token t = connector.createToken(LABEL, 100L, 1);
        } catch (TokenServiceException e) {
            Assert.assertNotNull(e.getMessage());
            Assert.assertTrue("Does not consist information about the failure",
                    e.getMessage().toLowerCase().contains("value"));
        }
    }

    @Test
    public void tooLongLabel() throws IOException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        try {
            Token t = connector.createToken("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" +
                    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100L, 8);
        } catch (TokenServiceException e) {
            Assert.assertNotNull(e.getMessage());
            Assert.assertTrue("Does not consist information about the failure",
                    e.getMessage().toLowerCase().contains("label"));
        }
    }

    @Test
    public void wrongValidity() throws IOException {
        TokenServiceConnector connector = new TokenServiceConnector(URI.create(getTokenServiceAddress()), null);
        try {
            Token t = connector.createToken(LABEL, -100L, 10);
        } catch (TokenServiceException e) {
            Assert.assertNotNull(e.getMessage());
            Assert.assertTrue("Does not consist information about the failure",
                    e.getMessage().toLowerCase().contains("duration"));
        }
    }
}
