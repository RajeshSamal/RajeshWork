package integration;

import com.google.common.collect.Maps;
import org.junit.After;
import org.junit.Before;
import play.test.FakeApplication;
import play.test.Helpers;
import play.test.TestServer;

import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenConnectorTest extends AbstractTokenConnectorTest {

    public static final Integer DEFAULT_LENGTH = 6;
    public static final int DEFAULT_DAYS = 14;
    public static final int DEFAULT_MINUTES = 10;
    private TestServer testServer;

    @Override
    public String getTokenServiceAddress() {
        return "http://127.0.0.1:9000";
    }

    @Before
    public void startApp() {
        Map<String, String> testConfig = Maps.newHashMap(Helpers.inMemoryDatabase());
        testConfig.put("db.default.user", "tokengenerator");
        testConfig.put("db.default.password", "tokengenerator");
        testConfig.put("db.default.driver", "com.mysql.jdbc.Driver");
        testConfig.put("db.default.url", "jdbc:mysql://localhost/tokengenerator");
        testConfig.put("token.max-duration", DEFAULT_DAYS + " days");
        testConfig.put("token.defaults.duration", DEFAULT_MINUTES + " minutes");
        testConfig.put("token.defaults.label", "none");
        testConfig.put("token.defaults.length", DEFAULT_LENGTH.toString());
        FakeApplication app = Helpers.fakeApplication(testConfig);
        testServer = new TestServer(9000, app);
        testServer.start();
    }

    @After
    public void stopApp() {
        testServer.stop();
    }
}
