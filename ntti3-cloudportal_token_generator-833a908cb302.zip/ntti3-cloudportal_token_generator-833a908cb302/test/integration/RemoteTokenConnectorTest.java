package integration;

import org.junit.Ignore;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Ignore
public class RemoteTokenConnectorTest extends AbstractTokenConnectorTest {

    @Override
    public String getTokenServiceAddress() {
        return "http://10.226.42.22:9007";
    }
}
