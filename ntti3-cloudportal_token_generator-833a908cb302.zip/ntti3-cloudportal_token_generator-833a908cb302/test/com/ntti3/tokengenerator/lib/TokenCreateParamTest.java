package com.ntti3.tokengenerator.lib;

import com.google.common.collect.Maps;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import play.test.FakeApplication;
import play.test.Helpers;
import play.test.TestServer;

import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenCreateParamTest {

    private FakeApplication app;
    private TestServer testServer;

    @Before
    public void startApp() {
        Map<String, String> testConfig = Maps.newHashMap(Helpers.inMemoryDatabase());
        testConfig.put("db.default.user", "tokengenerator");
        testConfig.put("db.default.password", "tokengenerator");
        testConfig.put("db.default.driver", "com.mysql.jdbc.Driver");
        testConfig.put("db.default.url", "jdbc:mysql://localhost/tokengenerator");
        testConfig.put("token.max-duration", "14 days");
        testConfig.put("token.defaults.duration", "10 minutes");
        testConfig.put("token.defaults.label", "none");
        testConfig.put("token.defaults.length", "6");
        app = Helpers.fakeApplication(testConfig);
        testServer = new TestServer(9000, app);
        testServer.start();
    }

    @After
    public void stopApp() {
        testServer.stop();
    }

    @Test(expected = NullPointerException.class)
    public void labelNull() {
        TokenCreateParam.builder().build();
    }

    @Test
    public void defaults() {
        TokenCreateParam param = TokenCreateParam.builder().label("").build();
        Assert.assertEquals(param.getLabel(), "");
        Assert.assertEquals(param.getValidityDuration(), TokenCreateParam.DEFAULT_DURATION);
        Assert.assertEquals((int)param.getLength(), TokenCreateParam.DEFAULT_LENGTH);
    }

    @Test
    public void correctParam() {
        final String label = "testLabel";
        final long durationSeconds = TokenCreateParam.DEFAULT_DURATION.getStandardSeconds();
        final Integer expectedLength = TokenCreateParam.DEFAULT_LENGTH;
        final TokenCreateParam param = TokenCreateParam.builder()
                .expectedLength(expectedLength)
                .label(label)
                .validityDuration(durationSeconds)
                .build();

        Assert.assertEquals(param.getLength(), expectedLength);
        Assert.assertEquals(param.getLabel(), label);
        Assert.assertEquals(param.getValidityDuration().getStandardSeconds(), durationSeconds);
    }

    @Test(expected = IllegalArgumentException.class)
    public void zeroDuration() {
        final long durationSeconds = 0;
        TokenCreateParam.builder()
                .label("")
                .validityDuration(durationSeconds)
                .build();
    }

    @Test(expected = IllegalArgumentException.class)
    public void minusDuration() {
        final long durationSeconds = -5;
        TokenCreateParam.builder()
                .label("")
                .validityDuration(durationSeconds)
                .build();
    }
}
