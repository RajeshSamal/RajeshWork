# --- !Ups

create table metadata (
  id                        integer auto_increment not null,
  token_id                  integer,
  keyName                   varchar(64),
  value                     varchar(64),
  constraint pk_metadata primary key (id))
;

create table tokens (
  id                        integer auto_increment not null,
  value                     varchar(64),
  label                     varchar(64) not null,
  validUntil                datetime not null,
  version                   datetime not null,
  constraint uq_tokens_value unique (value),
  constraint pk_tokens primary key (id))
;

alter table metadata add constraint fk_metadata_token_1 foreign key (token_id) references tokens (id) on delete restrict on update restrict;
create index ix_metadata_token_1 on metadata (token_id);



# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table metadata;

drop table tokens;

SET FOREIGN_KEY_CHECKS=1;

