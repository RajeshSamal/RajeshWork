# --- !Ups

alter table metadata drop foreign key fk_metadata_token_1;
alter table metadata add constraint fk_metadata_token_1 foreign key (token_id) references tokens (id) on delete cascade on update cascade;

# --- !Downs

alter table metadata drop foreign key fk_metadata_token_1;
alter table metadata add constraint fk_metadata_token_1 foreign key (token_id) references tokens (id) on delete restrict on update restrict;