import com.google.inject.Guice;
import com.google.inject.Injector;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import com.ntti3.tokengenerator.lib.exceptions.handlers.TokenExeptionsHandlerModule;
import com.ntti3.tokengenerator.lib.guice.DefaultTokenGeneratorModule;
import com.ntti3.tokengenerator.lib.guice.DefaultTokenManagerModule;
import play.Application;
import play.GlobalSettings;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.SimpleResult;

import java.lang.reflect.Method;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class Global extends GlobalSettings {

    private static final String TOKEN_GENERATOR = "token-generator";
    private Injector injector;

    @Override
    public void onStart(Application app) {
        super.onStart(app);
        injector = Guice.createInjector(
                new DefaultTokenGeneratorModule(),
                new DefaultTokenManagerModule(),
                new TokenExeptionsHandlerModule(),
                new BuildInfoReaderModule(TOKEN_GENERATOR)
        );
    }

    @Override
    public Action onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return injector.getInstance(controllerClass);
    }

    @Override
    public F.Promise<SimpleResult> onBadRequest(Http.RequestHeader request, String error) {
        return handleBadRequest(request);
    }

    @Override
    public F.Promise<SimpleResult> onHandlerNotFound(Http.RequestHeader request) {
        return handleBadRequest(request);
    }

    private F.Promise<SimpleResult> handleBadRequest(Http.RequestHeader request) {
        return F.Promise.<SimpleResult>pure(Controller.badRequest(ResponseHelper.errorResponse(ErrorCode
                .INCORRECT_CALL, "Bad request path",
                "Request path: " + request.path() + " is incorrect")));
    }
}
