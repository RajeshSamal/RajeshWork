package com.ntti3.tokengenerator.lib;

import com.google.common.base.Optional;
import com.ntti3.tokengenerator.lib.exceptions.TokenSavingException;
import com.ntti3.tokengenerator.models.Token;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface TokenManager {

    Token generate(TokenCreateParam param) throws TokenSavingException;

    boolean useToken(String label, String value);

    Optional<Token> checkToken(String label, String value);

    int deleteInvalidTokens();
}
