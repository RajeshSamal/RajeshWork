package com.ntti3.tokengenerator.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenParamException extends TokenException {
    public TokenParamException() {
        super();
    }

    public TokenParamException(String message) {
        super(message);
    }

    public TokenParamException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenParamException(Throwable cause) {
        super(cause.getMessage(), cause);
    }
}
