package com.ntti3.tokengenerator.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenInvalidApiCallException extends TokenException {
    public TokenInvalidApiCallException() {
        super();
    }

    public TokenInvalidApiCallException(String message) {
        super(message);
    }

    public TokenInvalidApiCallException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenInvalidApiCallException(Throwable cause) {
        super(cause);
    }
}
