package com.ntti3.tokengenerator.lib.exceptions.handlers;

import com.google.inject.PrivateModule;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.excetions.handling.SimpleExceptionHandler;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.tokengenerator.lib.exceptions.TokenException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenExeptionsHandlerModule extends PrivateModule {
    private final GlobalExceptionsHandler globalExceptionsHandler;

    public TokenExeptionsHandlerModule() {
        globalExceptionsHandler = new GlobalExceptionsHandler();

        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(
                TokenException.class, ErrorCode.INCORRECT_CALL, "Invalid API request"));
    }

    @Override
    protected void configure() {
        bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
        expose(GlobalExceptionsHandler.class);
    }

    @Override
    public int hashCode() {
        return TokenExeptionsHandlerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return TokenExeptionsHandlerModule.class.equals(obj.getClass());
    }
}
