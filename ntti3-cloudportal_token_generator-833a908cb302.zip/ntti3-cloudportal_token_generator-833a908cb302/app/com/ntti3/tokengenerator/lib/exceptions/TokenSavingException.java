package com.ntti3.tokengenerator.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TokenSavingException extends TokenException {
    public TokenSavingException() {
        super();
    }

    public TokenSavingException(String message) {
        super(message);
    }

    public TokenSavingException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenSavingException(Throwable cause) {
        super(cause);
    }
}
