package com.ntti3.tokengenerator.lib;

import com.avaje.ebean.Ebean;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.tokengenerator.lib.exceptions.TokenSavingException;
import com.ntti3.tokengenerator.models.Metadata;
import com.ntti3.tokengenerator.models.Token;
import org.joda.time.DateTime;
import play.Logger;

import javax.persistence.PersistenceException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultTokenManager implements TokenManager {

    private final TokenGenerator tokenGenerator;
    private final String USE_TOKEN_SQL;
    private final String DELETE_INVALID_TOKENS_SQL;
    private final int MAX_RETRIES;

    @Inject
    public DefaultTokenManager(TokenGenerator tokenGenerator, Properties properties) {
        this.tokenGenerator = tokenGenerator;
        USE_TOKEN_SQL = getPropertyNotNull(properties, "use-token-sql");
        DELETE_INVALID_TOKENS_SQL = getPropertyNotNull(properties, "delete-invalid-tokens-sql");
        MAX_RETRIES = getPropertyInt(properties, "max-retries");
    }

    @Override
    public Token generate(TokenCreateParam param) throws TokenSavingException {
        Token savedToken = null;
        Token generatedToken;
        Exception lastException = null;
        List<Metadata> metadataList = new ArrayList<Metadata>();
        for(Map.Entry<String, String> entry : param.getMetadata().entrySet()) {
            metadataList.add(new Metadata(entry.getKey(), entry.getValue()));
        }
        int counter = 0;
        do {
            generatedToken = tokenGenerator.generate(
                    param.getLength(),
                    param.getLabel(),
                    param.getValidityDuration(),
                    metadataList);
            try {
                generatedToken.save();
                generatedToken.refresh();
                savedToken = generatedToken;
            } catch (PersistenceException e) {
                lastException = e;
                Logger.warn(String.format("Can not save generated token %s (retries %d)", generatedToken, counter), e);
                counter++;
            }
        }
        while(counter < MAX_RETRIES && savedToken == null);

        if (savedToken == null) {
            throw new TokenSavingException("Token save retries exceeded", lastException);
        }

        return savedToken;
    }

    @Override
    public boolean useToken(String label, String value) {
        return 1 == Ebean.createUpdate(Token.class, USE_TOKEN_SQL)
                .setParameter("value", value)
                .setParameter("label", label)
                .setParameter("validUntil", DateTime.now())
                .execute();
    }

    @Override
    public Optional<Token> checkToken(String label, String value) {
        return Optional.fromNullable(Ebean.find(Token.class)
                .where()
                .eq(Token.VALUE_COLUMN, value)
                .eq(Token.LABEL_COLUMN, label)
                .findUnique());
    }

    @Override
    public int deleteInvalidTokens() {
        return Ebean.createUpdate(Token.class, DELETE_INVALID_TOKENS_SQL)
                .setParameter("validUntil", DateTime.now())
                .execute();
    }

    public static String getPropertyNotNull(Properties properties, String key) {
        final String propertyValue = properties.getProperty(key);
        Preconditions.checkNotNull(propertyValue,
                String.format("Missing property at key %s in DefaultTokenManager property file", key));
        return propertyValue;
    }

    public static int getPropertyInt(Properties properties, String key) {
        final String propertyValue = getPropertyNotNull(properties, key);
        final int propertyIntValue;
        try {
            propertyIntValue = Integer.parseInt(propertyValue);
        } catch (NumberFormatException e) {
            throw new NumberFormatException(
                    String.format("Property at key %s in DefaultTokenManager property file is NOT an integer!", key));
        }
        return propertyIntValue;
    }
}
