package com.ntti3.tokengenerator.lib;

import com.google.common.base.Optional;
import com.ntti3.tokengenerator.models.Metadata;
import com.ntti3.tokengenerator.models.Token;
import org.joda.time.Duration;
import play.Configuration;
import play.Play;

import javax.annotation.concurrent.Immutable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class TokenCreateParam {

    public static final int DEFAULT_LENGTH;
    public static final Duration DEFAULT_DURATION;

    static {
        Configuration tokenConfiguration = Play.application().configuration().getConfig("token");

        //defaults
        Configuration defaults = tokenConfiguration.getConfig("defaults");
        DEFAULT_LENGTH = defaults.getInt("length");
        DEFAULT_DURATION = Duration.millis(defaults.getMilliseconds("duration"));
    }

    public static class Builder {
        private Integer expectedLength;
        private String label;
        private Duration validityDuration;
        private Map<String, String> metadata;

        public Builder expectedLength(Integer expectedLength) {
            this.expectedLength = expectedLength;
            return this;
        }

        public Builder label(String label) {
            this.label = label;
            return this;
        }

        public Builder validityDuration(Long validityDurationSeconds) {
            if (validityDurationSeconds == null) {
                this.validityDuration = null;
            } else {
                this.validityDuration
                        = Duration.standardSeconds(validityDurationSeconds);
            }
            return this;
        }

        public Builder metadata(Map<String, String> metadata) {
            this.metadata = metadata;
            return this;
        }

        public TokenCreateParam build() {
            return new TokenCreateParam(
                    expectedLength,
                    label,
                    validityDuration,
                    metadata);
        }

        public Builder from(TokenCreateParam tokenCreateParam) {
            Builder builder = new Builder();
            builder.expectedLength = tokenCreateParam.expectedLength;
            builder.label = tokenCreateParam.label;
            builder.validityDuration = tokenCreateParam.validityDuration;
            return builder;
        }

        @Override
        public String toString() {
            return "Builder{" +
                    "expectedLength=" + expectedLength +
                    ", label='" + label + '\'' +
                    ", validityDuration=" + validityDuration +
                    ", metadata=" + metadata +
                    '}';
        }
    }

    private final Integer expectedLength;
    private final String label;
    private final Duration validityDuration;
    private final Map<String, String> metadata;

    public static Builder builder() {
        return new Builder();
    }

    public Integer getLength() {
        return expectedLength;
    }

    public String getLabel() {
        return label;
    }

    public Duration getValidityDuration() {
        return validityDuration;
    }

    public Map<String, String> getMetadata() { return metadata; }

    private TokenCreateParam(Integer expectedLength, String label, Duration validityDuration, Map<String, String> metadata) {
        this.expectedLength = Optional.fromNullable(expectedLength).or(DEFAULT_LENGTH);
        this.label = label;
        this.validityDuration = Optional.fromNullable(validityDuration).or(DEFAULT_DURATION);
        this.metadata = Optional.fromNullable(metadata).or(new HashMap<String, String>());
        verify();
    }

    private void verify() {
        Token.checkLabel(label);
        Token.checkValueLength(expectedLength);
        Token.checkDuration(validityDuration);
        Metadata.checkMap(metadata);
    }

    @Override
    public String toString() {
        return "TokenCreateParam{" +
                "expectedLength=" + expectedLength +
                ", label='" + label + '\'' +
                ", validityDuration=" + validityDuration +
                ", metadata=" + metadata +
                '}';
    }
}
