package com.ntti3.tokengenerator.lib;

import com.google.inject.Singleton;
import com.ntti3.tokengenerator.models.Metadata;
import com.ntti3.tokengenerator.models.Token;
import org.apache.commons.lang3.RandomStringUtils;
import org.joda.time.DateTime;
import org.joda.time.Duration;

import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class DefaultTokenGenerator implements TokenGenerator {

    @Override
    public Token generate(int length, String label, Duration validityDuration, List<Metadata> metadataList) {
        final String tokenValue = RandomStringUtils.randomAlphanumeric(length);
        return new Token(tokenValue, label, DateTime.now().plus(validityDuration), metadataList);
    }
}
