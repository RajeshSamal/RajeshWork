package com.ntti3.tokengenerator.lib;

import com.ntti3.tokengenerator.models.Metadata;
import com.ntti3.tokengenerator.models.Token;
import org.joda.time.Duration;

import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface TokenGenerator {

    Token generate(int length, String label, Duration validityDuration, List<Metadata> metadataList);
}
