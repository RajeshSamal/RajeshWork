package com.ntti3.tokengenerator.lib.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.ntti3.tokengenerator.lib.DefaultTokenGenerator;
import com.ntti3.tokengenerator.lib.TokenGenerator;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultTokenGeneratorModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(TokenGenerator.class).to(DefaultTokenGenerator.class).in(Singleton.class);
    }

    @Override
    public int hashCode() {
        return DefaultTokenGeneratorModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultTokenGeneratorModule.class.equals(obj.getClass());
    }
}
