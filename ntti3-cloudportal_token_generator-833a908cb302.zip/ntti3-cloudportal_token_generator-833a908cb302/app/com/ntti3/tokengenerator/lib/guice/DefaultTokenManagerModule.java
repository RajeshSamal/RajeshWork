package com.ntti3.tokengenerator.lib.guice;

import com.google.inject.PrivateModule;
import com.ntti3.tokengenerator.lib.DefaultTokenManager;
import com.ntti3.tokengenerator.lib.TokenManager;
import play.Play;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultTokenManagerModule extends PrivateModule {

    private final String DEFAULT_PROPERTIES_FILE = "default-token-manager.conf";
    private final Properties properties;

    public DefaultTokenManagerModule() {
        try (InputStream propInputStream = Play.application().classloader().getResourceAsStream(DEFAULT_PROPERTIES_FILE)) {
            properties = new Properties();
            properties.load(propInputStream);
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Could not find DefaultTokenManager properties file", e);
        } catch (IOException e) {
            throw new RuntimeException("Could not read DefaultTokenManager properties file", e);
        }
    }

    @Override
    protected void configure() {
        bind(Properties.class).toInstance(properties);
        bind(TokenManager.class).to(DefaultTokenManager.class);
        expose(TokenManager.class);
    }

    @Override
    public int hashCode() {
        return DefaultTokenManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultTokenManagerModule.class.equals(obj);
    }
}
