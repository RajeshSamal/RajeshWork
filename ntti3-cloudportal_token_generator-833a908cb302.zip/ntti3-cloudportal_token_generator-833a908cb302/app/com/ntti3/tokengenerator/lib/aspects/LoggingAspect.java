package com.ntti3.tokengenerator.lib.aspects;

import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

    @Pointcut("execution(* com.ntti3.tokengenerator.controllers.*.*(..)) && ! execution(* com.ntti3.tokengenerator.controllers.Reverse*.*(..))"
            +"&& ! execution(* com.ntti3.tokengenerator.controllers.*.*$*(..))")
    @Override
    public void controllerMethodPointcut() {
    }

    @Pointcut("within(com.ntti3.tokengenerator.lib..*)")
    @Override
    public void applicationMethodPointcut() {
    }

    @Override
    public String getPathContains() {
        return "token-generator";
    }
}
