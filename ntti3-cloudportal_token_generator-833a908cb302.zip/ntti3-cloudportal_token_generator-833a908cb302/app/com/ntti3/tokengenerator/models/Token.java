package com.ntti3.tokengenerator.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Preconditions;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Duration;
import org.joda.time.ReadableInstant;
import play.Configuration;
import play.Play;
import play.db.ebean.Model;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a token. Token has it's value (sequence of alphanumeric characters)
 * and a label defining token's purpose.
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Entity
@Immutable
@Table(name = Token.TOKENS_TABLE)
public class Token extends Model {

    public static final String TOKENS_TABLE = "tokens";
    public static final String VALID_UNTIL_COLUMN = "validUntil";
    public static final String LABEL_COLUMN = "label";
    public static final String VALUE_COLUMN = "value";

    public static final int VALUE_MAX_LENGTH = 64;
    public static final int VALUE_MIN_LENGTH = 6;
    public static final int LABEL_MAX_LENGTH = 64;


    public static final Duration DEFAULT_DURATION;
    public static final String DEFAULT_DURATION_STRING;
    public static final Duration MAX_DURATION;
    public static final String MAX_DURATION_STRING;

    static {
        Configuration tokenConfiguration = Play.application().configuration().getConfig("token");
        MAX_DURATION = Duration.millis(tokenConfiguration.getMilliseconds("max-duration"));
        MAX_DURATION_STRING = tokenConfiguration.getString("max-duration");

        //defaults
        Configuration defaults = tokenConfiguration.getConfig("defaults");
        DEFAULT_DURATION = Duration.millis(defaults.getMilliseconds("duration"));
        DEFAULT_DURATION_STRING = defaults.getString("duration");
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private final Integer id;

    @Column(name = VALUE_COLUMN, length = VALUE_MAX_LENGTH, unique = true)
    private final String value;

    @NotNull
    @Column(name = LABEL_COLUMN, length = LABEL_MAX_LENGTH, nullable = false)
    private final String label;

    @NotNull
    @Column(name = VALID_UNTIL_COLUMN, nullable = false)
    private final DateTime validUntil;

    @OneToMany(cascade=CascadeType.ALL)
    private final List<Metadata> metadata;

    @Version
    private Timestamp version;

    public Token(String value, String label, DateTime validUntil, List<Metadata> metadata) {
        id = null;
        this.value = value;
        this.label = label;
        this.validUntil = validUntil;
        this.metadata = metadata;
        verify();
    }

    public Token(String value, String label, DateTime validUntil) {
        id = null;
        this.value = value;
        this.label = label;
        this.validUntil = validUntil;
        this.metadata = null;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(value, "Token's value can not be null");
        checkValueLength(value.length());
        Preconditions.checkNotNull(validUntil, "Token's validUntil can not be null");
        checkLabel(label);
    }

    @JsonIgnore
    public int getId() { return id; }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    @JsonIgnore
    public List<Metadata> getMetadata() { return metadata; }

    @JsonProperty(value = "metadata")
    public Map<String, String> getMetadataMap() {
        Map<String, String> result = new HashMap<String, String>();
        for(Metadata m : metadata) {
            result.put(m.getKeyName(), m.getValue());
        }
        return result;
    }

    @JsonIgnore
    public DateTime getValidUntil() {
        return validUntil;
    }

    @JsonProperty(value = "validUntil")
    public String getValidUntilString() { return validUntil.withZone(DateTimeZone.UTC).toString(); }

    /**
     * Checks if the token is valid at a certain instant.
     * @param at
     * @return
     */
    public boolean isValid(@Nullable ReadableInstant at) {
        return validUntil.isAfter(at) || validUntil.isEqual(at);
    }

    /**
     * Checks if the token is valid now.
     * @return
     */
    @JsonIgnore
    public boolean isValid() {
        return isValid(null);
    }

    public static void checkValueLength(int length) {
        Preconditions.checkArgument(length <= VALUE_MAX_LENGTH,
                String.format("Token's value can not be longer than %d characters", VALUE_MAX_LENGTH));
        Preconditions.checkArgument(length >= VALUE_MIN_LENGTH,
                String.format("Token's value can not be shorter than %d characters", VALUE_MIN_LENGTH));
    }

    public static void checkLabel(String label) {
        Preconditions.checkNotNull(label, "Token label can not be null");
        Preconditions.checkArgument(label.length() <= LABEL_MAX_LENGTH,
                String.format("Token's label can not be longer than %d characters", LABEL_MAX_LENGTH));
    }

    public static void checkDuration(Duration validityDuration) {
        Preconditions.checkNotNull(validityDuration);
        Preconditions.checkArgument(validityDuration.isLongerThan(Duration.ZERO),
                "Token's duration length must be positive.");
        Preconditions.checkArgument(validityDuration.isEqual(DEFAULT_DURATION)
                        || validityDuration.isShorterThan(MAX_DURATION),
                String.format("Token's validity duration can not be longer than %s", MAX_DURATION_STRING));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Token token = (Token) o;

        if (label != null ? !label.equals(token.label) : token.label != null) return false;
        if (validUntil != null ? !validUntil.equals(token.validUntil) : token.validUntil != null) return false;
        if (value != null ? !value.equals(token.value) : token.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = value != null ? value.hashCode() : 0;
        result = 31 * result + (label != null ? label.hashCode() : 0);
        result = 31 * result + (validUntil != null ? validUntil.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Token{" +
                "id=" + id +
                ", value='" + value + '\'' +
                ", label='" + label + '\'' +
                ", validUntil=" + validUntil +
                ", metadata=" + metadata +
                ", version=" + new DateTime(version) +
                '}';
    }
}
