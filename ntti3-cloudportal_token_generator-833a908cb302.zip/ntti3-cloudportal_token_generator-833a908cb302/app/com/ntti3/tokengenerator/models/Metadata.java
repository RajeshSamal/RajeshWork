package com.ntti3.tokengenerator.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Preconditions;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.persistence.*;
import java.util.Map;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
@Entity
@Table(name = Metadata.METADATA_TABLE)
public class Metadata extends Model {

    public static final String METADATA_TABLE = "metadata";
    public static final String KEY_COLUMN = "keyName";
    public static final String VALUE_COLUMN = "value";

    public static final int KEY_MAX_LENGTH = 64;
    public static final int VALUE_MAX_LENGTH = 64;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Constraints.Required
    @ManyToOne(cascade = CascadeType.ALL)
    private Token token;

    @Column(name = KEY_COLUMN, length = KEY_MAX_LENGTH)
    private final String keyName;

    @Column(name = VALUE_COLUMN, length = VALUE_MAX_LENGTH)
    private final String value;

    public Metadata(final Token token, final String keyName, final String value) {
        this.token = token;
        this.keyName = keyName;
        this.value = value;
        verify();
    }

    public Metadata(final String keyName, final String value) {
        this(null, keyName, value);
    }

    @JsonIgnore
    public Token getToken() {
        return token;
    }

    public String getKeyName() {
        return keyName;
    }

    public String getValue() {
        return value;
    }

    private void verify() {
        checkKey(keyName);
        checkValue(value);
    }

    public static void checkMap(Map<String, String> metadataMap) {
        for(Map.Entry<String, String> entry : metadataMap.entrySet()) {
            checkKey(entry.getKey());
            checkValue(entry.getValue());
        }
    }

    public static void checkKey(String key) {
        Preconditions.checkArgument(key.length() <= KEY_MAX_LENGTH,
                String.format("Metadata key can not be longer than %d characters", KEY_MAX_LENGTH));
    }

    public static void checkValue(String value) {
        Preconditions.checkArgument(value.length() <= VALUE_MAX_LENGTH,
                String.format("Metadata value can not be longer than %d characters", VALUE_MAX_LENGTH));
    }
}
