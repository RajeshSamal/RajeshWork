package com.ntti3.tokengenerator.controllers;

import com.google.common.base.Optional;
import com.google.inject.Inject;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.tokengenerator.lib.TokenCreateParam;
import com.ntti3.tokengenerator.lib.TokenManager;
import com.ntti3.tokengenerator.lib.exceptions.TokenInvalidApiCallException;
import com.ntti3.tokengenerator.lib.exceptions.TokenParamException;
import com.ntti3.tokengenerator.lib.exceptions.TokenSavingException;
import com.ntti3.tokengenerator.models.Token;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import play.data.DynamicForm;
import play.data.Form;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.nio.charset.Charset;
import java.util.*;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@ControllerExceptionSupport.ExceptionHandler()
public class TokenController extends Controller {

    private final TokenManager tokenManager;

    @Inject
    public TokenController(TokenManager tokenManager) {
        this.tokenManager = tokenManager;
    }

    public Result index() {
        return ok("Token-generator");
    }

    public Result create() throws TokenInvalidApiCallException, TokenSavingException, TokenParamException {
        DynamicForm requestData = Form.form().bindFromRequest();
        final String label = requestData.get("label");
        final String secondsString = requestData.get("seconds");
        final String lengthString = requestData.get("length");
        final String metadataEncodedString = requestData.get("metadata");

        final Long seconds;
        if (secondsString != null) {
            try {
                seconds = Long.parseLong(secondsString);
            } catch (NumberFormatException e) {
                throw new TokenInvalidApiCallException("'Seconds' field must be a number or be empty!", e);
            }
        } else {
            seconds = null;
        }

        final Integer length;
        if (lengthString == null) {
            length = null;
        } else {
            try {
                length = Integer.parseInt(lengthString);
            } catch (NumberFormatException e) {
                throw new TokenInvalidApiCallException("'Length' field must be a number or be empty!", e);
            }
        }

        final Map<String, String> metadataMap;
        if(metadataEncodedString == null) {
            metadataMap = null;
        } else {
            metadataMap = new HashMap<String, String>();
            for(NameValuePair pair : URLEncodedUtils.parse(metadataEncodedString, Charset.forName("UTF-8"))) {
                metadataMap.put(pair.getName(), pair.getValue());
            }
        }

        final TokenCreateParam param;
        try {
            param = TokenCreateParam.builder()
                    .label(label)
                    .validityDuration(seconds)
                    .expectedLength(length)
                    .metadata(metadataMap).build();
        } catch (NullPointerException | IllegalArgumentException e) {
            throw new TokenParamException(e);
        }


        return ok(Json.toJson(tokenManager.generate(param)));
    }

    public Result useToken(String label, String value) throws TokenParamException {
        if (tokenManager.useToken(label, value)) {
            return ok("+");
        } else {
            return notFound("-");
        }
    }

    public Result checkToken(String label, String value) throws TokenParamException {
        Optional<Token> tokenOptional = tokenManager.checkToken(label, value);
        if (tokenOptional.isPresent()) {
            Token tokenObject = tokenOptional.get();
            if (tokenObject.isValid()) {
                return ok(Json.toJson(tokenObject));
            }
        }

        return notFound();
    }

    public Result deleteInvalidTokens() {
        return ok(Integer.toString(tokenManager.deleteInvalidTokens()));
    }
}
