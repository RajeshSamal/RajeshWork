/**
 * plugin.js
 *
 * Copyright, Moxiecode Systems AB
 * Released under LGPL License.
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */

/*global tinymce:true */

tinymce.PluginManager.add('advlistformatable', function(editor) {
	var olMenuItems, ulMenuItems, lastFormats = {},
	    listFormats = { 'OL': [], 'UL': [] },
	    defaultFormats = {
	        'OL': {
	            upperAlpha: {selector: 'ol', classes: 'upper-alpha'},
                lowerAlpha: {selector: 'ol', classes: 'lower-alpha'},
                upperRoman: {selector: 'ol', classes: 'upper-roman'},
                lowerRoman: {selector: 'ol', classes: 'lower-roman'},
                multiLevel: {selector: 'ol', classes: 'multi-level'}
	        },
	        'UL': {
	            circle: {selector: 'ul', classes: 'circle'},
                square: {selector: 'ul', classes: 'square'},
                disc: {selector: 'ul', classes: 'disc'}
	        }
	    }

	function buildMenuItems(listName, formats) {
		var items = [];

		tinymce.each(formats.split(/[ ,]/), function(format) {
			items.push({
				text: format.replace(/\W+/g, ' ').replace(/([a-z\d])([A-Z])/g, '$1 $2').replace(/\b\w/g, function(chr) {
					return chr.toUpperCase();
				}),
				data: format == 'default' ? '' : format
			});
			if (format !== 'default') { listFormats[listName].push(format); }
		});

		return items;
	}

	olMenuItems = buildMenuItems('OL', editor.getParam(
		"advlistformatable_number_formats",
		"default,lowerAlpha,lowerRoman,upperAlpha,upperRoman,multiLevel"
	));

	ulMenuItems = buildMenuItems('UL', editor.getParam("advlistformatable_bullet_formats", "default,circle,disc,square"));

	function applyListFormat(listName, format) {
		var list, dom = editor.dom, sel = editor.selection;

		// Check for existing list element
		list = dom.getParent(sel.getNode(), 'ol,ul');

		// Switch/add list type if needed
		if (!list || list.nodeName != listName || format === false) {
			editor.execCommand(listName == 'UL' ? 'InsertUnorderedList' : 'InsertOrderedList');
		}

		// Set style
		format = format === false ? lastFormats[listName] : format;
		lastFormats[listName] = format;
		list = dom.getParent(sel.getNode(), 'ol,ul');
		if (list) {
		    if (format && editor.formatter.get(format) === undefined && defaultFormats[listName][format]) {
		        editor.formatter.register(format, defaultFormats[listName][format]);
		    }
		    if (oldFormat = editor.formatter.matchAll(listFormats[listName])[0]) {
		        editor.formatter.remove(oldFormat)
		    }
		    editor.formatter.apply(format);
			list.removeAttribute('data-mce-style');
		}

		editor.focus();
	}

	function updateSelection(listName, control) {
	    var node = editor.dom.getParent(editor.selection.getNode(), 'ol,ul'),
	        listFormat = editor.formatter.matchAll(listFormats[listName])[0];
	    if (node !== null && listFormat) {
	        if (!editor.formatter.matchNode(node,listFormat)) { listFormat = ""; }
	        control.items().each(function(ctrl) {
                ctrl.active(ctrl.settings.data === listFormat);
            });
	    } else {
	        control.items().each(function(ctrl) {
                ctrl.active(false);
            });
	    };
	}

	editor.addButton('numlist', {
		type: 'splitbutton',
		tooltip: 'Numbered list',
		menu: olMenuItems,
		onshow: function(e){
		    updateSelection('OL', e.control)
		},
		onselect: function(e) {
			applyListFormat('OL', e.control.settings.data);
		},
		onclick: function() {
			applyListFormat('OL', false);
		}
	});

	editor.addButton('bullist', {
		type: 'splitbutton',
		tooltip: 'Bullet list',
		menu: ulMenuItems,
		onshow: function(e){
            updateSelection('UL', e.control)
        },
		onselect: function(e) {
			applyListFormat('UL', e.control.settings.data);
		},
		onclick: function() {
			applyListFormat('UL', false);
		}
	});
});