tinymce.PluginManager.add('newrootblock', function(editor) {
    var dr = editor.settings.forced_root_block;
    var s = new tinymce.html.Schema();
    if (!s.isValid(dr)) {
        err = new Error("TinyMCE nwerootblock plugin requires forced_root_block parameter defined as a valid html tag.");
        console.error(err.message,err.stack);
        return false;
    }

    var dra = editor.getParam('forced_root_block_attrs',{});
    var active = editor.getParam('keep_root_block',false);
    watch();
    var $ = tinymce.dom.DomQuery;

	editor.addMenuItem('insertnewroot', {
		text: 'Insert root block',
		menu: [
		    {text: 'Before', data: 'after'},
		    {text: 'After', data: 'before'}
		],
		onclick: function(e) {
		    var node = editor.dom.getParent(editor.selection.getNode(), 'body > *');
		    insertNewRoot({d: e.control.settings.data, n: node});
		}
	});

	editor.addMenuItem('appendnewroot', {
        text: 'Keep default root block',
        tooltip: 'Select this option, to always append an empty <' + dr + '> tag to the end of the document if its missing.',
        selectable: true,
        active: active,
        onclick: toggleWatch
    });

	function insertNewRoot(data){
	    var mode = data.d || 'before';
        var rn = editor.dom.create(dr,dra,'<br data-mce-bogus="1">');
        $(data.n)[mode](rn);
	}

	function toggleWatch(){
        active = !active
        this.active(active)
        watch();
	}

	function watch(){
	    if (active) {
            editor.on('BeforeAddUndo', check);
        } else {
            editor.off('BeforeAddUndo', check);
        }
	}

	function check(e){
        var lrb = editor.dom.select('body > *:last-child')[0];
        if (lrb.tagName !== dr.toUpperCase() && lrb.className !== 'mce-resizehandle') {
            insertNewRoot({n: lrb});
            return;
        }
	}
});