#!/bin/bash

. ./deploy.conf

service ${APPNAME} stop
su - ${USER} -c "rm -fr ${PROJECTNAME}-${VERSION}"
su - ${USER} -c "unzip ${PACKAGENAME}-${VERSION}.zip"

if [ ! -e /home/${USER}/$APPNAME.dir ] ; then 
    su - ${USER} -c "mkdir /home/${USER}/${APPNAME}.dir"
    su - ${USER} -c "cp -r ${PROJECTNAME}-${VERSION}/conf /home/${USER}/${APPNAME}.dir/"
fi

service ${APPNAME} start
