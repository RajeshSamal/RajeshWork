import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.TypeLiteral;
import com.ntti3.adminpanel.lib.exceptions.handlers.AdminPanelExceptionsHandlerModule;
import com.ntti3.adminpanel.lib.fakesession.FakeSessionModule;
import com.ntti3.billings.api.client.guice.DefaultApiClientModule;
import com.ntti3.billings.settings.reports.guice.DefaultUsageReportsSettingsManagerModule;
import com.ntti3.cms.Cms;
import com.ntti3.cms.DefaultCms;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ContentDirectory;
import com.ntti3.gums.guice.DefaultGumsConnectorFromConfigModule;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.pingfederate.connector.SPProtocolHelperFactory;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.guava.CookieUserSessionModule;
import com.ntti3.urlhelper.UrlHelper;
import play.*;
import play.data.format.Formatters;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Results;
import play.mvc.SimpleResult;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.Map;

/**
 * @author jan.karwowski@ntti3.com
 */
public class Global extends GlobalSettings {
    public static final String OVERRIDE_SESSION = "override-session";
    private static final String CONFIG_FILE_SP_ENTRY_KEY = "pfhelper.sp";
    private static final String APPLICATION_BASE_URL_CONFIG_KEY = "application.baseUrl";
    private static final String BMM_ADDRESS = "bmm-address";
    private static final String BMM_X_ACCEL_ADDRESS = "bmm-x-accel-address";
    private static final String BMM_API_VERSION = "bmm-api-version";
    private static final String GUMS_CONFIG_PREFIX = "gums";
    private static final String USER_UUID = "override-uuid";
    public static final String VHOSTS_CONFIG_KEY = "vhosts";
    public static final String ADMINPANEL = "adminpanel";
    private volatile Injector injector;
    private Cms cms;

    @Override
    public void onStart(Application app) {
        super.onStart(app);
        cms = new DefaultCms();

        DefaultGumsConnectorFromConfigModule gumsConnectorFromConfigModule;
        DefaultApiClientModule defaultApiClientModule;

        try {
            defaultApiClientModule = createDefaultApiClientModule();
            gumsConnectorFromConfigModule = new DefaultGumsConnectorFromConfigModule(
                    Maps.transformValues(
                            Configuration.root().getConfig(GUMS_CONFIG_PREFIX)
                                    .asMap(), new Function<Object, String>() {
                                @Override
                                public String apply(Object input) {
                                    return input.toString();
                                }
                            }
                    )
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        injector = Guice.createInjector(
                new BuildInfoReaderModule(ADMINPANEL),
                new DefaultUsageReportsSettingsManagerModule(),
                defaultApiClientModule, getSessionModule(),
                gumsConnectorFromConfigModule,
                new AdminPanelExceptionsHandlerModule(),
                getSsoControllerModule(),
                new AbstractModule() {
                    @Override
                    protected void configure() {
                        bind(Cms.class).toInstance(cms);
                    }
                }
        );

        Formatters.register(ContentDirectory.class, new Formatters.SimpleFormatter<ContentDirectory>() {
            @Override
            public ContentDirectory parse(String input, Locale l) {
                return cms.getNode(Long.parseLong(input), CmsType.TYPE_DIRECTORY);
            }

            @Override
            public String print(ContentDirectory cd, Locale l) {
                return cd.getId().toString();
            }
        });
    }

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass)
            throws Exception {
        return injector.getInstance(controllerClass);
    }

    protected DefaultApiClientModule createDefaultApiClientModule() throws URISyntaxException {
        URI billingsAddress = new URI(Play.application().configuration()
                .getString(BMM_ADDRESS));
        String billingsXAccelRedirectUri = Play.application().configuration()
                .getString(BMM_X_ACCEL_ADDRESS);
        int apiVersion = Play.application().configuration()
                .getInt(BMM_API_VERSION);
        return new DefaultApiClientModule(billingsAddress, billingsXAccelRedirectUri, apiVersion);
    }

    protected AbstractModule getSessionModule() {
        if (Play.application().isProd()) {
            return new CookieUserSessionModule();
        } else {
            String overrideSession = Play.application().configuration()
                    .getString(OVERRIDE_SESSION);
            String userUUid = Play.application().configuration()
                    .getString(USER_UUID);
            if (overrideSession != null) {
                if (userUUid != null)
                    return new FakeSessionModule(
                            Role.valueOf(overrideSession), userUUid);
                else
                    return new FakeSessionModule(
                            Role.valueOf(overrideSession));
            }
        }
        throw new RuntimeException("overridesession (superadmin/opcoadmin)");
    }

    @Override
    public F.Promise<SimpleResult> onBadRequest(Http.RequestHeader request,
                                                String error) {
        return handleBadRequest(request);
    }

    @Override
    public F.Promise<SimpleResult> onHandlerNotFound(Http.RequestHeader request) {
        return handleBadRequest(request);
    }

    private static F.Promise<SimpleResult> handleBadRequest(Http.RequestHeader request) {
        return F.Promise.<SimpleResult>pure(Results
                .badRequest(ResponseHelper.errorResponse(
                        ErrorCode.INCORRECT_CALL, "Bad request path",
                        "Request path: " + request.path() + " is incorrect")));
    }

    protected AbstractModule getSsoControllerModule() {
        return new AbstractModule() {

            final VhostInstanceSelector<UrlHelper> urlHelperSelector;
            final VhostInstanceSelector<SPProtocolHelper> spProtocolHelperSelector;
            final VhostInstanceSelector<String> idpParameterSelector;

            {
                SPProtocolHelperFactory spProtocolHelperFactory = new SPProtocolHelperFactory();
                Map<String, UrlHelper> urlHelpersMap = Maps.newHashMap();
                Map<String, SPProtocolHelper> spProtocolHelpersMap = Maps.newHashMap();
                Map<String, String> idpParametersMap = Maps.newHashMap();

                Configuration vhostsConfiguration = Configuration.root().getConfig(VHOSTS_CONFIG_KEY);

                for(String vhost : vhostsConfiguration.subKeys()) {
                    Logger.debug("loading vhost: " + vhost);
                    Configuration vhostConfiguration = Preconditions.checkNotNull(vhostsConfiguration.getConfig("\"" + vhost + "\""),
                            "Can not get vhost configuration for key " + vhost);

                    //url helper
                    urlHelpersMap.put(vhost, new UrlHelper(vhostConfiguration.getString(
                            APPLICATION_BASE_URL_CONFIG_KEY)));

                    // sp protocol helper
                    try {
                        spProtocolHelpersMap.put(vhost, spProtocolHelperFactory.getInstanceFromConfig(
                                Maps.transformValues(
                                        vhostConfiguration
                                                .getConfig(CONFIG_FILE_SP_ENTRY_KEY)
                                                .asMap(), new Function<Object, String>() {
                                    @Override
                                    public String apply(Object input) {
                                        return input.toString();
                                    }
                                }
                                )
                        ));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    //idp parameter
                    idpParametersMap.put(vhost, vhostConfiguration.getString("pfhelper.idp"));
                }

                urlHelperSelector = new VhostInstanceSelector<>(urlHelpersMap);
                spProtocolHelperSelector = new VhostInstanceSelector<>(spProtocolHelpersMap);
                idpParameterSelector = new VhostInstanceSelector<>(idpParametersMap);
            }

            @Override
            protected void configure() {
                bind(new TypeLiteral<VhostInstanceSelector<UrlHelper>>() {}).toInstance(urlHelperSelector);
                bind(new TypeLiteral<VhostInstanceSelector<SPProtocolHelper>>(){}).toInstance(spProtocolHelperSelector);
                bind(new TypeLiteral<VhostInstanceSelector<String>>(){}).toInstance(idpParameterSelector);
            }
        };
    }
}