package com.ntti3.adminpanel.controllers.models;

import play.data.validation.Constraints;

import java.util.List;

/**
 * Created by AdrianW on 2014-06-20.
 */
public class UserEditForm {
    @Constraints.Required
    @Constraints.MaxLength(value = 64)
    private String firstName;
    @Constraints.Required
    @Constraints.MaxLength(value = 64)
    private String lastName;
    @Constraints.Required
    @Constraints.Email
    @Constraints.MaxLength(value = 128)
    private String email;
    private boolean active;
    private List<String> flags;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<String> getFlags() {
        return flags;
    }

    public void setFlags(List<String> flags) {
        this.flags = flags;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
