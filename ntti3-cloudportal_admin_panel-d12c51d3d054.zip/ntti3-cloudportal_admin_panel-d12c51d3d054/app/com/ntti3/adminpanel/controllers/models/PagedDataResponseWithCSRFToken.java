package com.ntti3.adminpanel.controllers.models;

import java.util.List;

import com.ntti3.gums.OrderBy;

public class PagedDataResponseWithCSRFToken<T> extends PagedDataResponse<T> {
	private final String csrfToken;

	public PagedDataResponseWithCSRFToken(int currentPage, int pageCount,
			OrderBy orderBy, List<T> data, String csrfToken) {
		super(currentPage, pageCount, orderBy, data);
		this.csrfToken = csrfToken;
	}

	public String getCsrfToken() {
		return csrfToken;
	}
}
