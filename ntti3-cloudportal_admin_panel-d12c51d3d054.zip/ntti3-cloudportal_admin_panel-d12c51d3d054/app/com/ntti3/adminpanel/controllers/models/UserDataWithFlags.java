package com.ntti3.adminpanel.controllers.models;

import java.util.List;

import com.ntti3.gums.models.User;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author jan.karwowski@ntti3.com
 */
public class UserDataWithFlags {
	private User user;
	private List<String> flags;
	@JsonProperty
	private String csrfToken;

	public UserDataWithFlags(User user, List<String> flags, String csrfToken) {
		this.user = user;
		this.flags = flags;
		this.csrfToken = csrfToken;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<String> getFlags() {
		return flags;
	}

	public void setFlags(List<String> flags) {
		this.flags = flags;
	}

	public String getCsrfToken() {
		return csrfToken;
	}

	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}
	
}
