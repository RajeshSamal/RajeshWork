package com.ntti3.adminpanel.controllers.models;

import java.util.List;

import com.ntti3.gums.Order;
import com.ntti3.gums.OrderBy;

/**
 * @author jan.karwowski@ntti3.com
 */
public class PagedDataResponse<T> {
	int currentPage;
	int pageCount;
	List<T> data;
	private Order order;
	private String orderBy;

	public PagedDataResponse(int currentPage, int pageCount, OrderBy orderBy,
			List<T> data) {
		this.currentPage = currentPage;
		this.pageCount = pageCount;
		this.data = data;
		if (orderBy != null) {
			this.order = orderBy.getOrder();
			this.orderBy = orderBy.getColumn();
		}
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
}
