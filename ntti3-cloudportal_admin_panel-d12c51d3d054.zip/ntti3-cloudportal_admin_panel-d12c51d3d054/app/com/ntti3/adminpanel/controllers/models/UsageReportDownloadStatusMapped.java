package com.ntti3.adminpanel.controllers.models;

import java.io.IOException;

import javax.annotation.concurrent.Immutable;

import org.joda.time.DateTime;

import play.Logger;

import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import com.ntti3.billings.types.reports.UsageReportDownloadStatusType;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.models.Opco;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

@Immutable
public class UsageReportDownloadStatusMapped implements
		Comparable<UsageReportDownloadStatusMapped> {

	public static final String SERVICE_PROPERTY_NAME = "service";
	public static final String UNKNOWN_OPCO_NAME = "Unknown Opco";
	private final String opcoName;
	private final String opcoUid;
	private final ServiceUid serviceUid;
	private final Integer year;
	private final Integer month;
	private final ReportType reportType;
	private final String reportTypeName;
	private final String statusName;
	private final UsageReportDownloadStatusType statusType;
	private final Long downloadTimeMillis;

	public UsageReportDownloadStatusMapped(String opcoName, String opcoUid,
			ServiceUid serviceUid, Integer year, Integer month,
			ReportType reportType, String reportTypeName,
			UsageReportDownloadStatusType statusType,
			DateTime downloadTimeDateTime) {
		this.opcoName = opcoName;
		this.opcoUid = opcoUid;
		this.serviceUid = serviceUid;
		this.year = year;
		this.month = month;
		this.reportType = reportType;
		this.reportTypeName = reportTypeName;
		this.statusName = statusType.getTextRepresentation();
		this.statusType = statusType;

		if (downloadTimeDateTime != null) {
			this.downloadTimeMillis = downloadTimeDateTime.getMillis();
		} else {
			this.downloadTimeMillis = null;
		}
	}

	public static UsageReportDownloadStatusMapped from(
			UsageReportDownloadStatus usageReportDownloadStatus,
			GumsConnector gumsConnector) throws IOException,
			GumsProtocolException {

		Opco opco = gumsConnector.getOpco(usageReportDownloadStatus
				.getOpcoUid().getValue());
		String opcoName;
		if (opco == null) {
			opcoName = UNKNOWN_OPCO_NAME;
			Logger.warn("Gums returned 'null'-Opco for OpcoUid = "
					+ usageReportDownloadStatus.getOpcoUid().getValue());
		} else {
			opcoName = opco.getOpcoName();
		}
		return new UsageReportDownloadStatusMapped(opcoName,
				usageReportDownloadStatus.getOpcoUid().toString(),
				usageReportDownloadStatus.getServiceUid(),
				usageReportDownloadStatus.getYear(),
				usageReportDownloadStatus.getMonth(),
				usageReportDownloadStatus.getReportType(),
				usageReportDownloadStatus.getReportType()
						.getHumanReadableName(),
				usageReportDownloadStatus.getUsageReportDownloadStatusType(),
				usageReportDownloadStatus.getDownloadTime());
	}

	@Override
	public int compareTo(UsageReportDownloadStatusMapped other) {
		// Compare by opcoName, then by status, and then by downloadTimeDateTime
		// (if the report is downloaded).

		if (this == other)
			return 0;

		int opcoNameCompared = this.opcoName.compareTo(other.opcoName);
		if (opcoNameCompared != 0)
			return opcoNameCompared;

		int statusTypeCompared = this.statusType.compareTo(other.statusType);
		if (statusTypeCompared != 0)
			return statusTypeCompared;

		if (statusType.equals(UsageReportDownloadStatusType.OK)) {
			return Long.compare(downloadTimeMillis, other.downloadTimeMillis);
		}

		return 0;
	}

	public String getOpcoName() {
		return opcoName;
	}

	public String getOpcoUid() {
		return opcoUid;
	}

	@JsonProperty(value = SERVICE_PROPERTY_NAME)
	public ServiceUid getServiceUid() {
		return serviceUid;
	}

	public Integer getYear() {
		return year;
	}

	public Integer getMonth() {
		return month;
	}

	public ReportType getReportType() {
		return reportType;
	}

	public String getReportTypeName() {
		return reportTypeName;
	}

	public String getStatusName() {
		return statusName;
	}

	@JsonInclude(Include.NON_NULL)
	public Long getDownloadTimeMillis() {
		return downloadTimeMillis;
	}
}
