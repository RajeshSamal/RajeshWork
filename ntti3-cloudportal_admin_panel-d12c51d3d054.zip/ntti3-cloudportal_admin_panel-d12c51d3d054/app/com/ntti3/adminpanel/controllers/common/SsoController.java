package com.ntti3.adminpanel.controllers.common;

import com.google.inject.Inject;
import com.ntti3.adminpanel.controllers.common.routes;
import com.ntti3.pingfederate.connector.SPProtocolHelper;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.urlhelper.UrlHelper;
import org.apache.http.client.utils.URIBuilder;
import play.Configuration;
import play.mvc.Call;
import play.mvc.Result;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

/**
 * @author jan.karwowski@ntti3.com
 */
@NoCache
@ControllerExceptionSupport.ExceptionHandler
public class SsoController extends com.ntti3.spsso.SsoController {
	@Inject
	public SsoController(
            VhostInstanceSelector<SPProtocolHelper> vhostSPProtocolHelperSelector,
            VhostInstanceSelector<UrlHelper> vhostUrlHelperSelector,
			com.ntti3.spsso.session.UserSessionManager userSessionManager,
            VhostInstanceSelector<String> vhostIdpParameterSelector
    ) {
		super(vhostSPProtocolHelperSelector, vhostUrlHelperSelector, userSessionManager, vhostIdpParameterSelector);
	}

	@Override
	public Result ssoSuccessResult() {
		return ok(views.html.ssoHandler.render());
	}

	@Override
	public Result sloSuccessResult() {
		return ok(views.html.sloHandler.render());
	}

	@Override
	protected Call actionHandlerRoute(String s) {
		return routes.SsoController.actionHandler(s);
	}

	@Override
	protected Call sloSuccessRoute() {
		return routes.SsoController.sloSuccess();
	}

	@Override
	protected Call sloFailureRoute() {
		return routes.AdminPage.index("slo-failed");
	}

	@Override
	protected String getSsoSuccessTarget() throws MalformedURLException, UnknownVhostException {
		return getUrlHelper(request()).absoluteAddress(
				routes.SsoController.ssoSuccessResult());
	}

	public static String getStartSsoUrl() throws URISyntaxException {
		URIBuilder builder = new URIBuilder(Configuration.root().getString(
				"afp.startSso"));
		builder.addParameter("sp",
				Configuration.root().getString("afp.spEntityID"));
		builder.setParameter("errorUrl",
				Configuration.root().getString("afp.errorUrl"));
		return builder.build().toString();
	}

	public Result getStartSsoString() throws URISyntaxException {
		return ok(getStartSsoUrl());
	}

	public Result pfBaseUrl() throws UnknownVhostException {
		return ok(getSpProtocolHelper(request()).getPFBaseURI().toString());
	}
}
