package com.ntti3.adminpanel.controllers.common;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.inject.Inject;
import com.ntti3.cms.Cms;
import com.ntti3.cms.models.BaseContent;
import com.ntti3.cms.models.CmsType;
import com.ntti3.cms.models.ContentDirectory;
import com.ntti3.cms.models.ProductContent;
import com.ntti3.cms.models.WebPageContent;
import com.ntti3.cms.models.form.ContentDirectoryForm;
import com.ntti3.cms.models.form.ProductContentForm;
import com.ntti3.cms.models.form.WebPageContentForm;
import com.ntti3.cms.models.util.BaseContentWeightComparator;
import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.spsso.session.Role;
import play.data.Form;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.Collections;
import java.util.List;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-04-29.
 */
@Authorized(role = Role.SUPER_ADMIN)
public class CmsController extends Controller {
    public static final String DATA = "data";
    public static final String ID = "id";
    //public static final String TITLE = "title";
    //public static final String SUBTITLE = "subtitle";
    public static final String NAME = "name";
    public static final String REMOVABLE = "removable";
    public static final String DIRECTORY = "directory";
    public static final String WEIGHT = "weight";
    public static final String TYPE = "type";
    public static final String ITEMS = "items";
    public static final String SOURCE = "source";
    public static final String DESTINATION = "destination";
    public static final String INDEX = "index";
    //public static final String QUESTIONS = "questions";

    private final Cms cms;

    private static Result jsonOr404(BaseContent content) {
        if(content == null) {
            return notFound();
        }
        ObjectNode response = Json.newObject();
        response.put(DATA,Json.toJson(content));
        return ok(response);
    }

    private ObjectNode treeNodeBuilder(BaseContent content) {
        ObjectNode node = Json.newObject();
        node.put(ID, content.getId());
        node.put(NAME, content.getName());
        node.put(REMOVABLE, content.isRemovable());
        boolean isDir = content.getType().equals(CmsType.TYPE_DIRECTORY);
        node.put(DIRECTORY, isDir);
        node.put(WEIGHT, content.getWeight());
        node.put(TYPE, content.getType().toString());
        ArrayNode children = node.putArray(ITEMS);
        if(isDir) {
            ContentDirectory directory = (ContentDirectory)content;
            List<? extends BaseContent> childrenList = directory.getContent();
            Collections.sort(childrenList, new BaseContentWeightComparator());
            for(BaseContent child : childrenList) {
                children.add(treeNodeBuilder(child));
            }
        }
        return node;
    }

    @Inject
    public CmsController(Cms cms) {
        this.cms = cms;
    }

    public Result getTree() {
        ObjectNode result = Json.newObject();
        ArrayNode tree = result.putArray(DATA);
        List<? extends ContentDirectory> roots = cms.getMainDirectories();
        Collections.sort(roots, new BaseContentWeightComparator());
        for(ContentDirectory dir : roots) {
            tree.add(treeNodeBuilder(dir));
        }
        return ok(result);
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result updateTree() {
        JsonNode changes = request().body().asJson();
        Long nodeId = changes.findValue(ID).asLong();
        String type = changes.findValue(TYPE).asText();
        Long sourceId = changes.findValue(SOURCE).isNull() ? null : changes.findValue(SOURCE).asLong();
        Long destinationId = changes.findValue(DESTINATION).isNull() ? null : changes.findValue(DESTINATION).asLong();
        int index = changes.findValue(INDEX).asInt();

        cms.moveNode(nodeId, CmsType.fromString(type), sourceId, destinationId, index);

        return getTree();
    }

    public Result getPage(long id) {
        WebPageContent page = cms.getNode(id, CmsType.TYPE_WEBPAGE);
        return jsonOr404(page);
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result postPage() {
        Form<WebPageContentForm> form = Form.form(WebPageContentForm.class);
        form = form.bind(request().body().asJson(),"htmlContent","name","parent","id","removable","title","type","url","weight");
        if(form.hasErrors()) {
            return badRequest(form.errorsAsJson());
        }
        cms.saveNode(form.get());
        return ok();
    }

    public Result deletePage(long id) {
        cms.deleteNode(id, CmsType.TYPE_WEBPAGE);
        return ok();
    }

    public Result getProduct(long id) {
        ProductContent product = cms.getNode(id, CmsType.TYPE_PRODUCT);
        return jsonOr404(product);
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result postProduct() {
        Form<ProductContentForm> form = Form.form(ProductContentForm.class);
        form = form.bind(request().body().asJson());
        if(form.hasErrors()) {
            return badRequest(form.errorsAsJson());
        }
        ProductContentForm productContentForm = form.get();
        cms.saveNode(productContentForm);
        return ok();
    }

    public Result deleteProduct(long id) {
        cms.deleteNode(id, CmsType.TYPE_PRODUCT);
        return ok();
    }

    public Result getDirectory(long id) {
        ContentDirectory directory = cms.getNode(id, CmsType.TYPE_DIRECTORY);
        return jsonOr404(directory);
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result postDirectory() {
        Form<ContentDirectoryForm> form = Form.form(ContentDirectoryForm.class);
        form = form.bind(request().body().asJson());
        if(form.hasErrors()) {
            return badRequest(form.errorsAsJson());
        }
        cms.saveNode(form.get());
        return ok();
    }

    public Result deleteDirectory(long id) {
        cms.deleteNode(id, CmsType.TYPE_DIRECTORY);
        return ok();
    }
}
