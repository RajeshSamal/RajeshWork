package com.ntti3.adminpanel.controllers.common;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.ntti3.adminpanel.controllers.models.PagedDataResponseWithCSRFToken;
import com.ntti3.adminpanel.lib.PaginationHelper;
import com.ntti3.gums.*;
import com.ntti3.gums.models.PendingUser;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.play.annotations.csrf.AddCsrfToken;
import com.ntti3.play.annotations.csrf.CheckCsrfToken;
import com.ntti3.play.annotations.csrf.Constants;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import com.ntti3.protocol.CloseableIOIterator;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;
import play.Configuration;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

@Authorized(role = Role.OPCO_ADMIN)
@NoCache
@ExceptionHandler
public class AccountActivation extends Controller {
	private GumsConnector connector;
	private UserSessionManager sessionManager;
	private final int pageSize;

	@Inject
	public AccountActivation(UserSessionManager sessionManager,
			GumsConnector connector) {
		Preconditions.checkNotNull(sessionManager);
		Preconditions.checkNotNull(connector);
		this.connector = connector;
		this.sessionManager = sessionManager;
		pageSize = Configuration.root().getInt("pagination.pageSize");
	}

	@AddCsrfToken
	public Result index() throws GumsProtocolException, PeerIOFailureException {
        //TODO Update getPendingUsers method
		try {
			int currentPage = UserManagement.getPageNumberFromRequest(
					request(), "p");
			OrderBy orderBy = null;
			try {
				if (null != request().getQueryString("order")
						&& null != request().getQueryString("orderBy"))
					if (request().getQueryString("order").equalsIgnoreCase(
							"asc"))
						orderBy = new OrderBy(request().getQueryString(
								"orderBy"), Order.ASC);
					else
						orderBy = new OrderBy(request().getQueryString(
								"orderBy"), Order.DESC);
			} catch (IllegalArgumentException ex) {
				return badRequest();
			}

			UserSession userSession = sessionManager.getSession(session());
			List<PendingUser> usersPage = Lists.newLinkedList();
			List<Integer> uidPage = Lists.newLinkedList();
			final PagedResult<Integer> result;			
			if(userSession.hasRole(Role.SUPER_ADMIN))
			{
			    result = connector.getPendingUsers((currentPage - 1) * pageSize, pageSize, orderBy);
			}
			else
			{
			    result = connector.getOpcoPendingUsers(userSession.getOpcoUid().getValue(),(currentPage - 1) * pageSize, pageSize, orderBy);
			}

			int totalPages = PaginationHelper.calculateTotalPages(result,
					pageSize);

			try (CloseableIOIterator<Integer> uids = result.getResultPage()) {
				while (uids.hasNext()) {
					uidPage.add(uids.next());
				}
			}

			for (Integer id : uidPage) {
				usersPage.add(connector.getPendingUser(id));
			}

			return ok(Json.toJson(new PagedDataResponseWithCSRFToken<>(currentPage,
					totalPages, orderBy, usersPage, getCsrfToken())));
		} catch (IOException ex) {
			throw new PeerIOFailureException(ex);
		}
	}

	private String getCsrfToken() {
		return session(Constants.TOKEN_NAME);
	}

    @CheckCsrfToken
    public Result acceptUser(int id)
            throws GumsProtocolException, PeerIOFailureException {

        JsonNode body = request().body().asJson();
        JsonNode companyNode = body.get("company");
        final String companyId;
        final String companyName;

        if (companyNode != null) {
            companyId = companyNode.get("opco_c_uid").asText();
            companyName = companyNode.get("opco_c_name").asText();
        } else {
            companyId = null;
            companyName = null;
        }

        JsonNode productsNode = body.get("products");
        if (!productsNode.isArray()) {
            return badRequest();
        }

        List<String> products = new ArrayList<>();
        Iterator<JsonNode> productElements = productsNode.elements();
        while (productElements.hasNext())
            products.add(productElements.next().asText());

        try {
            connector.activateUser(id, products, companyId, companyName);
        } catch (IOException ex) {
            throw new PeerIOFailureException(ex);
        }
        return ok();
    }

    @CheckCsrfToken
    public Result rejectUser(int id) throws GumsProtocolException, PeerIOFailureException {
        try {
            connector.removePendingUser(id);
        } catch (IOException ex) {
            throw new PeerIOFailureException(ex);
        }
        return ok();
    }

    public Result getProducts() throws IOException, GumsProtocolException {
        List<String> products = connector.getProducts();
        ObjectNode response = Json.newObject();
        response.put("products", Json.toJson(products));

        return ok(Json.toJson(response));
    }
}