package com.ntti3.adminpanel.controllers.common;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.play.vhost.UnknownVhostException;
import com.ntti3.play.vhost.VhostInstanceSelector;
import com.ntti3.urlhelper.UrlHelper;
import play.mvc.Controller;
import play.mvc.Result;
import views.html.main;

import java.net.MalformedURLException;

public class AdminPage extends Controller {

    private VhostInstanceSelector<UrlHelper> urlHelperSelector;

    @Inject
    public AdminPage(VhostInstanceSelector<UrlHelper> urlHelperSelector) {
        this.urlHelperSelector = Preconditions.checkNotNull(urlHelperSelector,
                "URL helper can not be null");
    }

    public Result index(String action) throws UnknownVhostException, MalformedURLException {
		return ok(main.render(urlHelperSelector.getInstanceForVhost(request()).absoluteAddress("")));
	}
}
