package com.ntti3.adminpanel.controllers.common;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.ntti3.adminpanel.controllers.models.UsageReportDownloadStatusMapped;
import com.ntti3.adminpanel.lib.exceptions.InvalidRequestException;
import com.ntti3.adminpanel.lib.helpers.TypesHelper;
import com.ntti3.billings.api.client.ApiClient;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManagerFactory;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;
import play.Play;
import play.data.DynamicForm;
import play.data.Form;
import play.libs.F;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Billings Controller
 * 
 * @author Wojciech.Jurczyk <wojciech.jurczyk@codilime.com>
 */
@Authorized(role = Role.OPCO_ADMIN)
@NoCache
@ControllerExceptionSupport.ExceptionHandler()
public class Billings extends Controller {

	public static final String CUSTOMER_SUMMARY = "customer";
	public static final String SERVICE_PROVIDER_SUMMARY = "service";
	public static final String OVERALL_SUMMARY = "overall";
	public static final String SERVICE_PROVIDER_SUMMARY_SERVICES = "spsServices";
	public static final String CUSTOMER_SUMMARY_SERVICES = "csServices";
	public static final String OPCOS_REPORTS = "opcos-reports";
	public static final String X_ACCEL_REDIRECT = "x-accel-redirect";

	static final ObjectMapper objectMapper;

	static {
		objectMapper = new ObjectMapper();
		SimpleModule module = new SimpleModule("BillingsModule", new Version(1,
				0, 0, null, null, null));
		ServiceUid.ServiceUidJsonSerializer serializer = new ServiceUid.ServiceUidJsonSerializer();
		module.addSerializer(serializer);
		objectMapper.registerModule(module);
	}

	final GumsConnector gumsConnector;
	final ApiClient apiClient;
	private final UsageReportsSettingsManager usageReportsSettingsManager;
	private final UserSessionManager userSessionManager;

	@Inject
	public Billings(
			ApiClient apiClient,
			UsageReportsSettingsManagerFactory usageReportsSettingsManagerFactory,
			UserSessionManager userSessionManager, GumsConnector gumsConnector) {
		Preconditions.checkNotNull(apiClient);
		Preconditions.checkNotNull(usageReportsSettingsManagerFactory);
		Preconditions.checkNotNull(userSessionManager);
		Preconditions.checkNotNull(gumsConnector);
		
		this.apiClient = apiClient;
		usageReportsSettingsManager = usageReportsSettingsManagerFactory
				.create(Play.application().configuration()
						.getConfig(OPCOS_REPORTS));
		this.userSessionManager = userSessionManager;
		this.gumsConnector = gumsConnector;
	}

	public Result downloadReport() throws InvalidRequestException {
		final String customerSummaryServiceUidField = "csServiceUid";
		final String serviceProviderServiceUidField = "spsServiceUid";
		final String overallSummaryServiceUidField = "overallServiceUid";

		final DynamicForm dynamicForm;
		final String report;
		final Integer year;
		final Integer month;
		final YearAndMonth yearAndMonth;
		final OpcoUid opcoUid;
		final ServiceUid serviceUid;

		dynamicForm = Form.form().bindFromRequest();
		opcoUid = userSessionManager.getSession(session()).getOpcoUid();
		report = dynamicForm.get("report");
		year = TypesHelper.safeIntFromForm(dynamicForm, "year");
		month = TypesHelper.safeIntFromForm(dynamicForm, "month");

		try {
			yearAndMonth = YearAndMonth.fromInts(year, month);
		} catch (IllegalArgumentException e) {
			throw new InvalidRequestException(e);
		}

		switch (report) {
		case CUSTOMER_SUMMARY:
			serviceUid = TypesHelper.safeServiceUidFromForm(dynamicForm,
					customerSummaryServiceUidField);
			return downloadCustomerSummaryReport(opcoUid, serviceUid,
					yearAndMonth);
		case SERVICE_PROVIDER_SUMMARY:
			serviceUid = TypesHelper.safeServiceUidFromForm(dynamicForm,
					serviceProviderServiceUidField);
			return downloadServiceProviderSummaryReport(opcoUid, serviceUid,
					yearAndMonth);
		case OVERALL_SUMMARY:
			serviceUid = TypesHelper.safeServiceUidFromForm(dynamicForm,
					overallSummaryServiceUidField);
			return downloadOverallSummaryReport(serviceUid, yearAndMonth);
		default:
			throw new InvalidRequestException("Incorrect report type");
		}
	}

    @Authorized(role = Role.SUPER_ADMIN)
	public F.Promise<Result> getReportDownloadStatusesJson(final Integer year,
			final Integer month) throws InvalidRequestException {
		final YearAndMonth yearAndMonth;
		try {
			yearAndMonth = YearAndMonth.fromInts(year, month);
		} catch (IllegalArgumentException e) {
			throw new InvalidRequestException();
		}

		return F.Promise.promise(new F.Function0<Result>() {
			@Override
			public Result apply() throws Throwable {
				final Collection<UsageReportDownloadStatus> statusCollection = apiClient
						.getDownloadStatuses(yearAndMonth);

				final List<UsageReportDownloadStatusMapped> mappedStatusesList = Lists
						.newArrayList(mapUsageReportDownloadStatuses(statusCollection));

				Collections.sort(mappedStatusesList);

				return ok(objectMapper.writeValueAsString(mappedStatusesList));
			}
		});
	}

	public Result getAllServices() {
		return ok(objectMapper.valueToTree(ServiceUid.values()));
	}

	public Result getServices() {
		UserSession userSession = userSessionManager.getSession(session());
		OpcoUid opcoUid = userSession.getOpcoUid();
		ObjectNode servicesNode = Json.newObject();
		servicesNode.put(SERVICE_PROVIDER_SUMMARY_SERVICES, objectMapper
				.valueToTree(usageReportsSettingsManager.getRequestedReports(
						opcoUid, ReportType.SPS)));
		servicesNode.put(CUSTOMER_SUMMARY_SERVICES, objectMapper
				.valueToTree(usageReportsSettingsManager.getRequestedReports(
						opcoUid, ReportType.CS)));
		return ok(servicesNode);
	}

	Collection<UsageReportDownloadStatusMapped> mapUsageReportDownloadStatuses(
			Collection<UsageReportDownloadStatus> usageReportDownloadStatuses)
			throws IOException, GumsProtocolException {
		Collection<UsageReportDownloadStatusMapped> mappedStatuses = Lists
				.newArrayListWithCapacity(usageReportDownloadStatuses.size());
		for (UsageReportDownloadStatus status : usageReportDownloadStatuses) {
			mappedStatuses.add(UsageReportDownloadStatusMapped.from(status,
					gumsConnector));
		}
		return mappedStatuses;
	}

	private Result downloadCustomerSummaryReport(OpcoUid opcoUid,
			ServiceUid serviceUid, YearAndMonth yearAndMonth) {
		String uri = apiClient.getCustomerSummaryXAccelRedirectUri(opcoUid,
				serviceUid, yearAndMonth);
		return xAccelRedirectTo(uri);
	}

	private Result downloadServiceProviderSummaryReport(OpcoUid opcoUid,
			ServiceUid serviceUid, YearAndMonth yearAndMonth) {
		String uri = apiClient.getServiceProviderSummaryXAccelRedirectUri(
				opcoUid, serviceUid, yearAndMonth);
		return xAccelRedirectTo(uri);
	}

	private Result downloadOverallSummaryReport(ServiceUid serviceUid,
			YearAndMonth yearAndMonth) {
		String uri = apiClient.getOverallSummaryXAccelRedirectUri(serviceUid,
				yearAndMonth);
		return xAccelRedirectTo(uri);
	}

	private static  Result xAccelRedirectTo(String uri) {
		response().setHeader(X_ACCEL_REDIRECT, uri);
		return ok();
	}
}