package com.ntti3.adminpanel.controllers.common;

import com.google.inject.Inject;
import com.ntti3.play.build.BuildInfoReader;
import play.mvc.Result;

import static play.mvc.Results.ok;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class BuildInfoController {

    private BuildInfoReader buildInfoReader;

    @Inject
    public BuildInfoController(BuildInfoReader buildInfoReader) {
        this.buildInfoReader = buildInfoReader;
    }

    public Result index() {
        return ok(buildInfoReader.getHumanReadable());
    }
}