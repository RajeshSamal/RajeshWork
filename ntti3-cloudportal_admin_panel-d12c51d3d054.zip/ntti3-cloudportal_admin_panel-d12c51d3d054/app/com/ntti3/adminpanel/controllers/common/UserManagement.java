package com.ntti3.adminpanel.controllers.common;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.ntti3.adminpanel.controllers.models.PagedDataResponse;
import com.ntti3.adminpanel.controllers.models.UserDataWithFlags;
import com.ntti3.adminpanel.controllers.models.UserEditForm;
import com.ntti3.adminpanel.lib.exceptions.InvalidRequestException;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.GumsProtocolExceptionWithErrorResponse;
import com.ntti3.gums.Order;
import com.ntti3.gums.OrderBy;
import com.ntti3.gums.PagedResult;
import com.ntti3.gums.models.Company;
import com.ntti3.gums.models.User;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport.ExceptionHandler;
import com.ntti3.protocol.CloseableIOIterator;
import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;
import play.Configuration;
import play.Logger;
import play.data.Form;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http.Request;
import play.mvc.Result;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.ntti3.adminpanel.lib.PaginationHelper.calculateTotalPages;

/**
 * User Management Controller
 */
@Authorized(role = Role.OPCO_ADMIN)
@NoCache
@ExceptionHandler
public class UserManagement extends Controller {
    private final int pageSize;
    private final GumsConnector connector;
    private final UserSessionManager sessionManager;

    @Inject
    public UserManagement(UserSessionManager sessionManager,
                          GumsConnector connector) {
        Preconditions.checkNotNull(sessionManager);
        Preconditions.checkNotNull(connector);
        this.sessionManager = sessionManager;
        this.connector = connector;
        pageSize = Configuration.root().getInt("pagination.pageSize");
        Preconditions.checkNotNull(pageSize);
    }

    public Result index() throws IOException, GumsProtocolException {
        OrderBy orderBy = null;
        int currentPage = getPageNumberFromRequest(request(), "p");
        if (null != request().getQueryString("order")
                && null != request().getQueryString("orderBy"))
            if (request().getQueryString("order").equalsIgnoreCase("asc"))
                orderBy = new OrderBy(request().getQueryString("orderBy"),
                        Order.ASC);
            else
                orderBy = new OrderBy(request().getQueryString("orderBy"),
                        Order.DESC);

        List<User> usersPage = Lists.newLinkedList();
        final PagedResult<UUID> result;
        UserSession userSession = sessionManager.getSession(session());
        if (userSession.hasRole(Role.SUPER_ADMIN)) {
            result = connector.getUsers((currentPage - 1) * pageSize,
                    pageSize, orderBy);
        } else {
            result = connector.getOpcoUsers(
                    userSession.getOpcoUid().getValue(), (currentPage - 1)
                            * pageSize, pageSize, orderBy
            );
        }

        int totalPages = calculateTotalPages(result.getAllResultsCount(),
                pageSize);

        for (UUID uuid : getUuids(result)) {
            usersPage.add(connector.getUser(uuid));
        }

        return ok(Json.toJson(new PagedDataResponse<>(currentPage, totalPages,
                orderBy, usersPage)));
    }

    public static int getPageNumberFromRequest(Request request, String key) {
        int currentPage = 1;
        if (null != request.getQueryString(key)) {
            try {
                currentPage = Integer.parseInt(request.getQueryString(key));
            } catch (NumberFormatException ex) {
                Logger.debug(
                        "Given page: {} is not good enough to be number. Assuming 1.",
                        request.getQueryString(key));
            }
        }
        return currentPage;
    }

    private static List<UUID> getUuids(PagedResult<UUID> result) throws IOException {
        List<UUID> uidPage;
        uidPage = Lists.newLinkedList();
        try (CloseableIOIterator<UUID> uids = result.getResultPage()) {
            while (uids.hasNext()) {
                uidPage.add(uids.next());
            }
        }
        return uidPage;
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result save(UUID guid) throws IOException, GumsProtocolException {
        try {
            User user = connector.getUser(guid);
            if (!sessionManager.getSession(session()).hasRole(Role.SUPER_ADMIN)
                    && !user.getOpcoUid().equals(
                    sessionManager.getSession(session()).getOpcoUid()
                            .getValue()
            )) {
                return unauthorized();
            }

            Form<UserEditForm> form = Form.form(UserEditForm.class)
                    .bindFromRequest();

            if (form.hasErrors()) {
                return badRequest(form.errorsAsJson());
            }

            UserEditForm userEditForm = form.get();
            user.setEmail(userEditForm.getEmail());
            user.setFirstName(userEditForm.getFirstName());
            user.setLastName(userEditForm.getLastName());

            if (sessionManager.getSession(session()).hasRole(Role.SUPER_ADMIN)) {
                user.setFlags(Optional.fromNullable(userEditForm.getFlags()).or(new ArrayList<String>()));
            }

            user.setActive(userEditForm.getActive());

            connector.updateUserData(user);

            return ok();
        } catch (GumsProtocolExceptionWithErrorResponse ex) {
            return badRequest(Json.toJson(ex.getResponse()));
        }
    }

    public Result edit(UUID guid) throws IOException, GumsProtocolException {
        return ok(Json.toJson(new UserDataWithFlags(connector.getUser(guid), connector.getFlags(),
                session("csrfToken"))));
    }

    public Result getUserProducts(UUID guid) throws IOException,
            GumsProtocolException {
        List<String> whitelist = connector.getUserProductWhitelist(guid);
        List<String> products = connector.getProducts();
        Map<String, Boolean> prodMap = Maps.newHashMap();

        for (String prod : products) {
            prodMap.put(prod, whitelist.contains(prod));
        }
        Logger.trace("Sending product wl {}", prodMap);
        return ok(Json.toJson(prodMap));
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result saveUserProducts(UUID guid) throws IOException,
            GumsProtocolException {
        if (!request().getHeader("content-type").startsWith("application/json")) {
            return unauthorized();
        }
        JsonNode bl = request().body().asJson();
        List<String> whitelist = Lists.newArrayList();
        Iterator<String> names = bl.fieldNames();
        while (names.hasNext()) {
            String fieldName = names.next();
            if (bl.get(fieldName).asBoolean()) {
                whitelist.add(fieldName);
            }
        }
        connector.setUserProductWhitelist(guid, whitelist);
        return ok();
    }

    public Result getCompanyList() throws IOException, GumsProtocolException{
        String opcoUID = request().getQueryString("opco");
        final PagedResult<UUID> result = connector.getOpcoCompanies(opcoUID, null, null, null);

        List<Company> companyList = Lists.newArrayList();

        for (UUID uuid : getUuids(result)) {
            companyList.add(connector.getCompany(uuid));
        }

        ObjectNode response = Json.newObject();
        response.put("companies", Json.toJson(companyList));

        return ok(response);
    }

    public Result addCompany() throws IOException, GumsProtocolException, InvalidRequestException {
        JsonNode body = request().body().asJson();
        JsonNode nameNode = body.get("name");
        JsonNode opcoNode = body.get("opco");

        if (nameNode.isNull() || opcoNode.isNull()) {
            throw new InvalidRequestException();
        }
        connector.addCompany(null, nameNode.asText(), opcoNode.asText());
        return ok();
    }

    public Result saveCompany() throws IOException, GumsProtocolException, InvalidRequestException {
        JsonNode body = request().body().asJson();
        JsonNode companyGuidNode = body.get("company_guid");
        JsonNode opcoCUidNode = body.get("opco_c_uid");
        JsonNode opcoCNameNode = body.get("opco_c_name");
        JsonNode opcoUidNode = body.get("opco_uid");

        if (companyGuidNode.isNull() || opcoCUidNode.isNull() || opcoCNameNode.isNull() || opcoUidNode.isNull()) {
            throw new InvalidRequestException();
        }
        connector.updateCompany(new Company(
                UUID.fromString(companyGuidNode.asText()),
                opcoCUidNode.asText(),
                opcoCNameNode.asText(),
                opcoUidNode.asText()
        ));
        return ok();
    }
}

