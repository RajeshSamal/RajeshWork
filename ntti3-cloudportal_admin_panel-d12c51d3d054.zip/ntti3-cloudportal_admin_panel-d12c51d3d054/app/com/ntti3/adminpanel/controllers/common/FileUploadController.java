package com.ntti3.adminpanel.controllers.common;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.adminpanel.lib.exceptions.InvalidRequestException;
import com.ntti3.play.annotations.NoCache;
import com.ntti3.play.annotations.auth.Authorized;
import com.ntti3.play.annotations.csrf.AddCsrfToken;
import com.ntti3.play.annotations.csrf.CheckCsrfToken;
import com.ntti3.play.annotations.csrf.Constants;
import com.ntti3.spsso.session.Role;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.tika.Tika;
import play.Configuration;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Bartlomiej Biernacki <bartlomiej.biernacki@ntti3.com> on 2014-05-14.
 */
@Authorized(role = Role.SUPER_ADMIN)
public class FileUploadController extends Controller {
    private static final String CMS_UPLOAD_PATH = "cms.upload.path";
    public static final int STATUS_CREATED = 201;
    public static final int STATUS_OK = 200;
    private final String path;
    private final Tika tika = new Tika();

    private ObjectNode createTreeNode(File file) throws IOException {
        ObjectNode node = Json.newObject();
        node.put("name", file.getName());
        if(file.isDirectory()) {
            node.put("type", "directory");
        } else {
            node.put("type", tika.detect(file));
            node.put("url", com.ntti3.cms.controllers.routes.ServeFileController.serve(file.getName()).toString());
        }

        return node;
    }

    private int handleFile(File uploaded, String filename) throws IOException {
        int responseStatus = STATUS_CREATED;
        File destination = new File(FilenameUtils.concat(path, filename));
        if(destination.exists()) {
            responseStatus = STATUS_OK;
            Files.delete(destination.toPath());
        }
        FileUtils.moveFile(uploaded, destination);
        return responseStatus;
    }

    public FileUploadController() {
        this.path = Configuration.root().getString(CMS_UPLOAD_PATH);
    }

    @AddCsrfToken
    @NoCache
    public Result fileManager() {
        return ok(views.html.fileManager.render(session(Constants.TOKEN_NAME)));
    }

    public Result getFiles() throws IOException {
        ObjectNode result = Json.newObject();
        ArrayNode files = result.putArray("data");
        File root = new File(path);
        File[] children = root.listFiles();
        if(children != null && children.length > 0) {
            for(File child : children) {
                files.add(createTreeNode(child));
            }
        }
        return ok(result);
    }

    @CheckCsrfToken
    public Result postFile() throws InvalidRequestException, IOException {
        if(request().body().asMultipartFormData() == null || request().body().asMultipartFormData().getFiles().size() == 0) {
            throw new InvalidRequestException();
        }
        Http.MultipartFormData.FilePart uploaded = request().body().asMultipartFormData().getFiles().get(0);
        handleFile(uploaded.getFile(), uploaded.getFilename());
        return redirect(com.ntti3.adminpanel.controllers.common.routes.FileUploadController.getFiles());
    }

    @CheckCsrfToken
    public Result deleteFile(String filename) throws IOException {
        Path destination = Paths.get(path, filename);
        try {
            Files.delete(destination);
        } catch (NoSuchFileException ex) {
            return notFound("File not found");
        }
        return redirect(com.ntti3.adminpanel.controllers.common.routes.FileUploadController.getFiles());
    }
}
