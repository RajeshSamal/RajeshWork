package com.ntti3.adminpanel.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.ntti3.aspects.logging.PlayLoggingAspect;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {
	@Pointcut("execution(* com.ntti3.adminpanel.controllers.common.*.*(..)) && ! execution(* com.ntti3.adminpanel.controllers.common.Reverse*.*(..))"
			+ "&& ! execution(* com.ntti3.adminpanel.controllers.common.*.*$*(..))")
	@Override
	public void controllerMethodPointcut() {
	}
	
    @Pointcut("within(com.ntti3.adminpanel.lib..*)")
    @Override
    public void applicationMethodPointcut() {
    }

    @Override
    public String getPathContains() {
        return "adminpanel";
    }
}
