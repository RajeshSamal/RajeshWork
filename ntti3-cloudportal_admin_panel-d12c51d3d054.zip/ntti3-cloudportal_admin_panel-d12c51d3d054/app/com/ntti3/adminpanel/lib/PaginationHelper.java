package com.ntti3.adminpanel.lib;

import com.ntti3.gums.PagedResult;

/**
 * @author jan.karwowski@ntti3.com
 */
public class PaginationHelper {
	public static int calculateTotalPages(PagedResult<Integer> result,
			int pageSize) {
		return calculateTotalPages(result.getAllResultsCount(), pageSize);
	}

	public static int calculateTotalPages(int elements, int pageSize) {
		return elements / pageSize + (elements % pageSize == 0 ? 0 : 1);
	}
}
