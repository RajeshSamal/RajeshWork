package com.ntti3.adminpanel.lib.helpers;

import com.ntti3.adminpanel.lib.exceptions.InvalidRequestException;
import play.data.DynamicForm;

import com.ntti3.billings.types.base.ServiceUid;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class TypesHelper {

	public static int safeIntFromForm(DynamicForm dynamicForm, String key)
			throws InvalidRequestException {
		try {
			return Integer.parseInt(dynamicForm.get(key));
		} catch (NumberFormatException e) {
			throw new InvalidRequestException(String.format(
					"Could not parse '%s' form data to int", key), e);
		}
	}

	public static ServiceUid safeServiceUidFromForm(DynamicForm dynamicForm,
			String key) throws InvalidRequestException {
		try {
			return ServiceUid.fromString(dynamicForm.get(key));
		} catch (IllegalArgumentException e) {
			throw new InvalidRequestException(String.format(
					"Could not parse '%s' from data to serviceUid", key), e);
		}
	}

}
