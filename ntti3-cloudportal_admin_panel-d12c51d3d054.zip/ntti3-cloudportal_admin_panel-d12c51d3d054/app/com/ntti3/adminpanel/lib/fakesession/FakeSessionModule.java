package com.ntti3.adminpanel.lib.fakesession;

import com.ntti3.spsso.session.Role;
import com.ntti3.spsso.session.UserSessionManager;
import com.google.inject.AbstractModule;

/**
 * @author jan.karwowski@ntti3.com
 */
public class FakeSessionModule extends AbstractModule {
    Role level;
	private String uuidString;

	public FakeSessionModule(Role level) {
		this.level = level;
	}

	public FakeSessionModule(Role level, String uuidString) {
		this.level = level;
		this.uuidString = uuidString;
	}

	@Override
	protected void configure() {
		if (uuidString == null)
			bind(UserSessionManager.class).toInstance(
					new FakeSessionManager(level));
		else
			bind(UserSessionManager.class).toInstance(
					new FakeSessionManager(level, uuidString));
	}

	@Override
	public int hashCode() {
		return getClass().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return getClass().equals(obj.getClass());
	}
}
