package com.ntti3.adminpanel.lib.fakesession;

import java.util.UUID;

import com.ntti3.spsso.session.Role;
import play.mvc.Http;

import com.ntti3.spsso.session.UserSession;
import com.ntti3.spsso.session.UserSessionManager;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class FakeSessionManager implements UserSessionManager {
	private Role level;
	private String uuidString;

	public FakeSessionManager(Role level) {
		this.level = level;
		this.uuidString = UUID.randomUUID().toString();
	}

	public FakeSessionManager(Role level, String uuidString) {
		this.level = level;
		this.uuidString = uuidString;
	}

	@Override
	public UserSession getSession(Http.Session session) {
		return new FakeSession(uuidString, level);
	}
}
