package com.ntti3.adminpanel.lib.exceptions.handlers;

import com.ntti3.adminpanel.lib.exceptions.InvalidRequestException;

import com.ntti3.gums.GumsProtocolException;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.excetions.handling.SimpleExceptionHandler;
import com.ntti3.protocol.ErrorCode;
import com.google.inject.PrivateModule;

import com.ntti3.adminpanel.controllers.common.PeerIOFailureException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class AdminPanelExceptionsHandlerModule extends PrivateModule {

	private final GlobalExceptionsHandler globalExceptionsHandler;

	public AdminPanelExceptionsHandlerModule() {
		globalExceptionsHandler = new GlobalExceptionsHandler();

		globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(
				InvalidRequestException.class, ErrorCode.INCORRECT_CALL,
				"Invalid request"));		
		globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(PeerIOFailureException.class,
				ErrorCode.OPERATION_NOT_SUPPORTED, "Temporary failure", 500));
		globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(GumsProtocolException.class,
				ErrorCode.OPERATION_NOT_SUPPORTED, "Temporary failure", 500));
	}

	@Override
	protected void configure() {
		bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
		expose(GlobalExceptionsHandler.class);
	}

	@Override
	public int hashCode() {
		return AdminPanelExceptionsHandlerModule.class.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return AdminPanelExceptionsHandlerModule.class.equals(obj.getClass());
	}
}