package com.ntti3.adminpanel.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class AdminPanelException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	public AdminPanelException() {
		super();
	}

	public AdminPanelException(String message) {
		super(message);
	}

	public AdminPanelException(String message, Throwable cause) {
		super(message, cause);
	}

	public AdminPanelException(Throwable cause) {
		super(cause);
	}
}
