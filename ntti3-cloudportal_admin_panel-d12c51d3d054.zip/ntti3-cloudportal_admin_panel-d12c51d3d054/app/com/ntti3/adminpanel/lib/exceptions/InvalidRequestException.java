package com.ntti3.adminpanel.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class InvalidRequestException extends AdminPanelException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	public InvalidRequestException() {
		super();
	}

	public InvalidRequestException(String message) {
		super(message);
	}

	public InvalidRequestException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidRequestException(Throwable cause) {
		super(cause);
	}
}
