package controllers.codilime;

import com.ntti3.adminpanel.lib.PaginationHelper;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * @author jan.karwowski@ntti3.com
 */
public class CalculateTotalPagesTest {
	@Test
	public void noPages() {
		assertEquals(0, PaginationHelper.calculateTotalPages(0, 5));
	}

	@Test
	public void fullPage() {
		assertEquals(1, PaginationHelper.calculateTotalPages(5, 5));
	}

	@Test
	public void partialPage() {
		assertEquals(1, PaginationHelper.calculateTotalPages(1, 5));
	}

	@Test
	public void partialPages() {
		assertEquals(2, PaginationHelper.calculateTotalPages(6, 5));
	}
}
