package models;

import com.avaje.ebean.Ebean;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecordKey;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;
import org.junit.Test;
import utils.NoPullJobsTest;

import javax.persistence.PersistenceException;

import static org.fest.assertions.Assertions.assertThat;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UsageReportDownloadLogRecordTest extends NoPullJobsTest {

    public static final OpcoUid OPCO_UID = OpcoUid.fromString("OpcoUid");
    public static final DateTime NOW = DateTime.now();
    public static final ReportType REPORT_TYPE = ReportType.CS;
    public static final YearAndMonth YEAR_AND_MONTH = YearAndMonth.fromInts(2013, 12);
    public static final ServiceUid SERVICE_UID = ServiceUid.PLN;

    @Test
    public void builderTest() {
        UsageReportDownloadLogRecord usageReportDownloadLogRecord = getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW);

        assertThat(usageReportDownloadLogRecord.getOpcoUid()).isEqualTo(OPCO_UID);
        assertThat(usageReportDownloadLogRecord.getServiceUid()).isEqualTo(SERVICE_UID);
        assertThat(usageReportDownloadLogRecord.getDownloadTime()).isEqualTo(NOW);
        assertThat(usageReportDownloadLogRecord.getReportType()).isEqualTo(REPORT_TYPE);
        assertThat(usageReportDownloadLogRecord.getMonth()).isEqualTo(YEAR_AND_MONTH.getMonth());
        assertThat(usageReportDownloadLogRecord.getYear()).isEqualTo(YEAR_AND_MONTH.getYear());
    }

    @Test(expected = NullPointerException.class)
    public void opcoNull() {
        getReportDownloadRecord(null, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW);
    }

    @Test(expected = NullPointerException.class)
    public void serviceUidNull() {
        getReportDownloadRecord(OPCO_UID, null, YEAR_AND_MONTH, REPORT_TYPE, NOW);
    }

    @Test(expected = NullPointerException.class)
    public void yearAndMonthNull() {
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, null, REPORT_TYPE, NOW);
    }

    @Test(expected = NullPointerException.class)
    public void reportTypeNull() {
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, null, NOW);
    }

    @Test(expected = NullPointerException.class)
    public void downloadTimeNull() {
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, null);
    }

    @Test
    public void loadSaveIdentity() {
        UsageReportDownloadLogRecord usageReportDownloadLogRecord = getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW);
        usageReportDownloadLogRecord.save();
        usageReportDownloadLogRecord.refresh();
        UsageReportDownloadLogRecord usageReportDownloadLogRecordFromDb = Ebean.find(UsageReportDownloadLogRecord.class).findList().get(0);
        assertThat(usageReportDownloadLogRecordFromDb).isEqualTo(usageReportDownloadLogRecord);
    }

    @Test(expected = PersistenceException.class)
    public void checkPrimaryKeyUnique() {
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW).save();
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW).save();
    }

    @Test
    public void onUpdate() {
        // Create and save a record
        getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW).save();

        // Create a record with the same primary key as the previous one, but with a changed "downloadTime".
        UsageReportDownloadLogRecord expectedUsageReportDownloadLogRecord
                = getReportDownloadRecord(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE, NOW.plusHours(1));
        expectedUsageReportDownloadLogRecord.update();

        UsageReportDownloadLogRecord usageReportDownloadLogRecordFromDb
                = UsageReportDownloadLogRecord.FIND.byId(UsageReportDownloadLogRecordKey.create(OPCO_UID, SERVICE_UID, YEAR_AND_MONTH, REPORT_TYPE));

        // Expect that the value in the DB with the same PK has changed.
        assertThat(usageReportDownloadLogRecordFromDb).isEqualTo(expectedUsageReportDownloadLogRecord);
    }


    protected UsageReportDownloadLogRecord getReportDownloadRecord(OpcoUid opcoUid, ServiceUid serviceUid,
                                                                   YearAndMonth yearAndMonth, ReportType reportType,
                                                                   DateTime downloadTime) {
        return UsageReportDownloadLogRecord.builder()
                .opcoUid(opcoUid)
                .serviceUid(serviceUid)
                .downloadTime(downloadTime)
                .reportType(reportType)
                .yearAndMonth(yearAndMonth)
                .status(Status.D)
                .build();
    }
}
