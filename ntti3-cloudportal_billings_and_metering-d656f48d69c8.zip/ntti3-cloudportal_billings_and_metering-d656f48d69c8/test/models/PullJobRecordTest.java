package models;

import com.ntti3.billingmetering.models.PullJobRecord;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import org.joda.time.DateTime;
import org.junit.Test;
import utils.NoPullJobsTest;

import static org.fest.assertions.Assertions.assertThat;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

public class PullJobRecordTest extends NoPullJobsTest {

    @Test
    public void loadSaveIdentity() {
        PullJobRecord record1 = PullJobRecord.builder()
                .executeAt(DateTime.now())
                .busyTo(DateTime.now().plusDays(4))
                .status(Status.B)
                .targetService(ServiceUid.PLN)
                .build();

        record1.save();

        PullJobRecord record2 = PullJobRecord.FIND.byId(record1.getId());
        assertThat(record2).isEqualTo(record1);
    }

}
