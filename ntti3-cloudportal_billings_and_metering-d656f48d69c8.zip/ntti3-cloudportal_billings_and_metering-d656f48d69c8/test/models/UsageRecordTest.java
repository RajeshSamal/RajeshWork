package models;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import org.junit.Test;
import play.libs.Json;
import utils.NoPullJobsTest;

import java.sql.Date;
import java.util.UUID;

import static org.fest.assertions.Assertions.assertThat;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UsageRecordTest extends NoPullJobsTest {

    private static final UUID USER_GUID = UUID.randomUUID();
    public final ObjectNode details;

    public UsageRecordTest() {
        details = Json.newObject();
        details.put("test-variable", "test-value");
    }

    @Test
    public void loadSaveIdentity() {
        UsageRecord usageRecord = getSampleRecord();
        usageRecord.save();
        UsageRecord usageRecord2 = UsageRecord.FIND.byId(usageRecord.getUsageUid());
        assertThat(usageRecord2).isEqualTo(usageRecord);
    }

    @Test
    public void costToStringFormat1() {
        String expectedCostString = "3.14000";
        UsageRecord usageRecord = getSampleRecordWithCost(expectedCostString);
        usageRecord.save();
        UsageRecord usageRecord2 = UsageRecord.FIND.byId(usageRecord.getUsageUid());
        String costString = usageRecord2.getCost().toString();
        assertThat(costString).isEqualTo(expectedCostString);
    }

    @Test
    public void costToStringFormat2() {
        UsageRecord usageRecord = getSampleRecordWithCost("3.10000");
        usageRecord.save();
        UsageRecord usageRecord2 = UsageRecord.FIND.byId(usageRecord.getUsageUid());
        String expectedCostString = "3.10000";
        String costString = usageRecord2.getCost().toString();
        assertThat(costString).isEqualTo(expectedCostString);
    }

    @Test
    public void costToStringFormat3() {
        UsageRecord usageRecord = getSampleRecordWithCost("3");
        usageRecord.save();
        UsageRecord usageRecord2 = UsageRecord.FIND.byId(usageRecord.getUsageUid());
        String expectedCostString = "3.00000";
        String costString = usageRecord2.getCost().toString();
        assertThat(costString).isEqualTo(expectedCostString);
    }


    @Test
    public void costScaleOk() {
        UsageRecord.builder().fromOther(getSampleRecord())
                .cost("3.41004")
                .build();
    }

    @Test(expected = ArithmeticException.class)
    public void costScaleError() {
        UsageRecord.builder().fromOther(getSampleRecord())
                .cost("3.410001")
                .build();
    }


    protected UsageRecord getSampleRecord() {
        return getSampleRecordWithCost("3.14");
    }

    protected UsageRecord getSampleRecordWithCost(String cost) {
        return UsageRecord.builder()
                .usageUid(UsageUid.fromString("testUsageId"))
                .internalTransactionId(InternalId.fromString("testInternalId"))
                .itemType("JobCloudCost")
                .customerOpcoUserUid(OpcoUserUid.fromString("testCustomerOpcoUserId"))
                .customerOpcoUid(OpcoUid.fromString("testCustomerOpcoUid"))
                .billDate(Date.valueOf("1989-04-23"))
                .cost(cost)
                .costType(CostType.UNPAID)
                .currency(Currency.USD)
                .description("Test description")
                .details(details)
                .parentUsageUid(UsageUid.fromString("parentUsageUid"))
                .serviceUid(ServiceUid.PLN)
                .serviceOpcoUid(OpcoUid.fromString("testServiceOpcoUid"))
                .userGuid(USER_GUID)
                .build();
    }
}
