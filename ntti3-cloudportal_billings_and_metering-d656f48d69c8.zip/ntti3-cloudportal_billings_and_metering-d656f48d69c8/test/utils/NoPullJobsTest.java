package utils;

import com.google.common.collect.Maps;
import org.junit.After;
import org.junit.Before;
import play.test.FakeApplication;
import play.test.Helpers;
import play.test.TestServer;

import java.util.Map;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public abstract class NoPullJobsTest {

    private static FakeApplication app;
    private static TestServer testServer;

    @Before
    public void startApp() {
        System.out.println("test: " + this.getClass().getName());
        Map<String, String> testConfig = Maps.newHashMap(Helpers.inMemoryDatabase());
        // MySql compatibility mode
        testConfig.put("db.default.url", testConfig.get("db.default.url") + ";MODE=MYSQL");

        // So that the pull-jobs will not interfere with the test.
        testConfig.put("pull-jobs-on", "false");
        testConfig.put("fake-usage-records", "false");
        app = Helpers.fakeApplication(testConfig);
        testServer = new TestServer(9000, app);
        testServer.start();

    }

    @After
    public void stopApp() {
        testServer.stop();
    }
}
