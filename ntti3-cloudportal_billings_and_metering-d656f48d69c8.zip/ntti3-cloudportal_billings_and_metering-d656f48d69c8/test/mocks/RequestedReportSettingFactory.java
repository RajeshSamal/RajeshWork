package mocks;

import com.ntti3.billings.settings.reports.DefaultRequestedUsageReportSetting;
import com.ntti3.billings.settings.reports.RequestedUsageReportSetting;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class RequestedReportSettingFactory {
    public static RequestedUsageReportSetting get(final OpcoUid opcoUid, final ServiceUid serviceUid, final ReportType reportType) {
        return new DefaultRequestedUsageReportSetting(opcoUid, serviceUid, reportType);
    }
}
