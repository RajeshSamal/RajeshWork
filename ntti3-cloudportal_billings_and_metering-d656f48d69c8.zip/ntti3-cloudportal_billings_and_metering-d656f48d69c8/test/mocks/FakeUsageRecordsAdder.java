package mocks;

import com.avaje.ebean.Ebean;
import com.google.common.collect.Lists;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import org.joda.time.DateTime;
import play.Logger;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

/**
 * This is a class to fill the DB (in-memory in this case) with some
 * fake usage records.
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */

public class FakeUsageRecordsAdder {

    public static final String CUSTOMER_OPCO_UID = "customerOpcoUid";
    public static final String SERVICE_OPCO_UID = "serviceOpcoUid";
    private static final String DESCRIPTION = "Description ";

    public static void AddFakeUsageRecords() {
        if (UsageRecord.FIND.findRowCount() == 0) {
            String customerOpcoUid = CUSTOMER_OPCO_UID;
            String description = DESCRIPTION;
            DateTime date = DateTime.now();
            String serviceOpcoUid = SERVICE_OPCO_UID;
            List<UsageRecord> usageRecordsList = Lists.newArrayListWithCapacity(500);

            //Sequence of customer opcos
            for (int i = 0; i < 5; i++) {
                String currentCustomerOpcoUid = customerOpcoUid + i;

                // Sequence of service opco
                for (int j = 0; j < 2; j++) {
                    String currentServiceOpcoUid = serviceOpcoUid + j;

                    //sequence of uses
                    for (int m = 0; m < 50; m++) {
                        String currentDescription = description + m;
                        usageRecordsList.add(GenerateFakeUsageRecord(
                                UsageUid.fromString("truid" + i + "_" + j + "_" + m),
                                InternalId.fromString("int_id" + i * (j + 1) + m),
                                OpcoUid.fromString(currentCustomerOpcoUid),
                                currentDescription,
                                new Date(date/*.minusDays(m)*/.getMillis()),
                                new BigDecimal((i + 1) * (j + 1) * (m + 1)),
                                ServiceUid.PLN,
                                OpcoUid.fromString(currentServiceOpcoUid)
                        ));
                    }
                }
            }
            Ebean.save(usageRecordsList);
        } else {
            Logger.warn("FakeUsageRecordsAdder was used but there were UsageRecords in the DB!");
        }
    }

    public static UsageRecord GenerateFakeUsageRecord(UsageUid usageUid, InternalId internalTransactionId, OpcoUid customerOpcoUid, String description, Date billDate,
                                                      BigDecimal cost, ServiceUid serviceUid, OpcoUid serviceOpcoUid) {
        return UsageRecord.builder()
                .usageUid(usageUid)
                .internalTransactionId(internalTransactionId)
                .customerOpcoUid(customerOpcoUid)
                .userGuid(UUID.randomUUID())
                .customerOpcoUserUid(OpcoUserUid.fromString("A sample company user UID"))
                .description(description)
                .billDate(billDate)
                .cost(cost)
                .costType(CostType.UNPAID)
                .currency(Currency.USD)
                .serviceUid(serviceUid)
                .serviceOpcoUid(serviceOpcoUid)
                .itemType("JobCloudCost")
                .build();
    }
}
