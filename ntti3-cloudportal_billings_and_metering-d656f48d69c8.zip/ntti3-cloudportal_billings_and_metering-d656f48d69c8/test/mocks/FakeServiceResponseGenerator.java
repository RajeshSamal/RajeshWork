package mocks;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.billingmetering.lib.pulling.util.AmaServiceResponseRecord;
import com.ntti3.billingmetering.lib.pulling.util.DefaultServiceResponseRecord;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.ItemType;
import org.joda.time.DateTime;
import play.Logger;
import play.libs.F;
import play.libs.Json;

import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public enum FakeServiceResponseGenerator {

    AMA(new SchemaCaller() {
        @Override
        public JsonNode generateOkJson(int transactionId, int detailsValue) {
            ObjectNode record = Json.newObject();

            record.put(AmaServiceResponseRecord.TRANSACTION_ID, "fake-tr-id" + Integer.toString(transactionId));
            record.put(AmaServiceResponseRecord.BILL_DATE, DateTime.now().toString("MM/dd/yyyy h:m:s a"));
            record.put(AmaServiceResponseRecord.COST, "1.234");
            record.put(AmaServiceResponseRecord.CURRENCY, Currency.USD.getTextRepresentation());
            record.put(AmaServiceResponseRecord.DESCRIPTION, "description");
            record.put(AmaServiceResponseRecord.ITEM_TYPE, ItemType.JCC.getTextRepresentation());

            ObjectNode cloud = record.putObject(AmaServiceResponseRecord.CLOUD);
            cloud.put(AmaServiceResponseRecord.Cloud.INFRASTRUCTURE_ID, "fake-amazon");

            ObjectNode user = record.putObject(AmaServiceResponseRecord.USER);
            user.put(AmaServiceResponseRecord.UserInResponseRecord.USER_GUID, UUID.randomUUID().toString());


            ObjectNode details = record.putObject(AmaServiceResponseRecord.DETAILS);
            details.put("det-entry", "det-value" + Integer.toString(detailsValue));

            return record;
        }
    }, "{\"billItemsDetails\":["),
    DEFAULT(new SchemaCaller() {
        @Override
        public JsonNode generateOkJson(int transactionId, int detailsValue) {
            ObjectNode record = Json.newObject();

            record.put(DefaultServiceResponseRecord.TRANSACTION_ID, "fake-tr-id" + Integer.toString(transactionId));
            record.put(DefaultServiceResponseRecord.BILL_DATE, DateTime.now().toString("yyyy-MM-dd'T'HH:mm:ssZZ"));
            record.put(DefaultServiceResponseRecord.COST, "1.234");
            record.put(DefaultServiceResponseRecord.CURRENCY, Currency.USD.getTextRepresentation());
            record.put(DefaultServiceResponseRecord.DESCRIPTION, "description");
            record.put(DefaultServiceResponseRecord.ITEM_TYPE, ItemType.JCC.getTextRepresentation());
            record.put(DefaultServiceResponseRecord.CLOUD, "fake-amazon");
            record.put(DefaultServiceResponseRecord.USER, UUID.randomUUID().toString());

            ObjectNode details = record.putObject(DefaultServiceResponseRecord.DETAILS);
            details.put("det-entry", "det-value" + Integer.toString(detailsValue));
            
            return record;
        }
    }, "{\"transactions\":[");

    // The beginning and the ending of the json message
    private final String PRE_ARRAY_STRING;
    private final String POST_ARRAY_STRING = "]}\n";
    private final String ARRAY_ITEM_SEPARATOR = ", ";

    private final ObjectMapper mapper = new ObjectMapper();
    private final SchemaCaller schemaCaller;

    public enum Correctness {
        CORRECT,
        UNEXPECTED_DATA,
        UNEXPECTEDLY_CLOSED
    }

    interface SchemaCaller {
        JsonNode generateOkJson(int transactionId, int detailsValue);
    }

    FakeServiceResponseGenerator(SchemaCaller caller, String preArrayString) {
        this.schemaCaller = caller;
        PRE_ARRAY_STRING = preArrayString;
    }

    public InputStream generateStream(final int groupsCount,
                                             final int groupSize, final int groupDelay, final Correctness correctness) throws IOException {

        // Create streams
        final PipedInputStream inputStream = new PipedInputStream();
        final PipedOutputStream outputStream = new PipedOutputStream(inputStream);
        mapper.configure(JsonGenerator.Feature.AUTO_CLOSE_TARGET, false);

        // Write the beginning of Json data
        WritePreArrayString(outputStream);

        // Generate data (with delays, in a new thread)
        F.Promise<Void> promise = F.Promise.promise(new F.Function0<Void>() {
            @Override
            public Void apply() throws Throwable {
                WriteServiceResponseRecords(groupsCount, groupSize, groupDelay, outputStream);
                writeForCorrectness(correctness, outputStream);
                return null;
            }
        });

        promise.onFailure(new F.Callback<Throwable>() {
            @Override
            public void invoke(Throwable throwable) throws Throwable {
                Logger.error(String.format("Generating json (AMA mockup) failed: %s", throwable.getMessage()));
                outputStream.close();
            }
        });

        promise.onRedeem(new F.Callback<Void>() {
            @Override
            public void invoke(Void v) throws Throwable {
                outputStream.close();
            }
        });

        return inputStream;
    }

    private void writeForCorrectness(Correctness correctness,
                                              PipedOutputStream outputStream) throws IOException {
        switch (correctness) {
            case CORRECT:
                // Write the end of array so the json is correct
                WritePostArrayString(outputStream);
                break;
            case UNEXPECTED_DATA:
                // Write additional incorrect data
                outputStream.write("Additional and incorrect data".getBytes());
                break;
            case UNEXPECTEDLY_CLOSED:
                // The output stream could be closed here but it will be closed
                // on the promise's callback anyway (just after this 'case').
                break;
        }
    }

    private void WriteServiceResponseRecords(int groupsCount,
                                                    int groupSize,
                                                    int groupDelay,
                                                    PipedOutputStream outputStream) throws IOException {
        for (int i = 0; i < groupsCount; i++) {
            try {
                Thread.sleep(1000 * groupDelay);
            } catch (InterruptedException e) {
                // Just do nothing. The exception is not crucial.
            }
            for (int j = 0; j < groupSize; j++) {
                outputStream.write(Json.stringify(schemaCaller.generateOkJson(i * j, j * j * i)).getBytes());
                if (i != groupsCount - 1 || j != groupSize - 1) {
                    // Do not send the separator after the last element!
                    outputStream.write(ARRAY_ITEM_SEPARATOR.getBytes());
                }
            }
        }
    }

    private void WritePostArrayString(PipedOutputStream outputStream) throws IOException {
        outputStream.write(POST_ARRAY_STRING.getBytes());
    }

    private void WritePreArrayString(PipedOutputStream outputStream) throws IOException {
        outputStream.write(PRE_ARRAY_STRING.getBytes());
    }
}
