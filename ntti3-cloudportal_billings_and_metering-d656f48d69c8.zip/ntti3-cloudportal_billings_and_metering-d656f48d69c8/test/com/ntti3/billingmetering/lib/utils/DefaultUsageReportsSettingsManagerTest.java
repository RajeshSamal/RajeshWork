package com.ntti3.billingmetering.lib.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ntti3.billings.settings.reports.DefaultUsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.RequestedUsageReportSetting;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.typesafe.config.ConfigFactory;
import mocks.RequestedReportSettingFactory;
import org.fest.assertions.Assertions;
import org.junit.Test;
import play.Configuration;
import utils.NoPullJobsTest;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportsSettingsManagerTest extends NoPullJobsTest {

    private static final String NTTI_3 = "ntti3";
    private static final String CL = "cl";

    @Test
    public void loadsConfiguration() {
        Map<String, Object> fakeConfigMap = Maps.newHashMap();
        fakeConfigMap.put(NTTI_3, getNtti3Config());
        fakeConfigMap.put(CL, getCLConfig());

        Configuration fakeConfiguration = new Configuration(ConfigFactory.parseMap(fakeConfigMap));
        DefaultUsageReportsSettingsManager defaultOpcoReportsSettingsManager = new DefaultUsageReportsSettingsManager(fakeConfiguration);

        Set<RequestedUsageReportSetting> reportsSettings = defaultOpcoReportsSettingsManager.getRequestedReports();

        Set<RequestedUsageReportSetting> expectedReportsSettings = Sets.newHashSet(
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, ReportType.SPS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, ReportType.SPS),

                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.MGR, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.DVP, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.MGR, ReportType.SPS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.DVP, ReportType.SPS));

        Assertions.assertThat(reportsSettings).isEqualTo(expectedReportsSettings);
    }

    private Map<String, List<String>> getNtti3Config() {
        Map<String, List<String>> config = Maps.newHashMap();
        config.put(ReportType.CS.name(), Lists.newArrayList("PLN", "MGR"));
        config.put(ReportType.SPS.name(), Lists.newArrayList("PLN", "MGR"));
        return config;
    }

    private Map<String, List<String>> getCLConfig() {
        Map<String, List<String>> config = Maps.newHashMap();
        config.put(ReportType.CS.name(), Lists.newArrayList("MGR", "DVP"));
        config.put(ReportType.SPS.name(), Lists.newArrayList("MGR", "DVP"));
        return config;
    }
}
