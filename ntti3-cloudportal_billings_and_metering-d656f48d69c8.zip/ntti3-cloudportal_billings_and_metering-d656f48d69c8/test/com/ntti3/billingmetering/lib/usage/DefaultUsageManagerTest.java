package com.ntti3.billingmetering.lib.usage;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoCustomerUid;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;
import org.junit.Test;
import play.libs.Json;
import utils.NoPullJobsTest;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.fest.assertions.Assertions.assertThat;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageManagerTest extends NoPullJobsTest {

    private final static String USAGE_UID_STRING = "testUsageUid";
    private final static String DESCRIPTION = "Test description";
    private final static JsonNode DETAILS = Json.newObject();
    private final static String INTERNAL_ID_STRING = "internalId";
    private final static OpcoUid CUSTOMER_OPCO_UID_1 = OpcoUid.fromString("CUSTOMER_OPCO_UID_1");
    private final static OpcoUid CUSTOMER_OPCO_UID_2 = OpcoUid.fromString("CUSTOMER_OPCO_UID_2");
    private final static OpcoUid CUSTOMER_OPCO_UID_3 = OpcoUid.fromString("CUSTOMER_OPCO_UID_3");
    private final static OpcoUid SERVICE_OPCO_UID_1 = OpcoUid.fromString("SERVICE_OPCO_UID_1");
    private final static OpcoUid SERVICE_OPCO_UID_2 = OpcoUid.fromString("SERVICE_OPCO_UID_2");
    private final static OpcoUid SERVICE_OPCO_UID_3 = OpcoUid.fromString("SERVICE_OPCO_UID_3");
    private final static int YEAR = 2014;
    private final static int MONTH = Calendar.JANUARY;
    private final static int DAY = 1;
    private final static int ID_CONSTANT = 100;
    private UsageManager usageManager = new DefaultUsageManager();

    @Override
    public void startApp() {
        super.startApp();
        generateUsageRecords(CUSTOMER_OPCO_UID_1, SERVICE_OPCO_UID_1, ServiceUid.PLN);
        generateUsageRecords(CUSTOMER_OPCO_UID_1, SERVICE_OPCO_UID_2, ServiceUid.DVP);
        generateUsageRecords(CUSTOMER_OPCO_UID_2, SERVICE_OPCO_UID_1, ServiceUid.PLN);
    }

    @Test
    public void customerSummaryCustomer1Month1AMA() {
        final int expectedYear = 2014;
        final int expectedMonth = 1;
        final int expectedCount = 31; // Days in January 2014
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month2AMA() {
        final int expectedYear = 2014;
        final int expectedMonth = 2;
        final int expectedCount = 28; // Days in February 2014
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month3AMA() {
        final int expectedYear = 2014;
        final int expectedMonth = 3;
        final int expectedCount = 31;
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month4Empty() {
        final int expectedYear = 2014;
        final int expectedMonth = 4;
        final int expectedCount = 0;
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_2;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month1DO() {
        final int expectedYear = 2014;
        final int expectedMonth = 1;
        final int expectedCount = 31; // Days in January 2014
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.DVP;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_2;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month2DO() {
        final int expectedYear = 2014;
        final int expectedMonth = 2;
        final int expectedCount = 28;
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.DVP;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_2;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer1Month3DO() {
        final int expectedYear = 2014;
        final int expectedMonth = 3;
        final int expectedCount = 31;
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.DVP;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_2;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void customerSummaryCustomer3Empty() {
        final int expectedYear = 2014;
        final int expectedMonth = 3;
        final int expectedCount = 0;
        OpcoUid customerOpcoUid = CUSTOMER_OPCO_UID_3;
        ServiceUid serviceUid = ServiceUid.PLN;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        customerSummaryTestTemplate(expectedYear, expectedMonth, expectedCount,
                customerOpcoUid, serviceUid, serviceOpcoUid);
    }

    @Test
    public void serviceProviderSummary1AMA1() {
        final int expectedYear = 2014;
        final int expectedMonth = 1;
        final int expectedCount = 31 * 2; // Two customers for this serviceUid and serviceOpcoUid
        final int expectedRecrodsPerDay = 2;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        serviceProviderSummaryTestTemplate(expectedYear, expectedMonth,
                expectedCount, serviceOpcoUid, serviceUid, expectedRecrodsPerDay);
    }

    @Test
    public void serviceProviderSummary1AMA2() {
        final int expectedYear = 2014;
        final int expectedMonth = 2;
        final int expectedCount = 28 * 2;
        final int expectedRecrodsPerDay = 2;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        serviceProviderSummaryTestTemplate(expectedYear, expectedMonth,
                expectedCount, serviceOpcoUid, serviceUid, expectedRecrodsPerDay);
    }

    @Test
    public void serviceProviderSummary1AMATooEarly() {
        final int expectedYear = 2013;
        final int expectedMonth = 12;
        final int expectedCount = 0;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        serviceProviderSummaryTestTemplate(expectedYear, expectedMonth,
                expectedCount, serviceOpcoUid, serviceUid, 0);
    }

    @Test
    public void serviceProviderSummary1AMATooLate() {
        final int expectedYear = 2014;
        final int expectedMonth = 4;
        final int expectedCount = 0;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_1;
        ServiceUid serviceUid = ServiceUid.PLN;
        serviceProviderSummaryTestTemplate(expectedYear, expectedMonth,
                expectedCount, serviceOpcoUid, serviceUid, 0);
    }

    @Test
    public void serviceProviderSummary3AMAEmpty() {
        final int expectedYear = 2014;
        final int expectedMonth = 2;
        final int expectedCount = 0;
        OpcoUid serviceOpcoUid = SERVICE_OPCO_UID_3;
        ServiceUid serviceUid = ServiceUid.PLN;
        serviceProviderSummaryTestTemplate(expectedYear, expectedMonth,
                expectedCount, serviceOpcoUid, serviceUid, 0);
    }

    @Test
    public void overallSummaryAMA1() {
        final int expectedYear = 2014;
        final int expectedMonth = 1;
        final int expectedCount = 62;
        final int recordsPerDay = 2;
        ServiceUid serviceUid = ServiceUid.PLN;
        overallSummaryTestTemplate(expectedYear, expectedMonth, expectedCount, recordsPerDay, serviceUid);
    }

    @Test
    public void overallSummaryAMA2() {
        final int expectedYear = 2014;
        final int expectedMonth = 2;
        final int expectedCount = 56;
        final int recordsPerDay = 2;
        ServiceUid serviceUid = ServiceUid.PLN;
        overallSummaryTestTemplate(expectedYear, expectedMonth, expectedCount, recordsPerDay, serviceUid);
    }

    @Test
    public void overallSummaryAMA3() {
        final int expectedYear = 2014;
        final int expectedMonth = 3;
        final int expectedCount = 62;
        final int recordsPerDay = 2;
        ServiceUid serviceUid = ServiceUid.PLN;
        overallSummaryTestTemplate(expectedYear, expectedMonth, expectedCount, recordsPerDay, serviceUid);
    }

    @Test
    public void overallSummaryDO() {
        final int expectedYear = 2014;
        final int expectedMonth = 3;
        final int expectedCount = 31;
        final int recordsPerDay = 1;
        ServiceUid serviceUid = ServiceUid.DVP;
        overallSummaryTestTemplate(expectedYear, expectedMonth, expectedCount, recordsPerDay, serviceUid);
    }

    @Test
    public void overallSummaryEmpty() {
        final int expectedYear = 2013;
        final int expectedMonth = 12;
        final int expectedCount = 0;
        final int recordsPerDay = 0;
        ServiceUid serviceUid = ServiceUid.DVP;
        overallSummaryTestTemplate(expectedYear, expectedMonth, expectedCount, recordsPerDay, serviceUid);
    }

    private void overallSummaryTestTemplate(int expectedYear, int expectedMonth, int expectedCount, int recordsPerDay, ServiceUid serviceUid) {
        YearAndMonth yearAndMonth = YearAndMonth.fromInts(expectedYear, expectedMonth);
        QueryIterator<UsageRecord> overallSummaryRecords = usageManager.getOverallSummary(serviceUid, yearAndMonth);
        Map<Integer, Integer> daysCount = Maps.newHashMap();

        while (overallSummaryRecords.hasNext()) {
            UsageRecord usageRecord = overallSummaryRecords.next();
            DateTime billDateTime = new DateTime(usageRecord.getBillDate().getTime());
            Integer dayOfMonth = billDateTime.getDayOfMonth();
            Integer monthOfYear = billDateTime.getMonthOfYear();
            Integer year = billDateTime.getYear();
            checkDate(expectedYear, expectedMonth, year, monthOfYear);
            if (daysCount.containsKey(dayOfMonth)) {
                daysCount.put(dayOfMonth, daysCount.get(dayOfMonth) + 1);
            } else {
                daysCount.put(dayOfMonth, 1);
            }

            checkCost(usageRecord, monthOfYear, dayOfMonth);
        }

        int totalCount = checkCount(recordsPerDay, daysCount);
        assertThat(totalCount).isEqualTo(expectedCount);
    }

    private int checkCount(int recordsPerDay, Map<Integer, Integer> daysCount) {
        int totalCount = 0;
        for (Map.Entry<Integer, Integer> dayCount : daysCount.entrySet()) {
            int dayValue = dayCount.getValue();
            totalCount += dayValue;
            assertThat(dayValue).describedAs("Expected records per day").isEqualTo(recordsPerDay);
        }
        return totalCount;
    }

    private void serviceProviderSummaryTestTemplate(int expectedYear, int expectedMonth, int expectedCount, OpcoUid serviceOpcoUid, ServiceUid serviceUid, int expectedRecordsPerDay) {
        YearAndMonth yearAndMonth = YearAndMonth.fromInts(expectedYear, expectedMonth);
        Map<Integer, Integer> countPerDay = Maps.newHashMap();
        QueryIterator<UsageRecord> serviceProviderSummaryRecords
                = usageManager.getServiceProviderSummary(serviceOpcoUid, serviceUid, yearAndMonth);

        while (serviceProviderSummaryRecords.hasNext()) {
            UsageRecord usageRecord = serviceProviderSummaryRecords.next();

            DateTime billDateTime = new DateTime(usageRecord.getBillDate().getTime());
            Integer dayOfMonth = billDateTime.getDayOfMonth();
            Integer monthOfYear = billDateTime.getMonthOfYear();
            Integer year = billDateTime.getYear();

            checkDate(expectedYear, expectedMonth, year, monthOfYear);

            if (countPerDay.containsKey(dayOfMonth)) {
                countPerDay.put(dayOfMonth, countPerDay.get(dayOfMonth) + 1);
            } else {
                countPerDay.put(dayOfMonth, 1);
            }

            checkCost(usageRecord, monthOfYear, dayOfMonth);
        }

        int totalCount = checkCount(expectedRecordsPerDay, countPerDay);
        assertThat(totalCount).isEqualTo(expectedCount);
    }

    private void customerSummaryTestTemplate(int expectedYear, int expectedMonth,
                                             int expectedCount, OpcoUid customerOpcoUid,
                                             ServiceUid serviceUid, OpcoUid serviceOpcoUid) {

        QueryIterator<UsageRecord> customerSummaryRecords
                = usageManager.getCustomerSummary(customerOpcoUid, serviceUid,
                YearAndMonth.fromInts(expectedYear, expectedMonth));

        Set<Integer> days = Sets.newHashSet();
        while (customerSummaryRecords.hasNext()) {
            UsageRecord usageRecord = customerSummaryRecords.next();

            assertThat(usageRecord.getCustomerOpcoUid()).isEqualTo(customerOpcoUid);
            assertThat(usageRecord.getServiceUid()).isEqualTo(serviceUid);
            assertThat(usageRecord.getServiceOpcoUid()).isEqualTo(serviceOpcoUid);

            DateTime billDateTime = new DateTime(usageRecord.getBillDate().getTime());
            Integer year = billDateTime.getYear();
            Integer monthOfYear = billDateTime.getMonthOfYear();
            Integer dayOfMonth = billDateTime.getDayOfMonth();
            // Check if any date repeats (it should NOT).
            assertThat(days.contains(dayOfMonth)).isFalse();
            days.add(dayOfMonth);

            checkDate(expectedYear, expectedMonth, year, monthOfYear);

            checkCost(usageRecord, monthOfYear, dayOfMonth);
        }
        assertThat(days.size()).isEqualTo(expectedCount);
    }

    private void checkDate(int expectedYear, int expectedMonth, Integer year, Integer monthOfYear) {
        assertThat(monthOfYear).isEqualTo(expectedMonth);
        assertThat(year).isEqualTo(expectedYear);
    }

    private void checkCost(UsageRecord usageRecord, Integer monthOfYear, Integer dayOfMonth) {
        Integer id = generateTestingId(monthOfYear, dayOfMonth);
        BigDecimal expectedCost = new BigDecimal(id);
        assertThat(usageRecord.getCost().compareTo(expectedCost)).isEqualTo(0);
    }

    private void generateUsageRecords(OpcoUid customerOpcoUid, OpcoUid serviceOpcoUid, ServiceUid serviceUid) {
        String stringUid = customerOpcoUid.toString()
                + serviceOpcoUid.toString()
                + serviceUid.toString();

        OpcoCustomerUid opcoCustomerUid = OpcoCustomerUid.fromString("oc" + stringUid);
        UUID userGuid = UUID.randomUUID();
        OpcoUserUid opcoUserUid = OpcoUserUid.fromString("ou" + stringUid);

        Calendar calendar = Calendar.getInstance();
        calendar.set(YEAR, MONTH, DAY);

        Date firstDate = calendarToSqlDate(calendar);

        UsageRecord templateUsageRecord = UsageRecord.builder()
                .usageUid(UsageUid.fromString(USAGE_UID_STRING))
                .billDate(firstDate)
                .userGuid(userGuid)
                .cost(new BigDecimal(0))
                .currency(Currency.USD)
                .costType(CostType.UNPAID)
                .description(DESCRIPTION)
                .details(DETAILS)
                .internalTransactionId(InternalId.fromString(INTERNAL_ID_STRING))
                .customerOpcoUserUid(opcoUserUid)
                .customerOpcoUid(customerOpcoUid)
                .serviceOpcoUid(serviceOpcoUid)
                .serviceUid(serviceUid)
                .itemType("JobCloudCost")
                .build();

        List<UsageRecord> usageRecords = Lists.newArrayList();

        for (int monthIterator = 0; monthIterator < 3; monthIterator++) {
            calendar.set(YEAR, MONTH + monthIterator, 1);
            int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
            //System.out.println("daysInMonth = " + calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

            for (int dayIterator = 0; dayIterator < daysInMonth; dayIterator++) {
                calendar.set(YEAR, MONTH + monthIterator, dayIterator + 1);
                int id = generateTestingId(MONTH + monthIterator + 1, dayIterator + 1);
                Date billDate = calendarToSqlDate(calendar);
                UsageRecord generatedUsageRecord = UsageRecord.builder().fromOther(templateUsageRecord)
                        .usageUid(UsageUid.fromString(stringUid + id))
                        .billDate(billDate)
                        .cost(new BigDecimal(id))
                        .build();

                usageRecords.add(generatedUsageRecord);
            }
        }

        Ebean.save(usageRecords);
    }

    private int generateTestingId(int month, int day) {
        return ID_CONSTANT * month + day;
    }

    private Date calendarToSqlDate(Calendar c) {
        return new Date(c.getTimeInMillis());
    }
}
