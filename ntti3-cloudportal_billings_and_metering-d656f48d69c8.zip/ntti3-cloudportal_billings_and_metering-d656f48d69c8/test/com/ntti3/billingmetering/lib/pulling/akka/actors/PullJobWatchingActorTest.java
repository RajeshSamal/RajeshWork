package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobEnded;
import com.ntti3.billingmetering.lib.pulling.akka.messages.Saved;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import mocks.FakeUsageRecordsAdder;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import utils.NoPullJobsTest;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobWatchingActorTest extends NoPullJobsTest {

    private int counter = 0;

    private ActorSystem system;
    private JavaTestKit javaTestKit;

    @Override
    public void startApp() {
        super.startApp();
        system = ActorSystem.create();
        javaTestKit = new JavaTestKit(system);
    }

    @Override
    public void stopApp() {
        super.stopApp();
        JavaTestKit.shutdownActorSystem(system);
    }

    @Test
    public void emptySequence() {
        final Props props = Props.create(PullJobWatchingActor.class, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<PullJobWatchingActor> watchingActor
                = TestActorRef.create(system, props, "watchingActor");

        UUID processUid = UUID.randomUUID();
        generateSequence(processUid, new int[]{}, new boolean[]{});
        watchingActor.tell(new Saved(processUid), javaTestKit.getRef());
        JobEnded jobEnded = javaTestKit.expectMsgClass(JobEnded.class);
        Assert.assertEquals("jobEnded", processUid, jobEnded.getProcessUid());
        Assert.assertTrue("successfully", jobEnded.hasSucceeded());
    }

    @Test
    public void fullSequence() {
        final Props props = Props.create(PullJobWatchingActor.class, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<PullJobWatchingActor> watchingActor
                = TestActorRef.create(system, props, "watchingActor");

        UUID processUid = UUID.randomUUID();
        generateSequence(processUid,
                new int[]{5, 1, 0, 3, 2, 4},
                new boolean[]{true, false, false, false, false, false});
        watchingActor.tell(new Saved(processUid), javaTestKit.getRef());
        JobEnded jobEnded = javaTestKit.expectMsgClass(JobEnded.class);
        Assert.assertEquals("jobEnded", processUid, jobEnded.getProcessUid());
        Assert.assertTrue("successfully", jobEnded.hasSucceeded());
    }

    @Test
    public void notFullSequence() {
        final Props props = Props.create(PullJobWatchingActor.class, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<PullJobWatchingActor> watchingActor
                = TestActorRef.create(system, props, "watchingActor");

        UUID processUid = UUID.randomUUID();
        generateSequence(processUid, new int[]{5, 0, 3, 2, 4},
                new boolean[]{true, false, false, false, false});
        watchingActor.tell(new Saved(processUid), javaTestKit.getRef());
        javaTestKit.expectNoMsg();
    }

    @Test
    public void noLast() {
        final Props props = Props.create(PullJobWatchingActor.class, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<PullJobWatchingActor> watchingActor
                = TestActorRef.create(system, props, "watchingActor");

        UUID processUid = UUID.randomUUID();
        generateSequence(processUid, new int[]{5, 1, 0, 3, 2, 4},
                new boolean[]{false, false, false, false, false, false});
        watchingActor.tell(new Saved(processUid), javaTestKit.getRef());
        javaTestKit.expectNoMsg();
    }

    private void generateSequence(UUID processUid, int[] numbers, boolean[] isLast) {
        for (int i = 0; i < numbers.length; i++) {
            final int groupSize = 10;
            for (int k = 0; k < groupSize; k++) {
                generateUsageRecord(processUid, isLast[i], numbers[i]);
            }
        }
    }

    private void generateUsageRecord(UUID processUid, boolean isLast, int sequenceNumber) {
        UsageRecord record = FakeUsageRecordsAdder.GenerateFakeUsageRecord(
                UsageUid.fromString("truid" + counter),
                InternalId.fromString("int_id" + counter * 2),
                OpcoUid.fromString("opco"),
                "description" + counter,
                new Date(DateTime.now().getMillis()),
                new BigDecimal("11.35").multiply(new BigDecimal(counter + 1)),
                ServiceUid.MGR,
                OpcoUid.fromString("serviceOpco"));

        UsageRecord.builder().fromOther(record)
                .processUid(processUid)
                .lastSequence(isLast)
                .sequenceNumber(sequenceNumber)
                .build()
                .save();

        counter++;
    }
}