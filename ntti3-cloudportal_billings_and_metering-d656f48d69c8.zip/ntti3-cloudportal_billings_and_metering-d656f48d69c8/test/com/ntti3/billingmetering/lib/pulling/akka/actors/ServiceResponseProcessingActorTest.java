package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import com.google.common.base.Optional;
import com.google.common.collect.Sets;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseProcessingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ProcessedServiceResponse;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ServiceResponse;
import com.ntti3.billingmetering.lib.pulling.util.AmaServiceResponseRecord;
import com.ntti3.billingmetering.lib.pulling.util.InfrastructureMapper;
import com.ntti3.billingmetering.lib.pulling.util.MessageInfo;
import com.ntti3.billingmetering.lib.pulling.util.ServiceResponseRecord;
import com.ntti3.billingmetering.lib.utils.UsageUidGenerator;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import com.ntti3.gums.CachingGumsConnector;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.models.User;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import play.libs.Json;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseProcessingActorTest {

    private ActorSystem system;
    private JavaTestKit javaTestKit;
    private int transactionIdCounter = 0;
    private final String dateFormat = "MM/dd/yyyy h:m:s a";

    @Before
    public void startApp() {
        system = ActorSystem.create();
        javaTestKit = new JavaTestKit(system);
    }

    @After
    public void teardown() {
        JavaTestKit.shutdownActorSystem(system);
        system = null;
    }

    @Test
    public void zeroOk() throws IOException, GumsProtocolException, ParseException {
        final int recordsCount = 0;
        final ServiceResponse response = createFakeServiceResponse(recordsCount);
        final GumsConnector gumsConnector = getMockGumsConnector();
        final UsageUidGenerator usageUidGenerator = getMockUsageUidGenerator();
        final InfrastructureMapper infrastructureMapper = getMockInfrastructureMapper();

        final ServiceResponseProcessingActorConfig config = new ServiceResponseProcessingActorConfig(dateFormat);
        final Props props = Props.create(ServiceResponseProcessingActor.class, gumsConnector,
                usageUidGenerator, infrastructureMapper, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseProcessingActor> workerRef = TestActorRef.create(system, props, "processingActor");
        workerRef.tell(response, javaTestKit.getRef());
        ProcessedServiceResponse processedServiceResponse = javaTestKit.expectMsgClass(ProcessedServiceResponse.class);
        Assert.assertEquals(recordsCount, processedServiceResponse.getRecords().size());
    }

    @Test
    public void singleRecordOk() throws IOException, GumsProtocolException, ParseException {
        final int recordsCount = 1;
        final ServiceResponse response = createFakeServiceResponse(recordsCount);
        final GumsConnector gumsConnector = getMockGumsConnector();
        final UsageUidGenerator usageUidGenerator = getMockUsageUidGenerator();
        final InfrastructureMapper infrastructureMapper = getMockInfrastructureMapper();
        final ServiceResponseProcessingActorConfig config = new ServiceResponseProcessingActorConfig(dateFormat);
        final Props props = Props.create(ServiceResponseProcessingActor.class, gumsConnector,
                usageUidGenerator, infrastructureMapper, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseProcessingActor> workerRef = TestActorRef.create(system, props, "processingActor");
        workerRef.tell(response, javaTestKit.getRef());
        ProcessedServiceResponse processedServiceResponse = javaTestKit.expectMsgClass(ProcessedServiceResponse.class);
        Assert.assertEquals(recordsCount, processedServiceResponse.getRecords().size());
    }

    @Test
    public void manyRecordsOk() throws IOException, GumsProtocolException, ParseException {
        final int recordsCount = 200;
        final ServiceResponse response = createFakeServiceResponse(recordsCount);
        final GumsConnector gumsConnector = getMockGumsConnector();
        final UsageUidGenerator usageUidGenerator = getMockUsageUidGenerator();
        final InfrastructureMapper infrastructureMapper = getMockInfrastructureMapper();
        final ServiceResponseProcessingActorConfig config = new ServiceResponseProcessingActorConfig(dateFormat);
        final Props props = Props.create(ServiceResponseProcessingActor.class, gumsConnector,
                usageUidGenerator, infrastructureMapper, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseProcessingActor> workerRef = TestActorRef.create(system, props, "processingActor");
        workerRef.tell(response, javaTestKit.getRef());
        ProcessedServiceResponse processedServiceResponse = javaTestKit.expectMsgClass(ProcessedServiceResponse.class);
        Assert.assertEquals(recordsCount, processedServiceResponse.getRecords().size());
    }

    private InfrastructureMapper getMockInfrastructureMapper() {
        final InfrastructureMapper infrastructureMapper = Mockito.mock(InfrastructureMapper.class);
        when(infrastructureMapper.getOpcoUidFor(any(String.class))).then(new Answer<Optional<OpcoUid>>() {
            @Override
            public Optional<OpcoUid> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.of(OpcoUid.fromString("amazon"));
            }
        });
        return infrastructureMapper;
    }

    private ServiceResponse createFakeServiceResponse(int size) throws ParseException {
        Set<ServiceResponseRecord> records = Sets.newHashSet();
        for (int i = 0; i < size; i++) {
            records.add(createFakeServiceResponseRecord());
        }
        return new ServiceResponse(records, ServiceUid.PLN, new MessageInfo(UUID.randomUUID(), 13, false));
    }

    private AmaServiceResponseRecord createFakeServiceResponseRecord() throws ParseException {
        return new AmaServiceResponseRecord("tr" + transactionIdCounter++, UUID.randomUUID(), "amazon", "descr", new Date("10/13/2014 1:2:3 AM"), new BigDecimal("2.30"), "USD", "JobCloudCost", Json.newObject());
    }

    private UsageUidGenerator getMockUsageUidGenerator() {
        final UsageUidGenerator usageUidGenerator =
                Mockito.mock(UsageUidGenerator.class);
        when(usageUidGenerator.generate()).then(new Answer<UsageUid>() {
            @Override
            public UsageUid answer(InvocationOnMock invocation) throws Throwable {
                return new UsageUid(UUID.randomUUID().toString());
            }
        });
        return usageUidGenerator;
    }

    private CachingGumsConnector getMockGumsConnector() throws IOException, GumsProtocolException {
        final User user = getMockUser();
        final CachingGumsConnector cachingGumsConnector =
                Mockito.mock(CachingGumsConnector.class);
        when(cachingGumsConnector.getUser(any(UUID.class))).then(new Answer<User>() {
            @Override
            public User answer(InvocationOnMock invocation) throws Throwable {
                return user;
            }
        });
        return cachingGumsConnector;
    }

    private CachingGumsConnector getFailingGumsConnector() throws IOException, GumsProtocolException {
        return getFailingGumsConnector(Integer.MAX_VALUE);
    }


    private CachingGumsConnector getFailingGumsConnector(final int failures) throws IOException, GumsProtocolException {
        final User user = getMockUser();
        final CachingGumsConnector cachingGumsConnector =
                Mockito.mock(CachingGumsConnector.class);
        when(cachingGumsConnector.getUser(any(UUID.class))).then(new Answer<User>() {
            private int failuresLeft = failures;

            @Override
            public User answer(InvocationOnMock invocation) throws Throwable {
                if (failuresLeft > 0) {
                    failuresLeft--;
                    throw new GumsProtocolException("An expected GumsProtocolException!");
                }
                return user;
            }
        });
        return cachingGumsConnector;
    }

    private User getMockUser() {
        final User user = new User();
        final UUID userGuid = UUID.randomUUID();
        user.setOpcoCUid("asd");
        user.setGuid(userGuid);
        user.setOpcoUid("amazon");
        user.setOpcoUUid("opcouuid");
        return user;
    }
}
