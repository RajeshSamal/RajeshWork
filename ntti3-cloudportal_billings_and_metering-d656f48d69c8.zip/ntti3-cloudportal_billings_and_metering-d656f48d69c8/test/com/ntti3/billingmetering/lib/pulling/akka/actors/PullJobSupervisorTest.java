package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import com.google.common.base.Optional;
import com.ntti3.billingmetering.lib.pulling.PullJobDetails;
import com.ntti3.billingmetering.lib.pulling.PullJobManager;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.PullJobSupervisorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobEnded;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobOrder;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import scala.concurrent.duration.FiniteDuration;
import utils.NoPullJobsTest;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobSupervisorTest extends NoPullJobsTest {

    private final FiniteDuration tickDuration = FiniteDuration.create(1, TimeUnit.MINUTES);
    private final FiniteDuration bigBackoff = FiniteDuration.create(2, TimeUnit.SECONDS);
    private final FiniteDuration smallBackoff = FiniteDuration.create(1, TimeUnit.SECONDS);
    private final FiniteDuration jobTimeout = FiniteDuration.create(5, TimeUnit.SECONDS);
    private final PullJobSupervisorConfig config = new PullJobSupervisorConfig(tickDuration,
            smallBackoff, bigBackoff, jobTimeout);
    private final PullJobDetails pullJobDetails = Mockito.mock(PullJobDetails.class);

    private ActorSystem system;

    @Override
    public void startApp() {
        super.startApp();
        system = ActorSystem.create();
    }

    @Override
    public void stopApp() {
        super.stopApp();
        JavaTestKit.shutdownActorSystem(system);
        system = null;
    }

    @Test
    public void getJob() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerDefaultJobPresentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        Mockito.verify(pullJobManager).getJob();
        Mockito.verify(pullJobManager, times(2)).getNextJobTime();
        JobOrder jobOrder = probe.expectMsgClass(JobOrder.class);
        Assert.assertEquals(pullJobDetails, jobOrder.getPullJobDetails());
    }

    @Test
    public void getJobAbsent() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerAbsentJobAbsentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(bigBackoff.toMillis() * 2);
        Mockito.verify(pullJobManager).getJob();
        Mockito.verify(pullJobManager, times(2)).getNextJobTime();
        probe.expectNoMsg();
    }

    @Test
    public void endsSuccessfulJob() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerDefaultJobPresentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        JobOrder jobOrder = probe.expectMsgClass(JobOrder.class);
        supervisor.tell(JobEnded.withSuccess(jobOrder.getProcessUid()), null);
        Mockito.verify(pullJobManager).markJobDone(jobOrder.getPullJobDetails(), jobOrder.getProcessUid());
    }

    @Test
    public void noJobSuccess() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerAbsentJobPresentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        final UUID processUid = UUID.randomUUID();
        supervisor.tell(JobEnded.withSuccess(processUid), null);
        Mockito.verify(pullJobManager, never()).markJobDone(any(PullJobDetails.class), eq(processUid));
        Mockito.verify(pullJobManager, never()).markJobFailed(any(PullJobDetails.class), eq(processUid));
    }

    @Test
    public void noJobFailure() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerAbsentJobPresentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        probe.expectNoMsg();
        supervisor.tell(JobEnded.withFailure(UUID.randomUUID()), null);
        Mockito.verify(pullJobManager, never()).markJobDone(any(PullJobDetails.class), any(UUID.class));
        Mockito.verify(pullJobManager, never()).markJobFailed(any(PullJobDetails.class), any(UUID.class));
    }

    @Test
    public void timeoutsJobs() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerOneJob();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        Thread.sleep(jobTimeout.toMillis() * 2);
        Mockito.verify(pullJobManager).markJobFailed(eq(pullJobDetails), any(UUID.class));
    }

    @Test
    public void markFailed() throws InterruptedException {
        final PullJobManager pullJobManager = getPullJobManagerDefaultJobPresentTime();

        final JavaTestKit probe = new JavaTestKit(system);
        final Props props = Props.create(PullJobSupervisor.class, pullJobManager, config, system.actorSelection(probe.getRef().path()));
        final TestActorRef<PullJobSupervisor> supervisor = TestActorRef.create(system, props, "supervisor");
        Thread.sleep(smallBackoff.toMillis() * 2);
        JobOrder jobOrder = probe.expectMsgClass(JobOrder.class);
        supervisor.tell(JobEnded.withFailure(jobOrder.getProcessUid()), null);
        Mockito.verify(pullJobManager, never()).markJobDone(any(PullJobDetails.class), any(UUID.class));
        Mockito.verify(pullJobManager).markJobFailed(jobOrder.getPullJobDetails(), jobOrder.getProcessUid());
    }

    private PullJobManager getPullJobManagerAbsentJob() {
        final PullJobManager pullJobManager = Mockito.mock(PullJobManager.class);
        when(pullJobManager.getJob()).then(new Answer<Optional<PullJobDetails>>() {
            @Override
            public Optional<PullJobDetails> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.absent();
            }
        });
        return pullJobManager;
    }

    private PullJobManager getPullJobManagerDefaultJob() {
        final PullJobManager pullJobManager = Mockito.mock(PullJobManager.class);
        when(pullJobManager.getJob()).then(new Answer<Optional<PullJobDetails>>() {
            @Override
            public Optional<PullJobDetails> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.of(pullJobDetails);
            }
        });
        return pullJobManager;
    }

    private PullJobManager getPullJobManagerDefaultJobPresentTime() {
        final PullJobManager pullJobManager = getPullJobManagerDefaultJob();

        when(pullJobManager.getNextJobTime()).then(new Answer<Optional<DateTime>>() {

            @Override
            public Optional<DateTime> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.of(DateTime.now().minusHours(1));
            }
        });
        return pullJobManager;
    }

    private PullJobManager getPullJobManagerAbsentJobPresentTime() {
        final PullJobManager pullJobManager = getPullJobManagerAbsentJob();

        when(pullJobManager.getNextJobTime()).then(new Answer<Optional<DateTime>>() {
            @Override
            public Optional<DateTime> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.of(DateTime.now().minusHours(1));
            }
        });
        return pullJobManager;
    }

    private PullJobManager getPullJobManagerAbsentJobAbsentTime() {
        final PullJobManager pullJobManager = getPullJobManagerAbsentJob();

        when(pullJobManager.getNextJobTime()).then(new Answer<Optional<DateTime>>() {
            @Override
            public Optional<DateTime> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.absent();
            }
        });
        return pullJobManager;
    }

    private PullJobManager getPullJobManagerOneJob() {
        final PullJobManager pullJobManager = Mockito.mock(PullJobManager.class);
        when(pullJobManager.getJob()).then(new Answer<Optional<PullJobDetails>>() {

            boolean called = false;

            @Override
            public Optional<PullJobDetails> answer(InvocationOnMock invocation) throws Throwable {
                if (!called) {
                    called = true;
                    return Optional.of(pullJobDetails);
                } else {
                    return Optional.absent();
                }
            }
        });

        when(pullJobManager.getNextJobTime()).then(new Answer<Optional<DateTime>>() {

            @Override
            public Optional<DateTime> answer(InvocationOnMock invocation) throws Throwable {
                return Optional.of(DateTime.now().minusHours(1));
            }
        });

        return pullJobManager;
    }
}
