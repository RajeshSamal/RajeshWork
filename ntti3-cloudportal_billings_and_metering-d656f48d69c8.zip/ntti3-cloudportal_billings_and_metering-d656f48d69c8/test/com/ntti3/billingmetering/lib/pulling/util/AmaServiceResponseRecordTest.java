package com.ntti3.billingmetering.lib.pulling.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.ItemType;
import org.fest.assertions.Assertions;
import org.joda.time.DateTime;
import org.junit.Test;
import play.libs.Json;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class AmaServiceResponseRecordTest {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static final String FAKE_TR_ID = "fake-tr-id";
    public static final String COST_VALUE = "1.234";
    public static final String CURRENCY_TEXT_REPRESENTATION = Currency.USD.getTextRepresentation();
    public static final String DESCRIPTION = "description";
    public static final String ITEM_TYPE_TEXT_REPRESENTATION = ItemType.JCC.getTextRepresentation();
    public static final String FAKE_AMAZON = "fake-amazon";
    public static final String USER_UUID = UUID.randomUUID().toString();
    public static final String DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";

    @Test
    public void identityTest() {
        ObjectNode record = Json.newObject();
        DateTime now = DateTime.now();

        record.put(AmaServiceResponseRecord.TRANSACTION_ID, FAKE_TR_ID);
        record.put(AmaServiceResponseRecord.BILL_DATE, now.toString(DATE_FORMAT));
        record.put(AmaServiceResponseRecord.COST, COST_VALUE);
        record.put(AmaServiceResponseRecord.CURRENCY, CURRENCY_TEXT_REPRESENTATION);
        record.put(AmaServiceResponseRecord.DESCRIPTION, DESCRIPTION);
        record.put(AmaServiceResponseRecord.ITEM_TYPE, ItemType.JCC.getTextRepresentation());

        ObjectNode cloud = record.putObject(AmaServiceResponseRecord.CLOUD);
        cloud.put(AmaServiceResponseRecord.Cloud.INFRASTRUCTURE_ID, FAKE_AMAZON);

        ObjectNode user = record.putObject(AmaServiceResponseRecord.USER);
        user.put(AmaServiceResponseRecord.UserInResponseRecord.USER_GUID, USER_UUID);


        ObjectNode details = record.putObject(AmaServiceResponseRecord.DETAILS);
        details.put("det-entry", "det-value");

        AmaServiceResponseRecord amaServiceResponseRecord
                = Json.fromJson(record, AmaServiceResponseRecord.class);

        Assertions.assertThat(amaServiceResponseRecord.getTransactionId()).isEqualTo(FAKE_TR_ID);
        Assertions.assertThat(new SimpleDateFormat(DATE_FORMAT).format(amaServiceResponseRecord.getBillDate())).isEqualTo(now.toString(DATE_FORMAT));
        Assertions.assertThat(amaServiceResponseRecord.getCost()).isEqualTo(new BigDecimal(COST_VALUE));
        Assertions.assertThat(amaServiceResponseRecord.getCurrency()).isEqualTo(CURRENCY_TEXT_REPRESENTATION);
        Assertions.assertThat(amaServiceResponseRecord.getDescription()).isEqualTo(DESCRIPTION);
        Assertions.assertThat(amaServiceResponseRecord.getItemType()).isEqualTo(ITEM_TYPE_TEXT_REPRESENTATION);
        Assertions.assertThat(amaServiceResponseRecord.getInfrastructureId()).isEqualTo(FAKE_AMAZON);
        Assertions.assertThat(amaServiceResponseRecord.getUserGuid().toString()).isEqualTo(USER_UUID);
        Assertions.assertThat(Json.stringify(amaServiceResponseRecord.getDetails())).isEqualTo(Json.stringify(details));
    }
}
