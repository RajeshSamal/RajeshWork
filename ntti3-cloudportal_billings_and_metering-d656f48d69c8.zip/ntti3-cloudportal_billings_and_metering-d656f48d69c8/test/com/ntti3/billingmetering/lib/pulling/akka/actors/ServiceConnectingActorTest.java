package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import com.ntti3.billingmetering.lib.pulling.PullJobDetails;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceConnectingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobOrder;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ServiceResponse;
import com.ntti3.billingmetering.lib.pulling.util.PullJobConfig;
import com.ntti3.billingmetering.lib.pulling.util.ServiceConnector;
import com.ntti3.billingmetering.lib.pulling.util.SocketFactoryCreator;
import com.ntti3.billings.types.base.ServiceUid;
import mocks.FakeServiceResponseGenerator;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.SchemeSocketFactory;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import scala.concurrent.duration.FiniteDuration;
import utils.NoPullJobsTest;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceConnectingActorTest extends NoPullJobsTest {

    public static final PullJobDetails PULL_JOB_DETAILS;
    public static final PullJobDetails AMA_PULL_JOB_DETAILS;
    private ActorSystem system;
    private JavaTestKit javaTestKit;

    static {
        PULL_JOB_DETAILS = Mockito.mock(PullJobDetails.class);
        when(PULL_JOB_DETAILS.getPullJobConfig()).then(new Answer<PullJobConfig>() {
            private final PullJobConfig pullJobConfig = new PullJobConfig(ServiceUid.PLN, "", "DEFAULT");
            @Override
            public PullJobConfig answer(InvocationOnMock invocation) throws Throwable {
                return pullJobConfig;
            }
        });

        when(PULL_JOB_DETAILS.getServiceUid()).thenAnswer(new Answer<ServiceUid>(){
            @Override
            public ServiceUid answer(InvocationOnMock invocation) throws Throwable {
                return ServiceUid.PLN;
            }
        });

        AMA_PULL_JOB_DETAILS = Mockito.mock(PullJobDetails.class);
        when(AMA_PULL_JOB_DETAILS.getPullJobConfig()).then(new Answer<PullJobConfig>() {
            private final PullJobConfig pullJobConfig = new PullJobConfig(ServiceUid.PLN, "", "AMA");
            @Override
            public PullJobConfig answer(InvocationOnMock invocation) throws Throwable {
                return pullJobConfig;
            }
        });

        when(AMA_PULL_JOB_DETAILS.getServiceUid()).thenAnswer(new Answer<ServiceUid>(){
            @Override
            public ServiceUid answer(InvocationOnMock invocation) throws Throwable {
                return ServiceUid.PLN;
            }
        });
    }

    @Override
    public void startApp() {
        super.startApp();
        system = ActorSystem.create();
        javaTestKit = new JavaTestKit(system);
    }

    @Override
    public void stopApp() {
        super.stopApp();
        JavaTestKit.shutdownActorSystem(system);
        system = null;
    }

    @Test
    public void connectsAMA() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector connector = getFakeAmaServiceConnector(10, 5, FakeServiceResponseGenerator.Correctness.CORRECT);

        final JavaTestKit probe = new JavaTestKit(system);
        final int bufferSize = 25;
        final ServiceConnectingActorConfig config = new ServiceConnectingActorConfig(bufferSize);
        final SocketFactoryCreator socketFactoryCreator = getFakeSocketFactoryCreator();
        final Props props = Props.create(ServiceConnectingActor.class, connector, config, socketFactoryCreator, system.actorSelection(probe.getRef().path()));
        final TestActorRef<ServiceConnectingActor> connectingActorRef = TestActorRef.create(system, props, "connectingActor");
        probe.expectNoMsg();
        connectingActorRef.tell(new JobOrder(UUID.randomUUID(), AMA_PULL_JOB_DETAILS), javaTestKit.getRef());
        ServiceResponse response = probe.expectMsgClass(ServiceResponse.class);
        Assert.assertEquals("correct response size", bufferSize, response.getRecords().size());
        Assert.assertFalse("not last message", response.getMessageInfo().isLast());
        response = probe.expectMsgClass(ServiceResponse.class);
        Assert.assertEquals("correct response size", bufferSize, response.getRecords().size());
        Assert.assertTrue("not last message", response.getMessageInfo().isLast());
        probe.expectNoMsg();
        javaTestKit.expectNoMsg();
    }

    @Test
    public void connectsDefault() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector connector = getFakeDefaultServiceConnector(10, 5, FakeServiceResponseGenerator.Correctness.CORRECT);

        final JavaTestKit probe = new JavaTestKit(system);
        final int bufferSize = 25;
        final ServiceConnectingActorConfig config = new ServiceConnectingActorConfig(bufferSize);
        final SocketFactoryCreator socketFactoryCreator = getFakeSocketFactoryCreator();
        final Props props = Props.create(ServiceConnectingActor.class, connector, config, socketFactoryCreator, system.actorSelection(probe.getRef().path()));
        final TestActorRef<ServiceConnectingActor> connectingActorRef = TestActorRef.create(system, props, "connectingActor");
        probe.expectNoMsg();
        connectingActorRef.tell(new JobOrder(UUID.randomUUID(), PULL_JOB_DETAILS), javaTestKit.getRef());
        ServiceResponse response = probe.expectMsgClass(ServiceResponse.class);
        Assert.assertEquals("correct response size", bufferSize, response.getRecords().size());
        Assert.assertFalse("not last message", response.getMessageInfo().isLast());
        response = probe.expectMsgClass(ServiceResponse.class);
        Assert.assertEquals("correct response size", bufferSize, response.getRecords().size());
        Assert.assertTrue("not last message", response.getMessageInfo().isLast());
        probe.expectNoMsg();
        javaTestKit.expectNoMsg();
    }

    @Test
    public void finishesSuccessfully() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector connector = getFakeAmaServiceConnector(1, 51, FakeServiceResponseGenerator.Correctness.CORRECT);
        final JavaTestKit probe = new JavaTestKit(system);
        final int bufferSize = 25;
        final ServiceConnectingActorConfig config = new ServiceConnectingActorConfig(bufferSize);
        final SocketFactoryCreator socketFactoryCreator = getFakeSocketFactoryCreator();
        final Props props = Props.create(ServiceConnectingActor.class, connector, config, socketFactoryCreator, system.actorSelection(probe.getRef().path()));
        final TestActorRef<ServiceConnectingActor> connectingActorRef = TestActorRef.create(system, props, "connectingActor");
        probe.expectNoMsg();

        connectingActorRef.tell(new JobOrder(UUID.randomUUID(), AMA_PULL_JOB_DETAILS), javaTestKit.getRef());

        expectServiceResponse("first", probe, bufferSize, 0, false);
        expectServiceResponse("second", probe, bufferSize, 1, false);
        expectServiceResponse("last", probe, 1, 2, true);

        javaTestKit.expectNoMsg();
        probe.expectNoMsg();
    }

    @Test
    public void finishesSucessfullyOnEmpty() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector connector = getFakeAmaServiceConnector(1, 0, FakeServiceResponseGenerator.Correctness.CORRECT);
        final JavaTestKit probe = new JavaTestKit(system);
        final int bufferSize = 25;
        final ServiceConnectingActorConfig config = new ServiceConnectingActorConfig(bufferSize);
        final SocketFactoryCreator socketFactoryCreator = getFakeSocketFactoryCreator();
        final Props props = Props.create(ServiceConnectingActor.class, connector, config, socketFactoryCreator, system.actorSelection(probe.getRef().path()));
        final TestActorRef<ServiceConnectingActor> connectingActorRef = TestActorRef.create(system, props, "connectingActor");
        probe.expectNoMsg();

        connectingActorRef.tell(new JobOrder(UUID.randomUUID(), AMA_PULL_JOB_DETAILS), javaTestKit.getRef());

        expectServiceResponse("empty", probe, 0, 0, true);
        javaTestKit.expectNoMsg();
        probe.expectNoMsg();
    }

    private void expectServiceResponse(String message, JavaTestKit testKit, int size, int sequenceNumber, boolean last) {
        System.out.println(message);
        expectServiceResponse(testKit, size, sequenceNumber, last);
    }

    private void expectServiceResponse(JavaTestKit testKit, int size, int sequenceNumber, boolean last) {
        ServiceResponse response = testKit.expectMsgClass(new FiniteDuration(10, TimeUnit.SECONDS), ServiceResponse.class);
        Assert.assertEquals("size", size, response.getRecords().size());
        Assert.assertEquals("sequence number", sequenceNumber, response.getSequenceNumber());
        Assert.assertEquals("last", last, response.isLast());
    }

    private ServiceConnector getFakeAmaServiceConnector(final int groupCount, final int groupSize, final FakeServiceResponseGenerator.Correctness correctness)
            throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector serviceConnector = Mockito.mock(ServiceConnector.class);
        when(serviceConnector.connect(any(String.class), any(SchemeSocketFactory.class), any(String.class)))
                .then(new Answer<InputStream>() {

                    @Override
                    public InputStream answer(InvocationOnMock invocation) throws Throwable {
                        return FakeServiceResponseGenerator.AMA.generateStream(groupCount, groupSize, 0, correctness);
                    }
                });
        return serviceConnector;
    }

    private ServiceConnector getFakeDefaultServiceConnector(final int groupCount, final int groupSize, final FakeServiceResponseGenerator.Correctness correctness)
            throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
        ServiceConnector serviceConnector = Mockito.mock(ServiceConnector.class);
        when(serviceConnector.connect(any(String.class), any(SchemeSocketFactory.class), any(String.class)))
                .then(new Answer<InputStream>() {

                    @Override
                    public InputStream answer(InvocationOnMock invocation) throws Throwable {
                        return FakeServiceResponseGenerator.DEFAULT.generateStream(groupCount, groupSize, 0, correctness);
                    }
                });
        return serviceConnector;
    }

    private SocketFactoryCreator getFakeSocketFactoryCreator() {
        SocketFactoryCreator socketFactoryCreator = Mockito.mock(SocketFactoryCreator.class);
        when(socketFactoryCreator.getFactoryFor(any(String.class)))
                .then(new Answer<SchemeSocketFactory>() {
                    @Override
                    public SchemeSocketFactory answer(InvocationOnMock invocationOnMock) throws Throwable {
                        return new PlainSocketFactory();
                    }
                });
        return socketFactoryCreator;
    }
}
