package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import com.avaje.ebean.Ebean;
import com.google.common.collect.Sets;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseSavingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ProcessedServiceResponse;
import com.ntti3.billingmetering.lib.pulling.akka.messages.SaveFailed;
import com.ntti3.billingmetering.lib.pulling.akka.messages.Saved;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import mocks.FakeUsageRecordsAdder;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import scala.concurrent.duration.FiniteDuration;
import utils.NoPullJobsTest;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseSavingActorTest extends NoPullJobsTest {
    private static final FiniteDuration FLUSH_AFTER_DURATION = FiniteDuration.create(5, TimeUnit.SECONDS);

    private ActorSystem system;
    private JavaTestKit javaTestKit;
    private final UUID processUid = UUID.randomUUID();

    @Override
    public void startApp() {
        super.startApp();
        system = ActorSystem.create();
        javaTestKit = new JavaTestKit(system);
    }

    @Override
    public void stopApp() {
        super.stopApp();
        JavaTestKit.shutdownActorSystem(system);
        system = null;
    }

    @Test
    public void buffersAndFlushesAfterTimeout() {
        final int bufferSize = 20;
        ServiceResponseSavingActorConfig config
                = new ServiceResponseSavingActorConfig(bufferSize, FLUSH_AFTER_DURATION);
        final Props props = Props.create(ServiceResponseSavingActor.class, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseSavingActor> savingActor
                = TestActorRef.create(system, props, "savingActor");

        savingActor.tell(getProcessedResponse(10), javaTestKit.getRef());
        Assert.assertEquals(0, Ebean.find(UsageRecord.class).findRowCount());
        javaTestKit.expectNoMsg(FiniteDuration.Zero());
        Saved saved = javaTestKit.expectMsgClass(FLUSH_AFTER_DURATION.mul(2), Saved.class);
        Assert.assertEquals("messageInfo", processUid, saved.getProcessUid());
    }

    @Test
    public void flushesBuffer() {
        final int bufferSize = 10;
        final int packageSize = 20;
        ServiceResponseSavingActorConfig config
                = new ServiceResponseSavingActorConfig(bufferSize, FLUSH_AFTER_DURATION);
        final Props props = Props.create(ServiceResponseSavingActor.class, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseSavingActor> savingActor
                = TestActorRef.create(system, props, "savingActor");

        savingActor.tell(getProcessedResponse(packageSize), javaTestKit.getRef());
        Assert.assertEquals(packageSize, Ebean.find(UsageRecord.class).findRowCount());
        javaTestKit.expectMsgClass(Saved.class);
    }

    @Test
    public void handleErrors() {
        final int bufferSize = 10;
        final int packageSize = 20;
        ServiceResponseSavingActorConfig config
                = new ServiceResponseSavingActorConfig(bufferSize, FLUSH_AFTER_DURATION);
        final Props props = Props.create(ServiceResponseSavingActor.class, config, system.actorSelection(javaTestKit.getRef().path()));
        final TestActorRef<ServiceResponseSavingActor> savingActor
                = TestActorRef.create(system, props, "savingActor");

        ProcessedServiceResponse processedServiceResponse = getProcessedResponse(packageSize);
        Ebean.save(processedServiceResponse.getRecords());
        savingActor.tell(getProcessedResponse(packageSize), javaTestKit.getRef());
        Assert.assertEquals(packageSize, Ebean.find(UsageRecord.class).findRowCount());
        javaTestKit.expectMsgClass(SaveFailed.class);
    }

    private ProcessedServiceResponse getProcessedResponse(int size) {
        Set<UsageRecord> records = Sets.newHashSet();

        for (int i = 0; i < size; i++) {
            records.add(fakeUsageRecord(i));
        }
        return new ProcessedServiceResponse(records, processUid);
    }

    private UsageRecord fakeUsageRecord(int i) {
        return FakeUsageRecordsAdder.GenerateFakeUsageRecord(
                UsageUid.fromString("truid" + i),
                InternalId.fromString("int_id" + i * 2),
                OpcoUid.fromString("opco"),
                "description" + i,
                new Date(DateTime.now().getMillis()),
                new BigDecimal("11.35").multiply(new BigDecimal(i + 1)),
                ServiceUid.MGR,
                OpcoUid.fromString("serviceOpco"));
    }
}
