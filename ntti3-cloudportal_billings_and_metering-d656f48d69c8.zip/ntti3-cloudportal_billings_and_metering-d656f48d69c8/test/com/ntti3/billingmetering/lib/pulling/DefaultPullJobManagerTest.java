package com.ntti3.billingmetering.lib.pulling;

import com.avaje.ebean.Ebean;
import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.ntti3.billingmetering.lib.pulling.util.DefaultPullJobsConfigManager;
import com.ntti3.billingmetering.lib.pulling.util.PullJobConfig;
import com.ntti3.billingmetering.lib.pulling.util.PullJobManagerConfig;
import com.ntti3.billingmetering.lib.pulling.util.PullJobsConfigManager;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.SchedulingStrategy;
import com.ntti3.billingmetering.models.PullJobRecord;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.UsageUid;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import scala.concurrent.duration.FiniteDuration;
import utils.NoPullJobsTest;

import java.sql.Date;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultPullJobManagerTest extends NoPullJobsTest {

    public static final SchedulingStrategy EMPTY_SCHEDULING_STRATEGY = Mockito.mock(SchedulingStrategy.class);
    public static final PullJobManagerConfig EMPTY_PULL_JOB_MANAGER_CONFIG = Mockito.mock(PullJobManagerConfig.class);
    public static final PullJobsConfigManager EMPTY_PULL_JOBS_CONFIG_MANAGER
            = Mockito.mock(PullJobsConfigManager.class);
    private static final PullJobManagerConfig PULL_JOB_MANAGER_CONFIG
            = new PullJobManagerConfig(FiniteDuration.create(20, TimeUnit.SECONDS));
    private int counter = 0;

    @Test
    public void schedulesIfNoJobs() {
        SchedulingStrategy strategy = Mockito.mock(SchedulingStrategy.class);
        when(strategy.getFistExecutionTime()).then(new Answer<DateTime>() {
            @Override
            public DateTime answer(InvocationOnMock invocation) throws Throwable {
                return DateTime.now().minusHours(1);
            }
        });

        final PullJobConfig pullJobConfig = new PullJobConfig(ServiceUid.PLN, "", "AMA");
        PullJobsConfigManager configManager = Mockito.mock(DefaultPullJobsConfigManager.class);
        when(configManager.getAllConfigs()).then(new Answer<Collection<PullJobConfig>>() {
            @Override
            public Collection<PullJobConfig> answer(InvocationOnMock invocation) throws Throwable {
                return Lists.newArrayList(pullJobConfig);
            }
        });

        when(configManager.getConfig(any(ServiceUid.class))).then(new Answer<PullJobConfig>() {
            @Override
            public PullJobConfig answer(InvocationOnMock invocation) throws Throwable {
                return pullJobConfig;
            }
        });

        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(strategy,
                PULL_JOB_MANAGER_CONFIG, configManager);

        Optional<DateTime> nextJobTime = defaultPullJobManager.getNextJobTime();
        Optional<PullJobDetails> nextJob = defaultPullJobManager.getJob();

        Assert.assertTrue("nextJobTime present", nextJobTime.isPresent());
        Assert.assertTrue("nextJob present", nextJob.isPresent());
    }

    @Test
    public void nextJobTimeSelectOldestJobs() {
        List<PullJobRecord> pullJobRecords = twoReadyJobs();
        PullJobRecord oldestPullJob = pullJobRecords.get(1);
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                EMPTY_PULL_JOB_MANAGER_CONFIG, EMPTY_PULL_JOBS_CONFIG_MANAGER);
        Optional<DateTime> optionalNextJobTime = defaultPullJobManager.getNextJobTime();
        assertThat(optionalNextJobTime.isPresent()).isTrue();
        assertThat(optionalNextJobTime.get()).isEqualTo(oldestPullJob.getBusyTo());
    }

    @Test
    public void nextJobTimeWithFailedJob1() {
        PullJobRecord futureJob = PullJobRecord.builder()
                .targetService(ServiceUid.DVP)
                .executeAt(DateTime.now().plusMinutes(1))
                .build();

        PullJobRecord failedJob = PullJobRecord.builder()
                .targetService(ServiceUid.MGR)
                .status(Status.F)
                .busyTo(DateTime.now().plusHours(1))
                .executeAt(DateTime.now().minusMinutes(1))
                .build();

        futureJob.save();
        failedJob.save();


        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                EMPTY_PULL_JOB_MANAGER_CONFIG, EMPTY_PULL_JOBS_CONFIG_MANAGER);
        Optional<DateTime> optionalNextJobTime = defaultPullJobManager.getNextJobTime();
        assertThat(optionalNextJobTime.isPresent()).isTrue();
        assertThat(optionalNextJobTime.get()).isEqualTo(futureJob.getExecuteAt());
    }

    @Test
    public void nextJobTimeWithFailedJob2() {
        DateTime now = DateTime.now();
        PullJobRecord futureJob = PullJobRecord.builder()
                .targetService(ServiceUid.DVP)
                .executeAt(now.plusMinutes(30))
                .build();

        PullJobRecord failedJob = PullJobRecord.builder()
                .targetService(ServiceUid.MGR)
                .status(Status.F)
                .busyTo(now.plusMinutes(15))
                .executeAt(now.minusMinutes(1))
                .build();

        futureJob.save();
        failedJob.save();

        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                EMPTY_PULL_JOB_MANAGER_CONFIG, EMPTY_PULL_JOBS_CONFIG_MANAGER);

        Optional<DateTime> optionalNextJobTime = defaultPullJobManager.getNextJobTime();
        assertThat(optionalNextJobTime.isPresent()).isTrue();
        assertThat(optionalNextJobTime.get()).isEqualTo(failedJob.getBusyTo());
    }

    @Test
    public void noJobOnBusyButNotTimedOutJob() {
        busyButNotTimedOutJob();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                EMPTY_PULL_JOB_MANAGER_CONFIG, EMPTY_PULL_JOBS_CONFIG_MANAGER);
        Optional<PullJobDetails> jobDetails = defaultPullJobManager.getJob();
        Assert.assertFalse("jobDetails absent", jobDetails.isPresent());
    }

    @Test
    public void nextJobTimeBusyButNotTimedOutJob() {
        List<PullJobRecord> pullJobRecords = busyButNotTimedOutJob();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                EMPTY_PULL_JOB_MANAGER_CONFIG, EMPTY_PULL_JOBS_CONFIG_MANAGER);
        Optional<DateTime> optionalNextJobTime = defaultPullJobManager.getNextJobTime();
        assertThat(optionalNextJobTime.isPresent()).isTrue();
        assertThat(optionalNextJobTime.get()).isEqualTo(pullJobRecords.get(0).getBusyTo());
    }

    @Test
    public void timedOutJob() {
        PullJobRecord busyJob = PullJobRecord.builder()
                .targetService(ServiceUid.DVP)
                .executeAt(DateTime.now().minusMinutes(10))
                .status(Status.B)
                .busyTo(DateTime.now().minusMinutes(6))
                .build();

        busyJob.save();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());
        Optional<PullJobDetails> jobDetailsOptional = defaultPullJobManager.getJob();
        busyJob.refresh();
        Assert.assertTrue("job present", jobDetailsOptional.isPresent());
        Assert.assertEquals("records equal (id)", busyJob.getId(), jobDetailsOptional.get().getPullJobId());
    }

    @Test
    public void marksJobBusy() {
        DateTime startTime = DateTime.now();
        PullJobRecord pendingJob = readyJob();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());
        Optional<PullJobDetails> jobDetailsOptional = defaultPullJobManager.getJob();
        pendingJob.refresh();
        Assert.assertTrue("job present", jobDetailsOptional.isPresent());
        Assert.assertEquals("records equal (id)", pendingJob.getId(), jobDetailsOptional.get().getPullJobId());
        Assert.assertTrue("busyTo in future", pendingJob.getBusyTo().isAfter(startTime));
    }

    @Test
    public void marksJobDone() {
        SchedulingStrategy strategy = Mockito.mock(SchedulingStrategy.class);
        when(strategy.getNextExecutionTime(any(DateTime.class))).then(new Answer<DateTime>() {
            @Override
            public DateTime answer(InvocationOnMock invocation) throws Throwable {
                return DateTime.now().minusHours(1);
            }
        });
        PullJobRecord pendingJob = readyJob();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(strategy, PULL_JOB_MANAGER_CONFIG,
                getPullJobConfigManagerMock());
        Optional<PullJobDetails> jobDetailsOptional = defaultPullJobManager.getJob();
        final UUID processUid = UUID.randomUUID();
        UsageRecord usageRecord1 = getUsageRecord(processUid);
        usageRecord1.save();
        UsageRecord usageRecord2 = getUsageRecord(processUid);
        usageRecord2.save();
        UUID otherProcessUid = UUID.randomUUID();
        UsageRecord usageRecordOther1 = getUsageRecord(otherProcessUid);
        usageRecordOther1.save();
        UsageRecord usageRecordOther2 = getUsageRecord(null);
        usageRecordOther2.save();

        defaultPullJobManager.markJobDone(jobDetailsOptional.get(), processUid);
        pendingJob.refresh();
        Assert.assertEquals("job done", Status.D, pendingJob.getStatus());
        usageRecord1.refresh();
        usageRecord2.refresh();
        Assert.assertEquals(null, usageRecord1.getProcessUid());
        Assert.assertEquals(null, usageRecord2.getProcessUid());

        usageRecordOther1.refresh();
        usageRecordOther2.refresh();
        Assert.assertEquals(otherProcessUid, usageRecordOther1.getProcessUid());
        Assert.assertEquals(null, usageRecordOther2.getProcessUid());
    }

    @Test
    public void marksJobFailed() {
        PullJobRecord pendingJob = readyJob();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());
        Optional<PullJobDetails> jobDetailsOptional = defaultPullJobManager.getJob();
        final UUID processUid = UUID.randomUUID();
        UsageRecord usageRecord1 = getUsageRecord(processUid);
        usageRecord1.save();
        UsageRecord usageRecord2 = getUsageRecord(processUid);
        usageRecord2.save();
        UUID otherProcessUid = UUID.randomUUID();
        UsageRecord usageRecordOther1 = getUsageRecord(otherProcessUid);
        usageRecordOther1.save();
        UsageRecord usageRecordOther2 = getUsageRecord(null);
        usageRecordOther2.save();

        defaultPullJobManager.markJobFailed(jobDetailsOptional.get(), processUid);
        pendingJob.refresh();
        Assert.assertEquals("job failed", Status.F, pendingJob.getStatus());

        Assert.assertEquals("deleted records", 0,
                Ebean.find(UsageRecord.class).where().eq(UsageRecord.PROCESS_COLUMN, processUid).findRowCount());

        Assert.assertEquals("deleted records", 2,
                Ebean.find(UsageRecord.class).where().findRowCount());
    }

    @Test
    public void solvesRaceConditions() throws InterruptedException, ExecutionException {
        final int pullRecordManagerLag = 1000;
        PullJobRecord pendingPullJobRecord = PullJobRecord.builder()
                .executeAt(DateTime.now().minusHours(1))
                .targetService(ServiceUid.PLN)
                .build();
        pendingPullJobRecord.save();

        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<Optional<PullJobDetails>> futureOptionalPullJobRecord
                = executorService.submit(new Callable<Optional<PullJobDetails>>() {

            @Override
            public Optional<PullJobDetails> call() throws Exception {
                PullJobManager defaultPullJobManagerWithLags2
                        = createDefaultPullJobManagerWithLag(pullRecordManagerLag);
                return defaultPullJobManagerWithLags2.getJob();
            }
        });

        Thread.sleep(pullRecordManagerLag / 2);
        Optional<PullJobDetails> optionalPullJobDetails1 = defaultPullJobManager.getJob();
        assertThat(optionalPullJobDetails1.isPresent()).isFalse();
        Optional<PullJobDetails> optionalPullJobDetails2 = futureOptionalPullJobRecord.get();
        assertThat(optionalPullJobDetails2.isPresent()).isTrue();
    }

    @Test
    public void solvesRaceConditions2() throws InterruptedException, ExecutionException {
        // This timeout should be less than the timeout in the DB settings.
        final int pullRecordManagerLag = 1000;
        twoReadyJobs();
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<Optional<PullJobDetails>> futureOptionalPullJobRecord
                = executorService.submit(new Callable<Optional<PullJobDetails>>() {

            @Override
            public Optional<PullJobDetails> call() throws Exception {
                PullJobManager defaultPullJobManagerWithLags2
                        = createDefaultPullJobManagerWithLag(pullRecordManagerLag);
                return defaultPullJobManagerWithLags2.getJob();
            }
        });

        Thread.sleep(pullRecordManagerLag / 2);
        Optional<PullJobDetails> optionalPullJobDetails1 = defaultPullJobManager.getJob();
        assertThat(optionalPullJobDetails1.isPresent()).isTrue();
        Optional<PullJobDetails> optionalPullJobDetails2 = futureOptionalPullJobRecord.get();
        assertThat(optionalPullJobDetails2.isPresent()).isTrue();
        assertThat(optionalPullJobDetails1.get().getPullJobId())
                .isNotEqualTo(optionalPullJobDetails2.get().getPullJobId());
    }

    @Test(timeout = 10000)
    public void noErrorsOnDBTimeOut() throws InterruptedException, ExecutionException {
        readyPendingJob();
        // This timeout should be greater than the timeout in the DB settings.
        final int pullRecordManagerLag = 5000;
        DefaultPullJobManager defaultPullJobManager = new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY,
                PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock());

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<Optional<PullJobDetails>> futureOptionalPullJobRecord
                = executorService.submit(new Callable<Optional<PullJobDetails>>() {

            @Override
            public Optional<PullJobDetails> call() throws Exception {
                PullJobManager defaultPullJobManagerWithLags
                        = createDefaultPullJobManagerWithLag(pullRecordManagerLag);
                return defaultPullJobManagerWithLags.getJob();
            }
        });
        Thread.sleep(pullRecordManagerLag / 2);
        // This .getJob() will get a timeout (because of table lock), thus we're expecting isPresent to be false
        Optional<PullJobDetails> optionalPullJobDetails1 = defaultPullJobManager.getJob();
        assertThat(optionalPullJobDetails1.isPresent()).isFalse();
        futureOptionalPullJobRecord.cancel(true);
    }

    private PullJobsConfigManager getPullJobConfigManagerMock() {
        PullJobsConfigManager configManager = Mockito.mock(DefaultPullJobsConfigManager.class);
        when(configManager.getConfig(any(ServiceUid.class))).then(new Answer<PullJobConfig>() {
            @Override
            public PullJobConfig answer(InvocationOnMock invocation) throws Throwable {
                return new PullJobConfig(ServiceUid.PLN, "", "AMA");
            }
        });
        return configManager;
    }

    private UsageRecord getUsageRecord(UUID processUid) {
        return UsageRecord.builder()
                .usageUid(UsageUid.fromString(Integer.toString(counter++)))
                .internalTransactionId(InternalId.fromString(Integer.toString(counter++)))
                .customerOpcoUid(OpcoUid.fromString("a"))
                .userGuid(UUID.randomUUID())
                .customerOpcoUserUid(OpcoUserUid.fromString("A sample company user UID"))
                .description("descr")
                .billDate(new Date(DateTime.now().getMillis()))
                .cost("3.14")
                .costType(CostType.UNPAID)
                .currency(Currency.USD)
                .serviceUid(ServiceUid.PLN)
                .serviceOpcoUid(OpcoUid.fromString("asd"))
                .itemType("JobCloudCost")
                .processUid(processUid)
                .build();
    }

    private PullJobManager createDefaultPullJobManagerWithLag(final int lagInMillis) {
        return new DefaultPullJobManager(EMPTY_SCHEDULING_STRATEGY, PULL_JOB_MANAGER_CONFIG, getPullJobConfigManagerMock()){
            @Override
            PullJobRecord findJob() {
                PullJobRecord p = super.findJob();
                try {
                    Thread.sleep(lagInMillis);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return p;
            }
        };
    }

    private List<PullJobRecord> readyPendingJob() {
        List<PullJobRecord> readyPendingJobList = Lists.newArrayList(
                PullJobRecord.builder()
                        .targetService(ServiceUid.PLN)
                        .executeAt(DateTime.now().minusMinutes(1))
                        .build(),
                PullJobRecord.builder()
                        .targetService(ServiceUid.DVP)
                        .executeAt(DateTime.now().plusMinutes(1))
                        .build());
        save(readyPendingJobList);
        return readyPendingJobList;
    }

    private List<PullJobRecord> twoReadyJobs() {
        List<PullJobRecord> twoReadyJobsList = Lists.newArrayList(
                PullJobRecord.builder()
                        .targetService(ServiceUid.DVP)
                        .executeAt(DateTime.now().minusMinutes(1))
                        .build(),
                PullJobRecord.builder()
                        .targetService(ServiceUid.MGR)
                        .status(Status.F)
                        .busyTo(DateTime.now().minusMinutes(20))
                        .executeAt(DateTime.now().minusMinutes(30))
                        .build());
        save(twoReadyJobsList);
        return twoReadyJobsList;
    }

    private List<PullJobRecord> busyButNotTimedOutJob() {
        List<PullJobRecord> busyButNotTimedOutJobList = Lists.newArrayList(
                PullJobRecord.builder()
                        .targetService(ServiceUid.DVP)
                        .executeAt(DateTime.now().minusMinutes(10))
                        .status(Status.B)
                        .busyTo(DateTime.now().plusMinutes(1))
                        .build());

        save(busyButNotTimedOutJobList);
        return busyButNotTimedOutJobList;
    }

    private PullJobRecord readyJob() {
        PullJobRecord readyPullJobRecord = PullJobRecord.builder()
                .targetService(ServiceUid.DVP)
                .executeAt(DateTime.now().minusMinutes(10))
                .status(Status.P)
                .build();
        readyPullJobRecord.save();
        return readyPullJobRecord;
    }

    private void save(List<PullJobRecord> pullJobRecords) {
        Ebean.save(pullJobRecords);
    }
}
