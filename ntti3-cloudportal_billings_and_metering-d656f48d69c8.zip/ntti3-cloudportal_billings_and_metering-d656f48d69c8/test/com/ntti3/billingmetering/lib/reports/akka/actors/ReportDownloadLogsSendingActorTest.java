package com.ntti3.billingmetering.lib.reports.akka.actors;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.testkit.JavaTestKit;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ntti3.billingmetering.lib.reports.akka.messages.ReportDownloadStatusesRequest;
import com.ntti3.billingmetering.lib.reports.exceptions.UsageReportsException;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesManager;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.DownloadStatusesResponse;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import org.joda.time.DateTime;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import utils.NoPullJobsTest;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ReportDownloadLogsSendingActorTest extends NoPullJobsTest {

    private ActorSystem system;


    @Override
    public void startApp() {
        super.startApp();
        system = ActorSystem.create();
    }

    @Override
    public void stopApp() {
        super.stopApp();
        JavaTestKit.shutdownActorSystem(system);
        system = null;
    }

    private static final String NTTI_3 = "ntti3";
    private static final String CL = "cl";
    private static final DateTime downloadTime = DateTime.parse("2014-02-06").withTime(16, 19, 34, 0);
    private static final YearAndMonth yearAndMonth = YearAndMonth.fromInts(2014, 2);

    private final List<UsageReportDownloadStatus> elements = Lists.newArrayList(
            UsageReportDownloadStatus.downloaded(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, yearAndMonth.getYear(), yearAndMonth.getMonth(), downloadTime, ReportType.CS),
            UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
            UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),
            UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),

            UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
            UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.DVP, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
            UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),
            UsageReportDownloadStatus.downloaded(OpcoUid.fromString(CL), ServiceUid.DVP, yearAndMonth.getYear(), yearAndMonth.getMonth(), downloadTime, ReportType.SPS));


    @Test
    public void getDownloadStatuses() throws UsageReportsException, IOException, InterruptedException {
        UsageReportDownloadStatusesManager usageReportDownloadStatusesManager
                = Mockito.mock(UsageReportDownloadStatusesManager.class);

        when(usageReportDownloadStatusesManager.getReportDownloadStatuses(any(YearAndMonth.class)))
                .thenAnswer(new Answer<QueryIterator<UsageReportDownloadStatus>>() {
                    @Override
                    public QueryIterator<UsageReportDownloadStatus> answer(InvocationOnMock invocationOnMock) throws Throwable {
                        return getFakeUsageReportDownloadStatuses();
                    }
                });

        final PipedInputStream pipedInputStream = new PipedInputStream();
        final InputStream inputStream = new BufferedInputStream(pipedInputStream, 4096);
        final PipedOutputStream outputStream;
        try {
            outputStream = new PipedOutputStream(pipedInputStream);

        } catch (IOException e) {
            throw new UsageReportsException("Could not create PipedOutputStream", e);
        }
        ReportDownloadStatusesRequest request = new ReportDownloadStatusesRequest(outputStream, yearAndMonth);
        final Props props = Props.create(ReportDownloadLogsSendingActor.class, usageReportDownloadStatusesManager);
        final ActorRef sendingActor = system.actorOf(props, "sendingActor");
        sendingActor.tell(request, null);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonGenerator.Feature.AUTO_CLOSE_TARGET, false);
        DownloadStatusesResponse downloadStatusesHelper = objectMapper.readValue(inputStream, DownloadStatusesResponse.class);
        Collection<UsageReportDownloadStatus> usageReportDownloadStatusCollection = downloadStatusesHelper.getDownloadStatuses();

        assertThat(usageReportDownloadStatusCollection.size()).isEqualTo(elements.size());
        assertThat(Sets.newHashSet(usageReportDownloadStatusCollection)).isEqualTo(Sets.newHashSet(elements));
    }

    private QueryIterator<UsageReportDownloadStatus> getFakeUsageReportDownloadStatuses() {
        return new QueryIterator<UsageReportDownloadStatus>() {
            private Iterator<UsageReportDownloadStatus> elementsIterator = elements.iterator();

            @Override
            public boolean hasNext() {
                return elementsIterator.hasNext();
            }

            @Override
            public UsageReportDownloadStatus next() {
                return elementsIterator.next();
            }

            @Override
            public void remove() {
                //
            }

            @Override
            public void close() {
                //
            }
        };
    }
}
