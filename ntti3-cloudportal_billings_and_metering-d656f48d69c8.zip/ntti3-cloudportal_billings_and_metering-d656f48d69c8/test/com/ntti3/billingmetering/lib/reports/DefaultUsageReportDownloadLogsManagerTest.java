package com.ntti3.billingmetering.lib.reports;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.google.common.collect.Lists;
import com.ntti3.billingmetering.lib.reports.logs.DefaultUsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.YearAndMonth;
import org.fest.assertions.Assertions;
import org.joda.time.DateTime;
import org.junit.Test;
import utils.NoPullJobsTest;

import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadLogsManagerTest extends NoPullJobsTest {

    @Test
    public void selectsForYearAndMonth() {
        UsageReportDownloadLogRecord usageReportDownloadLogRecordTemplate = UsageReportDownloadLogRecord.builder()
                .downloadTime(DateTime.now())
                .status(Status.D)
                .opcoUid(OpcoUid.fromString("OpcoUid"))
                .yearAndMonth(YearAndMonth.fromInts(2014, 2))
                .serviceUid(ServiceUid.PLN)
                .reportType(ReportType.CS)
                .build();

        List<UsageReportDownloadLogRecord> usageReportDownloadLogRecords = Lists.newArrayList(
                usageReportDownloadLogRecordTemplate,
                UsageReportDownloadLogRecord.builder()
                        .fromOther(usageReportDownloadLogRecordTemplate)
                        .yearAndMonth(YearAndMonth.fromInts(2014, 3))
                        .build(),
                UsageReportDownloadLogRecord.builder()
                        .fromOther(usageReportDownloadLogRecordTemplate)
                        .yearAndMonth(YearAndMonth.fromInts(2013, 2))
                        .build());

        Ebean.save(usageReportDownloadLogRecords);

        UsageReportDownloadLogsManager usageReportDownloadLogsManager = new DefaultUsageReportDownloadLogsManager();
        QueryIterator<UsageReportDownloadLogRecord> records
                = usageReportDownloadLogsManager.getUsageReportDownloadLogs(YearAndMonth.fromInts(2014, 2));

        Assertions.assertThat(records.hasNext()).isTrue();
        UsageReportDownloadLogRecord recordFromDb = records.next();
        Assertions.assertThat(recordFromDb).isEqualTo(usageReportDownloadLogRecordTemplate);
        Assertions.assertThat(records.hasNext()).isFalse();
        records.close();
    }
}
