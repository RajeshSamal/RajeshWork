package com.ntti3.billingmetering.lib.reports;

import com.avaje.ebean.QueryIterator;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.reports.statuses.DefaultUsageReportDownloadStatusesManager;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesManager;
import com.ntti3.billingmetering.lib.utils.QueryIteratorHelper;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.settings.reports.RequestedUsageReportSetting;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManagerFactory;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import mocks.RequestedReportSettingFactory;
import org.fest.assertions.Assertions;
import org.joda.time.DateTime;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import play.Configuration;
import utils.NoPullJobsTest;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadStatusesManagerTest extends NoPullJobsTest {

    private static final String NTTI_3 = "ntti3";
    private static final String CL = "cl";
    private static final DateTime downloadTime = DateTime.parse("2014-02-06").withTime(16, 19, 34, 0);
    private static final YearAndMonth yearAndMonth = YearAndMonth.fromInts(2014, 2);

    @Test
    public void getReportDownloadStatuses() {
        UsageReportDownloadLogsManager usageReportDownloadLogsManager = Mockito.mock(UsageReportDownloadLogsManager.class);
        when(usageReportDownloadLogsManager.getUsageReportDownloadLogs(any(YearAndMonth.class)))
                .thenAnswer(new Answer<QueryIterator<UsageReportDownloadLogRecord>>() {
                    @Override
                    public QueryIterator<UsageReportDownloadLogRecord> answer(InvocationOnMock invocationOnMock) throws Throwable {
                        return getFakeReportDownloadRecords();
                    }
                });

        final UsageReportsSettingsManager usageReportsSettingsManager = Mockito.mock(UsageReportsSettingsManager.class);
        when(usageReportsSettingsManager.getRequestedReports()).thenAnswer(new Answer<Set<RequestedUsageReportSetting>>() {
            @Override
            public Set<RequestedUsageReportSetting> answer(InvocationOnMock invocationOnMock) throws Throwable {
                return getFakeRequestedReportSettings();
            }
        });

        UsageReportsSettingsManagerFactory usageReportsSettingsManagerFactory
                = Mockito.mock(UsageReportsSettingsManagerFactory.class);

        when(usageReportsSettingsManagerFactory.create(any(Configuration.class))).thenAnswer(new Answer<UsageReportsSettingsManager>() {
            @Override
            public UsageReportsSettingsManager answer(InvocationOnMock invocation) throws Throwable {
                return usageReportsSettingsManager;
            }
        });


        UsageReportDownloadStatusesManager usageReportDownloadStatusesManager
                = new DefaultUsageReportDownloadStatusesManager(usageReportDownloadLogsManager,
                usageReportsSettingsManagerFactory);

        Set<UsageReportDownloadStatus> generatedUsageReportDownloadStatusesSet
                = QueryIteratorHelper.toSet((usageReportDownloadStatusesManager.getReportDownloadStatuses(yearAndMonth)));

        Set<UsageReportDownloadStatus> expectedUsageReportDownloadStatuses = Sets.newHashSet(
                UsageReportDownloadStatus.downloaded(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, yearAndMonth.getYear(), yearAndMonth.getMonth(), downloadTime, ReportType.CS),
                UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
                UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),
                UsageReportDownloadStatus.pending(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),

                UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
                UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.DVP, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.CS),
                UsageReportDownloadStatus.pending(OpcoUid.fromString(CL), ServiceUid.MGR, yearAndMonth.getYear(), yearAndMonth.getMonth(), ReportType.SPS),
                UsageReportDownloadStatus.downloaded(OpcoUid.fromString(CL), ServiceUid.DVP, yearAndMonth.getYear(), yearAndMonth.getMonth(), downloadTime, ReportType.SPS)
        );

        Assertions.assertThat(generatedUsageReportDownloadStatusesSet).isEqualTo(expectedUsageReportDownloadStatuses);
    }

    private QueryIterator<UsageReportDownloadLogRecord> getFakeReportDownloadRecords() {
        return new QueryIterator<UsageReportDownloadLogRecord>() {
            private List<UsageReportDownloadLogRecord> elements = Lists.newArrayList(
                    UsageReportDownloadLogRecord.builder()
                            .downloadTime(downloadTime)
                            .serviceUid(ServiceUid.DVP)
                            .opcoUid(OpcoUid.fromString(CL))
                            .yearAndMonth(yearAndMonth)
                            .reportType(ReportType.SPS)
                            .status(Status.D)
                            .build(),

                    UsageReportDownloadLogRecord.builder()
                            .downloadTime(downloadTime)
                            .serviceUid(ServiceUid.PLN)
                            .opcoUid(OpcoUid.fromString(NTTI_3))
                            .yearAndMonth(yearAndMonth)
                            .status(Status.D)
                            .reportType(ReportType.CS)
                            .build());

            private Iterator<UsageReportDownloadLogRecord> elementsIterator = elements.iterator();


            @Override
            public boolean hasNext() {
                return elementsIterator.hasNext();
            }

            @Override
            public UsageReportDownloadLogRecord next() {
                return elementsIterator.next();
            }

            @Override
            public void remove() {
                //
            }

            @Override
            public void close() {
                //
            }
        };
    }

    private Set<RequestedUsageReportSetting> getFakeRequestedReportSettings() {
        return Sets.newHashSet(
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.PLN, ReportType.SPS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(NTTI_3), ServiceUid.MGR, ReportType.SPS),

                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.MGR, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.DVP, ReportType.CS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.MGR, ReportType.SPS),
                RequestedReportSettingFactory.get(OpcoUid.fromString(CL), ServiceUid.DVP, ReportType.SPS));
    }
}
