package com.ntti3.billingmetering.lib.reports.logs;

import com.avaje.ebean.QueryIterator;
import com.google.common.collect.Lists;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import utils.NoPullJobsTest;

import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadLogsManagerTest extends NoPullJobsTest {

    public static final YearAndMonth YEAR_AND_MONTH = YearAndMonth.fromInts(2013, 4);
    public static final OpcoUid OPCO_UID = OpcoUid.fromString("test-opco");
    public static final ServiceUid AMA = ServiceUid.MGR;
    public static final ReportType REPORT_TYPE = ReportType.SPS;

    @Test
    public void empty() {
        DefaultUsageReportDownloadLogsManager manager = new DefaultUsageReportDownloadLogsManager();
        QueryIterator<UsageReportDownloadLogRecord> downloadLogs = manager.getUsageReportDownloadLogs(YEAR_AND_MONTH);
        Assert.assertFalse(downloadLogs.hasNext());
    }

    @Test
    public void createsIfNone() {
        DefaultUsageReportDownloadLogsManager manager = new DefaultUsageReportDownloadLogsManager();

        manager.logUsageReportFailed(OPCO_UID, AMA, YEAR_AND_MONTH, REPORT_TYPE);
        List<UsageReportDownloadLogRecord> downloadLogs = iteratorToList(manager.getUsageReportDownloadLogs(YEAR_AND_MONTH));

        UsageReportDownloadLogRecord expectedDownloadLog = UsageReportDownloadLogRecord
                .logFailed(OPCO_UID, AMA, YEAR_AND_MONTH, REPORT_TYPE, DateTime.now());

        UsageReportDownloadLogRecord downloadLog = downloadLogs.get(0);
        Assert.assertEquals("size", 1, downloadLogs.size());
        Assert.assertEquals(expectedDownloadLog.getStatus(), downloadLog.getStatus());
        Assert.assertEquals(expectedDownloadLog.getMonth(), downloadLog.getMonth());
        Assert.assertEquals(expectedDownloadLog.getYear(), downloadLog.getYear());
        Assert.assertEquals(expectedDownloadLog.getOpcoUid(), downloadLog.getOpcoUid());
        Assert.assertEquals(expectedDownloadLog.getReportType(), downloadLog.getReportType());
    }

    @Test
    public void updates() {
        DefaultUsageReportDownloadLogsManager manager = new DefaultUsageReportDownloadLogsManager();

        manager.logUsageReportFailed(OPCO_UID, AMA, YEAR_AND_MONTH, REPORT_TYPE);
        manager.logUsageReportDownloaded(OPCO_UID, AMA, YEAR_AND_MONTH, REPORT_TYPE);
        List<UsageReportDownloadLogRecord> downloadLogs = iteratorToList(manager.getUsageReportDownloadLogs(YEAR_AND_MONTH));

        UsageReportDownloadLogRecord expectedDownloadLog = UsageReportDownloadLogRecord
                .logDownloaded(OPCO_UID, AMA, YEAR_AND_MONTH, REPORT_TYPE, DateTime.now());

        UsageReportDownloadLogRecord downloadLog = downloadLogs.get(0);
        Assert.assertEquals("size", 1, downloadLogs.size());
        Assert.assertEquals(expectedDownloadLog.getStatus(), downloadLog.getStatus());
        Assert.assertEquals(expectedDownloadLog.getMonth(), downloadLog.getMonth());
        Assert.assertEquals(expectedDownloadLog.getYear(), downloadLog.getYear());
        Assert.assertEquals(expectedDownloadLog.getOpcoUid(), downloadLog.getOpcoUid());
        Assert.assertEquals(expectedDownloadLog.getReportType(), downloadLog.getReportType());
    }

    private <T>List<T> iteratorToList(QueryIterator<T> it) {
        List<T> list = Lists.newArrayList();
        while(it.hasNext()) {
            list.add(it.next());
        }
        return list;
    }
}
