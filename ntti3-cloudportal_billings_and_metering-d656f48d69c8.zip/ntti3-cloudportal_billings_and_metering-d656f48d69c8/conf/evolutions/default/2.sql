# --- !Ups

ALTER TABLE usage_records DROP customer_opco_customer_uid;

# --- !Downs

ALTER TABLE usage_records ADD customer_opco_customer_uid varchar(64);