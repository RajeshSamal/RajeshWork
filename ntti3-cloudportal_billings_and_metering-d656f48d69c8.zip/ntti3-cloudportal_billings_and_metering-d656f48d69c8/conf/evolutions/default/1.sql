
# --- !Ups

create table pull_job_records (
  id                        integer auto_increment not null,
  status                    varchar(1),
  target_service            varchar(3),
  execute_at                datetime,
  busy_to                   datetime,
  constraint ck_pull_job_records_status check (status in ('P','B','D','F')),
  constraint ck_pull_job_records_target_service check (target_service in ('AMA','ML','MT','DO')),
  constraint pk_pull_job_records primary key (id))
;

create table usage_records (
  usage_uid                 varchar(64),
  parent_usage_uid          varchar(64),
  internal_transaction_id   varchar(64),
  customer_opco_uid         varchar(64),
  customer_opco_customer_uid varchar(64),
  user_guid                 varchar(40),
  customer_opco_user_uid    varchar(64),
  description               TEXT,
  bill_date                 date,
  cost                      decimal(11,5),
  cost_type                 varchar(16),
  currency                  varchar(3),
  service_uid               varchar(16),
  service_opco_uid          varchar(64),
  item_type                 varchar(255),
  details                   TEXT,
  process                   varchar(40),
  sequence_number           integer,
  last_sequence             tinyint(1) default 0,
  constraint ck_usage_records_cost_type check (cost_type in ('PAID','UNPAID')),
  constraint ck_usage_records_currency check (currency in ('USD')),
  constraint ck_usage_records_service_uid check (service_uid in ('AMA','ML','MT','DO')),
  constraint pk_usage_records primary key (usage_uid))
;

create table usage_reports_downloads (
  opco_uid                  varchar(64),
  service_uid               varchar(16),
  year                      integer,
  month                     integer,
  report_type               varchar(16),
  download_time             datetime,
  status                    varchar(1),
  constraint ck_usage_reports_downloads_service_uid check (service_uid in ('AMA','ML','MT','DO')),
  constraint ck_usage_reports_downloads_report_type check (report_type in ('CS','SPS')),
  constraint ck_usage_reports_downloads_status check (status in ('P','B','D','F')),
  constraint pk_usage_reports_downloads primary key (opco_uid, service_uid, year, month, report_type))
;




# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table pull_job_records;

drop table usage_records;

drop table usage_reports_downloads;

SET FOREIGN_KEY_CHECKS=1;

