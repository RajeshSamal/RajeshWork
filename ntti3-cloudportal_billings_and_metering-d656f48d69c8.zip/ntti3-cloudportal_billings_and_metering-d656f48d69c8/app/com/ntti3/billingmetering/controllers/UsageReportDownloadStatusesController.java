package com.ntti3.billingmetering.controllers;

import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.exceptions.InvalidApiRequest;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesJsonGenerator;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import play.libs.F;
import play.mvc.Controller;
import play.mvc.Result;

import javax.annotation.concurrent.Immutable;
import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
@ControllerExceptionSupport.ExceptionHandler()
public class UsageReportDownloadStatusesController extends Controller {

    private static final String JSON_UTF8 = "application/json; charset=utf-8";
    private final UsageReportDownloadStatusesJsonGenerator usageReportDownloadStatusesJsonGenerator;

    @Inject
    public UsageReportDownloadStatusesController(UsageReportDownloadStatusesJsonGenerator usageReportDownloadStatusesJsonGenerator) {
        this.usageReportDownloadStatusesJsonGenerator = usageReportDownloadStatusesJsonGenerator;
    }

    private static Result asJson(final InputStream inputStream) {
        return ok(inputStream).as(JSON_UTF8);
    }

    public F.Promise<Result> downloadStatus(final int year, final int month, int apiVersion) throws InvalidApiRequest {
        final YearAndMonth yearAndMonth;
        try {
            yearAndMonth = YearAndMonth.fromInts(year, month);
        } catch (IllegalArgumentException e) {
            throw new InvalidApiRequest(e.getMessage(), e);
        }

        return F.Promise.promise(new F.Function0<InputStream>() {
            @Override
            public InputStream apply() throws Throwable {
                return usageReportDownloadStatusesJsonGenerator.getReportDownloadStatuses(yearAndMonth);
            }
        }).map(new F.Function<InputStream, Result>() {
            @Override
            public Result apply(InputStream inputStream) throws Throwable {
                return asJson(inputStream);
            }
        });
    }
}
