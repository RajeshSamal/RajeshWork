package com.ntti3.billingmetering.controllers;

import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.api.DefaultUsageReportsApiMethods;
import com.ntti3.billingmetering.lib.api.UsageReportsApiMethod;
import com.ntti3.billingmetering.lib.api.UsageReportsApiParameters;
import com.ntti3.billingmetering.lib.exceptions.InvalidApiRequest;
import com.ntti3.play.excetions.handling.ControllerExceptionSupport;
import play.libs.F;
import play.mvc.Controller;
import play.mvc.Result;

import javax.annotation.concurrent.Immutable;
import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
@ControllerExceptionSupport.ExceptionHandler()
public class UsageReportsController extends Controller {

    public static final int CHUNK_SIZE = 50;
    public static final String CUSTOMER_SUMMARY = "customer_summary";
    public static final String SERVICE_PROVIDER_SUMMARY = "service_provider_summary";
    public static final String OVERALL_SUMMARY = "overall_summary";
    public static final String CSV_FILE_EXTENSION = ".csv";
    public static final String CONTENT_DISPOSITION = "Content-Disposition";
    public static final String ATTACHMENT_FILENAME = "attachment;filename=";
    protected static final Joiner FILENAME_JOINER = Joiner.on("_").skipNulls();
    public final DefaultUsageReportsApiMethods usageReportsApiMethods;

    @Inject
    public UsageReportsController(DefaultUsageReportsApiMethods usageReportsApiMethods) {
        this.usageReportsApiMethods = usageReportsApiMethods;
    }

    private static Result downloadableCsv(String fileName, InputStream inputStream) {
        setHeadersForDownloadableCsv(fileName);
        return ok(inputStream, CHUNK_SIZE);
    }

    private static void setHeadersForDownloadableCsv(String fileName) {
        response().setHeader(CONTENT_DISPOSITION, attachmentWithFilename(fileName));
    }

    private static String attachmentWithFilename(String fileName) {
        return ATTACHMENT_FILENAME + fileName;
    }

    private static String prepareFileName(String fileNamePrefix, Optional<String> opcoUidStringOptional,
                                          UsageReportsApiParameters usageReportsApiParameters) {
        return FILENAME_JOINER.join(fileNamePrefix,
                opcoUidStringOptional.orNull(),
                usageReportsApiParameters.getServiceUid().getTextRepresentation(),
                usageReportsApiParameters.getYearAndMonth().getYear(),
                usageReportsApiParameters.getYearAndMonth().getMonth()) + CSV_FILE_EXTENSION;
    }

    private static F.Promise<Result> apiMethodResultAsFilePromise(final UsageReportsApiMethod apiMethod, final String csvFileName) {
        return F.Promise.promise(new F.Function0<InputStream>() {
            @Override
            public InputStream apply() throws Throwable {
                return apiMethod.run();
            }
        }).map(new F.Function<InputStream, Result>() {
            @Override
            public Result apply(InputStream inputStream) throws Throwable {
                return downloadableCsv(csvFileName, inputStream);
            }
        });
    }

    public F.Promise<Result> customerSummary(final String opcoUidString, final String serviceUidString,
                                             int year, int month, int apiVersion) throws InvalidApiRequest {
        UsageReportsApiParameters parametersValidator
                = UsageReportsApiParameters.withOpco(opcoUidString, serviceUidString, year, month);

        final String fileName = prepareFileName(CUSTOMER_SUMMARY, Optional.of(opcoUidString), parametersValidator);
        UsageReportsApiMethod apiMethod = usageReportsApiMethods.customerSummaryReport(parametersValidator);
        return apiMethodResultAsFilePromise(apiMethod, fileName);
    }

    public F.Promise<Result> serviceProviderSummary(final String opcoUidString, final String serviceUidString,
                                                    int year, int month, int apiVersion) throws InvalidApiRequest {
        UsageReportsApiParameters parametersValidator
                = UsageReportsApiParameters.withOpco(opcoUidString, serviceUidString, year, month);

        final String fileName = prepareFileName(SERVICE_PROVIDER_SUMMARY, Optional.of(opcoUidString), parametersValidator);
        UsageReportsApiMethod apiMethod = usageReportsApiMethods.serviceProviderSummaryReport(parametersValidator);
        return apiMethodResultAsFilePromise(apiMethod, fileName);
    }

    public F.Promise<Result> overallSummary(final String serviceUidString,
                                            int year, int month, int apiVersion) throws InvalidApiRequest {
        UsageReportsApiParameters parametersValidator
                = UsageReportsApiParameters.withoutOpco(serviceUidString, year, month);

        final String fileName = prepareFileName(OVERALL_SUMMARY, Optional.<String>absent(), parametersValidator);
        UsageReportsApiMethod apiMethod = usageReportsApiMethods.overallSummaryReport(parametersValidator);
        return apiMethodResultAsFilePromise(apiMethod, fileName);
    }
}
