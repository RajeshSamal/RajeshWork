package com.ntti3.billingmetering.controllers;

import play.mvc.Controller;
import play.mvc.Result;

public class Application extends Controller {

    public static Result index() {
        return ok("Billings");
    }
}
