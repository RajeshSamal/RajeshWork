package com.ntti3.billingmetering.lib.api;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.ntti3.billingmetering.lib.exceptions.BillingAndMeteringModuleException;
import com.ntti3.billingmetering.lib.reports.UsageReportsManager;

import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class DefaultUsageReportsApiMethods implements UsageReportsApiMethods {

    private final UsageReportsManager usageReportsManager;

    @Inject
    public DefaultUsageReportsApiMethods(UsageReportsManager usageReportsManager) {
        this.usageReportsManager = usageReportsManager;
    }

    @Override
    public UsageReportsApiMethod customerSummaryReport(final UsageReportsApiParameters usageReportsApiParameters) {
        return new UsageReportsApiMethod(usageReportsApiParameters) {
            @Override
            public InputStream run() throws BillingAndMeteringModuleException {
                return usageReportsManager.getCustomerSummaryReport(
                        parameters.getOpcoUid(), parameters.getServiceUid(), parameters.getYearAndMonth());
            }
        };
    }

    @Override
    public UsageReportsApiMethod serviceProviderSummaryReport(final UsageReportsApiParameters usageReportsApiParameters) {
        return new UsageReportsApiMethod(usageReportsApiParameters) {
            @Override
            public InputStream run() throws BillingAndMeteringModuleException {
                return usageReportsManager.getServiceProviderSummaryReport(
                        parameters.getOpcoUid(), parameters.getServiceUid(), parameters.getYearAndMonth());
            }
        };
    }

    @Override
    public UsageReportsApiMethod overallSummaryReport(final UsageReportsApiParameters usageReportsApiParameters) {
        return new UsageReportsApiMethod(usageReportsApiParameters) {
            @Override
            public InputStream run() throws BillingAndMeteringModuleException {
                return usageReportsManager.getOverallSummaryReport(parameters.getServiceUid(),
                        parameters.getYearAndMonth());
            }
        };
    }
}
