package com.ntti3.billingmetering.lib.api;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportsApiMethods {

    /**
     * Returns ready to run CustomerSummaryReport API method
     *
     * @param usageReportsApiParameters Parameters for the API method.
     * @return UsageReportsApiMethod ready to run
     */
    UsageReportsApiMethod customerSummaryReport(UsageReportsApiParameters usageReportsApiParameters);

    /**
     * Returns ready to run ServiceProviderSummaryReport API method
     *
     * @param usageReportsApiParameters Parameters for the API method.
     * @return UsageReportsApiMethod ready to run
     */
    UsageReportsApiMethod serviceProviderSummaryReport(UsageReportsApiParameters usageReportsApiParameters);

    /**
     * Returns ready to run OverallSummaryReport API method
     *
     * @param usageReportsApiParameters Parameters for the API method.
     * @return UsageReportsApiMethod ready to run
     */
    UsageReportsApiMethod overallSummaryReport(UsageReportsApiParameters usageReportsApiParameters);
}
