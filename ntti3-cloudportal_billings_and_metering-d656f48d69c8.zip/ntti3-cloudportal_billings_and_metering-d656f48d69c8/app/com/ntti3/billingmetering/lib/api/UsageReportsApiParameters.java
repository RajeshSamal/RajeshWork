package com.ntti3.billingmetering.lib.api;

import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.exceptions.InvalidApiRequest;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class UsageReportsApiParameters {
    private final OpcoUid opcoUid;
    private final ServiceUid serviceUid;
    private final YearAndMonth yearAndMonth;

    private UsageReportsApiParameters(Optional<String> opcoUidStringOptional, String serviceUidString,
                                      int year, int month) {
        if (opcoUidStringOptional.isPresent()) {
            opcoUid = OpcoUid.fromString(opcoUidStringOptional.get());
        } else {
            opcoUid = null;
        }
        Preconditions.checkNotNull(serviceUidString, "ServiceUid can not be null");
        serviceUid = ServiceUid.fromString(serviceUidString);
        this.yearAndMonth = YearAndMonth.fromInts(year, month);
    }

    public static UsageReportsApiParameters withOpco(String opcoUidString, String serviceUidString,
                                                     int year, int month) throws InvalidApiRequest {
        return new UsageReportsApiParameters(Optional.of(opcoUidString),
                serviceUidString, year, month);
    }

    public static UsageReportsApiParameters withoutOpco(String serviceUidString, int year,
                                                        int month) throws InvalidApiRequest {
        return new UsageReportsApiParameters(Optional.<String>absent(),
                serviceUidString, year, month);
    }

    public OpcoUid getOpcoUid() {
        if (opcoUid == null) {
            throw new IllegalStateException("Can not get Opco in ApiParameters without Opco!");
        } else {
            return opcoUid;
        }
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public YearAndMonth getYearAndMonth() {
        return yearAndMonth;
    }
}
