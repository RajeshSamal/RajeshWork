package com.ntti3.billingmetering.lib.api.guice;

import com.google.inject.AbstractModule;
import com.ntti3.billingmetering.lib.api.DefaultUsageReportsApiMethods;
import com.ntti3.billingmetering.lib.api.UsageReportsApiMethods;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportsApiMethodsModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(UsageReportsApiMethods.class).to(DefaultUsageReportsApiMethods.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportsApiMethodsModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportsApiMethodsModule.class.equals(obj.getClass());
    }
}
