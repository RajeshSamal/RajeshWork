package com.ntti3.billingmetering.lib.api;

import com.ntti3.billingmetering.lib.exceptions.BillingAndMeteringModuleException;

import java.io.InputStream;

/**
 * UsageReportsApiMethod represents the API method ready to run (all parameters, if any,
 * are supplied supplied before).
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public abstract class UsageReportsApiMethod {

    protected final UsageReportsApiParameters parameters;

    protected UsageReportsApiMethod(UsageReportsApiParameters parameters) {
        this.parameters = parameters;
    }

    /**
     * Runs the Usage Reports API method
     *
     * @return Results from the API method as an InputStream
     * @throws BillingAndMeteringModuleException
     */
    public abstract InputStream run() throws BillingAndMeteringModuleException;
}
