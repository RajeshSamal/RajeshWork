package com.ntti3.billingmetering.lib.reports.generators;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.gums.CachingGumsConnector;
import com.ntti3.gums.GumsProtocolException;

import java.io.IOException;
import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public abstract class AbstractSummaryGenerator implements SummaryGenerator {

    private final CachingGumsConnector cachingGumsConnector;

    public AbstractSummaryGenerator(CachingGumsConnector cachingGumsConnector) {
        this.cachingGumsConnector = cachingGumsConnector;
        this.cachingGumsConnector.cleanCache();
    }

    protected abstract List<SummaryColumn> getSummaryColumns();

    @Override
    public List<String> produceColumnHeaders() {
        return Lists.transform(getSummaryColumns(), new Function<SummaryColumn, String>() {
            @Override
            public String apply(SummaryColumn column) {
                return column.getName();
            }
        });
    }

    @Override
    public List<String> produceRecord(final UsageRecord usageRecord) throws IOException, GumsProtocolException {
        List<String> recordsData = Lists.newArrayList();
        for (SummaryColumn column : getSummaryColumns()) {
            recordsData.add(column.getValue(usageRecord, cachingGumsConnector));
        }
        return recordsData;
    }
}
