package com.ntti3.billingmetering.lib.reports.generators;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.ntti3.billingmetering.lib.reports.generators.columns.BillDateColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CostColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CostTypeColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CurrencyColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerFirstNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerLastNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerOpcoCompanyNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerOpcoNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerOpcoUidColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.CustomerOpcoUserUidColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.DescriptionColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.DetailsColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ItemTypeColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ParentUsageUidColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ServiceNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ServiceOpcoNameColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ServiceOpcoUidColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.ServiceUidColumn;
import com.ntti3.billingmetering.lib.reports.generators.columns.UsageUidColumn;
import com.ntti3.gums.CachingGumsConnector;

import java.util.Collections;
import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class CustomerSummaryGenerator extends AbstractSummaryGenerator {

    private static final List<SummaryColumn> CUSTOMER_SUMMARY_COLUMNS = Collections
            .unmodifiableList(
                    Lists.<SummaryColumn>newArrayList(
                            new UsageUidColumn(),
                            new ParentUsageUidColumn(),
                            new CustomerOpcoUidColumn(),
                            new CustomerOpcoUserUidColumn(),
                            new CustomerOpcoNameColumn(),
                            new CustomerOpcoCompanyNameColumn(),
                            new CustomerFirstNameColumn(),
                            new CustomerLastNameColumn(),
                            new DescriptionColumn(),
                            new BillDateColumn(),
                            new CostColumn(),
                            new CostTypeColumn(),
                            new CurrencyColumn(),
                            new ServiceUidColumn(),
                            new ServiceNameColumn(),
                            new ServiceOpcoUidColumn(),
                            new ServiceOpcoNameColumn(),
                            new ItemTypeColumn(),
                            new DetailsColumn()
                    ));

    @Inject
    public CustomerSummaryGenerator(CachingGumsConnector cachingGumsConnector) {
        super(cachingGumsConnector);
    }

    @Override
    protected List<SummaryColumn> getSummaryColumns() {
        return CUSTOMER_SUMMARY_COLUMNS;
    }
}
