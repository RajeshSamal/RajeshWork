package com.ntti3.billingmetering.lib.reports.generators;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.ntti3.billingmetering.lib.reports.guice.annotations.CustomerSummary;
import com.ntti3.billingmetering.lib.reports.guice.annotations.OverallSummary;
import com.ntti3.billingmetering.lib.reports.guice.annotations.ServiceProviderSummary;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class SummaryGeneratorFactory {

    private final SummaryGenerator customerSummaryGenerator;
    private final SummaryGenerator serviceProviderSummaryGenerator;
    private final SummaryGenerator overallSummaryGenerator;

    @Inject
    public SummaryGeneratorFactory(@CustomerSummary SummaryGenerator customerSummaryGenerator,
                                   @ServiceProviderSummary SummaryGenerator serviceProviderSummaryGenerator,
                                   @OverallSummary SummaryGenerator overallSummaryGenerator) {
        this.customerSummaryGenerator = customerSummaryGenerator;
        this.serviceProviderSummaryGenerator = serviceProviderSummaryGenerator;
        this.overallSummaryGenerator = overallSummaryGenerator;
    }

    public SummaryGenerator getCustomerSummaryGenerator() {
        return customerSummaryGenerator;
    }

    public SummaryGenerator getServiceProviderSummaryGenerator() {
        return serviceProviderSummaryGenerator;
    }

    public SummaryGenerator getOverallSummaryGenerator() {
        return overallSummaryGenerator;
    }
}
