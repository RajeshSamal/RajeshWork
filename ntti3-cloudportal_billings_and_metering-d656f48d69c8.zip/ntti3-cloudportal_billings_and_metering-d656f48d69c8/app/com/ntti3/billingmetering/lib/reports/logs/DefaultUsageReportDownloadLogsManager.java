package com.ntti3.billingmetering.lib.reports.logs;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.QueryIterator;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;
import play.Logger;

import javax.persistence.PersistenceException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadLogsManager implements UsageReportDownloadLogsManager {

    @Override
    public void logUsageReportDownloaded(OpcoUid opcoUid, ServiceUid serviceUid,
                                         YearAndMonth yearAndMonth, ReportType reportType) {
        Logger.debug(String.format("default: logUsageReportDownloaded called %s, %s, %s, %s, %s",
                opcoUid, serviceUid.toString(), yearAndMonth.getYear(),
                yearAndMonth.getMonth(), reportType.toString()));
        UsageReportDownloadLogRecord usageReportDownloadLogRecord = UsageReportDownloadLogRecord
                .logDownloaded(opcoUid, serviceUid, yearAndMonth, reportType, DateTime.now());
        markIfNeeded(reportType, usageReportDownloadLogRecord);
    }

    @Override
    public void logUsageReportFailed(OpcoUid opcoUid, ServiceUid serviceUid,
                                     YearAndMonth yearAndMonth, ReportType reportType) {
        Logger.debug(String.format("default: logUsageReportFailed called %s, %s, %s, %s, %s",
                opcoUid, serviceUid.toString(), yearAndMonth.getYear(),
                yearAndMonth.getMonth(), reportType.toString()));
        UsageReportDownloadLogRecord usageReportDownloadLogRecord = UsageReportDownloadLogRecord
                .logFailed(opcoUid, serviceUid, yearAndMonth, reportType, DateTime.now());
        markIfNeeded(reportType, usageReportDownloadLogRecord);
    }

    @Override
    public QueryIterator<UsageReportDownloadLogRecord> getUsageReportDownloadLogs(YearAndMonth yearAndMonth) {
        return UsageReportDownloadLogRecord.FIND.where()
                .eq(UsageReportDownloadLogRecord.YEAR_COLUMN, yearAndMonth.getYear())
                .eq(UsageReportDownloadLogRecord.MONTH_COLUMN, yearAndMonth.getMonth())
                .findIterate();
    }

    private void markIfNeeded(ReportType reportType, UsageReportDownloadLogRecord usageReportDownloadLogRecord) {
        if (needMarking(reportType)) {
            saveOrUpdate(usageReportDownloadLogRecord);
        }
    }

    private static boolean needMarking(ReportType type) {
        switch (type) {
            case CS:
                return true;
            case SPS:
                return true;
            default:
                return false;
        }
    }

    private void saveOrUpdate(UsageReportDownloadLogRecord usageReportDownloadLogRecord) {
        try {
            usageReportDownloadLogRecord.save();
        } catch (PersistenceException e) {
            // The primary key duplication error or just DB's dead. There's no easy way to check that.
            // We were unable to insert, so try to update
            // Assuming that there is a record in the DB (because we were not able to insert)
            UsageReportDownloadLogRecord recordFromDb = Ebean
                    .find(UsageReportDownloadLogRecord.class,
                            usageReportDownloadLogRecord.getReportDownloadRecordPrimaryKey());
            // If the report was downloaded in the past, now do not update it's status.
            if (recordFromDb.getStatus() != Status.D) {
                usageReportDownloadLogRecord.update();
            }
        }
    }
}
