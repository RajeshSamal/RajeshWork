package com.ntti3.billingmetering.lib.reports.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.reports.statuses.DefaultUsageReportDownloadStatusesJsonGenerator;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesJsonGenerator;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadStatusesJsonGeneratorModule extends PrivateModule {

    private final ActorSelection sendingActorSelection;

    public DefaultUsageReportDownloadStatusesJsonGeneratorModule(ActorSelection sendingActorSelection) {
        this.sendingActorSelection = sendingActorSelection;
    }

    @Override
    protected void configure() {
        bind(ActorSelection.class).toInstance(sendingActorSelection);
        bind(UsageReportDownloadStatusesJsonGenerator.class).to(DefaultUsageReportDownloadStatusesJsonGenerator.class);
        expose(UsageReportDownloadStatusesJsonGenerator.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportDownloadStatusesJsonGeneratorModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportDownloadStatusesJsonGeneratorModule.class.equals(obj.getClass());
    }
}
