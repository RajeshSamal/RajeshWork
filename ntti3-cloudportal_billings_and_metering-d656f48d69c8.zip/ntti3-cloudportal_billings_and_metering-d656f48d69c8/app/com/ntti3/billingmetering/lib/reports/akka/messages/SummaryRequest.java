package com.ntti3.billingmetering.lib.reports.akka.messages;

import au.com.bytecode.opencsv.CSVWriter;
import com.avaje.ebean.QueryIterator;
import com.google.common.base.Optional;
import com.ntti3.billingmetering.lib.reports.DownloadCallback;
import com.ntti3.billingmetering.lib.reports.generators.SummaryGenerator;
import com.ntti3.billingmetering.models.UsageRecord;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class SummaryRequest {

    private final QueryIterator<UsageRecord> usageRecords;
    private final CSVWriter csvWriter;
    private final SummaryGenerator summaryGenerator;
    private final Optional<DownloadCallback> optionalDownloadCallback;

    public SummaryRequest(QueryIterator<UsageRecord> usageRecords, CSVWriter csvWriter,
                          SummaryGenerator summaryGenerator, Optional<DownloadCallback> optionalDownloadCallback) {
        this.usageRecords = usageRecords;
        this.csvWriter = csvWriter;
        this.summaryGenerator = summaryGenerator;
        this.optionalDownloadCallback = optionalDownloadCallback;
    }

    public QueryIterator<UsageRecord> getUsageRecords() {
        return usageRecords;
    }

    public CSVWriter getCsvWriter() {
        return csvWriter;
    }

    public SummaryGenerator getSummaryGenerator() {
        return summaryGenerator;
    }

    public Optional<DownloadCallback> getOptionalDownloadCallback() {
        return optionalDownloadCallback;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SummaryRequest request = (SummaryRequest) o;

        if (csvWriter != null ? !csvWriter.equals(request.csvWriter) : request.csvWriter != null) return false;
        if (optionalDownloadCallback != null ? !optionalDownloadCallback.equals(request.optionalDownloadCallback) : request.optionalDownloadCallback != null)
            return false;
        if (summaryGenerator != null ? !summaryGenerator.equals(request.summaryGenerator) : request.summaryGenerator != null)
            return false;
        if (usageRecords != null ? !usageRecords.equals(request.usageRecords) : request.usageRecords != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = usageRecords != null ? usageRecords.hashCode() : 0;
        result = 31 * result + (csvWriter != null ? csvWriter.hashCode() : 0);
        result = 31 * result + (summaryGenerator != null ? summaryGenerator.hashCode() : 0);
        result = 31 * result + (optionalDownloadCallback != null ? optionalDownloadCallback.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SummaryRequest{" +
                "usageRecords=" + usageRecords +
                ", csvWriter=" + csvWriter +
                ", summaryGenerator=" + summaryGenerator +
                ", optionalDownloadCallback=" + optionalDownloadCallback +
                '}';
    }
}
