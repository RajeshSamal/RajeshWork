package com.ntti3.billingmetering.lib.reports.logs;

import com.avaje.ebean.QueryIterator;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportDownloadLogsManager {

    /**
     * Stores the information that the UsageReport was successfully downloaded by the client.
     *
     * @param opcoUid      Unique identifier of Operating Company requesting the report.
     * @param serviceUid   Unique identifier of the service included in the report.
     * @param yearAndMonth Year and month of the report.
     * @param reportType   Type of the requested report.
     */
    void logUsageReportDownloaded(OpcoUid opcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth, ReportType reportType);

    /**
     * Stores the information that the UsageReport's download failed (server error or cancelled by the user) but
     * ONLY if the current status is not 'downloaded'.
     *
     * @param opcoUid      Unique identifier of Operating Company requesting the report.
     * @param serviceUid   Unique identifier of the service included in the report.
     * @param yearAndMonth Year and month of the report.
     * @param reportType   Type of the requested report.
     */
    void logUsageReportFailed(OpcoUid opcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth, ReportType reportType);

    /**
     * Returns logs of usage reports' downloads for specified year and month
     *
     * @param yearAndMonth Year and month of the reports to get download logs.
     * @return Logs of usage reports' downloads.
     */
    QueryIterator<UsageReportDownloadLogRecord> getUsageReportDownloadLogs(YearAndMonth yearAndMonth);
}