package com.ntti3.billingmetering.lib.reports.akka.messages;

import com.ntti3.billings.types.base.YearAndMonth;

import javax.annotation.concurrent.Immutable;
import java.io.OutputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ReportDownloadStatusesRequest {

    private final OutputStream outputStream;
    private final YearAndMonth yearAndMonth;

    public ReportDownloadStatusesRequest(OutputStream outputStream, YearAndMonth yearAndMonth) {
        this.outputStream = outputStream;
        this.yearAndMonth = yearAndMonth;
    }

    public OutputStream getOutputStream() {
        return outputStream;
    }

    public YearAndMonth getYearAndMonth() {
        return yearAndMonth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReportDownloadStatusesRequest that = (ReportDownloadStatusesRequest) o;

        if (outputStream != null ? !outputStream.equals(that.outputStream) : that.outputStream != null) return false;
        if (yearAndMonth != null ? !yearAndMonth.equals(that.yearAndMonth) : that.yearAndMonth != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = outputStream != null ? outputStream.hashCode() : 0;
        result = 31 * result + (yearAndMonth != null ? yearAndMonth.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ReportDownloadStatusesRequest{" +
                "outputStream=" + outputStream +
                ", yearAndMonth=" + yearAndMonth +
                '}';
    }
}
