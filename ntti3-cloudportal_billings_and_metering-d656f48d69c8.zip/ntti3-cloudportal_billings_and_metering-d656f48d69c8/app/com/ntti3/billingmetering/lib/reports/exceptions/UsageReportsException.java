package com.ntti3.billingmetering.lib.reports.exceptions;

import com.ntti3.billingmetering.lib.exceptions.BillingAndMeteringModuleException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UsageReportsException extends BillingAndMeteringModuleException {

    public UsageReportsException() {
        super();
    }

    public UsageReportsException(String message) {
        super(message);
    }

    public UsageReportsException(String message, Throwable cause) {
        super(message, cause);
    }

    public UsageReportsException(Throwable cause) {
        super(cause);
    }
}
