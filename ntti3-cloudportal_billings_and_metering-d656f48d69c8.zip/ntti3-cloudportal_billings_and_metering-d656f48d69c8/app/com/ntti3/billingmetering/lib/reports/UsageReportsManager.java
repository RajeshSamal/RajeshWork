package com.ntti3.billingmetering.lib.reports;

import com.ntti3.billingmetering.lib.reports.exceptions.UsageReportsException;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;

import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportsManager {

    /**
     * Returns a stream with CSV file containing the customer summary report.
     *
     * @param customerOpcoUid Unique identifier of the Operating Company for which the customer
     *                        summary report will be generated.
     * @param serviceUid      Unique identifier of the service for which the customer summary report
     *                        will be generated.
     * @param yearAndMonth    Year and month of the usage records to be included in the report.
     * @return An input stream with CSV file containing the customer summary report.
     * @throws UsageReportsException when report generation could not be finished.
     */
    InputStream getCustomerSummaryReport(OpcoUid customerOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth) throws UsageReportsException;

    /**
     * Returns a stream with CSV file containing the service provider summary report.
     *
     * @param serviceOpcoUid Unique identifier of the Operating Company for which the service
     *                       provider summary report will be generated.
     * @param serviceUid     Unique identifier of the service.
     * @param yearAndMonth   Year and month of the usage records to be included in the report.
     * @return An input stream with CSV file containing the service provider summary report.
     * @throws UsageReportsException when report generation could not be finished.
     */
    InputStream getServiceProviderSummaryReport(OpcoUid serviceOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth) throws UsageReportsException;

    /**
     * Returns a stream with CSV file containing the overall summary report.
     *
     * @param serviceUid   Unique identifier of the service.
     * @param yearAndMonth Year and month of the usage records to be included in the report.
     * @return An input stream with CSV file containing the overall summary report.
     * @throws UsageReportsException when report generation could not be finished.
     */
    InputStream getOverallSummaryReport(ServiceUid serviceUid, YearAndMonth yearAndMonth) throws UsageReportsException;
}
