package com.ntti3.billingmetering.lib.reports.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.reports.logs.DefaultUsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadLogsManagerModule extends PrivateModule {

    @Override
    protected void configure() {
        bind(UsageReportDownloadLogsManager.class).to(DefaultUsageReportDownloadLogsManager.class);
        expose(UsageReportDownloadLogsManager.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportDownloadLogsManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportDownloadLogsManagerModule.class.equals(obj.getClass());
    }
}
