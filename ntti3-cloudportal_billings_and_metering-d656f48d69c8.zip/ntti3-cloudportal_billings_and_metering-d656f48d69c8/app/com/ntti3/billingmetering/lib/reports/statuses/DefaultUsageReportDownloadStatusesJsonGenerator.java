package com.ntti3.billingmetering.lib.reports.statuses;

import akka.actor.ActorSelection;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.reports.akka.messages.ReportDownloadStatusesRequest;
import com.ntti3.billingmetering.lib.reports.exceptions.UsageReportsException;
import com.ntti3.billings.types.base.YearAndMonth;

import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadStatusesJsonGenerator implements UsageReportDownloadStatusesJsonGenerator {

    private final ActorSelection sendingActorSelection;

    @Inject
    public DefaultUsageReportDownloadStatusesJsonGenerator(ActorSelection sendingActorSelection) {
        this.sendingActorSelection = sendingActorSelection;
    }

    @Override
    public InputStream getReportDownloadStatuses(final YearAndMonth yearAndMonth) throws UsageReportsException {

        final PipedInputStream inputStream = new PipedInputStream();
        final PipedOutputStream outputStream;
        try {
            outputStream = new PipedOutputStream(inputStream);
        } catch (IOException e) {
            throw new UsageReportsException("Could not create PipedOutputStream", e);
        }

        ReportDownloadStatusesRequest request = new ReportDownloadStatusesRequest(outputStream, yearAndMonth);
        sendingActorSelection.tell(request, null);
        return inputStream;
    }
}
