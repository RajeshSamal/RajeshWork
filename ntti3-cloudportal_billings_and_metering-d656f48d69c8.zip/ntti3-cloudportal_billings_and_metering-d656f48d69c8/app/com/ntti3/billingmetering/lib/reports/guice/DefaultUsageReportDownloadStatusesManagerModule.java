package com.ntti3.billingmetering.lib.reports.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.reports.statuses.DefaultUsageReportDownloadStatusesManager;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesManager;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadStatusesManagerModule extends PrivateModule {

    @Override
    protected void configure() {
        bind(UsageReportDownloadStatusesManager.class).to(DefaultUsageReportDownloadStatusesManager.class);
        install(new DefaultUsageReportDownloadLogsManagerModule());
        expose(UsageReportDownloadStatusesManager.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportDownloadStatusesManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportDownloadStatusesManagerModule.class.equals(obj.getClass());
    }
}
