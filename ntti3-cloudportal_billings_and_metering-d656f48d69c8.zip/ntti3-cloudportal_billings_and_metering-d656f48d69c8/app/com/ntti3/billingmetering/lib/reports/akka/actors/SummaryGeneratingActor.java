package com.ntti3.billingmetering.lib.reports.akka.actors;

import akka.actor.UntypedActor;
import au.com.bytecode.opencsv.CSVWriter;
import com.avaje.ebean.QueryIterator;
import com.google.common.base.Optional;
import com.ntti3.billingmetering.lib.reports.DownloadCallback;
import com.ntti3.billingmetering.lib.reports.akka.messages.SummaryRequest;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.gums.GumsProtocolException;

import javax.persistence.PersistenceException;
import java.io.Closeable;
import java.io.IOException;
import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SummaryGeneratingActor extends UntypedActor {

    @Override
    public void onReceive(Object o) throws Exception {
        if (o instanceof SummaryRequest) {
            SummaryRequest request = (SummaryRequest) o;
            process(request);
        } else {
            unhandled(o);
        }
    }

    private void process(SummaryRequest request) {
        boolean summaryGeneratedSuccessfully = true;
        final QueryIterator<UsageRecord> usageRecords = request.getUsageRecords();
        final CSVWriter csvWriter = request.getCsvWriter();
        try {
            while (usageRecords.hasNext()) {
                final UsageRecord usageRecord = usageRecords.next();
                final List<String> record = request.getSummaryGenerator().produceRecord(usageRecord);
                csvWriter.writeNext(record.toArray(new String[record.size()]));
                csvWriter.flush();
            }
            csvWriter.flush();
        } catch (IOException e) {
            summaryGeneratedSuccessfully = false;
            play.Logger.error("IOException during usage records processing", e);
        } catch (PersistenceException e) {
            summaryGeneratedSuccessfully = false;
            play.Logger.error("PersistenceException during usage records processing", e);
        } catch (GumsProtocolException e) {
            summaryGeneratedSuccessfully = false;
            play.Logger.error("GumsConnector error during usage records processing", e);
        } finally {
            cleanup(request);
        }

        final Optional<DownloadCallback> optionalDownloadCallback = request.getOptionalDownloadCallback();
        if (optionalDownloadCallback.isPresent()) {
            DownloadCallback downloadCallback = optionalDownloadCallback.get();
            downloadCallback.setDownloadSucceeded(summaryGeneratedSuccessfully);
            downloadCallback.run();
        }
    }

    private void cleanup(SummaryRequest request) {
        safeClose(request.getCsvWriter());
        safeClose(request.getUsageRecords());
    }

    private void safeClose(Closeable obj) {
        try {
            obj.close();
        } catch (Exception e) {
            play.Logger.error("exception during cleanup", e);
        }
    }
}
