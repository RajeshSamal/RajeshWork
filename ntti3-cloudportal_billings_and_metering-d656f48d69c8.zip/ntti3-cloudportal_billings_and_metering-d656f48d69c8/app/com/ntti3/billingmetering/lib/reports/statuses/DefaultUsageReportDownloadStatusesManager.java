package com.ntti3.billingmetering.lib.reports.statuses;

import com.avaje.ebean.QueryIterator;
import com.google.common.collect.Iterables;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;
import com.ntti3.billingmetering.models.UsageReportDownloadLogRecord;
import com.ntti3.billings.settings.reports.DefaultRequestedUsageReportSetting;
import com.ntti3.billings.settings.reports.RequestedUsageReportSetting;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManager;
import com.ntti3.billings.settings.reports.UsageReportsSettingsManagerFactory;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import play.Logger;
import play.Play;

import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultUsageReportDownloadStatusesManager implements UsageReportDownloadStatusesManager {

    private UsageReportDownloadLogsManager usageReportDownloadLogsManager;
    private UsageReportsSettingsManager usageReportsSettingsManager;

    @Inject
    public DefaultUsageReportDownloadStatusesManager(UsageReportDownloadLogsManager usageReportDownloadLogsManager,
                                                     UsageReportsSettingsManagerFactory usageReportsSettingsManagerFactory) {
        this.usageReportDownloadLogsManager = usageReportDownloadLogsManager;
        usageReportsSettingsManager = usageReportsSettingsManagerFactory
                .create(Play.application().configuration().getConfig("opcos-reports"));
    }

    @Override
    public QueryIterator<UsageReportDownloadStatus> getReportDownloadStatuses(YearAndMonth yearAndMonth) {
        QueryIterator<UsageReportDownloadLogRecord> reportDownloadRecords
                = usageReportDownloadLogsManager.getUsageReportDownloadLogs(yearAndMonth);
        Set<RequestedUsageReportSetting> requestedUsageReportSettingSet = usageReportsSettingsManager.getRequestedReports();

        return new ReportDownloadStatusesIterator(reportDownloadRecords, requestedUsageReportSettingSet, yearAndMonth);
    }

    private class ReportDownloadStatusesIterator implements QueryIterator<UsageReportDownloadStatus> {

        private QueryIterator<UsageReportDownloadLogRecord> reportDownloadRecords;
        private Set<RequestedUsageReportSetting> requestedUsageReportSettings;
        private YearAndMonth yearAndMonth;

        private ReportDownloadStatusesIterator(QueryIterator<UsageReportDownloadLogRecord> reportDownloadRecords,
                                               Set<RequestedUsageReportSetting> requestedUsageReportSettings,
                                               YearAndMonth yearAndMonth) {
            this.reportDownloadRecords = reportDownloadRecords;
            this.requestedUsageReportSettings = requestedUsageReportSettings;
            this.yearAndMonth = yearAndMonth;
        }

        @Override
        public boolean hasNext() {
            return !requestedUsageReportSettings.isEmpty();
        }

        @Override
        public UsageReportDownloadStatus next() {
            while (reportDownloadRecords.hasNext()) {
                UsageReportDownloadLogRecord usageReportDownloadLogRecord = reportDownloadRecords.next();
                if (hasUnprocessedSetting(usageReportDownloadLogRecord)) {
                    switch (usageReportDownloadLogRecord.getStatus()) {
                        case D:
                            return UsageReportDownloadStatus.downloaded(
                                    usageReportDownloadLogRecord.getOpcoUid(),
                                    usageReportDownloadLogRecord.getServiceUid(),
                                    yearAndMonth.getYear(),
                                    yearAndMonth.getMonth(),
                                    usageReportDownloadLogRecord.getDownloadTime(),
                                    usageReportDownloadLogRecord.getReportType());
                        case F:
                            return UsageReportDownloadStatus.failed(
                                    usageReportDownloadLogRecord.getOpcoUid(),
                                    usageReportDownloadLogRecord.getServiceUid(),
                                    yearAndMonth.getYear(),
                                    yearAndMonth.getMonth(),
                                    usageReportDownloadLogRecord.getDownloadTime(),
                                    usageReportDownloadLogRecord.getReportType());
                        default:
                            Logger.warn("Skipping usageReportDownloadLogRecord due to invalid status: "
                                    + usageReportDownloadLogRecord.toString());
                    }
                }
            }
            return getReportDownloadStatusFromUnprocessedSetting();
        }

        @Override
        public void remove() {

        }

        @Override
        public void close() {
            reportDownloadRecords.close();
        }

        private RequestedUsageReportSetting getCorrespondingSetting(final UsageReportDownloadLogRecord usageReportDownloadLogRecord) {
            return new DefaultRequestedUsageReportSetting(usageReportDownloadLogRecord.getOpcoUid(),
                    usageReportDownloadLogRecord.getServiceUid(), usageReportDownloadLogRecord.getReportType());
        }

        private UsageReportDownloadStatus getReportDownloadStatusFromUnprocessedSetting() {
            RequestedUsageReportSetting unprocessedReportSetting
                    = getUnprocessedRequestedReportSetting();

            return UsageReportDownloadStatus.pending(unprocessedReportSetting.getOpcoUid(),
                    unprocessedReportSetting.getServiceUid(),
                    yearAndMonth.getYear(), yearAndMonth.getMonth(),
                    unprocessedReportSetting.getReportType());
        }

        private boolean hasUnprocessedSetting(UsageReportDownloadLogRecord usageReportDownloadLogRecord) {
            RequestedUsageReportSetting correspondingSetting = getCorrespondingSetting(usageReportDownloadLogRecord);
            if (requestedUsageReportSettings.contains(correspondingSetting)) {
                requestedUsageReportSettings.remove(correspondingSetting);
                return true;
            } else {
                return false;
            }
        }

        private RequestedUsageReportSetting getUnprocessedRequestedReportSetting() {
            RequestedUsageReportSetting unprocessedReportSetting = Iterables.get(requestedUsageReportSettings, 0);
            requestedUsageReportSettings.remove(unprocessedReportSetting);
            return unprocessedReportSetting;
        }
    }
}
