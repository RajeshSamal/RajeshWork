package com.ntti3.billingmetering.lib.reports;

import akka.actor.ActorSelection;
import au.com.bytecode.opencsv.CSVWriter;
import com.avaje.ebean.QueryIterator;
import com.google.common.base.Charsets;
import com.google.common.base.Optional;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.ntti3.billingmetering.lib.reports.akka.messages.SummaryRequest;
import com.ntti3.billingmetering.lib.reports.exceptions.UsageReportsException;
import com.ntti3.billingmetering.lib.reports.generators.SummaryGenerator;
import com.ntti3.billingmetering.lib.reports.generators.SummaryGeneratorFactory;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.usage.UsageManager;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import org.apache.commons.io.input.ReaderInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class DefaultUsageReportsManager implements UsageReportsManager {

    private final UsageManager usageManager;
    private final SummaryGeneratorFactory summaryGeneratorsFactory;
    private final UsageReportDownloadLogsManager usageReportDownloadLogsManager;
    private final ActorSelection generatingActorSelection;

    @Inject
    public DefaultUsageReportsManager(UsageManager usageManager, SummaryGeneratorFactory summaryGeneratorsFactory,
                                      UsageReportDownloadLogsManager usageReportDownloadLogsManager,
                                      ActorSelection generatingActorSelection) {
        this.usageManager = usageManager;
        this.summaryGeneratorsFactory = summaryGeneratorsFactory;
        this.usageReportDownloadLogsManager = usageReportDownloadLogsManager;
        this.generatingActorSelection = generatingActorSelection;
    }

    @Override
    public InputStream getCustomerSummaryReport(OpcoUid customerOpcoUid, ServiceUid serviceUid,
                                                YearAndMonth yearAndMonth) throws UsageReportsException {
        final DownloadCallback downloadCallback
                = new DefaultDownloadCallback(customerOpcoUid, yearAndMonth, serviceUid, ReportType.CS);
        final SummaryGenerator customerSummaryGenerator = summaryGeneratorsFactory.getCustomerSummaryGenerator();
        final QueryIterator<UsageRecord> usageRecordsIterator =
                usageManager.getCustomerSummary(customerOpcoUid, serviceUid, yearAndMonth);
        return generateSummaryStream(usageRecordsIterator, customerSummaryGenerator,
                Optional.of(downloadCallback));
    }

    @Override
    public InputStream getServiceProviderSummaryReport(OpcoUid serviceOpcoUid, ServiceUid serviceUid,
                                                       YearAndMonth yearAndMonth) throws UsageReportsException {
        final DownloadCallback downloadCallback
                = new DefaultDownloadCallback(serviceOpcoUid, yearAndMonth, serviceUid, ReportType.SPS);
        final SummaryGenerator serviceProviderSummaryGenerator = summaryGeneratorsFactory.getServiceProviderSummaryGenerator();
        final QueryIterator<UsageRecord> usageRecords =
                usageManager.getServiceProviderSummary(serviceOpcoUid, serviceUid, yearAndMonth);
        return generateSummaryStream(usageRecords, serviceProviderSummaryGenerator,
                Optional.of(downloadCallback));
    }

    @Override
    public InputStream getOverallSummaryReport(ServiceUid serviceUid, YearAndMonth yearAndMonth) throws UsageReportsException {
        final SummaryGenerator overallSummaryGenerator = summaryGeneratorsFactory.getOverallSummaryGenerator();
        final QueryIterator<UsageRecord> usageRecords =
                usageManager.getOverallSummary(serviceUid, yearAndMonth);
        return generateSummaryStream(usageRecords, overallSummaryGenerator,
                Optional.<DownloadCallback>absent());
    }

    private InputStream generateSummaryStream(final QueryIterator<UsageRecord> usageRecords,
                                              final SummaryGenerator summaryGenerator,
                                              final Optional<DownloadCallback> downloadCallbackOptional) throws UsageReportsException {

        final PipedReader pipedReader = new PipedReader();
        final PipedWriter pipedWriter;
        try {
            pipedWriter = new PipedWriter(pipedReader);
        } catch (IOException e) {
            throw new UsageReportsException("PipedWriter creating error", e);
        }

        final CSVWriter csvWriter = new CSVWriter(pipedWriter);
        final ReaderInputStream readerInputStream = new ReaderInputStream(pipedReader, Charsets.UTF_8);

        final List<String> columnsNamesList = summaryGenerator.produceColumnHeaders();
        csvWriter.writeNext(columnsNamesList.toArray(new String[columnsNamesList.size()]));

        final SummaryRequest request = new SummaryRequest(usageRecords, csvWriter,
                summaryGenerator, downloadCallbackOptional);
        generatingActorSelection.tell(request, null);
        return readerInputStream;
    }

    private class DefaultDownloadCallback implements DownloadCallback {
        private final OpcoUid opcoUid;
        private final YearAndMonth yearAndMonth;
        private final ServiceUid serviceUid;
        private final ReportType reportType;
        private boolean downloadSucceeded;

        public DefaultDownloadCallback(OpcoUid opcoUid, YearAndMonth yearAndMonth,
                                       ServiceUid serviceUid, ReportType reportType) {
            this.opcoUid = opcoUid;
            this.yearAndMonth = yearAndMonth;
            this.serviceUid = serviceUid;
            this.reportType = reportType;
        }

        public boolean getDownloadSucceeded() {
            return downloadSucceeded;
        }

        public void setDownloadSucceeded(Boolean downloadSucceeded) {
            this.downloadSucceeded = downloadSucceeded;
        }

        @Override
        public void run() {
            if (getDownloadSucceeded()) {
                usageReportDownloadLogsManager.logUsageReportDownloaded(opcoUid, serviceUid, yearAndMonth, reportType);
            } else {
                usageReportDownloadLogsManager.logUsageReportFailed(opcoUid, serviceUid, yearAndMonth, reportType);
            }
        }
    }
}
