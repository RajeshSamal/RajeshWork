package com.ntti3.billingmetering.lib.reports;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface DownloadCallback extends Runnable {

    boolean getDownloadSucceeded();

    void setDownloadSucceeded(Boolean downloadSucceeded);
}
