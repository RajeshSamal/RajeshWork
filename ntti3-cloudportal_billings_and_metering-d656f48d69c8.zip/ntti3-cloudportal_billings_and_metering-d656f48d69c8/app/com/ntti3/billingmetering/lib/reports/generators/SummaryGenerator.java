package com.ntti3.billingmetering.lib.reports.generators;

import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.gums.GumsProtocolException;

import java.io.IOException;
import java.util.List;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface SummaryGenerator {

    List<String> produceColumnHeaders();

    List<String> produceRecord(UsageRecord usageRecord) throws IOException, GumsProtocolException;
}
