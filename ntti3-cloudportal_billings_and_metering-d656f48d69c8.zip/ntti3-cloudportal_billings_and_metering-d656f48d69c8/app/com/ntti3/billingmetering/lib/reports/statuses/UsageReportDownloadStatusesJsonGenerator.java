package com.ntti3.billingmetering.lib.reports.statuses;

import com.ntti3.billingmetering.lib.reports.exceptions.UsageReportsException;
import com.ntti3.billings.types.base.YearAndMonth;

import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportDownloadStatusesJsonGenerator {

    InputStream getReportDownloadStatuses(YearAndMonth yearAndMonth) throws UsageReportsException;
}
