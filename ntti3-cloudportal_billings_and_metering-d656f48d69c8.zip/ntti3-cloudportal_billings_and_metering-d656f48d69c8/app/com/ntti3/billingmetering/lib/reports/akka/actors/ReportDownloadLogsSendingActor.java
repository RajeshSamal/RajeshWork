package com.ntti3.billingmetering.lib.reports.akka.actors;

import akka.actor.UntypedActor;
import com.avaje.ebean.QueryIterator;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.reports.akka.messages.ReportDownloadStatusesRequest;
import com.ntti3.billingmetering.lib.reports.statuses.UsageReportDownloadStatusesManager;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;
import play.Logger;

import java.io.Closeable;
import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ReportDownloadLogsSendingActor extends UntypedActor {

    private static final String DOWNLOAD_STATUSES = "download_statuses";
    private static final JsonFactory JSON_FACTORY = new JsonFactory(new ObjectMapper());
    private UsageReportDownloadStatusesManager usageReportDownloadStatusesManager;

    @Inject
    public ReportDownloadLogsSendingActor(UsageReportDownloadStatusesManager usageReportDownloadStatusesManager) {
        this.usageReportDownloadStatusesManager = usageReportDownloadStatusesManager;
    }

    @Override
    public void onReceive(Object o) throws Exception {
        if (o instanceof ReportDownloadStatusesRequest) {
            generateStatuses((ReportDownloadStatusesRequest) o);
        }
    }

    private void generateStatuses(ReportDownloadStatusesRequest request) throws IOException {
        JsonGenerator jsonGenerator = null;

        try (QueryIterator<UsageReportDownloadStatus> statusesQueryIterator
                     = usageReportDownloadStatusesManager.getReportDownloadStatuses(request.getYearAndMonth())) {

            jsonGenerator = JSON_FACTORY.createGenerator(request.getOutputStream());
            jsonGenerator.configure(JsonGenerator.Feature.AUTO_CLOSE_TARGET, true);

            jsonGenerator.writeStartObject();
            jsonGenerator.writeArrayFieldStart(DOWNLOAD_STATUSES);

            while (statusesQueryIterator.hasNext()) {
                UsageReportDownloadStatus usageReportDownloadStatus = statusesQueryIterator.next();
                jsonGenerator.writeObject(usageReportDownloadStatus);
            }

            jsonGenerator.writeEndArray();
            jsonGenerator.writeEndObject();
        } finally {
            safeClose(jsonGenerator);
        }
    }

    private void safeClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                Logger.error(String.format("Could not close %s in ReportDownloadLogsSendingActor",
                        closeable.toString()), e);
            }
        }
    }
}
