package com.ntti3.billingmetering.lib.reports;

import akka.actor.ActorSelection;
import akka.actor.Props;
import akka.routing.SmallestMailboxRouter;
import com.google.inject.Injector;
import com.ntti3.billingmetering.lib.akka.actors.factories.PullJobActorFactory;
import com.ntti3.billingmetering.lib.reports.akka.actors.ReportDownloadLogsSendingActor;
import com.ntti3.billingmetering.lib.reports.akka.actors.SummaryGeneratingActor;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;
import play.libs.Akka;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UsageReportsActorsConfigurator {

    public static final String GENERATING_ACTOR_NAME = "generatingActor";
    public static final String DOWNLOAD_STATUS_GENERATING_ACTOR_NAME = "downloadStatusSendingActor";
    private final ActorSelection generatingActorSelection = buildActorSelection(GENERATING_ACTOR_NAME);
    private final ActorSelection downloadStatusesActorSelection = buildActorSelection(DOWNLOAD_STATUS_GENERATING_ACTOR_NAME);
    private final int generatingActorsCount;
    private final int downloadStatusesActorsCount;

    public UsageReportsActorsConfigurator(Configuration configuration) {
        generatingActorsCount = ConfigurationHelper.safeGetInt(configuration, "generating-actors");
        downloadStatusesActorsCount = ConfigurationHelper.safeGetInt(configuration, "download-statuses-actors");
    }

    public static ActorSelection buildActorSelection(String actorName) {
        return Akka.system().actorSelection("/user/" + actorName);
    }

    public ActorSelection getGeneratingActorSelection() {
        return generatingActorSelection;
    }

    public ActorSelection getDownloadStatusesActorSelection() {
        return downloadStatusesActorSelection;
    }

    public void createGeneratingActors(Injector injector) {
        Props generatingActorProps = Props.create(PullJobActorFactory.class, injector, SummaryGeneratingActor.class);
        Props downloadStatusesActorProps = Props.create(PullJobActorFactory.class, injector, ReportDownloadLogsSendingActor.class);

        // report generating actors
        Akka.system().actorOf(generatingActorProps
                .withRouter(new SmallestMailboxRouter(generatingActorsCount)), GENERATING_ACTOR_NAME);

        Akka.system().actorOf(downloadStatusesActorProps
                .withRouter(new SmallestMailboxRouter(downloadStatusesActorsCount)), DOWNLOAD_STATUS_GENERATING_ACTOR_NAME);
    }
}