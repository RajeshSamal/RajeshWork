package com.ntti3.billingmetering.lib.reports.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.reports.DefaultUsageReportsManager;
import com.ntti3.billingmetering.lib.reports.UsageReportsManager;
import com.ntti3.billingmetering.lib.reports.generators.CustomerSummaryGenerator;
import com.ntti3.billingmetering.lib.reports.generators.OverallSummaryGenerator;
import com.ntti3.billingmetering.lib.reports.generators.ServiceProviderSummaryGenerator;
import com.ntti3.billingmetering.lib.reports.generators.SummaryGenerator;
import com.ntti3.billingmetering.lib.reports.guice.annotations.CustomerSummary;
import com.ntti3.billingmetering.lib.reports.guice.annotations.OverallSummary;
import com.ntti3.billingmetering.lib.reports.guice.annotations.ServiceProviderSummary;
import com.ntti3.billingmetering.lib.reports.logs.DefaultUsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.reports.logs.UsageReportDownloadLogsManager;
import com.ntti3.billingmetering.lib.usage.guice.DefaultUsageManagerModule;

/**
 * @author Tomasz Roda (tomasz.roda@codilime.com)
 */
public class DefaultUsageReportsManagerModule extends PrivateModule {

    private final ActorSelection generatingActorSelection;

    public DefaultUsageReportsManagerModule(ActorSelection generatingActorSelection) {
        this.generatingActorSelection = generatingActorSelection;
    }

    @Override
    protected void configure() {
        bind(ActorSelection.class).toInstance(generatingActorSelection);
        bind(UsageReportsManager.class).to(DefaultUsageReportsManager.class);
        bind(UsageReportDownloadLogsManager.class).to(DefaultUsageReportDownloadLogsManager.class);

        bind(SummaryGenerator.class).annotatedWith(CustomerSummary.class).to(CustomerSummaryGenerator.class);
        bind(SummaryGenerator.class).annotatedWith(ServiceProviderSummary.class).to(ServiceProviderSummaryGenerator.class);
        bind(SummaryGenerator.class).annotatedWith(OverallSummary.class).to(OverallSummaryGenerator.class);

        install(new DefaultUsageManagerModule());

        expose(UsageReportsManager.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageReportsManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageReportsManagerModule.class.equals(obj.getClass());
    }
}
