package com.ntti3.billingmetering.lib.reports.generators.columns;

import com.ntti3.billingmetering.lib.reports.generators.SummaryColumn;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;

import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class CustomerOpcoCompanyNameColumn implements SummaryColumn {
    @Override
    public String getName() {
        return "customer_opco_c_name";
    }

    @Override
    public String getValue(UsageRecord usageRecord, GumsConnector gumsConnector) throws IOException, GumsProtocolException {
        return gumsConnector.getUser(usageRecord.getUserGuid()).getOpcoCName();
    }
}
