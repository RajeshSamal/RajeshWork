package com.ntti3.billingmetering.lib.reports.generators;

import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;

import java.io.IOException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface SummaryColumn {

    String getName();

    String getValue(final UsageRecord usageRecord, final GumsConnector gumsConnector) throws IOException, GumsProtocolException;
}
