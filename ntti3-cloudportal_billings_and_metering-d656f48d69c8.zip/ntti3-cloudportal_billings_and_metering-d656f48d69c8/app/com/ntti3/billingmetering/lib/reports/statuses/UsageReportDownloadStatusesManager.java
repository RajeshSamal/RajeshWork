package com.ntti3.billingmetering.lib.reports.statuses;

import com.avaje.ebean.QueryIterator;
import com.ntti3.billings.types.base.YearAndMonth;
import com.ntti3.billings.types.reports.UsageReportDownloadStatus;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageReportDownloadStatusesManager {
    /**
     * Returns download status for each of report that can be downloaded in the specified year and month.
     *
     * @param yearAndMonth Year and month of reports to get download statuses.
     * @return Download statuses of reports that can be downloaded in the specified year and month.
     */
    QueryIterator<UsageReportDownloadStatus> getReportDownloadStatuses(YearAndMonth yearAndMonth);
}
