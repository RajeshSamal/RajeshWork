package com.ntti3.billingmetering.lib.akka.actors.factories;

import akka.actor.Actor;
import akka.actor.IndirectActorProducer;
import com.google.inject.Injector;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobActorFactory implements IndirectActorProducer {

    private final Injector injector;
    private Class<? extends Actor> cls;

    public PullJobActorFactory(Injector injector, Class<? extends Actor> cls) {
        this.injector = injector;
        this.cls = cls;
    }

    @Override
    public Actor produce() {
        return injector.getInstance(cls);
    }

    @Override
    public Class<? extends Actor> actorClass() {
        return cls;
    }
}
