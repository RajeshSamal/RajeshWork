package com.ntti3.billingmetering.lib.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class InvalidApiRequest extends BillingAndMeteringModuleException {
    public InvalidApiRequest() {
        super();
    }

    public InvalidApiRequest(String message) {
        super(message);
    }

    public InvalidApiRequest(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidApiRequest(Throwable cause) {
        super(cause);
    }
}
