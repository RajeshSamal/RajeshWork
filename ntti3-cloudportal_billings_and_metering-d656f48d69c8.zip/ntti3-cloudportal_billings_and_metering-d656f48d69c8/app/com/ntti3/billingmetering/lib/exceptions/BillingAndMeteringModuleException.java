package com.ntti3.billingmetering.lib.exceptions;

/**
 * @author Tomasz Roda (tomasz.roda@codilime.com)
 */
public class BillingAndMeteringModuleException extends Exception {

    public BillingAndMeteringModuleException() {
        super();
    }

    public BillingAndMeteringModuleException(String message) {
        super(message);
    }

    public BillingAndMeteringModuleException(String message, Throwable cause) {
        super(message, cause);
    }

    public BillingAndMeteringModuleException(Throwable cause) {
        super(cause);
    }

    @Override
    public String toString() {
        return "Exception{" +
                "message=" + getMessage() +
                ", cause=" + getCause() +
                '}';
    }
}
