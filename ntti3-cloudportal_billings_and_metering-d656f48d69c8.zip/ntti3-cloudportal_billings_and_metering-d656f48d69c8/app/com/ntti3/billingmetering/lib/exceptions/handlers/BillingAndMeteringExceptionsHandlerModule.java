package com.ntti3.billingmetering.lib.exceptions.handlers;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.exceptions.InvalidApiRequest;
import com.ntti3.play.excetions.handling.GlobalExceptionsHandler;
import com.ntti3.play.excetions.handling.SimpleExceptionHandler;
import com.ntti3.protocol.ErrorCode;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class BillingAndMeteringExceptionsHandlerModule extends PrivateModule {

    private final GlobalExceptionsHandler globalExceptionsHandler;

    public BillingAndMeteringExceptionsHandlerModule() {
        globalExceptionsHandler = new GlobalExceptionsHandler();

        globalExceptionsHandler.registerHandler(new SimpleExceptionHandler(
                InvalidApiRequest.class, ErrorCode.INCORRECT_CALL, "Invalid API request"));
    }

    @Override
    protected void configure() {
        bind(GlobalExceptionsHandler.class).toInstance(globalExceptionsHandler);
        expose(GlobalExceptionsHandler.class);
    }

    @Override
    public int hashCode() {
        return BillingAndMeteringExceptionsHandlerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return BillingAndMeteringExceptionsHandlerModule.class.equals(obj.getClass());
    }
}
