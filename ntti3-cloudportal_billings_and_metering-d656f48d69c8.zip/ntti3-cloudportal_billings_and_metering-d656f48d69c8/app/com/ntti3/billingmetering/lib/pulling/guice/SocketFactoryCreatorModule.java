package com.ntti3.billingmetering.lib.pulling.guice;

import com.google.common.base.Preconditions;
import com.google.inject.PrivateModule;
import com.google.inject.TypeLiteral;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.CertPassword;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.CertPath;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.SocketFactoryConfig;
import com.ntti3.billingmetering.lib.pulling.util.DefaultSocketFactoryCreator;
import com.ntti3.billingmetering.lib.pulling.util.SocketFactoryCreator;
import play.Configuration;

import java.util.Map;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public class SocketFactoryCreatorModule extends PrivateModule {

    private static final String CERT_PASSWORD = "cert-password";
    private static final String CERT_PATH = "cert-path";
    private final String certPath;
    private final String certPassword;
    private final Map<String, Object> socketConfiguration;

    public SocketFactoryCreatorModule(Configuration serviceConnectorConfiguration, Configuration socketConfiguration) {
        Preconditions.checkNotNull(serviceConnectorConfiguration, "ServiceConnectorConfiguration can't be null");
        Preconditions.checkNotNull(socketConfiguration, "SocketConfiguration can't be null");
        this.certPath = serviceConnectorConfiguration.getString(CERT_PATH);
        this.certPassword = serviceConnectorConfiguration.getString(CERT_PASSWORD);
        this.socketConfiguration = socketConfiguration.asMap();
    }

    @Override
    protected void configure() {
        bind(String.class).annotatedWith(CertPath.class).toInstance(certPath);
        bind(String.class).annotatedWith(CertPassword.class).toInstance(certPassword);
        bind(new TypeLiteral<Map<String, Object>>() {
        }).annotatedWith(SocketFactoryConfig.class).toInstance(socketConfiguration);
        bind(SocketFactoryCreator.class).to(DefaultSocketFactoryCreator.class);
        expose(SocketFactoryCreator.class);
    }
}
