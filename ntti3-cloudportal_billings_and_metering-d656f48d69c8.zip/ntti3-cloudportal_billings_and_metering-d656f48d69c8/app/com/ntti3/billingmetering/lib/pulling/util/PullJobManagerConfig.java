package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;
import scala.concurrent.duration.FiniteDuration;

import java.util.concurrent.TimeUnit;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobManagerConfig {

    private final FiniteDuration pullJobTimeout;

    public PullJobManagerConfig(FiniteDuration pullJobTimeout) {
        this.pullJobTimeout = pullJobTimeout;
        verify();
    }

    public PullJobManagerConfig(Configuration configuration) {
        pullJobTimeout = FiniteDuration
                .create(ConfigurationHelper.safeGetDuration(configuration, "pull-job-timeout").getMillis(),
                        TimeUnit.MILLISECONDS);
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull("pullJobTimeout can not be null!");
    }

    public FiniteDuration getPullJobTimeout() {
        return pullJobTimeout;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PullJobManagerConfig that = (PullJobManagerConfig) o;

        return !(pullJobTimeout != null ? !pullJobTimeout.equals(that.pullJobTimeout) : that.pullJobTimeout != null);

    }

    @Override
    public int hashCode() {
        return pullJobTimeout != null ? pullJobTimeout.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "PullJobManagerConfig{" +
                "pullJobTimeout=" + pullJobTimeout +
                '}';
    }
}
