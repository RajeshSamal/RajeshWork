package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceResponseProcessingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseProcessingActorConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseProcessingActorModule extends PrivateModule {

    private final ServiceResponseProcessingActorConfig config;
    private final ActorSelection sendTo;

    public ServiceResponseProcessingActorModule(ServiceResponseProcessingActorConfig config,
                                                ActorSelection sendTo) {
        this.config = config;
        this.sendTo = sendTo;
    }

    public ServiceResponseProcessingActorModule(Configuration configuration,
                                                ActorSelection sendTo) {
        this.config = new ServiceResponseProcessingActorConfig(configuration);
        this.sendTo = sendTo;
    }

    @Override
    protected void configure() {
        bind(ServiceResponseProcessingActorConfig.class).toInstance(config);
        bind(ActorSelection.class).toInstance(sendTo);
        bind(ServiceResponseProcessingActor.class);
        expose(ServiceResponseProcessingActor.class);
    }
}
