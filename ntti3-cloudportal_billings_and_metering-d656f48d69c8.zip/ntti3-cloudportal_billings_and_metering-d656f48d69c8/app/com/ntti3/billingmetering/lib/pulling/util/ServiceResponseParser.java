package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Optional;
import com.ntti3.billingmetering.lib.pulling.exceptions.ServiceResponseParsingException;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface ServiceResponseParser {

    /**
     * Initializes the parser to read the service stream.
     *
     * @param serviceStream The service stream with billing and metering data.
     * @throws IOException
     */
    void startProcessing(@Nonnull InputStream serviceStream, @Nonnull ProtocolSchemaHelper schemaHelper) throws IOException, ServiceResponseParsingException;

    /**
     * Reads next record from the service stream.
     *
     * @return Next record from the service stream or Absent if there is no records left.
     * @throws ServiceResponseParsingException When there is unexpected data in the stream.
     */
    Optional<ServiceResponseRecord> readServiceResponseRecord() throws ServiceResponseParsingException;
}
