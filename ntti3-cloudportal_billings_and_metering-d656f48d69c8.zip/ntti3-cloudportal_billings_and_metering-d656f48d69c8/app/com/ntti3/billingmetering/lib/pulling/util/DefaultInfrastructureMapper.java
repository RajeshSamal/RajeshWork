package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import com.ntti3.billings.types.base.OpcoUid;
import play.Configuration;
import play.Play;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultInfrastructureMapper implements InfrastructureMapper {

    private final ImmutableSet<InfrastructureMapping> mappings;

    public DefaultInfrastructureMapper() {
        Configuration mappingsConfiguration = Play.application().configuration().getConfig("mappings");
        mappings = readConfig(mappingsConfiguration);
    }

    public DefaultInfrastructureMapper(Configuration configuration) {
        mappings = readConfig(configuration);
    }

    private ImmutableSet<InfrastructureMapping> readConfig(Configuration mappingsConfiguration) {
        ImmutableSet.Builder<InfrastructureMapping> builder = ImmutableSet.builder();
        for (Map.Entry<String, Object> mappingConfig : mappingsConfiguration.asMap().entrySet()) {
            Object mappingConfigValueObject = mappingConfig.getValue();
            if (mappingConfigValueObject instanceof String) {
                String mappingRegex = (String) mappingConfigValueObject;
                builder.add(new InfrastructureMapping(OpcoUid.fromString(mappingConfig.getKey()), Pattern.compile(mappingRegex)));
            }
        }

        return builder.build();
    }

    @Override
    public Optional<OpcoUid> getOpcoUidFor(@Nullable String infrastructureId) {
        if (infrastructureId == null) {
            return Optional.absent();
        }

        for (InfrastructureMapping mapping : mappings) {
            if (mapping.isMachingTo(infrastructureId)) {
                return Optional.of(mapping.getOpcoUid());
            }
        }
        return Optional.absent();
    }

    @Immutable
    private static class InfrastructureMapping {
        private final OpcoUid opcoUid;
        private final Pattern pattern;

        private InfrastructureMapping(OpcoUid opcoUid, Pattern pattern) {
            this.opcoUid = opcoUid;
            this.pattern = pattern;
        }

        public OpcoUid getOpcoUid() {
            return opcoUid;
        }

        public Pattern getPattern() {
            return pattern;
        }

        public boolean isMachingTo(String infrastructureId) {
            return pattern.matcher(infrastructureId).matches();
        }

        @Override
        public int hashCode() {
            int result = opcoUid != null ? opcoUid.hashCode() : 0;
            result = 31 * result + (pattern != null ? pattern.hashCode() : 0);
            return result;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            InfrastructureMapping that = (InfrastructureMapping) o;

            if (opcoUid != null ? !opcoUid.equals(that.opcoUid) : that.opcoUid != null) return false;
            if (pattern != null ? !pattern.equals(that.pattern) : that.pattern != null) return false;

            return true;
        }

        @Override
        public String toString() {
            return "InfrastructureMapping{" +
                    "opcoUid=" + opcoUid +
                    ", pattern=" + pattern +
                    '}';
        }
    }
}
