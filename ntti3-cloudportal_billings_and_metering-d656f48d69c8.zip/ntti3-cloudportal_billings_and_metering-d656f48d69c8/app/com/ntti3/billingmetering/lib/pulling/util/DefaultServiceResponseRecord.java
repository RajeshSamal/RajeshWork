package com.ntti3.billingmetering.lib.pulling.util;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.concurrent.Immutable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.UUID;

/**
 * @author Mateusz Piękos (mateusz.piekos@codilime.com)
 */
@Immutable
@JsonIgnoreProperties(ignoreUnknown = true)
public class DefaultServiceResponseRecord extends ServiceResponseRecord {

    public final static String TRANSACTION_ID = "transaction_uid";
    public final static String USER = "user_guid";
    public final static String DESCRIPTION = "description";
    public final static String BILL_DATE = "bill_date";
    public final static String COST = "cost";
    public final static String CURRENCY = "currency";
    public final static String CLOUD = "service_opco_uid";
    public final static String ITEM_TYPE = "item_type";
    public final static String DETAILS = "details";
    private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssX";

    // Constructor for deserialization from Json
    @JsonCreator
    public DefaultServiceResponseRecord(
            @JsonProperty(value = TRANSACTION_ID)
            String transactionId,

            @JsonProperty(value = USER)
            String userGuid,

            @JsonProperty(value = DESCRIPTION)
            String description,

            @JsonProperty(value = BILL_DATE)
            String billDate,

            @JsonProperty(value = COST)
            BigDecimal cost,

            @JsonProperty(value = CURRENCY)
            String currency,

            @JsonProperty(value = ITEM_TYPE)
            String itemType,

            @JsonProperty(value = DETAILS)
            JsonNode details,

            @JsonProperty(value = CLOUD)
            String opcoUid) throws ParseException {
        super(transactionId, getGuid(userGuid), opcoUid, null, description, new SimpleDateFormat(DATE_FORMAT).parse(billDate), cost, currency, itemType, details);
    }

    private static UUID getGuid(String userInResponseRecord) {
        UUID guid;
        try {
            guid = UUID.fromString(userInResponseRecord);
        } catch (IllegalArgumentException | NullPointerException e) {
            guid = null;
        }
        return guid;
    }
}
