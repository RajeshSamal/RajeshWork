package com.ntti3.billingmetering.lib.pulling;

import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.pulling.util.PullJobConfig;
import com.ntti3.billingmetering.models.PullJobRecord;
import com.ntti3.billings.types.base.ServiceUid;
import org.joda.time.DateTime;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class PullJobDetails {

    private final PullJobConfig pullJobConfig;
    private final DateTime fromDate;
    private final DateTime toDate;
    private final ServiceUid targetService;
    private final DateTime executeAt;
    private final Integer recordId;

    public PullJobDetails(PullJobRecord record, PullJobConfig pullJobConfig) {
        final int month = record.getExecuteAt().getMonthOfYear();
        final int year = record.getExecuteAt().getYear();
        toDate = new DateTime(year, month, 1, 0, 0, 0, 0);
        fromDate = toDate.minusMonths(1);
        this.targetService = record.getTargetService();
        this.executeAt = record.getExecuteAt();
        this.recordId = record.getId();
        this.pullJobConfig = pullJobConfig;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(pullJobConfig);
    }

    public ServiceUid getServiceUid() {
        return targetService;
    }

    public PullJobConfig getPullJobConfig() {
        return pullJobConfig;
    }

    public DateTime getExecutionTime() {
        return executeAt;
    }

    public Integer getPullJobId() {
        return recordId;
    }

    public DateTime getFromDate() {
        return fromDate;
    }

    public DateTime getToDate() {
        return toDate;
    }
}
