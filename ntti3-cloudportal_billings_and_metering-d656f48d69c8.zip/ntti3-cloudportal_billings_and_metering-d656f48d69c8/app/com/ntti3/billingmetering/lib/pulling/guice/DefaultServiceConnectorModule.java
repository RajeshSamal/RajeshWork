package com.ntti3.billingmetering.lib.pulling.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.util.DefaultServiceConnector;
import com.ntti3.billingmetering.lib.pulling.util.ServiceConnector;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultServiceConnectorModule extends PrivateModule {

    public DefaultServiceConnectorModule(Configuration configuration) {
    }

    @Override
    protected void configure() {
        bind(ServiceConnector.class).to(DefaultServiceConnector.class);
        expose(ServiceConnector.class);
    }

    @Override
    public int hashCode() {
        return DefaultServiceConnectorModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultServiceConnectorModule.class.equals(obj.getClass());
    }


}
