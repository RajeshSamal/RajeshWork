package com.ntti3.billingmetering.lib.pulling.akka.actors.configs;

import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ServiceConnectingActorConfig {

    private static final String BUFFER_SIZE = "buffer-size";
    private final int bufferSize;

    public ServiceConnectingActorConfig(Configuration configuration) {
        this.bufferSize = ConfigurationHelper.safeGetInt(configuration, BUFFER_SIZE);
    }

    public ServiceConnectingActorConfig(int bufferSize) {
        this.bufferSize = bufferSize;
    }

    public int getBufferSize() {
        return bufferSize;
    }
}
