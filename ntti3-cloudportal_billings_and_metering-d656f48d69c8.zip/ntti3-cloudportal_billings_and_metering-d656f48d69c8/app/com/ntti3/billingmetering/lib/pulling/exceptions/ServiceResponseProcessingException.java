package com.ntti3.billingmetering.lib.pulling.exceptions;

import com.ntti3.billingmetering.lib.exceptions.BillingAndMeteringModuleException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseProcessingException extends BillingAndMeteringModuleException {
    public ServiceResponseProcessingException() {
        super();
    }

    public ServiceResponseProcessingException(String message) {
        super(message);
    }

    public ServiceResponseProcessingException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceResponseProcessingException(Throwable cause) {
        super(cause);
    }
}
