package com.ntti3.billingmetering.lib.pulling.exceptions;

import com.ntti3.billingmetering.lib.exceptions.BillingAndMeteringModuleException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseParsingException extends BillingAndMeteringModuleException {
    public ServiceResponseParsingException() {
        super();
    }

    public ServiceResponseParsingException(String message) {
        super(message);
    }

    public ServiceResponseParsingException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceResponseParsingException(Throwable cause) {
        super(cause);
    }


}
