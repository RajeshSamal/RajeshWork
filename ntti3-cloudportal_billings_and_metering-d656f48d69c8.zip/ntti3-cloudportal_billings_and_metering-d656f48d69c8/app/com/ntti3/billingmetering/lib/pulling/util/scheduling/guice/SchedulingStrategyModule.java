package com.ntti3.billingmetering.lib.pulling.util.scheduling.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Module;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SchedulingStrategyModule extends AbstractModule {

    private final Module schedulingModule;

    public SchedulingStrategyModule(Configuration configuration) {
        Boolean fastReschedule = configuration.getBoolean("fast-reschedule");
        if (fastReschedule != null && fastReschedule) {
            // fast reschedule
            int rescheduleAfter = ConfigurationHelper
                    .safeGetDuration(configuration, "reschedule-after")
                    .toStandardSeconds().getSeconds();
            schedulingModule = new FastSchedulingStrategyModule(rescheduleAfter);
        } else {
            // default scheduling
            int dayOfMonth = ConfigurationHelper.safeGetInt(configuration, "day-of-month");
            int hourOfDay = ConfigurationHelper.safeGetInt(configuration, "hour-of-day");
            schedulingModule = new DefaultSchedulingStrategyModule(dayOfMonth, hourOfDay);
        }
    }

    @Override
    protected void configure() {
        install(schedulingModule);
    }
}
