package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceConnectingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceConnectingActorConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceConnectingActorModule extends PrivateModule {

    private final ServiceConnectingActorConfig config;
    private final ActorSelection sendTo;

    public ServiceConnectingActorModule(ServiceConnectingActorConfig config,
                                        ActorSelection sendTo) {
        this.config = config;
        this.sendTo = sendTo;
    }

    public ServiceConnectingActorModule(Configuration configuration,
                                        ActorSelection sendTo) {
        this.config = new ServiceConnectingActorConfig(configuration);
        this.sendTo = sendTo;
    }

    @Override
    protected void configure() {
        bind(ServiceConnectingActorConfig.class).toInstance(config);
        bind(ActorSelection.class).toInstance(sendTo);
        bind(ServiceConnectingActor.class);
        expose(ServiceConnectingActor.class);
    }
}
