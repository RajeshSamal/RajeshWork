package com.ntti3.billingmetering.lib.pulling.guice;

import com.google.inject.AbstractModule;
import com.ntti3.billingmetering.lib.pulling.util.DefaultInfrastructureMapper;
import com.ntti3.billingmetering.lib.pulling.util.InfrastructureMapper;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultInfrastructureMapperModule extends AbstractModule {

    private DefaultInfrastructureMapper mapper;

    public DefaultInfrastructureMapperModule(Configuration configuration) {
        this.mapper = new DefaultInfrastructureMapper(configuration);
    }

    @Override
    protected void configure() {
        bind(InfrastructureMapper.class).toInstance(mapper);
    }
}
