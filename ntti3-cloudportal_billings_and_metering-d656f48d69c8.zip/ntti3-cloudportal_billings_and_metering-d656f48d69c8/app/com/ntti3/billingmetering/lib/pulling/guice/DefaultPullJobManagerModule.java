package com.ntti3.billingmetering.lib.pulling.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.DefaultPullJobManager;
import com.ntti3.billingmetering.lib.pulling.PullJobManager;
import com.ntti3.billingmetering.lib.pulling.util.PullJobManagerConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultPullJobManagerModule extends PrivateModule {

    private final PullJobManagerConfig config;

    public DefaultPullJobManagerModule(Configuration configuration) {
        config = new PullJobManagerConfig(configuration);
    }

    @Override
    protected void configure() {
        bind(PullJobManagerConfig.class).toInstance(config);
        bind(PullJobManager.class).to(DefaultPullJobManager.class);
        expose(PullJobManager.class);
    }
}
