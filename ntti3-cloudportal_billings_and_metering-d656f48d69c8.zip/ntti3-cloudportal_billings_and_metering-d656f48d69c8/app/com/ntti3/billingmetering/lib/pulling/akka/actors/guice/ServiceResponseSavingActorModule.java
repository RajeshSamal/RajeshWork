package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceResponseSavingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseSavingActorConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseSavingActorModule extends PrivateModule {

    private final ServiceResponseSavingActorConfig config;
    private final ActorSelection monitoringActors;

    public ServiceResponseSavingActorModule(Configuration configuration, ActorSelection monitoringActors) {
        this.config = new ServiceResponseSavingActorConfig(configuration);
        this.monitoringActors = monitoringActors;
    }

    public ServiceResponseSavingActorModule(ServiceResponseSavingActorConfig config, ActorSelection monitoringActors) {
        this.config = config;
        this.monitoringActors = monitoringActors;
    }

    @Override
    protected void configure() {
        bind(ServiceResponseSavingActorConfig.class).toInstance(config);
        bind(ActorSelection.class).toInstance(monitoringActors);
        bind(ServiceResponseSavingActor.class);
        expose(ServiceResponseSavingActor.class);
    }
}
