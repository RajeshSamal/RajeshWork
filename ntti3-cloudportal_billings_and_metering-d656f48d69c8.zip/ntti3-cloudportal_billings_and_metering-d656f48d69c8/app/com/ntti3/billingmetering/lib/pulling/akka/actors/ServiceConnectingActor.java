package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSelection;
import akka.actor.UntypedActor;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.PullJobDetails;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceConnectingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobOrder;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ServiceResponse;
import com.ntti3.billingmetering.lib.pulling.exceptions.ServiceResponseParsingException;
import com.ntti3.billingmetering.lib.pulling.util.DefaultServiceResponseParser;
import com.ntti3.billingmetering.lib.pulling.util.MessageInfoGenerator;
import com.ntti3.billingmetering.lib.pulling.util.PullJobConfig;
import com.ntti3.billingmetering.lib.pulling.util.ServiceConnector;
import com.ntti3.billingmetering.lib.pulling.util.ServiceResponseParser;
import com.ntti3.billingmetering.lib.pulling.util.ServiceResponseRecord;
import com.ntti3.billingmetering.lib.pulling.util.SocketFactoryCreator;
import play.Logger;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceConnectingActor extends UntypedActor {

    private final ServiceConnector serviceConnector;
    private final ActorSelection processingActors;
    private final MessageInfoGenerator messageInfoGenerator;
    private ServiceConnectingActorConfig config;
    private ServiceResponseParser parser;
    private Set<ServiceResponseRecord> records;
    private JobOrder order;
    private SocketFactoryCreator socketFactoryCreator;

    @Inject
    public ServiceConnectingActor(ServiceConnector serviceConnector,
                                  ServiceConnectingActorConfig config,
                                  SocketFactoryCreator socketFactoryCreator,
                                  ActorSelection processingActors) {
        this.serviceConnector = serviceConnector;
        this.processingActors = processingActors;
        this.config = config;
        this.messageInfoGenerator = new MessageInfoGenerator();
        this.parser = new DefaultServiceResponseParser();
        this.socketFactoryCreator = socketFactoryCreator;

        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(serviceConnector);
        Preconditions.checkNotNull(processingActors);
        Preconditions.checkNotNull(config);
        Preconditions.checkNotNull(socketFactoryCreator);
    }

    @Override
    public void onReceive(Object o) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException,
            IOException, KeyManagementException, KeyStoreException, ServiceResponseParsingException {
        if (o instanceof JobOrder) {
            order = (JobOrder) o;
            processJob();
        } else {
            unhandled(o);
        }
    }

    private void processJob() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException,
            IOException, KeyManagementException, KeyStoreException, ServiceResponseParsingException {
        InputStream serviceStream = null;
        try {
            serviceStream = connectToService(order.getPullJobDetails());
            messageInfoGenerator.reset(order.getProcessUid());
            records = Sets.newHashSet();
            parser.startProcessing(serviceStream, order.getPullJobDetails().getPullJobConfig().getSchemaHelper());
            processServiceStream();
        } finally {
            silentClose(serviceStream);
            serviceConnector.releaseConnection();
        }
    }

    private static void silentClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                Logger.error("Could not close:" + closeable, e);
            }
        }
    }

    private void processServiceStream() throws ServiceResponseParsingException {
        Optional<ServiceResponseRecord> optionalRecord = parser.readServiceResponseRecord();

        if (!optionalRecord.isPresent()) {
            checkSend(true);
        }

        while (optionalRecord.isPresent()) {
            records.add(optionalRecord.get());
            optionalRecord = parser.readServiceResponseRecord();
            checkSend(!optionalRecord.isPresent());
        }
    }

    private void checkSend(boolean last) {
        if (records.size() >= config.getBufferSize() || last) {
            ServiceResponse serviceResponse = new ServiceResponse(records,
                    order.getPullJobDetails().getServiceUid(), messageInfoGenerator.generate(last));
            processingActors.tell(serviceResponse, getSelf());
            records.clear();
        }
    }

    private InputStream connectToService(PullJobDetails pullJobDetails) throws CertificateException, IOException,
            UnrecoverableKeyException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException {

        PullJobConfig pullJobConfig = pullJobDetails.getPullJobConfig();
        return serviceConnector.connect(
                pullJobConfig.getRemoteAddress(),
                socketFactoryCreator.getFactoryFor(pullJobConfig.getServiceUid().toString()),
                pullJobConfig.getSchemaHelper().getQuery(pullJobDetails.getFromDate(), pullJobDetails.getToDate())
        );
    }
}
