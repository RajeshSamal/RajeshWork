package com.ntti3.billingmetering.lib.pulling.util;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.concurrent.Immutable;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class ServiceResponseRecord implements Serializable {

    @JsonIgnore
    private final String transactionId;
    @JsonIgnore
    private final UUID userGuid;
    @JsonIgnore
    private final String serviceOpcoUid;
    @JsonIgnore
    private final String infrastructureId;
    @JsonIgnore
    private final String description;
    @JsonIgnore
    private final Date billDate;
    @JsonIgnore
    private final BigDecimal cost;
    @JsonIgnore
    private final String currency;
    @JsonIgnore
    private final String itemType;
    @JsonIgnore
    private final JsonNode details;

    protected ServiceResponseRecord(String transactionId, UUID userGuid, String serviceOpcoUid, String infrastructureId, String description, Date billDate, BigDecimal cost, String currency, String itemType, JsonNode details) {
        this.transactionId = transactionId;
        this.userGuid = userGuid;
        this.serviceOpcoUid = serviceOpcoUid;
        this.infrastructureId = infrastructureId;
        this.description = description;
        this.billDate = billDate;
        this.cost = cost;
        this.currency = currency;
        this.itemType = itemType;
        this.details = details;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public UUID getUserGuid() {
        return userGuid;
    }

    public String getDescription() {
        return description;
    }

    public Date getBillDate() {
        return billDate;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public String getCurrency() {
        return currency;
    }

    public String getInfrastructureId() {
        return infrastructureId;
    }

    public String getServiceOpcoUid() {
        return serviceOpcoUid;
    }

    public String getItemType() {
        return itemType;
    }

    public JsonNode getDetails() {
        return details;
    }

    /**
     * Checks validity in context of later processing. Service can serve records without information about
     * the user or cloud. In that case we want to filter these out. We could skip it if the services served
     * correct data.
     *
     * @return
     */
    public boolean isValid() {
        if (getTransactionId() == null) return false;
        if (getUserGuid() == null) return false;
        if (getDescription() == null) return false;
        if (getBillDate() == null) return false;
        if (getCost() == null) return false;
        if (getCurrency() == null) return false;
        if ((getInfrastructureId() == null && getServiceOpcoUid() == null)
                || (getInfrastructureId() != null && getServiceOpcoUid() != null)) return false;
        if (getItemType() == null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = transactionId != null ? transactionId.hashCode() : 0;
        result = 31 * result + (userGuid != null ? userGuid.hashCode() : 0);
        result = 31 * result + (infrastructureId != null ? infrastructureId.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (billDate != null ? billDate.hashCode() : 0);
        result = 31 * result + (cost != null ? cost.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (itemType != null ? itemType.hashCode() : 0);
        result = 31 * result + (details != null ? details.hashCode() : 0);
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceResponseRecord that = (ServiceResponseRecord) o;

        if (billDate != null ? !billDate.equals(that.billDate) : that.billDate != null) return false;
        if (cost != null ? !cost.equals(that.cost) : that.cost != null) return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (details != null ? !details.equals(that.details) : that.details != null) return false;
        if (infrastructureId != null ? !infrastructureId.equals(that.infrastructureId) : that.infrastructureId != null)
            return false;
        if (itemType != null ? !itemType.equals(that.itemType) : that.itemType != null) return false;
        if (transactionId != null ? !transactionId.equals(that.transactionId) : that.transactionId != null)
            return false;
        return !(userGuid != null ? !userGuid.equals(that.userGuid) : that.userGuid != null);
    }

    @Override
    public String toString() {
        return "ServiceResponseRecord{" +
                "transactionId='" + transactionId + '\'' +
                ", userGuid=" + userGuid +
                ", infrastructureId='" + infrastructureId + '\'' +
                ", description='" + description + '\'' +
                ", billDate='" + billDate + '\'' +
                ", cost=" + cost +
                ", currency='" + currency + '\'' +
                ", itemType='" + itemType + '\'' +
                ", details='" + details + '\'' +
                '}';
    }
}
