package com.ntti3.billingmetering.lib.pulling.util.scheduling;

import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.guice.annotations.DayOfMonth;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.guice.annotations.HourOfDay;
import org.joda.time.DateTime;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultSchedulingStrategy implements SchedulingStrategy {

    private final int hourOfDay;
    private final int dayOfMonth;

    @Inject
    public DefaultSchedulingStrategy(@HourOfDay int hourOfDay, @DayOfMonth int dayOfMonth) {
        this.hourOfDay = hourOfDay;
        this.dayOfMonth = dayOfMonth;
    }

    @Override
    public DateTime getNextExecutionTime(DateTime lastExecutionTime) {
        return lastExecutionTime.plusMonths(1)
                .withDayOfMonth(dayOfMonth)
                .withMillisOfDay(0)
                .withHourOfDay(hourOfDay);
    }

    @Override
    public DateTime getFistExecutionTime() {
        return DateTime.now()
                .plusMonths(1)
                .withDayOfMonth(dayOfMonth)
                .withMillisOfDay(0)
                .withHourOfDay(hourOfDay);
    }
}
