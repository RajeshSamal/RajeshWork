package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSelection;
import akka.actor.UntypedActor;
import com.avaje.ebean.Ebean;
import com.avaje.ebean.ExpressionList;
import com.avaje.ebean.QueryIterator;
import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobEnded;
import com.ntti3.billingmetering.lib.pulling.akka.messages.SaveFailed;
import com.ntti3.billingmetering.lib.pulling.akka.messages.Saved;
import com.ntti3.billingmetering.models.UsageRecord;
import play.Logger;

import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobWatchingActor extends UntypedActor {

    private final ActorSelection pullJobSupervisor;

    @Inject
    public PullJobWatchingActor(ActorSelection pullJobSupervisor) {
        this.pullJobSupervisor = pullJobSupervisor;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(pullJobSupervisor);
    }

    @Override
    public void onReceive(Object o) {
        if (o instanceof Saved) {
            processSaved((Saved) o);
        }
        if (o instanceof SaveFailed) {
            processFailed((SaveFailed) o);
        } else {
            unhandled(o);
        }
    }

    private void processFailed(SaveFailed saveFailed) {
        UUID processUid = saveFailed.getProcessUid();
        tellSupervisor(JobEnded.withFailure(processUid));
    }

    private void processSaved(Saved saved) {
        UUID processUid = saved.getProcessUid();

        if (isSequenceFinished(processUid)) {
            tellSupervisor(JobEnded.withSuccess(processUid));
        }
    }

    private boolean isSequenceFinished(UUID processUid) {
        // Check if last sequence is saved
        UsageRecord lastRecord = getProcessRecords(processUid)
                .eq(UsageRecord.LAST_SEQUENCE, true)
                .setMaxRows(1)
                .findUnique();

        if (lastRecord == null) {
            return 0 == getProcessRecords(processUid).findRowCount();
        } else {
            int lastSequenceNumber = lastRecord.getSequenceNumber();

            // Check if all sequence number are in DB
            boolean[] sequenceNumberOccured = new boolean[lastSequenceNumber + 1];

            try (QueryIterator<UsageRecord> recordsIterator = getProcessRecords(processUid)
                    .findIterate()) {

                while (recordsIterator.hasNext()) {
                    int sequenceNumber = recordsIterator.next().getSequenceNumber();
                    if (sequenceNumber < 0 || sequenceNumber > lastSequenceNumber) {
                        Logger.warn("Got incorrect sequence number = {}! (last sequence number = {})",
                                sequenceNumber, lastSequenceNumber);
                        return false;
                    } else {
                        sequenceNumberOccured[sequenceNumber] = true;
                    }
                }
            }

            // all true?
            for (boolean occured : sequenceNumberOccured) if (!occured) return false;
            return true;
        }
    }

    private static ExpressionList<UsageRecord> getProcessRecords(UUID processUid) {
        return Ebean.find(UsageRecord.class)
                .select("sequenceNumber")
                .where()
                .eq(UsageRecord.PROCESS_COLUMN, processUid);
    }

    private void tellSupervisor(Object message) {
        pullJobSupervisor.tell(message, getSelf());
    }
}
