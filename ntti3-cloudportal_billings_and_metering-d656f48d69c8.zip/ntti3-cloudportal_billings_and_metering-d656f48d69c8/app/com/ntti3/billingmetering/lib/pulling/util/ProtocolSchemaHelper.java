package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.collect.Lists;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

import java.util.List;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public enum ProtocolSchemaHelper {
    AMA(AmaServiceResponseRecord.class, new QueryParametersHelper() {
        @Override
        public String getQuery(DateTime fromDate, DateTime toDate) {
            List<NameValuePair> nameValuePairs = Lists.newArrayListWithCapacity(3);
            nameValuePairs.add(new BasicNameValuePair("startTime", DateTimeFormat.forPattern(Constants.AMA_INPUT_DATE_FORMAT).print(fromDate)));
            nameValuePairs.add(new BasicNameValuePair("endTime", DateTimeFormat.forPattern(Constants.AMA_INPUT_DATE_FORMAT).print(toDate)));
            nameValuePairs.add(new BasicNameValuePair("cloudCostOnly", "true"));
            return URLEncodedUtils.format(nameValuePairs, Constants.ENCODING);
        }
    }, "billItemsDetails"),
    DEFAULT(DefaultServiceResponseRecord.class, new QueryParametersHelper() {
        @Override
        public String getQuery(DateTime fromDate, DateTime toDate) {
            List<NameValuePair> nameValuePairs = Lists.newArrayListWithCapacity(2);
            nameValuePairs.add(new BasicNameValuePair("from_date", DateTimeFormat.forPattern(Constants.DEFAULT_INPUT_DATE_FORMAT).print(fromDate)));
            nameValuePairs.add(new BasicNameValuePair("to_date", DateTimeFormat.forPattern(Constants.DEFAULT_INPUT_DATE_FORMAT).print(toDate)));
            return URLEncodedUtils.format(nameValuePairs, Constants.ENCODING);
        }
    }, "transactions");

    private final Class<? extends ServiceResponseRecord> recordClass;
    private final QueryParametersHelper helper;
    private final String transactionsArrayName;

    private ProtocolSchemaHelper(Class<? extends ServiceResponseRecord> recordClass, QueryParametersHelper helper, String transactionsArrayName) {
        this.recordClass = recordClass;
        this.helper = helper;
        this.transactionsArrayName = transactionsArrayName;
    }

    public String getQuery(DateTime fromDate, DateTime toDate) {
        return helper.getQuery(fromDate, toDate);
    }

    public Class<? extends ServiceResponseRecord> getResponseRecordClass() {
        return recordClass;
    }

    public String getTransactionsArrayName() {
        return transactionsArrayName;
    }

    public static ProtocolSchemaHelper forName(final String name) {
        return ProtocolSchemaHelper.valueOf(name);
    }

    private interface QueryParametersHelper {
        String getQuery(DateTime fromDate, DateTime toDate);
    }

    private static class Constants {
        private static final String AMA_INPUT_DATE_FORMAT = "d-MMM-y";
        private static final String ENCODING = "UTF-8";
        private static final String DEFAULT_INPUT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZZ";
    }
}
