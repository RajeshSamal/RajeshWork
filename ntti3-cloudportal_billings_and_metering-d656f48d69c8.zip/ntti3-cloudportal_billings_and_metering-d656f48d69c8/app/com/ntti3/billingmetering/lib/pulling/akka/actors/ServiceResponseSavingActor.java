package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSelection;
import akka.actor.Cancellable;
import akka.actor.UntypedActor;
import com.avaje.ebean.Ebean;
import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseSavingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ProcessedServiceResponse;
import com.ntti3.billingmetering.lib.pulling.akka.messages.SaveFailed;
import com.ntti3.billingmetering.lib.pulling.akka.messages.Saved;
import com.ntti3.billingmetering.models.UsageRecord;
import play.Logger;

import javax.persistence.PersistenceException;
import java.util.Collection;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseSavingActor extends UntypedActor {

    private static final String FLUSH_BUFFER = "tick";
    private final Collection<UsageRecord> bufferedRecords;
    private final Collection<UUID> bufferedProcessUids;
    private final ActorSelection monitoringActors;
    private final ServiceResponseSavingActorConfig config;
    private Cancellable scheduledClearing = null;

    @Inject
    public ServiceResponseSavingActor(ServiceResponseSavingActorConfig config, ActorSelection monitoringActors) {
        this.config = config;
        this.monitoringActors = monitoringActors;
        this.bufferedRecords = Sets.newHashSet();
        this.bufferedProcessUids = Sets.newHashSet();

        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(config);
        Preconditions.checkNotNull(monitoringActors);
    }

    @Override
    public void onReceive(Object o) {
        if (o instanceof ProcessedServiceResponse) {
            ProcessedServiceResponse processedServiceResponse = (ProcessedServiceResponse) o;
            addToBuffer(processedServiceResponse);
        } else if (o.equals(FLUSH_BUFFER)) {
            flushBuffer();
        } else {
            unhandled(o);
        }
    }

    private void flushBuffer() {
        try {
            Ebean.save(bufferedRecords);
            answerOk();
        } catch (PersistenceException e) {
            Logger.error("Could not save records!", e);
            answerFailure(e);
        }
        unscheduleBufferFlush();
        clearBuffer();
    }

    private void addToBuffer(ProcessedServiceResponse processedServiceResponse) {
        bufferedRecords.addAll(processedServiceResponse.getRecords());
        bufferedProcessUids.add(processedServiceResponse.getProcessUid());
        checkFlushBuffer();
    }

    private void checkFlushBuffer() {
        if (bufferedRecords.size() >= config.getBufferSize()) {
            flushBuffer();
        } else {
            scheduleBufferFlush();
        }
    }

    private void scheduleBufferFlush() {
        unscheduleBufferFlush();
        scheduledClearing = getContext().system().scheduler().schedule(
                config.getFlushBufferAfter(), config.getFlushBufferAfter(),
                getSelf(), FLUSH_BUFFER, getContext().dispatcher(), null);
    }

    private void unscheduleBufferFlush() {
        if (scheduledClearing != null) {
            scheduledClearing.cancel();
        }
    }

    private void clearBuffer() {
        bufferedProcessUids.clear();
        bufferedRecords.clear();
    }

    private void answerOk() {
        for (UUID processUid : bufferedProcessUids) {
            tellMonitoringActor(new Saved(processUid));
        }
    }

    private void answerFailure(Exception cause) {

        for (UUID processUid : bufferedProcessUids) {
            tellMonitoringActor(new SaveFailed(processUid, cause));
        }
    }

    private void tellMonitoringActor(Object message) {
        monitoringActors.tell(message, getSelf());
    }
}
