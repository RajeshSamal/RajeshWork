package com.ntti3.billingmetering.lib.pulling.akka.messages;

import com.google.common.collect.ImmutableSet;
import com.ntti3.billingmetering.models.UsageRecord;

import javax.annotation.concurrent.Immutable;
import java.util.Set;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ProcessedServiceResponse {

    private final Set<UsageRecord> records;
    private final UUID processUid;

    public ProcessedServiceResponse(Set<UsageRecord> records, UUID processUid) {
        this.records = ImmutableSet.copyOf(records);
        this.processUid = processUid;
    }

    public Set<UsageRecord> getRecords() {
        return records;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProcessedServiceResponse that = (ProcessedServiceResponse) o;

        if (processUid != null ? !processUid.equals(that.processUid) : that.processUid != null) return false;
        return !(records != null ? !records.equals(that.records) : that.records != null);
    }

    @Override
    public int hashCode() {
        int result = records != null ? records.hashCode() : 0;
        result = 31 * result + (processUid != null ? processUid.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ProcessedServiceResponse{" +
                "records=" + records +
                ", processUid=" + processUid +
                '}';
    }
}
