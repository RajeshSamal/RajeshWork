package com.ntti3.billingmetering.lib.pulling;

import com.google.common.base.Optional;
import org.joda.time.DateTime;

import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface PullJobManager {

    /**
     * Finds and returns a pending job. Takes into account current time.
     * Returns a job only if there is any to be done (when it's 'executeAt' passed,
     * if the job's status is 'pending' or when it's 'busyTo' passed if the job's
     * status is 'busy' or 'failed').
     * <p/>
     * Sets the returned job's status to 'busy' and updates 'busyTo' value (atomically).
     *
     * @return Optional<PullJobDetails> Optional PullJobDetails if there is a job to be processed or <code>Optional.absent()</code>
     */
    Optional<PullJobDetails> getJob();

    /**
     * Marks a pull-job as failed and deletes all temporary data created by a process.
     *
     * @param pullJobDetails Details of the failed job.
     * @param processUid     Unique identifier of the failed process.
     */
    void markJobFailed(PullJobDetails pullJobDetails, UUID processUid);

    /**
     * Marks a pull-job as done.
     *
     * @param pullJobDetails Details of the done job.
     * @param processUid     Unique identifier of the succeeded process.
     */
    void markJobDone(PullJobDetails pullJobDetails, UUID processUid);

    /**
     * Returns the time when getJob()'s returned value will change
     * (it depends on pending jobs' execution time or busy jobs' time out limit).
     *
     * @return DateTime when getJob() should be called.
     */
    Optional<DateTime> getNextJobTime();
}
