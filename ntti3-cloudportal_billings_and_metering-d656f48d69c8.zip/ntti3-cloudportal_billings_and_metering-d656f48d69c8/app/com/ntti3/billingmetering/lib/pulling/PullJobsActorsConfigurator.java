package com.ntti3.billingmetering.lib.pulling;

import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.actor.Props;
import akka.routing.SmallestMailboxRouter;
import com.google.inject.Injector;
import com.ntti3.billingmetering.lib.akka.actors.factories.PullJobActorFactory;
import com.ntti3.billingmetering.lib.pulling.akka.actors.PullJobSupervisor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.PullJobWatchingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceConnectingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceResponseProcessingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.ServiceResponseSavingActor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.guice.PullJobsModule;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;
import play.libs.Akka;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobsActorsConfigurator {

    private static final String PULL_JOB_SUPERVISOR_NAME = "pullJobSupervisor";
    private static final String WATCHING_ACTOR_NAME = "watchingActor";
    private static final String CONNECTING_ACTOR_NAME = "connectingActor";
    private static final String PROCESSING_ACTOR_NAME = "processingActor";
    private static final String SAVING_ACTOR_NAME = "savingActor";
    private final PullJobsModule guiceModule;
    private final int connectingActorsCount;
    private final int processingActorsCount;
    private final int savingActorsCount;
    private final int watchingActorsCount;

    public PullJobsActorsConfigurator(Configuration configuration) {
        ActorSelection pullJobSupervisorSelection = buildActorSelection(PULL_JOB_SUPERVISOR_NAME);
        ActorSelection pullJobWatchingActorSelection = buildActorSelection(WATCHING_ACTOR_NAME);
        ActorSelection serviceConnectingActorSelection = buildActorSelection(CONNECTING_ACTOR_NAME);
        ActorSelection serviceResponseProcessingActorSelection = buildActorSelection(PROCESSING_ACTOR_NAME);
        ActorSelection serviceResponseSavingActorSelection = buildActorSelection(SAVING_ACTOR_NAME);

        connectingActorsCount = ConfigurationHelper.safeGetInt(configuration, "connecting-actors");
        processingActorsCount = ConfigurationHelper.safeGetInt(configuration, "processing-actors");
        savingActorsCount = ConfigurationHelper.safeGetInt(configuration, "saving-actors");
        watchingActorsCount = ConfigurationHelper.safeGetInt(configuration, "watching-actors");

        guiceModule = new PullJobsModule(
                ConfigurationHelper.safeGetConfiguration(configuration, "supervisor"),
                serviceConnectingActorSelection,
                pullJobSupervisorSelection,
                ConfigurationHelper.safeGetConfiguration(configuration, "connecting-actor"),
                serviceResponseProcessingActorSelection,
                ConfigurationHelper.safeGetConfiguration(configuration, "processing-actor"),
                serviceResponseSavingActorSelection,
                ConfigurationHelper.safeGetConfiguration(configuration, "saving-actor"),
                pullJobWatchingActorSelection);
    }

    private static ActorSelection buildActorSelection(String actorName) {
        return Akka.system().actorSelection("/user/" + actorName);
    }

    public PullJobsModule getGuiceModule() {
        return guiceModule;
    }

    public ActorRef createSupervisorWithWorkers(Injector injector) {
        Props supervisorProps = Props.create(PullJobActorFactory.class, injector, PullJobSupervisor.class);
        Props watchingActorProps = Props.create(PullJobActorFactory.class, injector, PullJobWatchingActor.class);
        Props serviceConnectingActorProps = Props.create(PullJobActorFactory.class, injector, ServiceConnectingActor.class);
        Props serviceResponseProcessingActorProps = Props.create(PullJobActorFactory.class, injector, ServiceResponseProcessingActor.class);
        Props serviceResponseSavingActorProps = Props.create(PullJobActorFactory.class, injector, ServiceResponseSavingActor.class);

        // connecting actors
        Akka.system().actorOf(serviceConnectingActorProps
                .withRouter(new SmallestMailboxRouter(connectingActorsCount)), CONNECTING_ACTOR_NAME);
        // processing actors
        Akka.system().actorOf(serviceResponseProcessingActorProps
                .withRouter(new SmallestMailboxRouter(processingActorsCount)), PROCESSING_ACTOR_NAME);
        // saving actors
        Akka.system().actorOf(serviceResponseSavingActorProps
                .withRouter(new SmallestMailboxRouter(savingActorsCount)), SAVING_ACTOR_NAME);
        // watching actors
        Akka.system().actorOf(watchingActorProps
                .withRouter(new SmallestMailboxRouter(watchingActorsCount)), WATCHING_ACTOR_NAME);

        // supervisor
        return Akka.system().actorOf(supervisorProps, PULL_JOB_SUPERVISOR_NAME);
    }
}
