package com.ntti3.billingmetering.lib.pulling.util;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.pulling.exceptions.ServiceResponseParsingException;
import play.Logger;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultServiceResponseParser implements ServiceResponseParser {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final JsonFactory JSON_FACTORY = new JsonFactory();

    private JsonParser jsonParser;
    private boolean isStateOk;
    private ProtocolSchemaHelper schemaHelper;

    @Override
    public void startProcessing(InputStream serviceStream, ProtocolSchemaHelper schemaHelper) throws IOException, ServiceResponseParsingException {
        this.jsonParser = JSON_FACTORY.createParser(serviceStream);
        this.schemaHelper = Preconditions.checkNotNull(schemaHelper, "SchemaHelper can't be null");
        goToPullRecordsArray();
    }

    @Override
    public Optional<ServiceResponseRecord> readServiceResponseRecord() throws ServiceResponseParsingException {
        Optional<ServiceResponseRecord> optionalRecord;
        do {
            optionalRecord = readServiceResponseRecordRaw();
        } while (optionalRecord.isPresent() && !optionalRecord.get().isValid());

        return optionalRecord;
    }

    private Optional<ServiceResponseRecord> readServiceResponseRecordRaw() throws ServiceResponseParsingException {
        if (!isStateOk) {
            throw new IllegalStateException("Records array has finished or there was an exception already");
        }

        isStateOk = false;

        final JsonToken token;
        try {
            token = jsonParser.nextToken();
        } catch (IOException e) {
            throw new ServiceResponseParsingException("Could not get next token during ServiceResponseRecord read", e);
        }

        if (JsonToken.END_ARRAY.equals(token)) {
            Logger.debug("End of array");
            isStateOk = true;
            // There might be some data after the array but we just skip it.
            return Optional.absent();
        }

        try {
            if (JsonToken.START_OBJECT.equals(token)) {
                ServiceResponseRecord serviceResponseRecord
                        = OBJECT_MAPPER.readValue(jsonParser, schemaHelper.getResponseRecordClass());
                Logger.debug("ServiceResponseRecord: " + serviceResponseRecord.toString());
                isStateOk = true;
                return Optional.of(serviceResponseRecord);
            }
        } catch (JsonParseException e) {
            throw new ServiceResponseParsingException("Input stream is not a valid Json", e);
        } catch (JsonMappingException e) {
            throw new ServiceResponseParsingException("JsonMappingException during ServiceResponseRecord read", e);
        } catch (IOException e) {
            throw new ServiceResponseParsingException("IO exception during ServiceResponseRecord read", e);
        }

        throw new ServiceResponseParsingException("Unexpected token: " + token.toString());
    }

    private void goToPullRecordsArray() throws ServiceResponseParsingException {
        try {
            while (!jsonParser.isClosed()) {
                JsonToken token = jsonParser.nextToken();
                if (JsonToken.FIELD_NAME.equals(token)
                        && jsonParser.getCurrentName().equals(schemaHelper.getTransactionsArrayName())) {

                    token = jsonParser.nextToken();
                    if (JsonToken.START_ARRAY.equals(token)) {
                        Logger.debug("Found transactions array!");
                        isStateOk = true;
                        return;
                    }
                }
            }
        } catch (JsonParseException e) {
            throw new ServiceResponseParsingException("Could not find transactions array", e);
        } catch (IOException e) {
            throw new ServiceResponseParsingException("IO exception during transactions array search", e);
        }
    }
}
