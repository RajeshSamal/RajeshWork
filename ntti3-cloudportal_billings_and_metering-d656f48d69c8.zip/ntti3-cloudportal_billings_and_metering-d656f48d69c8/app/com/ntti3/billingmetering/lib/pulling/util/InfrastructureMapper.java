package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Optional;
import com.ntti3.billings.types.base.OpcoUid;

import javax.annotation.Nullable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface InfrastructureMapper {

    /**
     * Returns OpcoUid that corresponds with the infrastructureId
     *
     * @param infrastructureId String representation of unique identifier of the infrastructure.
     * @return OpcoUid that corresponds with the infrastructureId or Absent if infrastructureId is null or unknown.
     */
    Optional<OpcoUid> getOpcoUidFor(@Nullable String infrastructureId);
}
