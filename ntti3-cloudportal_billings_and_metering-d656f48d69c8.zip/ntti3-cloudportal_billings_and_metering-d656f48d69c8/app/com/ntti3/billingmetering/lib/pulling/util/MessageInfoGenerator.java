package com.ntti3.billingmetering.lib.pulling.util;

import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class MessageInfoGenerator {

    private volatile UUID processUid;
    private volatile int sequenceNumber;

    public MessageInfoGenerator() {
        reset();
    }

    public void reset(UUID processUid) {
        reset();
        this.processUid = processUid;
    }

    public void reset() {
        sequenceNumber = 0;
    }

    public MessageInfo generate(boolean last) {
        MessageInfo messageInfo = new MessageInfo(processUid, sequenceNumber++, last);
        if (last) {
            reset();
        }
        return messageInfo;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }
}
