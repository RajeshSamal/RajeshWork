package com.ntti3.billingmetering.lib.pulling.akka.messages;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet;
import com.ntti3.billingmetering.lib.pulling.util.MessageInfo;
import com.ntti3.billingmetering.lib.pulling.util.ServiceResponseRecord;
import com.ntti3.billings.types.base.ServiceUid;

import javax.annotation.concurrent.Immutable;
import java.util.Set;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ServiceResponse {

    private final Set<ServiceResponseRecord> records;
    private final ServiceUid serviceUid;
    private final MessageInfo messageInfo;

    public ServiceResponse(Set<ServiceResponseRecord> records, ServiceUid serviceUid, MessageInfo messageInfo) {
        Preconditions.checkNotNull(records, "records set can not be null");
        this.records = ImmutableSet.copyOf(records);
        this.serviceUid = serviceUid;
        this.messageInfo = messageInfo;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(serviceUid, "serviceUid can not be null");
        Preconditions.checkNotNull(messageInfo, "messageInfo can not be null");
    }

    public Set<ServiceResponseRecord> getRecords() {
        return records;
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public UUID getProcessUid() {
        return messageInfo.getProcessUid();
    }

    public int getSequenceNumber() {
        return messageInfo.getSequenceNumber();
    }

    public boolean isLast() {
        return messageInfo.isLast();
    }

    public MessageInfo getMessageInfo() {
        return messageInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceResponse that = (ServiceResponse) o;

        if (messageInfo != null ? !messageInfo.equals(that.messageInfo) : that.messageInfo != null) return false;
        if (records != null ? !records.equals(that.records) : that.records != null) return false;
        return serviceUid == that.serviceUid;
    }

    @Override
    public int hashCode() {
        int result = records != null ? records.hashCode() : 0;
        result = 31 * result + (serviceUid != null ? serviceUid.hashCode() : 0);
        result = 31 * result + (messageInfo != null ? messageInfo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ServiceResponse{" +
                "records=" + records +
                ", serviceUid=" + serviceUid +
                ", messageInfo=" + messageInfo +
                '}';
    }
}
