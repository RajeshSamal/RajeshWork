package com.ntti3.billingmetering.lib.pulling.guice;

import com.google.inject.AbstractModule;
import com.ntti3.billingmetering.lib.pulling.util.DefaultPullJobsConfigManager;
import com.ntti3.billingmetering.lib.pulling.util.PullJobsConfigManager;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultPullJobsConfigManagerModule extends AbstractModule {

    private final DefaultPullJobsConfigManager defaultPullJobsConfigManager;

    public DefaultPullJobsConfigManagerModule(Configuration configuration) {
        this.defaultPullJobsConfigManager = new DefaultPullJobsConfigManager(configuration);
    }

    @Override
    protected void configure() {
        bind(PullJobsConfigManager.class).toInstance(defaultPullJobsConfigManager);
    }
}
