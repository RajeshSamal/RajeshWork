package com.ntti3.billingmetering.lib.pulling.akka.messages;

import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class SaveFailed {

    private final UUID processUid;
    private final Exception cause;

    public SaveFailed(UUID processUid, Exception cause) {
        this.processUid = processUid;
        this.cause = cause;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    public Exception getCause() {
        return cause;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SaveFailed that = (SaveFailed) o;

        if (cause != null ? !cause.equals(that.cause) : that.cause != null) return false;
        return !(processUid != null ? !processUid.equals(that.processUid) : that.processUid != null);
    }

    @Override
    public int hashCode() {
        int result = processUid != null ? processUid.hashCode() : 0;
        result = 31 * result + (cause != null ? cause.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SaveFailed{" +
                "processUid=" + processUid +
                ", cause=" + cause +
                '}';
    }
}
