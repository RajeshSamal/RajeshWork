package com.ntti3.billingmetering.lib.pulling.akka.actors.configs;

import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;
import scala.concurrent.duration.FiniteDuration;

import javax.annotation.concurrent.Immutable;
import java.util.concurrent.TimeUnit;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ServiceResponseSavingActorConfig {

    public static final String BUFFER_SIZE = "buffer-size";
    public static final String FLUSH_BUFFER_AFTER = "flush-buffer-after";
    private final int bufferSize;
    private final FiniteDuration flushBufferAfter;

    public ServiceResponseSavingActorConfig(int bufferSize, FiniteDuration flushBufferAfter) {
        this.bufferSize = bufferSize;
        this.flushBufferAfter = flushBufferAfter;
        verify();
    }

    public ServiceResponseSavingActorConfig(Configuration configuration) {
        this.bufferSize = ConfigurationHelper.safeGetInt(configuration, BUFFER_SIZE);
        this.flushBufferAfter = FiniteDuration.create(ConfigurationHelper
                        .safeGetDuration(configuration, FLUSH_BUFFER_AFTER).getMillis(),
                TimeUnit.MILLISECONDS);
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(flushBufferAfter, "flushBufferAfter can not be null");
    }

    public int getBufferSize() {
        return bufferSize;
    }

    public FiniteDuration getFlushBufferAfter() {
        return flushBufferAfter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceResponseSavingActorConfig that = (ServiceResponseSavingActorConfig) o;

        if (bufferSize != that.bufferSize) return false;
        return !(flushBufferAfter != null ? !flushBufferAfter.equals(that.flushBufferAfter) : that.flushBufferAfter != null);
    }

    @Override
    public int hashCode() {
        int result = bufferSize;
        result = 31 * result + (flushBufferAfter != null ? flushBufferAfter.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ServiceResponseSavingActorConfig{" +
                "bufferSize=" + bufferSize +
                ", flushBufferAfter=" + flushBufferAfter +
                '}';
    }
}
