package com.ntti3.billingmetering.lib.pulling.util.scheduling;

import com.google.inject.Inject;
import org.joda.time.DateTime;
import org.joda.time.Duration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class FastSchedulingStrategy implements SchedulingStrategy {

    private final Duration duration;

    @Inject
    public FastSchedulingStrategy(Duration duration) {
        this.duration = duration;
    }

    @Override
    public DateTime getNextExecutionTime(DateTime lastExecutionTime) {
        return DateTime.now().plus(duration);
    }

    @Override
    public DateTime getFistExecutionTime() {
        return DateTime.now();
    }
}
