package com.ntti3.billingmetering.lib.pulling;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Expr;
import com.avaje.ebean.Query;
import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.Collections2;
import com.google.common.primitives.Ints;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.util.PullJobConfig;
import com.ntti3.billingmetering.lib.pulling.util.PullJobManagerConfig;
import com.ntti3.billingmetering.lib.pulling.util.PullJobsConfigManager;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.SchedulingStrategy;
import com.ntti3.billingmetering.models.NextPullJobTime;
import com.ntti3.billingmetering.models.PullJobRecord;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.Status;
import org.joda.time.DateTime;
import scala.concurrent.duration.FiniteDuration;

import javax.persistence.PersistenceException;
import java.util.Collection;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultPullJobManager implements PullJobManager {

    public static final String SUCCESS
            = "update UsageRecord set processUid = :newProcessUid where processUid = :processUid";
    public static final String DELETE_FAILED = "delete from UsageRecord where processUid = :processUid";
    private final SchedulingStrategy schedulingStrategy;
    private final PullJobsConfigManager pullJobsConfigManager;
    private final PullJobManagerConfig pullJobManagerConfig;

    @Inject
    public DefaultPullJobManager(SchedulingStrategy schedulingStrategy,
                                 PullJobManagerConfig pullJobManagerConfig,
                                 PullJobsConfigManager pullJobsConfigManager) {
        this.schedulingStrategy = schedulingStrategy;
        this.pullJobManagerConfig = pullJobManagerConfig;
        this.pullJobsConfigManager = pullJobsConfigManager;

        verify();
        scheduleJobsIfNone();
    }

    private void verify() {
        Preconditions.checkNotNull(schedulingStrategy);
        Preconditions.checkNotNull(pullJobManagerConfig);
        Preconditions.checkNotNull(pullJobsConfigManager);
    }

    @Override
    public void markJobFailed(PullJobDetails pullJobDetails, UUID processUid) {
        Ebean.beginTransaction();
        try {
            //mark failed
            Ebean.find(PullJobRecord.class)
                    .where()
                    .idEq(pullJobDetails.getPullJobId())
                    .findUnique()
                    .markFailed()
                    .update();

            // delete records from failed process
            Ebean.createUpdate(UsageRecord.class, DELETE_FAILED)
                    .setParameter("processUid", processUid)
                    .execute();

            Ebean.commitTransaction();
        } finally {
            Ebean.endTransaction();
        }
    }

    @Override
    public void markJobDone(PullJobDetails pullJobDetails, UUID processUid) {
        Ebean.beginTransaction();
        try {
            //mark done
            PullJobRecord record = Ebean.find(PullJobRecord.class)
                    .where()
                    .idEq(pullJobDetails.getPullJobId())
                    .findUnique();

            PullJobRecord nextRunRecord = PullJobRecord.builder()
                    .executeAt(schedulingStrategy.getNextExecutionTime(record.getExecuteAt()))
                    .targetService(record.getTargetService())
                    .build();

            record.markDone().update();
            nextRunRecord.save();

            // delete records from failed process
            Ebean.createUpdate(UsageRecord.class, SUCCESS)
                    .setParameter("processUid", processUid)
                    .setParameter("newProcessUid", null)
                    .execute();

            Ebean.commitTransaction();
        } finally {
            Ebean.endTransaction();
        }
    }

    @Override
    public Optional<PullJobDetails> getJob() {
        Ebean.beginTransaction();
        try {
            PullJobRecord record = findJob();
            if (record == null) {
                return Optional.absent();
            } else {
                PullJobRecord busyRecord = markBusyTo(record, pullJobManagerConfig.getPullJobTimeout());
                PullJobDetails details
                        = new PullJobDetails(busyRecord, pullJobsConfigManager.getConfig(record.getTargetService()));
                Ebean.commitTransaction();
                return Optional.of(details);
            }
        } finally {
            Ebean.endTransaction();
        }
    }

    private PullJobRecord markBusyTo(PullJobRecord record, FiniteDuration pullJobTimeout) {
        DateTime newBusyTo = DateTime.now().plusSeconds(Ints.checkedCast(pullJobTimeout.toSeconds()));
        PullJobRecord busyRecord = record.markBusyTo(newBusyTo);
        busyRecord.update();
        return busyRecord;
    }

    @Override
    public Optional<DateTime> getNextJobTime() {
        Query<NextPullJobTime> query = NextPullJobTime.getQuery();
        NextPullJobTime nextPullJobTime = query.findUnique();
        if (nextPullJobTime == null) {
            return Optional.absent();
        } else {
            return nextPullJobTime.getNextPullJobTime();
        }
    }

    PullJobRecord findJob() {
        DateTime now = DateTime.now();
        // Select the record that is either PENDING and EXECUTE_AT is in the past
        // OR busy/failed and BUSY_TO is in the past
        // Select the one that EXECUTE_AT or BUSY_TO is the oldest.
        try {
            return PullJobRecord.FIND.setForUpdate(true)
                    .where()
                    .or(Expr.and(
                                    Expr.eq(PullJobRecord.STATUS_COLUMN, Status.P),
                                    Expr.le(PullJobRecord.EXECUTE_AT_COLUMN, now)),
                            Expr.and(
                                    Expr.or(
                                            Expr.eq(PullJobRecord.STATUS_COLUMN, Status.B),
                                            Expr.eq(PullJobRecord.STATUS_COLUMN, Status.F)),
                                    Expr.le(PullJobRecord.BUSY_TO, now)))
                    .orderBy().asc(PullJobRecord.EXECUTE_AT_COLUMN)
                    .orderBy().asc(PullJobRecord.BUSY_TO)
                    .orderBy().asc(PullJobRecord.ID_COLUMN)
                    .setMaxRows(1)
                    .findUnique();
        } catch (PersistenceException e) {
            return null;
        }
    }

    private void scheduleJobsIfNone() {
        Ebean.beginTransaction();
        try {
            int scheduledJobs = PullJobRecord.FIND.setForUpdate(true).findRowCount();
            if (scheduledJobs == 0) {
                Collection<PullJobRecord> jobs = Collections2.transform(pullJobsConfigManager.getAllConfigs(),
                        new Function<PullJobConfig, PullJobRecord>() {
                            @Override
                            public PullJobRecord apply(PullJobConfig input) {
                                return PullJobRecord.builder()
                                        .executeAt(schedulingStrategy.getFistExecutionTime())
                                        .targetService(input.getServiceUid())
                                        .build();
                            }
                        });
                Ebean.save(jobs);
                Ebean.commitTransaction();
            }
        } finally {
            Ebean.endTransaction();
        }
    }
}
