package com.ntti3.billingmetering.lib.pulling.akka.messages;

import javax.annotation.concurrent.Immutable;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class JobTimeout {

    private final UUID processUid;

    public JobTimeout(UUID processUid) {
        this.processUid = processUid;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    @Override
    public String toString() {
        return "JobTimeout{" +
                "processUid=" + processUid +
                '}';
    }
}
