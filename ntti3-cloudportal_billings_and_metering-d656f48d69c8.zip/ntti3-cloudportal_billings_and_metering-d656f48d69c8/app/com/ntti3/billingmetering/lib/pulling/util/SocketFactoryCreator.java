package com.ntti3.billingmetering.lib.pulling.util;

import org.apache.http.conn.scheme.SchemeSocketFactory;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */
public interface SocketFactoryCreator {
    public SchemeSocketFactory getFactoryFor(String name);
}
