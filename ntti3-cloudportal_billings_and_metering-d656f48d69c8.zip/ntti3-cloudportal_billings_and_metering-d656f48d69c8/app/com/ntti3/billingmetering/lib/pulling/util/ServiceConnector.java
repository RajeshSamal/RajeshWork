package com.ntti3.billingmetering.lib.pulling.util;

import org.apache.http.conn.scheme.SchemeSocketFactory;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface ServiceConnector {

    /**
     * Connects to a service and requests billing and metering data.
     * After each <code>connect()</code> <code>releaseConnection</code> must be called.
     *
     * @param httpAddress  HTTP address of the service.
     * @param keyFile      Path of a key file to be used for secure connection.
     * @param keyPassword  Password for the key file.
     * @param paramsString String containing request parameters
     * @return A stream with the requested billing and metering data.
     * @throws IOException
     * @throws KeyStoreException
     * @throws CertificateException
     * @throws NoSuchAlgorithmException
     * @throws UnrecoverableKeyException
     * @throws KeyManagementException
     */
    InputStream connect(@Nonnull String httpAddress, @Nonnull SchemeSocketFactory socketFactory,
                        @Nonnull String paramsString)
            throws IOException, KeyStoreException, CertificateException,
            NoSuchAlgorithmException, UnrecoverableKeyException, KeyManagementException;

    /**
     * Aborts the connection.
     */
    void abort();

    /**
     * Gracefully release the connection.
     */
    void releaseConnection();
}
