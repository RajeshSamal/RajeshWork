package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSelection;
import akka.actor.UntypedActor;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseProcessingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ProcessedServiceResponse;
import com.ntti3.billingmetering.lib.pulling.akka.messages.ServiceResponse;
import com.ntti3.billingmetering.lib.pulling.exceptions.ServiceResponseProcessingException;
import com.ntti3.billingmetering.lib.pulling.exceptions.UnknownInfrastructureId;
import com.ntti3.billingmetering.lib.pulling.util.InfrastructureMapper;
import com.ntti3.billingmetering.lib.pulling.util.MessageInfo;
import com.ntti3.billingmetering.lib.pulling.util.ServiceResponseRecord;
import com.ntti3.billingmetering.lib.utils.UsageUidGenerator;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.gums.GumsConnector;
import com.ntti3.gums.GumsProtocolException;
import com.ntti3.gums.models.User;
import play.Logger;

import java.io.IOException;
import java.sql.Date;
import java.util.Set;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class ServiceResponseProcessingActor extends UntypedActor {

    private final GumsConnector gumsConnector;
    private final UsageUidGenerator usageUidGenerator;
    private final InfrastructureMapper infrastructureMapper;
    private final ServiceResponseProcessingActorConfig config;
    private final ActorSelection sendToActors;

    @Inject
    public ServiceResponseProcessingActor(GumsConnector gumsConnector,
                                          UsageUidGenerator usageUidGenerator,
                                          InfrastructureMapper infrastructureMapper,
                                          ServiceResponseProcessingActorConfig config,
                                          ActorSelection sendToActors) {
        this.gumsConnector = gumsConnector;
        this.usageUidGenerator = usageUidGenerator;
        this.infrastructureMapper = infrastructureMapper;
        this.config = config;
        this.sendToActors = sendToActors;

        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(gumsConnector);
        Preconditions.checkNotNull(usageUidGenerator);
        Preconditions.checkNotNull(infrastructureMapper);
        Preconditions.checkNotNull(config);
        Preconditions.checkNotNull(sendToActors);
    }

    @Override
    public void onReceive(Object o) throws ServiceResponseProcessingException {
        if (o instanceof ServiceResponse) {
            ServiceResponse serviceResponse = (ServiceResponse) o;
            ProcessedServiceResponse processedServiceResponse;
            processedServiceResponse = process(serviceResponse);
            sendToActors.tell(processedServiceResponse, getSelf());
        } else {
            unhandled(o);
        }
    }

    private ProcessedServiceResponse process(ServiceResponse serviceResponse) throws ServiceResponseProcessingException {
        Set<UsageRecord> usageRecords = Sets.newHashSet();
        for (ServiceResponseRecord responseRecord : serviceResponse.getRecords()) {
            usageRecords.add(processRecord(responseRecord, serviceResponse.getServiceUid(), serviceResponse.getMessageInfo()));
        }
        return new ProcessedServiceResponse(usageRecords, serviceResponse.getProcessUid());
    }

    private UsageRecord processRecord(ServiceResponseRecord serviceResponseRecord, ServiceUid serviceUid, MessageInfo messageInfo) throws ServiceResponseProcessingException {
        final UUID userGuid = serviceResponseRecord.getUserGuid();
        final User user;
        try {
            user = gumsConnector.getUser(userGuid);
        } catch (IOException | GumsProtocolException e) {
            throw new ServiceResponseProcessingException(String.format("Can not get user with guid %s from gums", userGuid.toString()), e);
        }

        final Date billDate = new Date(serviceResponseRecord.getBillDate().getTime());
        Logger.debug("BillDate after parsing: " + billDate.toString());

        return UsageRecord.builder()
                // Attributes that can be read from serviceResponseRecord
                .usageUid(usageUidGenerator.generate())
                .internalTransactionId(InternalId.fromString(serviceResponseRecord.getTransactionId()))
                .description(serviceResponseRecord.getDescription())
                .billDate(billDate)
                .cost(serviceResponseRecord.getCost())
                .currency(Currency.fromString(serviceResponseRecord.getCurrency()))
                .serviceOpcoUid(getServiceOpcoUid(serviceResponseRecord))
                .details(serviceResponseRecord.getDetails())
                .userGuid(user.getGuid())
                .itemType(serviceResponseRecord.getItemType())
                        // Attributes that have to be read from GUMS
                .customerOpcoUid(OpcoUid.fromString(user.getOpcoUid()))
                .customerOpcoUserUid(OpcoUserUid.fromString(user.getOpcoUUid()))
                        // TODO Hardcoded
                .costType(CostType.UNPAID)
                        // Others
                .serviceUid(serviceUid)
                        // PullJob info
                .processUid(messageInfo.getProcessUid())
                .lastSequence(messageInfo.isLast())
                .sequenceNumber(messageInfo.getSequenceNumber())
                .build();
    }

    private OpcoUid getServiceOpcoUid(ServiceResponseRecord serviceResponseRecord) throws UnknownInfrastructureId {
        String infrastructureId = serviceResponseRecord.getInfrastructureId();
        if (serviceResponseRecord.getServiceOpcoUid() != null) {
            return OpcoUid.fromString(serviceResponseRecord.getServiceOpcoUid());
        } else {
            Optional<OpcoUid> opcoUidOptional = infrastructureMapper.getOpcoUidFor(infrastructureId);
            if (opcoUidOptional.isPresent()) {
                return opcoUidOptional.get();
            } else {
                throw new UnknownInfrastructureId(infrastructureId);
            }
        }
    }
}
