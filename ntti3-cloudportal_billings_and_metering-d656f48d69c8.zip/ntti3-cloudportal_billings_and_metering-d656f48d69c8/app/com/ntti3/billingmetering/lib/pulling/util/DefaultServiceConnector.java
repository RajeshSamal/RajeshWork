package com.ntti3.billingmetering.lib.pulling.util;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultServiceConnector implements ServiceConnector {

    private final HttpClient httpClient;
    private HttpGet httpGet;

    public DefaultServiceConnector() {
        this.httpClient = new DefaultHttpClient();
    }

    @Override
    public InputStream connect(String httpAddress, SchemeSocketFactory socketFactory, String paramsString)
            throws IOException, KeyStoreException, CertificateException, NoSuchAlgorithmException,
            UnrecoverableKeyException, KeyManagementException {

        final URL url = new URL(httpAddress);
        final String protocol = url.getProtocol();
        final int port = url.getPort();

        Scheme sch = new Scheme(protocol, port, socketFactory);
        httpClient.getConnectionManager().getSchemeRegistry().register(sch);


        httpGet = new HttpGet(httpAddress + "?" + paramsString);
        HttpResponse httpResponse = httpClient.execute(httpGet);
        HttpEntity httpEntity = httpResponse.getEntity();
        return httpEntity.getContent();
    }

    @Override
    public void abort() {
        if (httpGet != null) {
            httpGet.abort();
        }
    }

    @Override
    public void releaseConnection() {
        if (httpGet != null) {
            httpGet.releaseConnection();
        }
    }
}
