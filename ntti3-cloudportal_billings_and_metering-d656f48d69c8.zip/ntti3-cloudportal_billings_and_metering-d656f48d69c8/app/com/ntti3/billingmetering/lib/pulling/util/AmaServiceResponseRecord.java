package com.ntti3.billingmetering.lib.pulling.util;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.concurrent.Immutable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * @author Mateusz Piękos (mateusz.piekos@codilime.com)
 */
@Immutable
@JsonIgnoreProperties(ignoreUnknown = true)
public class AmaServiceResponseRecord extends ServiceResponseRecord {

    public final static String TRANSACTION_ID = "id";
    public final static String USER = "user";
    public final static String DESCRIPTION = "description";
    public final static String BILL_DATE = "timestamp";
    public final static String COST = "amount";
    public final static String CURRENCY = "currency";
    public final static String CLOUD = "cloud";
    public final static String ITEM_TYPE = "itemType";
    public final static String DETAILS = "details";
    private static final String DATE_FORMAT = "MM/dd/yyyy h:m:s a";

    public AmaServiceResponseRecord(String transactionId, UUID userGuid, String infrastructureId, String description, Date billDate, BigDecimal cost, String currency, String itemType, JsonNode details) {
        super(transactionId, userGuid, null, infrastructureId, description, billDate, cost, currency, itemType, details);
    }

    // Constructor for deserialization from Json
    @JsonCreator
    public AmaServiceResponseRecord(
            @JsonProperty(value = TRANSACTION_ID)
            String transactionId,

            @JsonProperty(value = USER)
            UserInResponseRecord userInResponseRecord,

            @JsonProperty(value = DESCRIPTION)
            String description,

            @JsonProperty(value = BILL_DATE)
            String billDate,

            @JsonProperty(value = COST)
            BigDecimal cost,

            @JsonProperty(value = CURRENCY)
            String currency,

            @JsonProperty(value = ITEM_TYPE)
            String itemType,

            @JsonProperty(value = DETAILS)
            JsonNode details,

            @JsonProperty(value = CLOUD)
            Cloud cloud) throws ParseException {
        super(transactionId, getGuid(userInResponseRecord), null, getInfrastructureId(cloud), description, new SimpleDateFormat(DATE_FORMAT).parse(billDate), cost, currency, itemType, details);
    }

    private static String getInfrastructureId(Cloud cloud) {
        String infrastructureId;
        if (cloud == null) {
            infrastructureId = null;
        } else {
            infrastructureId = cloud.infrastructureId;
        }
        return infrastructureId;
    }

    private static UUID getGuid(UserInResponseRecord userInResponseRecord) {
        UUID guid;
        if (userInResponseRecord == null) {
            guid = null;
        } else {
            UUID temporaryUserUid;
            try {
                temporaryUserUid = UUID.fromString(userInResponseRecord.userGuid);
            } catch (IllegalArgumentException | NullPointerException e) {
                temporaryUserUid = null;
            }
            guid = temporaryUserUid;
        }
        return guid;
    }


    @Immutable
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UserInResponseRecord {

        public static final String USER_GUID = "externalId";
        @JsonIgnore
        private final String userGuid;

        @JsonCreator
        public UserInResponseRecord(
                @JsonProperty(value = USER_GUID)
                String userGuid) {
            this.userGuid = userGuid;
        }
    }

    @Immutable
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Cloud {

        public static final String INFRASTRUCTURE_ID = "id";
        private final String infrastructureId;

        @JsonCreator
        public Cloud(
                @JsonProperty(value = INFRASTRUCTURE_ID)
                String infrastructureId) {
            this.infrastructureId = infrastructureId;
        }
    }
}
