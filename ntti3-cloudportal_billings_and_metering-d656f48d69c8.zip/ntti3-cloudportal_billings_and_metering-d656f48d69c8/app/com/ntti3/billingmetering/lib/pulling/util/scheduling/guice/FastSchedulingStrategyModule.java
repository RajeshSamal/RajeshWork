package com.ntti3.billingmetering.lib.pulling.util.scheduling.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.FastSchedulingStrategy;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.SchedulingStrategy;
import org.joda.time.Duration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class FastSchedulingStrategyModule extends PrivateModule {

    private final Duration duration;

    public FastSchedulingStrategyModule(long millis) {
        duration = new Duration(millis);
    }

    @Override
    protected void configure() {
        bind(Duration.class).toInstance(duration);
        bind(SchedulingStrategy.class).to(FastSchedulingStrategy.class);
        expose(SchedulingStrategy.class);
    }
}
