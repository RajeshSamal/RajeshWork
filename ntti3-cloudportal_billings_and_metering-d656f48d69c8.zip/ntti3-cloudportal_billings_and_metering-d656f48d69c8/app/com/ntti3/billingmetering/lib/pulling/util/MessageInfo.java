package com.ntti3.billingmetering.lib.pulling.util;

import javax.annotation.concurrent.Immutable;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class MessageInfo {

    private final UUID processUid;
    private final int sequenceNumber;
    private final boolean last;

    public MessageInfo(UUID processUid, int sequenceNumber, boolean last) {
        this.processUid = processUid;
        this.sequenceNumber = sequenceNumber;
        this.last = last;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public boolean isLast() {
        return last;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MessageInfo that = (MessageInfo) o;

        if (last != that.last) return false;
        if (sequenceNumber != that.sequenceNumber) return false;
        return !(processUid != null ? !processUid.equals(that.processUid) : that.processUid != null);

    }

    @Override
    public int hashCode() {
        int result = processUid != null ? processUid.hashCode() : 0;
        result = 31 * result + sequenceNumber;
        result = 31 * result + (last ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "MessageInfo{" +
                "processUid=" + processUid +
                ", sequenceNumber=" + sequenceNumber +
                ", last=" + last +
                '}';
    }
}
