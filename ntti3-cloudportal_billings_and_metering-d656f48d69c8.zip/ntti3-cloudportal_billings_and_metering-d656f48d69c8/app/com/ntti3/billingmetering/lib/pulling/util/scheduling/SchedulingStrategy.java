package com.ntti3.billingmetering.lib.pulling.util.scheduling;

import org.joda.time.DateTime;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface SchedulingStrategy {

    DateTime getNextExecutionTime(DateTime lastExecutionTime);

    DateTime getFistExecutionTime();
}
