package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Preconditions;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.CertPassword;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.CertPath;
import com.ntti3.billingmetering.lib.pulling.guice.annotations.SocketFactoryConfig;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.SchemeSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Mateusz Piękos (mateusz.piekos@codilime.com).
 */

public class DefaultSocketFactoryCreator implements SocketFactoryCreator {

    private static final String SOCKET_FACTORY_CONFIG = "socket-factory";
    private static final String KEY_FILE_PATH_CONFIG = "key-file-path";
    private static final String KEY_FILE_PASSWORD_CONFIG = "key-file-password";
    private static final String SOCKET_TYPE_CONFIG = "type";
    private final String certStorePath;
    private final String certStorePass;
    private final Map<String, SchemeSocketFactory> socketFactoryMap;

    @Inject
    DefaultSocketFactoryCreator(@CertPath String certStorePath,
                                @CertPassword String certStorePass,
                                @SocketFactoryConfig Map<String, Object> config) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, UnrecoverableKeyException {
        this.certStorePass = certStorePass;
        this.certStorePath = certStorePath;
        socketFactoryMap = new HashMap<>();
        Preconditions.checkNotNull(certStorePath, "Cert store path can't be null");
        Preconditions.checkNotNull(certStorePass, "Cert store pass can't be null");
        Preconditions.checkNotNull(config, "SocketFactory config can't be null");
        for (Map.Entry<String, Object> e : config.entrySet()) {
            if (e.getValue() instanceof Map) {
                Map<String, Object> entry = (Map) e.getValue();
                if (entry.containsKey(SOCKET_FACTORY_CONFIG)) {
                    socketFactoryMap.put(e.getKey(), buildConf((Map) entry.get(SOCKET_FACTORY_CONFIG)));
                }
            }
        }
    }

    interface Configure {
        SchemeSocketFactory getFactory(Map<String, String> configuration, String certStorePass, String certStorePath) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, UnrecoverableKeyException;
    }

    enum SocketType {
        SECURE(new Configure() {

            @Override
            public SchemeSocketFactory getFactory(Map<String, String> configuration, String certStorePass, String certStorePath) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, UnrecoverableKeyException {
                final KeyStore keyStore;
                final String keyPassword = configuration.get(KEY_FILE_PASSWORD_CONFIG);
                final String keyPath = configuration.get(KEY_FILE_PATH_CONFIG);
                KeyStore certStore = KeyStore.getInstance(KeyStore.getDefaultType());
                if (keyPath != null) {
                    keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                    Preconditions.checkNotNull(keyPassword, String.format("Key file path is set" +
                            " so key file password in PullJobConfig for service can not be null!"));

                    try (FileInputStream instream = new FileInputStream(keyPath)) {
                        keyStore.load(instream, keyPassword.toCharArray());
                    }
                } else {
                    keyStore = null;
                }

                try (FileInputStream instream = new FileInputStream(new File(certStorePath))) {
                    certStore.load(instream, certStorePass.toCharArray());
                }

                if (keyStore == null) {
                    return new SSLSocketFactory(certStore);
                } else {
                    return new SSLSocketFactory(keyStore, keyPassword, certStore);
                }
            }

        }), PLAIN(new Configure() {

            @Override
            public SchemeSocketFactory getFactory(Map<String, String> configuration, String certStorePass, String certStorePath) {
                return new PlainSocketFactory();
            }

        });

        final Configure configure;

        private SocketType(Configure configure) {
            this.configure = configure;
        }

        public SchemeSocketFactory getSocket(Map<String, String> value, String certStorePass, String certStorePath) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, UnrecoverableKeyException {
            return configure.getFactory(value, certStorePass, certStorePath);
        }
    }

    @Override
    public SchemeSocketFactory getFactoryFor(String name) {
        return socketFactoryMap.get(name);
    }

    private SchemeSocketFactory buildConf(Map<String, String> configuration) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, UnrecoverableKeyException {
        return SocketType.valueOf(configuration.get(SOCKET_TYPE_CONFIG)).getSocket(configuration, certStorePass, certStorePath);
    }
}
