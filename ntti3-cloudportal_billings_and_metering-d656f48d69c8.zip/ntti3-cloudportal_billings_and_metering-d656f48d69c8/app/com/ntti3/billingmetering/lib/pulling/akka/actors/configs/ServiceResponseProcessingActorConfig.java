package com.ntti3.billingmetering.lib.pulling.akka.actors.configs;

import com.google.common.base.Preconditions;
import play.Configuration;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class ServiceResponseProcessingActorConfig {

    private static final String DATE_FORMAT = "date-format";
    private final String dateFormat;

    public ServiceResponseProcessingActorConfig(Configuration configuration) {
        this.dateFormat = configuration.getString(DATE_FORMAT);
        verify();
    }

    public ServiceResponseProcessingActorConfig(String dateFormat) {
        this.dateFormat = dateFormat;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(dateFormat, "dateFormat can not be null");
    }

    public String getDateFormat() {
        return dateFormat;
    }
}
