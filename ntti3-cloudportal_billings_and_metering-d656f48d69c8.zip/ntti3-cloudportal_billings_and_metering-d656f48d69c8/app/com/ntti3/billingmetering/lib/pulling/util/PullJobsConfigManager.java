package com.ntti3.billingmetering.lib.pulling.util;

import com.ntti3.billings.types.base.ServiceUid;

import javax.annotation.Nonnull;
import java.util.Collection;

/**
 * Manages configs of pull-jobs. Pull-job of each service has its own configuration.
 *
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface PullJobsConfigManager {

    /**
     * Gets pull-job configuration of the specified service.
     *
     * @param serviceUid Unique identifier of the service.
     * @return Configuration for pull-job of specified service.
     */
    PullJobConfig getConfig(@Nonnull ServiceUid serviceUid);

    /**
     * Return a collection of all known pull-job configurations.
     *
     * @return A collection of all known pull-job configurations.
     */
    Collection<PullJobConfig> getAllConfigs();
}