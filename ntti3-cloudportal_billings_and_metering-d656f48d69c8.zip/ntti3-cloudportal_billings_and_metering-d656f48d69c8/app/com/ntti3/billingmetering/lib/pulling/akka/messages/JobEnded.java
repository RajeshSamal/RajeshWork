package com.ntti3.billingmetering.lib.pulling.akka.messages;

import javax.annotation.concurrent.Immutable;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class JobEnded {

    private final UUID processUid;
    private final boolean succeeded;

    public JobEnded(UUID processUid, boolean succeeded) {
        this.processUid = processUid;
        this.succeeded = succeeded;
    }

    public static JobEnded withSuccess(UUID processUid) {
        return new JobEnded(processUid, true);
    }

    public static JobEnded withFailure(UUID processUid) {
        return new JobEnded(processUid, false);
    }

    public UUID getProcessUid() {
        return processUid;
    }

    public boolean hasSucceeded() {
        return succeeded;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JobEnded jobEnded = (JobEnded) o;

        if (succeeded != jobEnded.succeeded) return false;
        return !(processUid != null ? !processUid.equals(jobEnded.processUid) : jobEnded.processUid != null);

    }

    @Override
    public int hashCode() {
        int result = processUid != null ? processUid.hashCode() : 0;
        result = 31 * result + (succeeded ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "JobEnded{" +
                "processUid=" + processUid +
                ", succeeded=" + succeeded +
                '}';
    }
}
