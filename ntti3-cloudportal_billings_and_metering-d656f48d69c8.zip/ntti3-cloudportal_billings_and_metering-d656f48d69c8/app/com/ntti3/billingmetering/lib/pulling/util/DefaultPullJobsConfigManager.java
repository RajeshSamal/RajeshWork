package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.collect.ImmutableMap;
import com.google.inject.Inject;
import com.ntti3.billings.types.base.ServiceUid;
import play.Configuration;

import java.util.Collection;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultPullJobsConfigManager implements PullJobsConfigManager {

    private final ImmutableMap<ServiceUid, PullJobConfig> servicesConfigurations;

    @Inject
    public DefaultPullJobsConfigManager(Configuration configuration) {
        ImmutableMap.Builder<ServiceUid, PullJobConfig> builder = ImmutableMap.builder();

        for (String serviceUidString : configuration.subKeys()) {
            final ServiceUid serviceUid = ServiceUid.fromString(serviceUidString);
            final Configuration serviceConfiguration = configuration.getConfig(serviceUidString);
            builder.put(serviceUid,
                    PullJobConfig.fromPlayConfiguration(serviceConfiguration, serviceUid));
        }
        servicesConfigurations = builder.build();
    }

    @Override
    public PullJobConfig getConfig(ServiceUid serviceUid) {
        return servicesConfigurations.get(serviceUid);
    }

    @Override
    public Collection<PullJobConfig> getAllConfigs() {
        return servicesConfigurations.values();
    }
}
