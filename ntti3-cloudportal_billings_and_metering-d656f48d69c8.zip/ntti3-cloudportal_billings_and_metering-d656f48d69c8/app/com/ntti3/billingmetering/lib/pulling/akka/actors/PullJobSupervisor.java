package com.ntti3.billingmetering.lib.pulling.akka.actors;

import akka.actor.ActorSelection;
import akka.actor.Cancellable;
import akka.actor.UntypedActor;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.ntti3.billingmetering.lib.pulling.PullJobDetails;
import com.ntti3.billingmetering.lib.pulling.PullJobManager;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.PullJobSupervisorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobEnded;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobOrder;
import com.ntti3.billingmetering.lib.pulling.akka.messages.JobTimeout;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import play.Logger;
import scala.concurrent.duration.FiniteDuration;

import java.util.UUID;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobSupervisor extends UntypedActor {

    private static final String TICK = "tick";
    private final PullJobManager pullJobManager;
    private final ConcurrentMap<UUID, PullJobDetails> runningJobs;
    private final ConcurrentMap<UUID, Cancellable> jobTimeouts;
    private final ActorSelection connectingActors;
    private final PullJobSupervisorConfig config;
    private Cancellable scheduledTicks;

    @Inject
    public PullJobSupervisor(PullJobManager pullJobManager, PullJobSupervisorConfig config, ActorSelection connectingActors) {
        this.pullJobManager = pullJobManager;
        this.runningJobs = Maps.newConcurrentMap();
        this.jobTimeouts = Maps.newConcurrentMap();
        this.config = config;
        this.connectingActors = connectingActors;

        verify();
        scheduleTicks();
    }

    private void verify() {
        Preconditions.checkNotNull(pullJobManager);
        Preconditions.checkNotNull(config);
        Preconditions.checkNotNull(connectingActors);
    }

    @Override
    public void onReceive(Object o) throws Exception {
        if (o.equals(TICK)) {
            getJob();
            scheduleTicks();
        } else if (o instanceof JobEnded) {
            JobEnded jobEnded = (JobEnded) o;
            Logger.info("Job ended: " + jobEnded);
            endJob(jobEnded.getProcessUid(), jobEnded.hasSucceeded());
            scheduleTicks();
        } else if (o instanceof JobTimeout) {
            JobTimeout jobTimeout = (JobTimeout) o;
            Logger.warn("Job timed out: " + jobTimeout);
            endJob(jobTimeout.getProcessUid(), false);
            scheduleTicks();
        } else {
            unhandled(o);
        }
    }

    private void endJob(UUID processUid, boolean withSuccess) {
        if (runningJobs.containsKey(processUid)) {
            cancelTimeout(processUid);
            if (withSuccess) {
                pullJobManager.markJobDone(runningJobs.get(processUid), processUid);
            } else {
                pullJobManager.markJobFailed(runningJobs.get(processUid), processUid);
            }
            runningJobs.remove(processUid);
        }
    }

    private void getJob() {
        // get job
        Optional<PullJobDetails> optionalJobDetails = pullJobManager.getJob();

        // delegate job if any
        if (optionalJobDetails.isPresent()) {
            delegateJob(optionalJobDetails.get());
        }
    }

    private void scheduleTicks() {
        if (scheduledTicks != null) {
            scheduledTicks.cancel();
        }
        final Optional<DateTime> optionalNextJobTime = pullJobManager.getNextJobTime();
        final FiniteDuration initialTickDelay;
        if (optionalNextJobTime.isPresent()) {
            final DateTime nextJob = optionalNextJobTime.get();
            final long waitDurationMillis = new Duration(DateTime.now(), nextJob).getMillis();
            final FiniteDuration waitDuration = FiniteDuration
                    .create(waitDurationMillis, TimeUnit.MILLISECONDS);
            if (waitDuration.lt(config.getSmallBackoff())) {
                initialTickDelay = config.getSmallBackoff();
            } else {
                initialTickDelay = waitDuration;
            }
        } else {
            initialTickDelay = config.getBigBackoff();
        }

        // schedule repeating ticks
        scheduledTicks = getContext().system().scheduler().schedule(initialTickDelay, config.getTickDuration(),
                getSelf(), TICK, getContext().system().dispatcher(), null);
    }

    private void delegateJob(PullJobDetails pullJobDetails) {
        UUID newProcessUid = UUID.randomUUID();
        JobOrder jobOrder = new JobOrder(newProcessUid, pullJobDetails);
        runningJobs.put(newProcessUid, pullJobDetails);
        connectingActors.tell(jobOrder, getSelf());
        scheduleTimeout(newProcessUid);
    }

    private void scheduleTimeout(UUID processUid) {
        jobTimeouts.put(processUid, getContext().system().scheduler().scheduleOnce(config.getPullJobTimeout(), getSelf(),
                new JobTimeout(processUid), getContext().system().dispatcher(), null));
    }

    private void cancelTimeout(UUID processUid) {
        if (jobTimeouts.containsKey(processUid)) {
            jobTimeouts.get(processUid).cancel();
            jobTimeouts.remove(processUid);
        }
    }

}
