package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.AbstractModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.PullJobSupervisorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceConnectingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseProcessingActorConfig;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.ServiceResponseSavingActorConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobsModule extends AbstractModule {

    private final PullJobSupervisorConfig pullJobSupervisorConfig;
    private final ActorSelection pullJobSupervisorSendTo;

    private final ActorSelection pullJobWatchingActorSendTo;

    private final ServiceConnectingActorConfig serviceConnectingActorConfig;
    private final ActorSelection serviceConnectingActorSendTo;

    private final ServiceResponseProcessingActorConfig serviceResponseProcessingActorConfig;
    private final ActorSelection serviceProcessingActorSendTo;

    private final ServiceResponseSavingActorConfig serviceResponseSavingActorConfig;
    private final ActorSelection serviceResponseSavingActorSendTo;

    public PullJobsModule(PullJobSupervisorConfig pullJobSupervisorConfig,
                          ActorSelection pullJobSupervisorSendTo,
                          ActorSelection pullJobWatchingActorSendTo,
                          ServiceConnectingActorConfig serviceConnectingActorConfig,
                          ActorSelection serviceConnectingActorSendTo,
                          ServiceResponseProcessingActorConfig serviceResponseProcessingActorConfig,
                          ActorSelection serviceProcessingActorSendTo,
                          ServiceResponseSavingActorConfig serviceResponseSavingActorConfig,
                          ActorSelection serviceResponseSavingActorSendTo) {
        this.pullJobSupervisorConfig = pullJobSupervisorConfig;
        this.pullJobSupervisorSendTo = pullJobSupervisorSendTo;
        this.pullJobWatchingActorSendTo = pullJobWatchingActorSendTo;
        this.serviceConnectingActorConfig = serviceConnectingActorConfig;
        this.serviceConnectingActorSendTo = serviceConnectingActorSendTo;
        this.serviceResponseProcessingActorConfig = serviceResponseProcessingActorConfig;
        this.serviceProcessingActorSendTo = serviceProcessingActorSendTo;
        this.serviceResponseSavingActorConfig = serviceResponseSavingActorConfig;
        this.serviceResponseSavingActorSendTo = serviceResponseSavingActorSendTo;
    }

    public PullJobsModule(Configuration pullJobSupervisorConfig,
                          ActorSelection pullJobSupervisorSendTo,
                          ActorSelection pullJobWatchingActorSendTo,
                          Configuration serviceConnectingActorConfig,
                          ActorSelection serviceConnectingActorSendTo,
                          Configuration serviceResponseProcessingActorConfig,
                          ActorSelection serviceProcessingActorSendTo,
                          Configuration serviceResponseSavingActorConfig,
                          ActorSelection serviceResponseSavingActorSendTo) {
        this.pullJobSupervisorConfig = new PullJobSupervisorConfig(pullJobSupervisorConfig);
        this.pullJobSupervisorSendTo = pullJobSupervisorSendTo;
        this.pullJobWatchingActorSendTo = pullJobWatchingActorSendTo;
        this.serviceConnectingActorConfig = new ServiceConnectingActorConfig(serviceConnectingActorConfig);
        this.serviceConnectingActorSendTo = serviceConnectingActorSendTo;
        this.serviceResponseProcessingActorConfig = new ServiceResponseProcessingActorConfig(serviceResponseProcessingActorConfig);
        this.serviceProcessingActorSendTo = serviceProcessingActorSendTo;
        this.serviceResponseSavingActorConfig = new ServiceResponseSavingActorConfig(serviceResponseSavingActorConfig);
        this.serviceResponseSavingActorSendTo = serviceResponseSavingActorSendTo;
    }

    @Override
    protected void configure() {
        install(new PullJobSupervisorModule(pullJobSupervisorConfig, pullJobSupervisorSendTo));
        install(new PullJobWatchingActorModule(pullJobWatchingActorSendTo));
        install(new ServiceConnectingActorModule(serviceConnectingActorConfig, serviceConnectingActorSendTo));
        install(new ServiceResponseProcessingActorModule(serviceResponseProcessingActorConfig, serviceProcessingActorSendTo));
        install(new ServiceResponseSavingActorModule(serviceResponseSavingActorConfig, serviceResponseSavingActorSendTo));
    }
}
