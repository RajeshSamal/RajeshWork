package com.ntti3.billingmetering.lib.pulling.akka.actors.configs;

import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import play.Configuration;
import scala.concurrent.duration.FiniteDuration;

import javax.annotation.concurrent.Immutable;
import java.util.concurrent.TimeUnit;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class PullJobSupervisorConfig {

    private static final String TICK_DURATION = "tick-duration";
    private static final String SMALL_BACKOFF = "small-backoff";
    private static final String BIG_BACKOFF = "big-backoff";
    private static final String PULL_JOB_TIMEOUT = "pull-job-timeout";
    private final FiniteDuration smallBackoff;
    private final FiniteDuration bigBackoff;
    private final FiniteDuration pullJobTimeout;
    private final FiniteDuration tickDuration;

    public PullJobSupervisorConfig(Configuration configuration) {
        this.tickDuration = FiniteDuration.create(ConfigurationHelper
                        .safeGetDuration(configuration, TICK_DURATION).getMillis(),
                TimeUnit.MILLISECONDS);
        this.smallBackoff = FiniteDuration.create(ConfigurationHelper
                        .safeGetDuration(configuration, SMALL_BACKOFF).getMillis(),
                TimeUnit.MILLISECONDS);
        this.bigBackoff = FiniteDuration.create(ConfigurationHelper
                        .safeGetDuration(configuration, BIG_BACKOFF).getMillis(),
                TimeUnit.MILLISECONDS);
        this.pullJobTimeout = FiniteDuration.create(ConfigurationHelper
                        .safeGetDuration(configuration, PULL_JOB_TIMEOUT).getMillis(),
                TimeUnit.MILLISECONDS);
    }

    public PullJobSupervisorConfig(FiniteDuration tickDuration,
                                   FiniteDuration smallBackoff,
                                   FiniteDuration bigBackoff,
                                   FiniteDuration pullJobTimeout) {
        this.tickDuration = tickDuration;
        this.smallBackoff = smallBackoff;
        this.bigBackoff = bigBackoff;
        this.pullJobTimeout = pullJobTimeout;
        verify();
    }

    private void verify() {
        checkNotNull(tickDuration, "tickDuration");
        checkNotNull(smallBackoff, "smallBackoff");
        checkNotNull(bigBackoff, "bigBackoff");
        checkNotNull(pullJobTimeout, "pullJobTimeout");
    }

    private void checkNotNull(Object o, String name) {
        Preconditions.checkNotNull(o, name + " can not be null");
    }

    public FiniteDuration getTickDuration() {
        return tickDuration;
    }

    public FiniteDuration getSmallBackoff() {
        return smallBackoff;
    }

    public FiniteDuration getBigBackoff() {
        return bigBackoff;
    }

    public FiniteDuration getPullJobTimeout() {
        return pullJobTimeout;
    }
}
