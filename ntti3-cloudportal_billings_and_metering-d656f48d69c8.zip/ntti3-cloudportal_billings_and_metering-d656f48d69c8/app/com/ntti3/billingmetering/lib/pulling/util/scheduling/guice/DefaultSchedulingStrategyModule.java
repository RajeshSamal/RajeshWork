package com.ntti3.billingmetering.lib.pulling.util.scheduling.guice;

import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.DefaultSchedulingStrategy;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.SchedulingStrategy;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.guice.annotations.DayOfMonth;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.guice.annotations.HourOfDay;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class DefaultSchedulingStrategyModule extends PrivateModule {

    private final int dayOfMonth;
    private final int hourOfDay;

    public DefaultSchedulingStrategyModule(int dayOfMonth, int hourOfDay) {
        this.dayOfMonth = dayOfMonth;
        this.hourOfDay = hourOfDay;
    }

    @Override
    protected void configure() {
        bind(int.class).annotatedWith(DayOfMonth.class).toInstance(dayOfMonth);
        bind(int.class).annotatedWith(HourOfDay.class).toInstance(hourOfDay);
        bind(SchedulingStrategy.class).to(DefaultSchedulingStrategy.class);
        expose(SchedulingStrategy.class);
    }
}
