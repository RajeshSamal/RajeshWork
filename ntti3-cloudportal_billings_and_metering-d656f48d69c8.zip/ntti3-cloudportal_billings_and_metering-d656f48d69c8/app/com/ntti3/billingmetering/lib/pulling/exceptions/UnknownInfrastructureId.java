package com.ntti3.billingmetering.lib.pulling.exceptions;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class UnknownInfrastructureId extends ServiceResponseProcessingException {

    public UnknownInfrastructureId(String instrastructureId) {
        super(String.format("Could not find mapping for id: %s", instrastructureId));
    }
}
