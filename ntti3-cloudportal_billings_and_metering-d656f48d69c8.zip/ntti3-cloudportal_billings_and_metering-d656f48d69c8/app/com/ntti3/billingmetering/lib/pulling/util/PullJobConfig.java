package com.ntti3.billingmetering.lib.pulling.util;

import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.ServiceUid;
import play.Configuration;

import javax.annotation.concurrent.Immutable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class PullJobConfig {

    private final ServiceUid serviceUid;
    private final String remoteAddress;
    private final ProtocolSchemaHelper schemaHelper;

    /**
     * Creates new PullJobConfig
     *
     * @param serviceUid      Unique identifier of the service that the data will be pulled from.
     * @param remoteAddress   HTTP(s) addres of the service.
     * @param keyFilePath     A path of a key file to be used for HTTPS authentication.
     * @param keyFilePassword Key's file password.
     */
    public PullJobConfig(ServiceUid serviceUid, String remoteAddress,
                         String apiSchema) {
        this.serviceUid = serviceUid;
        this.remoteAddress = remoteAddress;

        Preconditions.checkNotNull(serviceUid, "ServiceUid in PullJobConfig can not be null!");
        Preconditions.checkNotNull(remoteAddress,
                String.format("Remote address in PullJobConfig for %s can not be null!", serviceUid));
        Preconditions.checkNotNull(apiSchema,
                String.format("Api schema for %s can not be null!", serviceUid));

        schemaHelper = ProtocolSchemaHelper.forName(apiSchema);
    }

    public static PullJobConfig fromPlayConfiguration(Configuration configuration, ServiceUid serviceUid) {
        final String remoteAddress = configuration.getString("remote-address");
        final String apiSchema = configuration.getString("api-schema");

        return new PullJobConfig(
                serviceUid,
                remoteAddress,
                apiSchema
        );
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public String getRemoteAddress() {
        return remoteAddress;
    }

    public ProtocolSchemaHelper getSchemaHelper() {
        return schemaHelper;
    }
}
