package com.ntti3.billingmetering.lib.pulling.akka.messages;

import com.google.common.base.Preconditions;
import com.ntti3.billingmetering.lib.pulling.PullJobDetails;

import javax.annotation.concurrent.Immutable;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
public class JobOrder {

    private final UUID processUid;
    private final PullJobDetails pullJobDetails;

    public JobOrder(UUID processUid, PullJobDetails pullJobDetails) {
        this.processUid = processUid;
        this.pullJobDetails = pullJobDetails;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(processUid, "processUid can not be null");
        Preconditions.checkNotNull(pullJobDetails, "pullJobDetails can not be null");
    }

    public PullJobDetails getPullJobDetails() {
        return pullJobDetails;
    }

    public UUID getProcessUid() {
        return processUid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JobOrder jobOrder = (JobOrder) o;

        if (processUid != null ? !processUid.equals(jobOrder.processUid) : jobOrder.processUid != null) return false;
        return !(pullJobDetails != null ? !pullJobDetails.equals(jobOrder.pullJobDetails) : jobOrder.pullJobDetails != null);
    }

    @Override
    public int hashCode() {
        int result = processUid != null ? processUid.hashCode() : 0;
        result = 31 * result + (pullJobDetails != null ? pullJobDetails.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "JobOrder{" +
                "processUid=" + processUid +
                ", pullJobDetails=" + pullJobDetails +
                '}';
    }
}
