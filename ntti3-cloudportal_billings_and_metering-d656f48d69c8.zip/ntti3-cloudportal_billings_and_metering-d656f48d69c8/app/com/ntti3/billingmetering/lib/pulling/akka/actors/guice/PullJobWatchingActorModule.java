package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.PullJobWatchingActor;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobWatchingActorModule extends PrivateModule {

    private ActorSelection sendTo;

    public PullJobWatchingActorModule(ActorSelection sendTo) {
        this.sendTo = sendTo;
    }

    @Override
    protected void configure() {
        bind(ActorSelection.class).toInstance(sendTo);
        bind(PullJobWatchingActor.class);
        expose(PullJobWatchingActor.class);
    }
}
