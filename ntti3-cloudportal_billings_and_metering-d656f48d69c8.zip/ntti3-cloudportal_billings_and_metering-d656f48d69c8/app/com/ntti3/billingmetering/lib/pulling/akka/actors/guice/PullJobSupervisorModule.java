package com.ntti3.billingmetering.lib.pulling.akka.actors.guice;

import akka.actor.ActorSelection;
import com.google.inject.PrivateModule;
import com.ntti3.billingmetering.lib.pulling.akka.actors.PullJobSupervisor;
import com.ntti3.billingmetering.lib.pulling.akka.actors.configs.PullJobSupervisorConfig;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class PullJobSupervisorModule extends PrivateModule {

    private final PullJobSupervisorConfig config;
    private final ActorSelection connectingActor;

    public PullJobSupervisorModule(PullJobSupervisorConfig config, ActorSelection connectingActor) {
        this.config = config;
        this.connectingActor = connectingActor;
    }

    public PullJobSupervisorModule(Configuration configuration, ActorSelection connectingActor) {
        this.config = new PullJobSupervisorConfig(configuration);
        this.connectingActor = connectingActor;
    }

    @Override
    protected void configure() {
        bind(ActorSelection.class).toInstance(connectingActor);
        bind(PullJobSupervisorConfig.class).toInstance(config);
        bind(PullJobSupervisor.class);
        expose(PullJobSupervisor.class);
    }
}
