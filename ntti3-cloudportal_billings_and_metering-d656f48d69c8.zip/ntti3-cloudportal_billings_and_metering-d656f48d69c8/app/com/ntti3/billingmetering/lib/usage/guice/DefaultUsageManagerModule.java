package com.ntti3.billingmetering.lib.usage.guice;

import com.google.inject.AbstractModule;
import com.ntti3.billingmetering.lib.usage.DefaultUsageManager;
import com.ntti3.billingmetering.lib.usage.UsageManager;

/**
 * @author Tomasz Roda (tomasz.roda@codilime.com)
 */
public class DefaultUsageManagerModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(UsageManager.class).to(DefaultUsageManager.class);
    }

    @Override
    public int hashCode() {
        return DefaultUsageManagerModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUsageManagerModule.class.equals(obj.getClass());
    }
}
