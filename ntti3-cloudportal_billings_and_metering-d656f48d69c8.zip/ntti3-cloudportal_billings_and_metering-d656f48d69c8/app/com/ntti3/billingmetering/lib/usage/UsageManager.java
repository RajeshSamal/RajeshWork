package com.ntti3.billingmetering.lib.usage;

import com.avaje.ebean.QueryIterator;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageManager {
    /**
     * Returns {@link com.ntti3.billingmetering.models.UsageRecord}s describing all operations from the service
     * of the customers of the Operating Company from the specified month.
     *
     * @param customerOpcoUid Unique identifier of the Operating Company which customers have to
     *                        be included in the summary.
     * @param serviceUid      Unique identifier of the service which has to be included in the summary
     * @param yearAndMonth    Year and month of the {@link com.ntti3.billingmetering.models.UsageRecord}s to be included in the report.
     * @return QueryIterator with all appropriate usage records.
     */
    QueryIterator<UsageRecord> getCustomerSummary(OpcoUid customerOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth);

    /**
     * Returns {@link com.ntti3.billingmetering.models.UsageRecord}s describing all operations from the service
     * within the specified month of the Operating Company as a service provider.
     *
     * @param serviceOpcoUid Unique identifier of the Operating Company which is the service provider.
     * @param serviceUid     Unique identifier of the service which has to be included in the summary.
     * @param yearAndMonth   Year and month of the usage records to be included in the report.
     * @return QueryIterator with all appropriate usage records.
     */
    QueryIterator<UsageRecord> getServiceProviderSummary(OpcoUid serviceOpcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth);

    /**
     * Returns all {@link com.ntti3.billingmetering.models.UsageRecord}s for the specified service, year and month.
     *
     * @param serviceUid   Unique identifier of the service to be included in the summary.
     * @param yearAndMonth Year and month of the {@link com.ntti3.billingmetering.models.UsageRecord}s to be included in the report.
     * @return QueryIterator with all appropriate usage records.
     */
    QueryIterator<UsageRecord> getOverallSummary(ServiceUid serviceUid, YearAndMonth yearAndMonth);
}
