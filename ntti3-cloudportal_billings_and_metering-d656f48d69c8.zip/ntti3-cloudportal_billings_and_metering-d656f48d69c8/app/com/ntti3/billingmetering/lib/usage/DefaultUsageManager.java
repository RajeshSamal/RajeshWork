package com.ntti3.billingmetering.lib.usage;

import com.avaje.ebean.ExpressionList;
import com.avaje.ebean.QueryIterator;
import com.google.inject.Singleton;
import com.ntti3.billingmetering.models.UsageRecord;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class DefaultUsageManager implements UsageManager {

    // [first day of month, first day of next month)
    private static ExpressionList<UsageRecord> selectInMonth(ExpressionList<UsageRecord> expressionList,
                                                             YearAndMonth yearAndMonth) {
        return expressionList
                .ge(UsageRecord.BILL_DATE_COLUMN, firstMonthDay(yearAndMonth))
                .lt(UsageRecord.BILL_DATE_COLUMN, firstNextMonthDay(yearAndMonth));
    }

    private static DateTime firstMonthDay(YearAndMonth yearAndMonth) {
        return new DateTime(yearAndMonth.getYear(), yearAndMonth.getMonth(),
                1, 0, 0, 0, 0);
    }

    private static DateTime firstNextMonthDay(YearAndMonth yearAndMonth) {
        return firstMonthDay(yearAndMonth).plusMonths(1);
    }

    @Override
    public QueryIterator<UsageRecord> getCustomerSummary(OpcoUid customerOpcoUid,
                                                         ServiceUid serviceUid,
                                                         YearAndMonth yearAndMonth) {
        final String customerOpcoUidColumn = UsageRecord.CUSTOMER_OPCO_UID_COLUMN;
        final ExpressionList<UsageRecord> usageRecordsExpressionList
                = getOpcoSummary(customerOpcoUid, serviceUid, customerOpcoUidColumn);
        return selectInMonth(usageRecordsExpressionList, yearAndMonth).findIterate();
    }

    @Override
    public QueryIterator<UsageRecord> getServiceProviderSummary(OpcoUid serviceOpcoUid,
                                                                ServiceUid serviceUid,
                                                                YearAndMonth yearAndMonth) {
        final ExpressionList<UsageRecord> usageRecordsExpressionList
                = getOpcoSummary(serviceOpcoUid, serviceUid, UsageRecord.SERVICE_OPCO_UID_COLUMN);
        return selectInMonth(usageRecordsExpressionList, yearAndMonth).findIterate();
    }

    @Override
    public QueryIterator<UsageRecord> getOverallSummary(ServiceUid serviceUid, YearAndMonth yearAndMonth) {
        final ExpressionList<UsageRecord> usageRecordsExpressionList = getSummary(serviceUid);
        return selectInMonth(usageRecordsExpressionList, yearAndMonth).findIterate();
    }

    private ExpressionList<UsageRecord> getOpcoSummary(OpcoUid opcoUid, ServiceUid serviceUid, String opcoUidColumn) {
        return getSummary(serviceUid)
                .eq(opcoUidColumn, opcoUid.getValue());
    }

    private ExpressionList<UsageRecord> getSummary(ServiceUid serviceUid) {
        return UsageRecord.FIND.where()
                .eq(UsageRecord.SERVICE_UID_COLUMN, serviceUid)
                .isNull(UsageRecord.PROCESS_COLUMN);
    }
}
