package com.ntti3.billingmetering.lib.utils.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Scopes;
import com.ntti3.billingmetering.lib.utils.DefaultUsageUidGenerator;
import com.ntti3.billingmetering.lib.utils.UsageUidGenerator;

/**
 * @author Tomasz Roda (tomasz.roda@codilime.com)
 */
public class DefaultUtilsModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(UsageUidGenerator.class).to(DefaultUsageUidGenerator.class).in(Scopes.SINGLETON);
    }

    @Override
    public int hashCode() {
        return DefaultUtilsModule.class.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return DefaultUtilsModule.class.equals(obj.getClass());
    }
}
