package com.ntti3.billingmetering.lib.utils;

import com.ntti3.billings.types.base.UsageUid;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public interface UsageUidGenerator {

    UsageUid generate();
}
