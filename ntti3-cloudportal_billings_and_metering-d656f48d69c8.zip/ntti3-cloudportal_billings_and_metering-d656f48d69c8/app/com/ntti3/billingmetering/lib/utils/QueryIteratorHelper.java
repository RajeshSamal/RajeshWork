package com.ntti3.billingmetering.lib.utils;

import com.avaje.ebean.QueryIterator;
import com.google.common.collect.Sets;

import java.util.Set;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class QueryIteratorHelper {

    public static <T> Set<T> toSet(QueryIterator<T> queryIterator) {
        Set<T> set = Sets.newHashSet(queryIterator);
        queryIterator.close();
        return set;
    }
}
