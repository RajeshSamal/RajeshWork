package com.ntti3.billingmetering.lib.utils;

import com.google.inject.Singleton;
import com.ntti3.billings.types.base.UsageUid;
import org.joda.time.DateTime;
import play.Play;

import java.util.Random;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Singleton
public class DefaultUsageUidGenerator implements UsageUidGenerator {

    private final int COUNTER_LIMIT = 9999;
    private final long instanceId;
    private final String instanceIdHex;
    private final Random random;
    private int counter = 0;
    private DateTime lastCounterReset;

    public DefaultUsageUidGenerator() {
        instanceId = Play.application().configuration().getLong("instance-id");
        instanceIdHex = Long.toHexString(instanceId);
        lastCounterReset = DateTime.now();
        random = new Random(lastCounterReset.getMillis());
    }

    public synchronized UsageUid generate() {
        long lastCounterResetMillis = lastCounterReset.getMillis();
        int nextNumber = getNextNumber();
        int randomNumber = random.nextInt();

        String uidString = instanceIdHex
                + Integer.toHexString(nextNumber)
                + Long.toHexString(lastCounterResetMillis)
                + Integer.toHexString(randomNumber);

        return UsageUid.fromString(uidString);
    }

    private int getNextNumber() {
        int value = counter;
        counter++;

        if (counter > COUNTER_LIMIT) {
            counter = 0;
            lastCounterReset = DateTime.now();
        }

        return value;
    }
}
