package com.ntti3.billingmetering.lib.utils;

import com.google.common.base.Preconditions;
import org.joda.time.Duration;
import play.Configuration;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public final class ConfigurationHelper {

    private ConfigurationHelper() {

    }

    public static Duration safeGetDuration(Configuration configuration, String key) {
        try {
            return Duration.millis(configuration.getMilliseconds(key));
        } catch (Exception e) {
            throw configuration.reportError(key, String.format("Could not read duration at key '%s'!", key), e);
        }
    }

    public static int safeGetInt(Configuration configuration, String key) {
        try {
            Integer value = configuration.getInt(key);
            Preconditions.checkNotNull(value);
            return value;
        } catch (Exception e) {
            throw configuration.reportError(key, String.format("Could not read int at key '%s'!", key), e);
        }
    }

    public static boolean safeGetBoolean(Configuration configuration, String key) {
        try {
            Boolean value = configuration.getBoolean(key);
            Preconditions.checkNotNull(value);
            return value;
        } catch (Exception e) {
            throw configuration.reportError(key, String.format("Could not read boolean at key '%s'!", key), e);
        }
    }

    public static Configuration safeGetConfiguration(Configuration configuration, String key) {
        try {
            Configuration subConfiguration = configuration.getConfig(key);
            Preconditions.checkNotNull(subConfiguration);
            return subConfiguration;
        } catch (Exception e) {
            throw configuration.reportError(key, String.format("Could not read configuration at key '%s'!", key), e);
        }
    }
}
