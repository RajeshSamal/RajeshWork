package com.ntti3.billingmetering.aspects;


import com.ntti3.aspects.logging.PlayLoggingAspect;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import play.Logger;

@Aspect
public class LoggingAspect extends PlayLoggingAspect {

    @Override
    @Pointcut("execution(public * com.ntti3.billingmetering.controllers.*.*(..))")
    public void controllerMethodPointcut() {
    }

    @Pointcut("execution(public * com.ntti3.billingmetering.lib.pulling.akka.actors.*.*(..))")
    public void publicPointcut() {
    }

    @Pointcut("execution(protected * com.ntti3.billingmetering.lib.pulling.akka.actors.*.*(..))")
    public void protectedPointcut() {
    }

    @Pointcut("execution(private * com.ntti3.billingmetering.lib.pulling.akka.actors.*.*(..))")
    public void privatePointcut() {
    }

    @Pointcut("publicPointcut() || protectedPointcut() || privatePointcut()")
    public void actorsWorkingPointcut() {
    }

    @Before("actorsWorkingPointcut()")
    public void logBeforeActorsWorking(JoinPoint joinPoint) {
        Logger.trace("Called: {}", pointcutDescription(joinPoint));
    }

    @AfterReturning(pointcut = "actorsWorkingPointcut()",
            returning = "result")
    public void logAfterActorsWorking(JoinPoint joinPoint, Object result) {
        if (result == null) {
            Logger.trace("Actor returned: {} => {}",
                    pointcutDescription(joinPoint), "null");
        } else {
            final String resultClassName = result.getClass().getSimpleName();
            Logger.trace("Actor returned: {} => {}: {}",
                    pointcutDescription(joinPoint), resultClassName, result.toString());
        }
    }

    @AfterThrowing(pointcut = "actorsWorkingPointcut()", throwing = "ex")
    public void logAfterThrowingActorsWorking(JoinPoint joinPoint, Throwable ex) {
        Logger.error("Thrown from: {}", pointcutDescription(joinPoint), ex);
    }

    @Override
    @Pointcut("within(com.ntti3.billingmetering.lib..*)")
    public void applicationMethodPointcut() {

    }

    @Override
    public String getPathContains() {
        return "billingmetering";
    }
}
