package com.ntti3.billingmetering.models.converter;

import com.avaje.ebean.config.ScalarTypeConverter;
import com.fasterxml.jackson.databind.JsonNode;
import play.libs.Json;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class JsonNodeConverter implements ScalarTypeConverter<JsonNode, String> {

    @Override
    public JsonNode getNullValue() {
        return null;
    }

    @Override
    public JsonNode wrapValue(String scalarType) {
        return Json.parse(scalarType);
    }

    @Override
    public String unwrapValue(JsonNode beanType) {
        return Json.stringify(beanType);
    }
}
