package com.ntti3.billingmetering.models;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Query;
import com.avaje.ebean.RawSql;
import com.avaje.ebean.RawSqlBuilder;
import com.avaje.ebean.annotation.Sql;
import com.google.common.base.Optional;
import com.ntti3.billings.types.base.Status;
import org.joda.time.DateTime;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Entity;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Entity
@Sql
@Immutable
public class NextPullJobTime {

    private static final String STATUS_BUSY = Status.B.getTextRepresentation();
    private static final String STATUS_FAILED = Status.F.getTextRepresentation();
    private static final String STATUS_PENDING = Status.P.getTextRepresentation();
    private static final String RAW_SQL_STRING
            = "select pending.min_execute_at as executeAt, busyFailed.min_busy_to as busyTo from " +
            "(select min(busy_to) as min_busy_to from " + PullJobRecord.TABLE_NAME +
            " where status = '" + STATUS_BUSY + "' or status = '" + STATUS_FAILED + "') as busyFailed, " +
            "(select min(execute_at) as min_execute_at from " + PullJobRecord.TABLE_NAME +
            " where status = '" + STATUS_PENDING + "') as pending";
    private DateTime executeAt;
    private DateTime busyTo;

    public static Query<NextPullJobTime> getQuery() {
        RawSql rawSql = RawSqlBuilder.parse(RAW_SQL_STRING).create();
        Query<NextPullJobTime> query = Ebean.find(NextPullJobTime.class);
        query.setRawSql(rawSql);
        return query;
    }

    public Optional<DateTime> getNextPullJobTime() {
        return minDateTime(executeAt, busyTo);
    }

    private Optional<DateTime> minDateTime(DateTime d1, DateTime d2) {
        if (d1 == null && d2 == null) return Optional.absent();
        if (d1 == null) return Optional.of(d2);
        if (d2 == null) return Optional.of(d1);
        return Optional.of((d1.isBefore(d2)) ? d1 : d2);
    }
}
