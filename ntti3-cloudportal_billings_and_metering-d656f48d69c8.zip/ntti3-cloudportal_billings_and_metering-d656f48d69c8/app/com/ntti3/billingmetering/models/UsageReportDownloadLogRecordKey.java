package com.ntti3.billingmetering.models;

import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.YearAndMonth;
import play.data.validation.Constraints;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Immutable
@Embeddable
public class UsageReportDownloadLogRecordKey implements Serializable {

    // XXX: Ebean does not let to have Embedded field in an Embeddable class and this is a workaround for this.
    @Constraints.Required
    @Column(name = UsageReportDownloadLogRecord.OPCO_UID_COLUMN, length = OpcoUid.MAX_LENGTH)
    private final String opcoUidStringRepresentation;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = UsageReportDownloadLogRecord.SERVICE_UID_COLUMN, length = 16)
    private final ServiceUid serviceUid;

    @Constraints.Required
    @Column(name = UsageReportDownloadLogRecord.YEAR_COLUMN)
    private final Integer year;

    @Constraints.Required
    @Column(name = UsageReportDownloadLogRecord.MONTH_COLUMN)
    private final Integer month;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = UsageReportDownloadLogRecord.REPORT_TYPE_COLUMN, length = 16)
    private final ReportType reportType;

    private UsageReportDownloadLogRecordKey(OpcoUid opcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth, ReportType reportType) {
        this.year = yearAndMonth.getYear();
        this.month = yearAndMonth.getMonth();
        this.reportType = reportType;
        this.opcoUidStringRepresentation = opcoUid.toString();
        this.serviceUid = serviceUid;
        verify();
    }

    public static UsageReportDownloadLogRecordKey create(OpcoUid opcoUid, ServiceUid serviceUid, YearAndMonth yearAndMonth, ReportType reportType) {
        return new UsageReportDownloadLogRecordKey(opcoUid, serviceUid, yearAndMonth, reportType);
    }

    private void verify() {
        Preconditions.checkNotNull(opcoUidStringRepresentation);
        Preconditions.checkNotNull(serviceUid);
        Preconditions.checkNotNull(year);
        Preconditions.checkNotNull(month);
        Preconditions.checkNotNull(reportType);
    }

    public OpcoUid getOpcoUid() {
        return OpcoUid.fromString(opcoUidStringRepresentation);
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getMonth() {
        return month;
    }

    public ReportType getReportType() {
        return reportType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UsageReportDownloadLogRecordKey that = (UsageReportDownloadLogRecordKey) o;

        if (!month.equals(that.month)) return false;
        if (opcoUidStringRepresentation != null ? !opcoUidStringRepresentation.equals(that.opcoUidStringRepresentation) : that.opcoUidStringRepresentation != null)
            return false;
        if (reportType != that.reportType) return false;
        if (serviceUid != that.serviceUid) return false;
        return year.equals(that.year);
    }

    @Override
    public int hashCode() {
        int result = opcoUidStringRepresentation != null ? opcoUidStringRepresentation.hashCode() : 0;
        result = 31 * result + (serviceUid != null ? serviceUid.hashCode() : 0);
        result = 31 * result + year.hashCode();
        result = 31 * result + month.hashCode();
        result = 31 * result + (reportType != null ? reportType.hashCode() : 0);
        return result;
    }
}
