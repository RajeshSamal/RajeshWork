package com.ntti3.billingmetering.models;

import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.ReportType;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import com.ntti3.billings.types.base.YearAndMonth;
import org.joda.time.DateTime;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Entity
@Immutable
@Table(name = UsageReportDownloadLogRecord.TABLE_NAME)
public class UsageReportDownloadLogRecord extends Model implements Serializable {

    public final static String TABLE_NAME = "usage_reports_downloads";
    public final static String OPCO_UID_COLUMN = "opco_uid";
    public final static String SERVICE_UID_COLUMN = "service_uid";
    public final static String YEAR_COLUMN = "year";
    public final static String MONTH_COLUMN = "month";
    public final static String REPORT_TYPE_COLUMN = "report_type";
    public final static String DOWNLOAD_TIME_COLUMN = "download_time";
    public final static String STATUS = "status";

    public static class Builder {

        private OpcoUid opcoUid;
        private ServiceUid serviceUid;
        private YearAndMonth yearAndMonth;
        private ReportType reportType;
        private DateTime downloadTime;
        private Status status;

        public UsageReportDownloadLogRecord build() {
            return new UsageReportDownloadLogRecord(this);
        }

        public Builder fromOther(UsageReportDownloadLogRecord usageReportDownloadLogRecord) {
            this.opcoUid = usageReportDownloadLogRecord.getOpcoUid();
            this.serviceUid = usageReportDownloadLogRecord.getServiceUid();
            this.yearAndMonth = YearAndMonth.fromInts(usageReportDownloadLogRecord.getYear(), usageReportDownloadLogRecord.getMonth());
            this.downloadTime = usageReportDownloadLogRecord.downloadTime;
            this.reportType = usageReportDownloadLogRecord.getReportType();
            this.status = usageReportDownloadLogRecord.status;
            return this;
        }

        public Builder opcoUid(OpcoUid opcoUid) {
            this.opcoUid = opcoUid;
            return this;
        }

        public Builder serviceUid(ServiceUid serviceUid) {
            this.serviceUid = serviceUid;
            return this;
        }

        public Builder yearAndMonth(YearAndMonth yearAndMonth) {
            this.yearAndMonth = yearAndMonth;
            return this;
        }

        public Builder reportType(ReportType reportType) {
            this.reportType = reportType;
            return this;
        }

        public Builder downloadTime(DateTime downloadTime) {
            this.downloadTime = downloadTime;
            return this;
        }

        public Builder status(Status status) {
            this.status = status;
            return this;
        }

        public Builder key(UsageReportDownloadLogRecordKey key) {
            this.opcoUid = key.getOpcoUid();
            this.serviceUid = key.getServiceUid();
            this.yearAndMonth = YearAndMonth.fromInts(key.getYear(), key.getMonth());
            this.reportType = key.getReportType();
            return this;
        }
    }

    public static final Finder<UsageReportDownloadLogRecordKey, UsageReportDownloadLogRecord> FIND = new Finder<>(
            UsageReportDownloadLogRecordKey.class, UsageReportDownloadLogRecord.class
    );

    @Id
    private UsageReportDownloadLogRecordKey reportDownloadRecordPrimaryKey;

    @Constraints.Required
    @Column(name = DOWNLOAD_TIME_COLUMN)
    private final DateTime downloadTime;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = STATUS, length = 1)
    private final Status status;

    public static Builder builder() {
        return new Builder();
    }

    private UsageReportDownloadLogRecord(Builder builder) {
        this.downloadTime = builder.downloadTime;
        this.status = builder.status;

        reportDownloadRecordPrimaryKey = UsageReportDownloadLogRecordKey.create(builder.opcoUid,
                builder.serviceUid, builder.yearAndMonth, builder.reportType);
        verify();
    }

    public static UsageReportDownloadLogRecord logDownloaded(OpcoUid opcoUid, ServiceUid serviceUid,
                                                             YearAndMonth yearAndMonth, ReportType reportType,
                                                             DateTime downloadTime) {
        return create(opcoUid, serviceUid, yearAndMonth, reportType, downloadTime, Status.D);
    }

    public static UsageReportDownloadLogRecord logFailed(OpcoUid opcoUid, ServiceUid serviceUid,
                                                         YearAndMonth yearAndMonth, ReportType reportType,
                                                         DateTime downloadTime) {
        return create(opcoUid, serviceUid, yearAndMonth, reportType, downloadTime, Status.F);
    }

    private static UsageReportDownloadLogRecord create(OpcoUid opcoUid, ServiceUid serviceUid,
                                                       YearAndMonth yearAndMonth, ReportType reportType,
                                                       DateTime downloadTime, Status status) {
        return UsageReportDownloadLogRecord.builder()
                .opcoUid(opcoUid)
                .serviceUid(serviceUid)
                .yearAndMonth(yearAndMonth)
                .reportType(reportType)
                .downloadTime(downloadTime)
                .status(status)
                .build();
    }

    private void verify() {
        Preconditions.checkNotNull(reportDownloadRecordPrimaryKey);
        Preconditions.checkNotNull(status);
        Preconditions.checkNotNull(downloadTime);
    }

    public void setReportDownloadRecordPrimaryKey(UsageReportDownloadLogRecordKey reportDownloadRecordPrimaryKey) {
        this.reportDownloadRecordPrimaryKey = reportDownloadRecordPrimaryKey;
    }

    public UsageReportDownloadLogRecordKey getReportDownloadRecordPrimaryKey() {
        return reportDownloadRecordPrimaryKey;
    }

    public OpcoUid getOpcoUid() {
        return reportDownloadRecordPrimaryKey.getOpcoUid();
    }

    public ServiceUid getServiceUid() {
        return reportDownloadRecordPrimaryKey.getServiceUid();
    }

    public Integer getYear() {
        return reportDownloadRecordPrimaryKey.getYear();
    }

    public Integer getMonth() {
        return reportDownloadRecordPrimaryKey.getMonth();
    }

    public DateTime getDownloadTime() {
        return downloadTime;
    }

    public ReportType getReportType() {
        return reportDownloadRecordPrimaryKey.getReportType();
    }

    public Status getStatus() {
        return status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        UsageReportDownloadLogRecord that = (UsageReportDownloadLogRecord) o;

        if (downloadTime != null ? !downloadTime.equals(that.downloadTime) : that.downloadTime != null) return false;
        if (reportDownloadRecordPrimaryKey != null ? !reportDownloadRecordPrimaryKey.equals(that.reportDownloadRecordPrimaryKey) : that.reportDownloadRecordPrimaryKey != null)
            return false;
        return status == that.status;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (reportDownloadRecordPrimaryKey != null ? reportDownloadRecordPrimaryKey.hashCode() : 0);
        result = 31 * result + (downloadTime != null ? downloadTime.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UsageReportDownloadLogRecord{" +
                "reportDownloadRecordPrimaryKey=" + reportDownloadRecordPrimaryKey +
                ", downloadTime=" + downloadTime +
                ", status=" + status +
                '}';
    }
}
