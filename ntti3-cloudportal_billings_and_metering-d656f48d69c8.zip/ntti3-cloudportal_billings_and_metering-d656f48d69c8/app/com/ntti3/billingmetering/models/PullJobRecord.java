package com.ntti3.billingmetering.models;

import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.Status;
import org.joda.time.DateTime;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Entity
@Immutable
@Table(name = PullJobRecord.TABLE_NAME)
public class PullJobRecord extends Model {

    public static final Finder<Integer, PullJobRecord> FIND = new Finder<>(
            Integer.class, PullJobRecord.class
    );
    public static final String TABLE_NAME = "pull_job_records";
    public static final String ID_COLUMN = "id";
    public static final String TARGET_SERVICE_COLUMN = "target_service";
    public static final String STATUS_COLUMN = "status";
    public static final String EXECUTE_AT_COLUMN = "execute_at";
    public static final String BUSY_TO = "busy_to";
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = ID_COLUMN)
    private final Integer id;
    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = STATUS_COLUMN, length = 1)
    private final Status status;
    @Constraints.Required
    @Column(name = TARGET_SERVICE_COLUMN)
    private final ServiceUid targetService;
    @Constraints.Required
    @Column(name = EXECUTE_AT_COLUMN)
    private final DateTime executeAt;
    @Column(name = BUSY_TO)
    private final DateTime busyTo;

    private PullJobRecord(Builder builder) {
        this.id = builder.id;
        this.status = builder.status;
        this.targetService = builder.targetService;
        this.executeAt = builder.executeAt;
        this.busyTo = builder.busyTo;
        verify();
    }

    public static Builder builder() {
        return new Builder();
    }

    private void verify() {
        Preconditions.checkNotNull(status);
        Preconditions.checkNotNull(targetService);
        Preconditions.checkNotNull(executeAt);
        if (status != Status.P && status != Status.D) {
            Preconditions.checkNotNull(busyTo);
        }

        if (busyTo != null) {
            Preconditions.checkArgument(executeAt.isBefore(busyTo),
                    "executeAt should be before busyTo");
        }
    }

    public PullJobRecord markBusyTo(DateTime newBusyTo) {
        Preconditions.checkNotNull(newBusyTo);
        Preconditions.checkArgument(newBusyTo.isAfter(executeAt));
        return PullJobRecord.builder()
                .fromOther(this)
                .status(Status.B)
                .busyTo(newBusyTo)
                .build();
    }

    public PullJobRecord markDone() {
        return PullJobRecord.builder()
                .fromOther(this)
                .status(Status.D)
                .busyTo(null)
                .build();
    }

    public PullJobRecord markFailed() {
        return PullJobRecord.builder()
                .fromOther(this)
                .status(Status.F)
                .build();
    }

    public PullJobRecord markPending() {
        return PullJobRecord.builder()
                .fromOther(this)
                .status(Status.P)
                .build();
    }

    public Integer getId() {
        return id;
    }

    public Status getStatus() {
        return status;
    }

    public ServiceUid getTargetService() {
        return targetService;
    }

    public DateTime getExecuteAt() {
        return executeAt;
    }

    public DateTime getBusyTo() {
        return busyTo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        PullJobRecord that = (PullJobRecord) o;

        if (busyTo != null ? !busyTo.equals(that.busyTo) : that.busyTo != null) return false;
        if (executeAt != null ? !executeAt.equals(that.executeAt) : that.executeAt != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (status != that.status) return false;
        return targetService == that.targetService;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (targetService != null ? targetService.hashCode() : 0);
        result = 31 * result + (executeAt != null ? executeAt.hashCode() : 0);
        result = 31 * result + (busyTo != null ? busyTo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PullJobRecord{" +
                "id=" + id +
                ", status=" + status +
                ", targetService=" + targetService +
                ", executeAt=" + executeAt +
                ", busyTo=" + busyTo +
                '}';
    }

    public static class Builder {

        private Integer id;
        private Status status = Status.P;
        private ServiceUid targetService;
        private DateTime executeAt;
        private DateTime busyTo;

        public PullJobRecord build() {
            return new PullJobRecord(this);
        }

        public Builder id(Integer id) {
            this.id = id;
            return this;
        }

        public Builder status(Status status) {
            this.status = status;
            return this;
        }

        public Builder targetService(ServiceUid targetService) {
            this.targetService = targetService;
            return this;
        }

        public Builder executeAt(DateTime executeAt) {
            this.executeAt = executeAt;
            return this;
        }

        public Builder busyTo(DateTime busyTo) {
            this.busyTo = busyTo;
            return this;
        }

        public Builder fromOther(PullJobRecord pullJobRecord) {
            this.id = pullJobRecord.getId();
            this.status = pullJobRecord.getStatus();
            this.targetService = pullJobRecord.getTargetService();
            this.executeAt = pullJobRecord.getExecuteAt();
            this.busyTo = pullJobRecord.getBusyTo();
            return this;
        }
    }
}
