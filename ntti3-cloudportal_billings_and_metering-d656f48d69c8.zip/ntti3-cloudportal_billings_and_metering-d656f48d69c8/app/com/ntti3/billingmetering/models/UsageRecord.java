package com.ntti3.billingmetering.models;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.base.Preconditions;
import com.ntti3.billings.types.base.CostType;
import com.ntti3.billings.types.base.Currency;
import com.ntti3.billings.types.base.InternalId;
import com.ntti3.billings.types.base.OpcoUid;
import com.ntti3.billings.types.base.OpcoUserUid;
import com.ntti3.billings.types.base.ServiceUid;
import com.ntti3.billings.types.base.UsageUid;
import play.data.validation.Constraints;
import play.db.ebean.Model;

import javax.annotation.concurrent.Immutable;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.UUID;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
@Entity
@Immutable
@Table(name = UsageRecord.TABLE_NAME)
public final class UsageRecord extends Model {

    public static class Builder {

        private UsageUid usageUid;
        private UsageUid parentUsageUid;
        private InternalId internalTransactionId;
        private OpcoUid customerOpcoUid;
        private UUID userGuid;
        private OpcoUserUid customerOpcoUserUid;
        private String description;
        private Date billDate;
        private BigDecimal cost;
        private CostType costType;
        private Currency currency;
        private ServiceUid serviceUid;
        private OpcoUid serviceOpcoUid;
        private String itemType;
        private JsonNode details;
        private UUID processUid;
        private Integer sequenceNumber;
        private Boolean lastSequence;

        public UsageRecord build() {
            return new UsageRecord(this);
        }

        public Builder fromOther(UsageRecord usageRecord) {
            this.usageUid = usageRecord.usageUid;
            this.parentUsageUid = usageRecord.parentUsageUid;
            this.internalTransactionId = usageRecord.internalTransactionId;
            this.customerOpcoUid = usageRecord.customerOpcoUid;
            this.userGuid = usageRecord.userGuid;
            this.customerOpcoUserUid = usageRecord.customerOpcoUserUid;
            this.description = usageRecord.description;
            this.billDate = usageRecord.billDate;
            this.cost = usageRecord.cost;
            this.costType = usageRecord.costType;
            this.currency = usageRecord.currency;
            this.serviceUid = usageRecord.serviceUid;
            this.serviceOpcoUid = usageRecord.serviceOpcoUid;
            this.itemType = usageRecord.itemType;
            this.details = usageRecord.details;
            this.processUid = usageRecord.processUid;
            this.sequenceNumber = usageRecord.sequenceNumber;
            this.lastSequence = usageRecord.lastSequence;
            return this;
        }

        public Builder usageUid(UsageUid usageUid) {
            this.usageUid = usageUid;
            return this;
        }

        public Builder parentUsageUid(UsageUid parentUsageUid) {
            this.parentUsageUid = parentUsageUid;
            return this;
        }

        public Builder internalTransactionId(InternalId internalTransactionId) {
            this.internalTransactionId = internalTransactionId;
            return this;
        }

        public Builder customerOpcoUid(OpcoUid customerOpcoUid) {
            this.customerOpcoUid = customerOpcoUid;
            return this;
        }

        public Builder userGuid(UUID userGuid) {
            this.userGuid = userGuid;
            return this;
        }

        public Builder customerOpcoUserUid(OpcoUserUid customerOpcoUserUid) {
            this.customerOpcoUserUid = customerOpcoUserUid;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder billDate(Date billDate) {
            this.billDate = billDate;
            return this;
        }

        public Builder cost(BigDecimal cost) {
            this.cost = cost;
            return this;
        }

        public Builder cost(String cost) {
            this.cost = new BigDecimal(cost);
            return this;
        }

        public Builder costType(CostType costType) {
            this.costType = costType;
            return this;
        }

        public Builder currency(Currency currency) {
            this.currency = currency;
            return this;
        }

        public Builder serviceUid(ServiceUid serviceUid) {
            this.serviceUid = serviceUid;
            return this;
        }

        public Builder serviceOpcoUid(OpcoUid serviceOpcoUid) {
            this.serviceOpcoUid = serviceOpcoUid;
            return this;
        }

        public Builder itemType(String itemType) {
            this.itemType = itemType;
            return this;
        }

        public Builder details(JsonNode details) {
            this.details = details;
            return this;
        }

        public Builder processUid(UUID processUid) {
            this.processUid = processUid;
            return this;
        }

        public Builder sequenceNumber(Integer sequenceNumber) {
            this.sequenceNumber = sequenceNumber;
            return this;
        }

        public Builder lastSequence(Boolean lastSequence) {
            this.lastSequence = lastSequence;
            return this;
        }
    }

    public static final String TABLE_NAME = "usage_records";
    public static final String USAGE_UID_COLUMN = "usage_uid";
    public static final String PARENT_USAGE_UID_COLUMN = "parent_usage_uid";
    public static final String INTERNAL_TRANSACTION_ID = "internal_transaction_id";
    public static final String CUSTOMER_OPCO_UID_COLUMN = "customer_opco_uid";
    public static final String USER_GUID_COLUMN = "user_guid";
    public static final String CUSTOMER_OPCO_USER_UID_COLUMN = "customer_opco_user_uid";
    public static final String DESCRIPTION_COLUMN = "description";
    public static final String BILL_DATE_COLUMN = "bill_date";
    public static final String COST_COLUMN = "cost";
    public static final String COST_TYPE_COLUMN = "cost_type";
    public static final String CURRENCY_COLUMN = "currency";
    public static final String SERVICE_UID_COLUMN = "service_uid";
    public static final String SERVICE_OPCO_UID_COLUMN = "service_opco_uid";
    public static final String ITEM_TYPE_COLUMN = "item_type";
    public static final String DETAILS_COLUMN = "details";
    public static final String PROCESS_COLUMN = "process";
    public static final String SEQUENCE_NUMBER_COLUMN = "sequence_number";
    public static final String LAST_SEQUENCE = "last_sequence";
    private static final int COST_COLUMN_SCALE = 5;


    public static final Finder<UsageUid, UsageRecord> FIND = new Finder<>(
            UsageUid.class, UsageRecord.class
    );

    @Id
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = USAGE_UID_COLUMN))
    })
    private final UsageUid usageUid;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = PARENT_USAGE_UID_COLUMN))
    })
    private final UsageUid parentUsageUid;

    @Constraints.Required
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = INTERNAL_TRANSACTION_ID))
    })
    private final InternalId internalTransactionId;


    @Constraints.Required
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = CUSTOMER_OPCO_UID_COLUMN))
    })
    private final OpcoUid customerOpcoUid;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = USER_GUID_COLUMN))
    })
    @Constraints.Required
    private final UUID userGuid;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = CUSTOMER_OPCO_USER_UID_COLUMN))
    })
    @Constraints.Required
    private final OpcoUserUid customerOpcoUserUid;

    @Constraints.Required
    @Column(name = DESCRIPTION_COLUMN, columnDefinition = "TEXT")
    private final String description;

    @Constraints.Required
    @Column(name = BILL_DATE_COLUMN)
    private final Date billDate;

    @Constraints.Required
    @Column(name = COST_COLUMN, precision = 11, scale = COST_COLUMN_SCALE)
    private final BigDecimal cost;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = COST_TYPE_COLUMN, length = 16)
    private final CostType costType;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = CURRENCY_COLUMN, length = 3)
    private final Currency currency;

    @Constraints.Required
    @Enumerated(EnumType.STRING)
    @Column(name = SERVICE_UID_COLUMN, length = 16)
    private final ServiceUid serviceUid;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = SERVICE_OPCO_UID_COLUMN))
    })
    @Column(name = SERVICE_OPCO_UID_COLUMN)
    private final OpcoUid serviceOpcoUid;

    @Constraints.Required
    @Column(name = ITEM_TYPE_COLUMN, length = 255)
    private final String itemType;

    @Column(name = DETAILS_COLUMN, columnDefinition = "TEXT")
    private final JsonNode details;

    @Column(name = PROCESS_COLUMN)
    private final UUID processUid;

    @Column(name = SEQUENCE_NUMBER_COLUMN)
    private final Integer sequenceNumber;

    @Column(name = LAST_SEQUENCE)
    private final Boolean lastSequence;

    public static Builder builder() {
        return new Builder();
    }

    private UsageRecord(Builder builder) {
        this.usageUid = builder.usageUid;
        this.parentUsageUid = builder.parentUsageUid;
        this.internalTransactionId = builder.internalTransactionId;
        this.customerOpcoUid = builder.customerOpcoUid;
        this.userGuid = builder.userGuid;
        this.customerOpcoUserUid = builder.customerOpcoUserUid;
        this.description = builder.description;
        this.billDate = builder.billDate;
        this.cost = builder.cost == null ? null : builder.cost.setScale(COST_COLUMN_SCALE, RoundingMode.UNNECESSARY);
        this.costType = builder.costType;
        this.currency = builder.currency;
        this.serviceUid = builder.serviceUid;
        this.serviceOpcoUid = builder.serviceOpcoUid;
        this.itemType = builder.itemType;
        this.details = builder.details;
        this.processUid = builder.processUid;
        this.sequenceNumber = builder.sequenceNumber;
        this.lastSequence = builder.lastSequence;
        verify();
    }

    private void verify() {
        Preconditions.checkNotNull(usageUid, "UsageUid is required");
        Preconditions.checkNotNull(internalTransactionId, "InternalTransactionId is required");
        Preconditions.checkNotNull(customerOpcoUid, "CustomerOpcoUid is required");
        Preconditions.checkNotNull(userGuid, "UserGuid is required");
        Preconditions.checkNotNull(customerOpcoUserUid, "CustomerOpcoUserUid is required");
        Preconditions.checkNotNull(description, "Description is required");
        Preconditions.checkNotNull(billDate, "BillDate is required");
        Preconditions.checkNotNull(cost, "Cost is required");
        Preconditions.checkArgument(cost.scale() == COST_COLUMN_SCALE);
        Preconditions.checkNotNull(costType, "CostType is required");
        Preconditions.checkNotNull(currency, "Currency is required");
        Preconditions.checkNotNull(serviceUid, "ServiceUid is required");
        Preconditions.checkNotNull(serviceOpcoUid, "ServiceOpcoUid is required");
        Preconditions.checkNotNull(itemType, "ItemType is required");
    }

    public UsageUid getUsageUid() {
        return usageUid;
    }

    public UsageUid getParentUsageUid() {
        return parentUsageUid;
    }

    public boolean isSetParentUsageUid() {
        return parentUsageUid != null;
    }

    public InternalId getInternalTransactionId() {
        return internalTransactionId;
    }

    public OpcoUid getCustomerOpcoUid() {
        return customerOpcoUid;
    }

    public UUID getUserGuid() {
        return userGuid;
    }

    public OpcoUserUid getCustomerOpcoUserUid() {
        return customerOpcoUserUid;
    }

    public String getDescription() {
        return description;
    }

    public Date getBillDate() {
        return new Date(billDate.getTime());
    }

    public BigDecimal getCost() {
        return cost;
    }

    public CostType getCostType() {
        return costType;
    }

    public Currency getCurrency() {
        return currency;
    }

    public ServiceUid getServiceUid() {
        return serviceUid;
    }

    public OpcoUid getServiceOpcoUid() {
        return serviceOpcoUid;
    }

    public String getItemType() {
        return itemType;
    }

    public JsonNode getDetails() {
        if (details == null) {
            return null;
        } else {
            return details.deepCopy();
        }
    }

    // Fields for Pull Jobs
    public UUID getProcessUid() {
        return processUid;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public boolean isLastSequence() {
        return lastSequence;
    }
    // End of fields for Pull Jobs


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        UsageRecord that = (UsageRecord) o;

        if (billDate != null ? !billDate.equals(that.billDate) : that.billDate != null) return false;
        if (cost != null ? !cost.equals(that.cost) : that.cost != null) return false;
        if (costType != that.costType) return false;
        if (currency != that.currency) return false;
        if (customerOpcoUid != null ? !customerOpcoUid.equals(that.customerOpcoUid) : that.customerOpcoUid != null)
            return false;
        if (customerOpcoUserUid != null ? !customerOpcoUserUid.equals(that.customerOpcoUserUid) : that.customerOpcoUserUid != null)
            return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (details != null ? !details.equals(that.details) : that.details != null) return false;
        if (internalTransactionId != null ? !internalTransactionId.equals(that.internalTransactionId) : that.internalTransactionId != null)
            return false;
        if (itemType != null ? !itemType.equals(that.itemType) : that.itemType != null) return false;
        if (lastSequence != null ? !lastSequence.equals(that.lastSequence) : that.lastSequence != null) return false;
        if (parentUsageUid != null ? !parentUsageUid.equals(that.parentUsageUid) : that.parentUsageUid != null)
            return false;
        if (processUid != null ? !processUid.equals(that.processUid) : that.processUid != null) return false;
        if (sequenceNumber != null ? !sequenceNumber.equals(that.sequenceNumber) : that.sequenceNumber != null)
            return false;
        if (serviceOpcoUid != null ? !serviceOpcoUid.equals(that.serviceOpcoUid) : that.serviceOpcoUid != null)
            return false;
        if (serviceUid != that.serviceUid) return false;
        if (usageUid != null ? !usageUid.equals(that.usageUid) : that.usageUid != null) return false;
        return !(userGuid != null ? !userGuid.equals(that.userGuid) : that.userGuid != null);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (usageUid != null ? usageUid.hashCode() : 0);
        result = 31 * result + (parentUsageUid != null ? parentUsageUid.hashCode() : 0);
        result = 31 * result + (internalTransactionId != null ? internalTransactionId.hashCode() : 0);
        result = 31 * result + (customerOpcoUid != null ? customerOpcoUid.hashCode() : 0);
        result = 31 * result + (userGuid != null ? userGuid.hashCode() : 0);
        result = 31 * result + (customerOpcoUserUid != null ? customerOpcoUserUid.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (billDate != null ? billDate.hashCode() : 0);
        result = 31 * result + (cost != null ? cost.hashCode() : 0);
        result = 31 * result + (costType != null ? costType.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (serviceUid != null ? serviceUid.hashCode() : 0);
        result = 31 * result + (serviceOpcoUid != null ? serviceOpcoUid.hashCode() : 0);
        result = 31 * result + (itemType != null ? itemType.hashCode() : 0);
        result = 31 * result + (details != null ? details.hashCode() : 0);
        result = 31 * result + (processUid != null ? processUid.hashCode() : 0);
        result = 31 * result + (sequenceNumber != null ? sequenceNumber.hashCode() : 0);
        result = 31 * result + (lastSequence != null ? lastSequence.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UsageRecord{" +
                "usageUid=" + usageUid +
                ", parentUsageUid=" + parentUsageUid +
                ", internalTransactionId=" + internalTransactionId +
                ", customerOpcoUid=" + customerOpcoUid +
                ", userGuid=" + userGuid +
                ", customerOpcoUserUid=" + customerOpcoUserUid +
                ", description='" + description + '\'' +
                ", billDate=" + billDate +
                ", cost=" + cost +
                ", costType=" + costType +
                ", currency=" + currency +
                ", serviceUid=" + serviceUid +
                ", serviceOpcoUid=" + serviceOpcoUid +
                ", itemType='" + itemType + '\'' +
                ", details='" + details + '\'' +
                ", processUid=" + processUid +
                ", sequenceNumber=" + sequenceNumber +
                ", lastSequence=" + lastSequence +
                '}';
    }
}
