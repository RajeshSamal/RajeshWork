import com.google.common.base.Function;
import com.google.common.collect.Maps;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.ntti3.billingmetering.lib.api.guice.DefaultUsageReportsApiMethodsModule;
import com.ntti3.billingmetering.lib.exceptions.handlers.BillingAndMeteringExceptionsHandlerModule;
import com.ntti3.billingmetering.lib.pulling.PullJobsActorsConfigurator;
import com.ntti3.billingmetering.lib.pulling.guice.DefaultInfrastructureMapperModule;
import com.ntti3.billingmetering.lib.pulling.guice.DefaultPullJobManagerModule;
import com.ntti3.billingmetering.lib.pulling.guice.DefaultPullJobsConfigManagerModule;
import com.ntti3.billingmetering.lib.pulling.guice.DefaultServiceConnectorModule;
import com.ntti3.billingmetering.lib.pulling.guice.SocketFactoryCreatorModule;
import com.ntti3.billingmetering.lib.pulling.util.scheduling.guice.SchedulingStrategyModule;
import com.ntti3.billingmetering.lib.reports.UsageReportsActorsConfigurator;
import com.ntti3.billingmetering.lib.reports.guice.DefaultUsageReportDownloadStatusesJsonGeneratorModule;
import com.ntti3.billingmetering.lib.reports.guice.DefaultUsageReportDownloadStatusesManagerModule;
import com.ntti3.billingmetering.lib.reports.guice.DefaultUsageReportsManagerModule;
import com.ntti3.billingmetering.lib.utils.ConfigurationHelper;
import com.ntti3.billingmetering.lib.utils.guice.DefaultUtilsModule;
import com.ntti3.billings.settings.reports.guice.DefaultUsageReportsSettingsManagerModule;
import com.ntti3.gums.guice.DefaultCachingGumsConnectorModule;
import com.ntti3.gums.guice.DefaultGumsConnectorFromConfigModule;
import com.ntti3.play.annotations.SetSessionIdAction;
import com.ntti3.play.build.guice.BuildInfoReaderModule;
import com.ntti3.protocol.ErrorCode;
import com.ntti3.protocol.ResponseHelper;
import play.Application;
import play.Configuration;
import play.GlobalSettings;
import play.Play;
import play.libs.F;
import play.mvc.Action;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.SimpleResult;

import java.lang.reflect.Method;

/**
 * @author Wojciech Jurczyk (wojciech.jurczyk@codilime.com)
 */
public class Global extends GlobalSettings {

    private static final String MAPPINGS = "mappings";
    private static final String PULL_JOB_SERVICES = "pull-job-services";
    private static final String GUMS_CONFIG_PREFIX = "gums";
    private static final String SERVICE_CONNECTOR_CONFIG_PREFIX = "service-connector";
    private static final String PULL_JOBS_ON = "pull-jobs-on";
    private static final String BILLINGMETERING = "billingmetering";
    private PullJobsActorsConfigurator pullJobsActorsConfigurator;
    private UsageReportsActorsConfigurator usageReportsActorsConfigurator;
    private Injector injector;

    @Override
    public void onStart(Application app) {
        Configuration appConfig = Play.application().configuration();

        DefaultGumsConnectorFromConfigModule defaultGumsConnectorFromConfigModule;
        try {
            defaultGumsConnectorFromConfigModule = new DefaultGumsConnectorFromConfigModule(
                    Maps.transformValues(Configuration.root().getConfig(GUMS_CONFIG_PREFIX).asMap(),
                            new Function<Object, String>() {
                                @Override
                                public String apply(Object input) {
                                    return input.toString();
                                }
                            }));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        final Configuration pullJobConfiguration = ConfigurationHelper
                .safeGetConfiguration(appConfig, "pull-jobs");
        pullJobsActorsConfigurator = new PullJobsActorsConfigurator(pullJobConfiguration);


        final Configuration reportsConfiguration = ConfigurationHelper
                .safeGetConfiguration(appConfig, "reports");
        usageReportsActorsConfigurator = new UsageReportsActorsConfigurator(reportsConfiguration);

        super.onStart(app);
        injector = Guice.createInjector(
                new DefaultUsageReportsManagerModule(usageReportsActorsConfigurator
                        .getGeneratingActorSelection()),
                new DefaultUsageReportDownloadStatusesJsonGeneratorModule(usageReportsActorsConfigurator
                        .getDownloadStatusesActorSelection()),
                defaultGumsConnectorFromConfigModule,
                new DefaultUtilsModule(),
                new DefaultCachingGumsConnectorModule(),
                new BillingAndMeteringExceptionsHandlerModule(),
                new DefaultUsageReportsApiMethodsModule(),
                new DefaultServiceConnectorModule(Configuration.root()
                        .getConfig(SERVICE_CONNECTOR_CONFIG_PREFIX)),
                new DefaultPullJobManagerModule(ConfigurationHelper
                        .safeGetConfiguration(appConfig, "pull-job-manager")),
                getDefaultSchedulingStrategyModule(pullJobConfiguration),
                new DefaultPullJobsConfigManagerModule(ConfigurationHelper
                        .safeGetConfiguration(appConfig, PULL_JOB_SERVICES)),
                new DefaultInfrastructureMapperModule(ConfigurationHelper
                        .safeGetConfiguration(appConfig, MAPPINGS)),
                new DefaultUsageReportDownloadStatusesManagerModule(),
                new DefaultUsageReportsSettingsManagerModule(),
                pullJobsActorsConfigurator.getGuiceModule(),
                new BuildInfoReaderModule(BILLINGMETERING),
                new SocketFactoryCreatorModule(Configuration.root()
                        .getConfig(SERVICE_CONNECTOR_CONFIG_PREFIX), ConfigurationHelper
                        .safeGetConfiguration(appConfig, PULL_JOB_SERVICES))
        );

        createPullingWorkers();
        createSummaryGeneratingActors();
    }

    private SchedulingStrategyModule getDefaultSchedulingStrategyModule(Configuration configuration) {
        Configuration schedulingConfiguration = ConfigurationHelper.safeGetConfiguration(configuration, "scheduling");
        return new SchedulingStrategyModule(schedulingConfiguration);
    }

    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return injector.getInstance(controllerClass);
    }

    private void createPullingWorkers() {
        Boolean pullJobsOn = Play.application().configuration().getBoolean(PULL_JOBS_ON);
        if (pullJobsOn) {
            pullJobsActorsConfigurator.createSupervisorWithWorkers(injector);
        }
    }

    private void createSummaryGeneratingActors() {
        usageReportsActorsConfigurator.createGeneratingActors(injector);
    }

    @Override
    public F.Promise<SimpleResult> onBadRequest(Http.RequestHeader request, String error) {
        return handleBadRequest(request);
    }

    @Override
    public F.Promise<SimpleResult> onError(Http.RequestHeader request, Throwable t) {
        return F.Promise.<SimpleResult>pure(Controller.internalServerError("Internal server error, sorry!"));
    }

    @Override
    public F.Promise<SimpleResult> onHandlerNotFound(Http.RequestHeader request) {
        return handleBadRequest(request);
    }

    private F.Promise<SimpleResult> handleBadRequest(Http.RequestHeader request) {
        return F.Promise.<SimpleResult>pure(Controller.badRequest(ResponseHelper.errorResponse(ErrorCode
                .INCORRECT_CALL, "Bad request path",
                "Request path: " + request.path() + " is incorrect")));
    }

    @Override
    public Action<Void> onRequest(Http.Request request, Method actionMethod) {
        return new SetSessionIdAction(SetSessionIdAction.DEFAULT_SESSION_ID_KEY);
    }
}
